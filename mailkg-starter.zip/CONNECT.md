# LiteLLM 게이트웨이 연결

## 1. 설정 (최초 1회)

```bash
python run.py config --url http://<게이트웨이IP>:4000 --model <LiteLLM에 등록한 모델명>
export MAILKG_API_KEY=sk-...            # Windows: set MAILKG_API_KEY=sk-...
```

`--model` 값은 **LiteLLM `config.yaml` 의 `model_name`** 을 그대로 씁니다
(백엔드 실제 모델명이 아니라 프록시에 등록한 별칭). 모르면 `doctor` 가 목록을 보여줍니다.

API 키는 **설정 파일에 저장되지 않습니다.** 환경변수에서만 읽고, 콘솔 출력에서도 가려집니다.

HTTPS 사설 인증서를 쓴다면:

```bash
python run.py config --ca /path/to/corp-ca.pem
# 최후의 수단(검증 끄기, 권장하지 않음): python run.py config --no-verify-ssl
```

## 2. 연결 점검

```bash
python run.py doctor
```

실패한 지점의 원인과 조치를 함께 출력합니다.

| 단계 | 실패 시 원인 |
|---|---|
| 네트워크 도달 | LiteLLM 미기동 / `--host 0.0.0.0` 누락 / 방화벽 4000 차단 |
| 인증 | API 키 오류 |
| 모델 목록 | 모델 별칭 오타 (`config.yaml` 의 `model_name` 확인) |
| 한국어 응답 | 모델 로딩 실패, `max_tokens` 과소 |
| 기능 감지 | 실패가 아니라 **동작 모드 결정** — 아래 참조 |
| 추출 시연 | 프롬프트/모델 크기 문제 |

## 3. 게이트웨이 기능에 따른 자동 대응

폐쇄망 배포는 백엔드와 구동 옵션에 따라 지원 범위가 다릅니다.
코드가 감지해서 **자동으로 한 단계씩 내려갑니다.** 따로 설정할 것은 없습니다.

| 기능 | 지원 시 | 미지원 시 |
|---|---|---|
| `response_format: json_schema` | 스키마 강제 (최선) | ↓ 로 하강 |
| `response_format: json_object` | JSON 강제 | ↓ 로 하강 |
| (없음) | — | 프롬프트 지시 + 중괄호 균형 파싱 |
| `tools` / `tool_calls` | 네이티브 tool calling | JSON 지시 루프 |

감지 결과는 프로세스 내에서 한 번만 계산해 캐시합니다.
지원 범위를 넓히려면 vLLM 백엔드 기동 옵션을 확인하세요.

```bash
# 구조화 출력 안정화
--guided-decoding-backend outlines
# 네이티브 tool calling 활성화 (Qwen3 계열)
--enable-auto-tool-choice --tool-call-parser hermes
```

## 4. Qwen3 사고(thinking) 모드

Qwen3 하이브리드 모델은 `<think>...</think>` 를 본문에 섞어 보냅니다.
게이트웨이가 걸러주지 않는 경우가 많아 두 가지를 함께 겁니다.

- 요청에 `chat_template_kwargs: {"enable_thinking": false}` 를 실어 보냄
  (미지원 게이트웨이는 이 필드를 무시하므로 안전)
- 응답에서 `<think>` 블록 제거 — 닫히지 않고 잘린 경우까지 처리

추출 작업에서 사고 모드는 속도만 크게 늘리고 정확도 이득이 적습니다.
켜려면 `python run.py config --thinking`.

## 5. 처리량

```bash
python run.py extract                 # 순차
python run.py extract --workers 4     # 병렬
python run.py extract --limit 20      # 20통만 (프롬프트 튜닝 중에)
```

`doctor` 가 1통 처리 시간으로 전체 예상 시간을 계산해 줍니다.
동시 요청은 LiteLLM `rpm`/`tpm` 제한과 백엔드 배치 크기에 걸리므로
`--workers 2` 부터 올려가며 실패율을 보세요.
실패한 메일은 `extracted=0` 으로 남아 **재실행하면 이어서** 처리됩니다.

## 6. 모의 게이트웨이로 미리 검증

실제 서버 없이 폴백 경로가 동작하는지 확인할 수 있습니다.

```bash
python mock_gateway.py --port 4000 --mode full    # 전부 지원
python mock_gateway.py --port 4002 --mode bare    # JSON·tools 모두 미지원
python mock_gateway.py --port 4003 --mode noauth  # 키 검증

MAILKG_BASE_URL=http://127.0.0.1:4002 MAILKG_API_KEY=sk-test-1234 python run.py doctor
```

## 7. 자주 걸리는 것

- **모델 별칭** — 백엔드 모델명(`Qwen/Qwen3-32B`)이 아니라 LiteLLM에 등록한
  `model_name`을 써야 합니다. 404가 나면 거의 이 문제입니다.
- **`--host 0.0.0.0`** — 다른 PC에서 붙는데 LiteLLM이 `127.0.0.1`에만 바인딩된 경우.
- **타임아웃** — 32B 모델 + 긴 본문이면 기본 300초도 빠듯할 수 있습니다.
  `python run.py config --timeout 600`.
- **빈 응답** — `max_tokens`가 작아 `<think>` 블록만 채우고 끝난 경우.
  사고 모드를 끄거나 `max_tokens`를 올리세요.
