#!/usr/bin/env python3
"""
mailkg MCP 서버 — goose 등 MCP 클라이언트에 메일 지식그래프를 도구로 노출한다.

설계 원칙
 - 외부 의존성 0. MCP stdio 전송은 줄 단위 JSON-RPC 2.0 이라 표준 라이브러리로 충분하다.
   (폐쇄망에 fastmcp/SDK 를 추가 반입하지 않기 위함)
 - 모든 도구는 읽기 전용. 그래프를 바꾸는 도구는 노출하지 않는다.
 - 로그는 반드시 stderr 로. stdout 은 프로토콜 전용이라 한 줄이라도 섞이면 연결이 깨진다.

실행
    MAILKG_DB=/path/mail.db python mcp_server.py
    python mcp_server.py --db /path/mail.db
"""

from __future__ import annotations

import json
import os
import sqlite3
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from mailkg import query as q  # noqa: E402
from mailkg.parse import connect  # noqa: E402

SERVER_NAME = "mailkg"
SERVER_VERSION = "1.0.0"

# 클라이언트가 요청한 버전을 그대로 수락한다. goose 버전에 따라 달라지므로
# 목록에 있으면 echo, 없으면 우리 기본값을 제안한다.
KNOWN_PROTOCOLS = {
    "2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25", "2026-03-26",
}
DEFAULT_PROTOCOL = "2025-06-18"

DB_PATH = os.environ.get("MAILKG_DB", "mail.db")
_db: sqlite3.Connection | None = None


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def db() -> sqlite3.Connection:
    global _db
    if _db is None:
        p = Path(DB_PATH)
        if not p.exists():
            raise FileNotFoundError(
                f"그래프 DB가 없습니다: {p.resolve()}. "
                f"먼저 `python run.py ingest <폴더> && python run.py extract && "
                f"python run.py build` 을 실행하거나 MAILKG_DB 를 올바른 경로로 지정하세요.")
        _db = connect(str(p))
        _db.row_factory = None
    return _db


# --------------------------------------------------------------------- 도구 정의
def _obj(props: dict, required: list[str] | None = None) -> dict:
    return {"type": "object", "properties": props,
            "required": required or [], "additionalProperties": False}


RO = {"readOnlyHint": True, "destructiveHint": False,
      "idempotentHint": True, "openWorldHint": False}

TOOLS: list[dict] = [
    {
        "name": "mail_graph_overview",
        "title": "메일 그래프 개요",
        "description": (
            "지식그래프 전체 규모와 주요 사안 목록을 한 번에 본다. "
            "무엇을 물어야 할지 모를 때 가장 먼저 호출한다. "
            "메일/인물/사안/의사결정/액션아이템 건수와 기간, 상위 사안 id 를 반환한다."),
        "inputSchema": _obj({}),
        "annotations": RO,
    },
    {
        "name": "mail_find_person",
        "title": "인물 찾기",
        "description": (
            "이름이나 메일주소 일부로 인물을 검색해 정확한 메일주소(addr)를 얻는다. "
            "특정 인물에 대한 다른 도구(mail_person_network, mail_open_action_items)를 "
            "쓰기 전에 반드시 이 도구로 addr 을 먼저 확정한다. "
            "동명이인이 있으면 메일 참여 건수가 많은 순으로 최대 10명을 반환한다."),
        "inputSchema": _obj(
            {"name": {"type": "string",
                      "description": "검색어. 부분 일치. 예: '이영희', 'yh.lee', 'vendor.co.kr'"}},
            ["name"]),
        "annotations": RO,
    },
    {
        "name": "mail_person_network",
        "title": "인물 관계망",
        "description": (
            "한 인물의 협업 관계망(자주 함께 일한 사람)과 관여 사안을 반환한다. "
            "'누구랑 일하나', '어떤 일에 관여했나' 류 질문에 쓴다. "
            "addr 은 mail_find_person 으로 먼저 확정한다."),
        "inputSchema": _obj(
            {"addr": {"type": "string",
                      "description": "정확한 메일주소. mail_find_person 결과의 addr 값"},
             "top": {"type": "integer", "description": "각 목록 최대 개수 (기본 10)",
                     "minimum": 1, "maximum": 50}},
            ["addr"]),
        "annotations": RO,
    },
    {
        "name": "mail_list_cases",
        "title": "사안 목록",
        "description": (
            "사안(프로젝트·과제·안건) 목록을 메일 수가 많은 순으로 반환한다. "
            "각 항목의 id 는 mail_case_timeline 에 그대로 넘긴다. "
            "'다른표기'는 같은 사안의 표기 흔들림을 통합한 결과라, 사용자가 쓴 약칭이 "
            "여기 있는지 확인하면 어떤 사안을 말하는지 알 수 있다."),
        "inputSchema": _obj(
            {"top": {"type": "integer", "description": "최대 개수 (기본 20)",
                     "minimum": 1, "maximum": 100}}),
        "annotations": RO,
    },
    {
        "name": "mail_case_timeline",
        "title": "사안 이력",
        "description": (
            "사안 하나의 전체 이력을 시간순으로 반환한다 — 관련 메일, 의사결정(승인/반려/"
            "확정/변경/보류), 액션아이템(담당·기한), 일정. "
            "'이 사업 어떻게 흘러왔나', '언제 뭐가 결정됐나' 류 질문의 핵심 도구다. "
            "case_id 는 mail_list_cases 로 먼저 확인한다."),
        "inputSchema": _obj(
            {"case_id": {"type": "string",
                         "description": "사안 id. 예: 'case::차세대관제'. "
                                        "mail_list_cases 결과의 id 값"}},
            ["case_id"]),
        "annotations": RO,
    },
    {
        "name": "mail_open_action_items",
        "title": "미완료 업무",
        "description": (
            "메일에서 요청·지시된 액션아이템을 기한 순으로 반환한다. "
            "담당자나 기한으로 좁힐 수 있다. "
            "'내가 할 일', '기한 지난 것', '누구한테 뭘 요청했나' 류 질문에 쓴다."),
        "inputSchema": _obj(
            {"addr": {"type": "string",
                      "description": "담당자 메일주소로 필터. 생략하면 전체. "
                                     "mail_find_person 으로 확정한 addr 을 넣는다"},
             "before": {"type": "string",
                        "description": "이 날짜 이전 기한만. YYYY-MM-DD. "
                                       "기한 초과 업무를 찾을 때 오늘 날짜를 넣는다"}}),
        "annotations": RO,
    },
    {
        "name": "mail_decisions_about",
        "title": "의사결정 조회",
        "description": (
            "의사결정을 키워드·기간으로 조회한다. 최신순. "
            "각 결정에는 구분(승인/반려/확정/변경/보류), 결정자, 시점, 소속 사안, "
            "그리고 근거가 된 본문 원문과 출처 메일 id 가 함께 온다. "
            "답변할 때 이 근거를 반드시 인용한다."),
        "inputSchema": _obj(
            {"keyword": {"type": "string",
                         "description": "결정 내용에 포함된 단어. 생략하면 전체"},
             "since": {"type": "string",
                       "description": "이 날짜 이후만. YYYY-MM-DD"}}),
        "annotations": RO,
    },
    {
        "name": "mail_search_messages",
        "title": "메일 전문검색",
        "description": (
            "메일 제목·본문 전문검색(FTS5). 그래프에 구조화되지 않은 내용을 찾을 때 쓴다. "
            "그래프 도구(mail_case_timeline, mail_decisions_about)로 못 찾았을 때의 "
            "차선책이지 첫 수단이 아니다. 여러 단어는 공백으로 구분하면 AND 검색."),
        "inputSchema": _obj(
            {"q": {"type": "string", "description": "검색어. 예: '인증 방식'"},
             "limit": {"type": "integer", "description": "최대 개수 (기본 10)",
                       "minimum": 1, "maximum": 50}},
            ["q"]),
        "annotations": RO,
    },
    {
        "name": "mail_read_message",
        "title": "메일 원문",
        "description": (
            "메일 한 통의 원문(제목·일자·발신·수신·본문)을 읽는다. "
            "다른 도구가 돌려준 출처 메일 id 로 근거를 직접 확인할 때 쓴다. "
            "사용자에게 사실을 단정해 말하기 전에 이 도구로 원문을 확인하면 오답이 크게 준다."),
        "inputSchema": _obj(
            {"message_id": {"type": "string",
                            "description": "메일 id. 다른 도구 결과의 id / 출처메일 값"}},
            ["message_id"]),
        "annotations": RO,
    },
]

TOOL_BY_NAME = {t["name"]: t for t in TOOLS}


# --------------------------------------------------------------------- 도구 실행
def graph_overview() -> dict:
    d = db()
    counts = {cls: n for cls, n in d.execute(
        "SELECT class, COUNT(*) FROM node WHERE class NOT LIKE '\\_%' ESCAPE '\\' "
        "GROUP BY class")}
    rng = d.execute("SELECT MIN(sent_at), MAX(sent_at) FROM message "
                    "WHERE sent_at != ''").fetchone()
    return {
        "규모": {"메일": counts.get("Message", 0), "인물": counts.get("Person", 0),
               "사안": counts.get("Case", 0), "의사결정": counts.get("Decision", 0),
               "액션아이템": counts.get("ActionItem", 0), "일정": counts.get("Event", 0),
               "스레드": counts.get("Thread", 0), "첨부": counts.get("Attachment", 0)},
        "기간": f"{(rng[0] or '')[:10]} ~ {(rng[1] or '')[:10]}",
        "주요 사안": q.list_cases(d, 10),
        "안내": "사안 상세는 mail_case_timeline(case_id), 인물은 mail_find_person 부터.",
    }


HANDLERS = {
    "mail_graph_overview": lambda a: graph_overview(),
    "mail_find_person": lambda a: q.find_person(db(), a["name"]),
    "mail_person_network": lambda a: q.person_network(db(), a["addr"], a.get("top", 10)),
    "mail_list_cases": lambda a: q.list_cases(db(), a.get("top", 20)),
    "mail_case_timeline": lambda a: q.case_timeline(db(), a["case_id"]),
    "mail_open_action_items": lambda a: q.open_action_items(
        db(), a.get("addr", ""), a.get("before", "")),
    "mail_decisions_about": lambda a: q.decisions_about(
        db(), a.get("keyword", ""), a.get("since", "")),
    "mail_search_messages": lambda a: q.search_messages(
        db(), a["q"], a.get("limit", 10)),
    "mail_read_message": lambda a: q.read_message(db(), a["message_id"]),
}


def run_tool(name: str, args: dict) -> dict:
    """도구 실행. 실패해도 예외를 던지지 않고 isError 결과로 돌려준다
    (MCP 규약: 도구 오류는 프로토콜 오류가 아니라 결과로 전달해야 모델이 복구할 수 있다)."""
    if name not in HANDLERS:
        return _err(f"없는 도구: {name}. 사용 가능: {', '.join(TOOL_BY_NAME)}")

    schema = TOOL_BY_NAME[name]["inputSchema"]
    missing = [k for k in schema.get("required", []) if not args.get(k)]
    if missing:
        hint = {"addr": "mail_find_person 으로 먼저 addr 을 확정하세요.",
                "case_id": "mail_list_cases 로 먼저 사안 id 를 확인하세요.",
                "message_id": "다른 도구 결과의 '출처메일' 또는 'id' 값을 넣으세요."}
        return _err(f"필수 인자 누락: {', '.join(missing)}. "
                    + " ".join(hint.get(m, "") for m in missing).strip())

    try:
        result = HANDLERS[name](args)
    except FileNotFoundError as e:
        return _err(str(e))
    except sqlite3.OperationalError as e:
        return _err(f"DB 조회 실패: {e}. 그래프가 아직 구축되지 않았을 수 있습니다 "
                    f"(`python run.py build`).")
    except KeyError as e:
        return _err(f"인자 {e} 가 필요합니다.")
    except Exception as e:
        log("tool error:", traceback.format_exc())
        return _err(f"{type(e).__name__}: {e}")

    if isinstance(result, list) and not result:
        return _ok(result, note="결과 없음. 검색어를 넓히거나 "
                                "mail_search_messages 로 원문을 검색해 보세요.")
    return _ok(result)


def _ok(payload, note: str = "") -> dict:
    text = json.dumps(payload, ensure_ascii=False, indent=1)
    if note:
        text = f"{text}\n\n[안내] {note}"
    return {"content": [{"type": "text", "text": text}],
            "structuredContent": payload if isinstance(payload, dict) else {"items": payload},
            "isError": False}


def _err(msg: str) -> dict:
    return {"content": [{"type": "text", "text": f"오류: {msg}"}], "isError": True}


# --------------------------------------------------------------------- JSON-RPC
def handle(req: dict) -> dict | None:
    method = req.get("method")
    rid = req.get("id")
    params = req.get("params") or {}

    if method == "initialize":
        want = params.get("protocolVersion", DEFAULT_PROTOCOL)
        ver = want if want in KNOWN_PROTOCOLS else DEFAULT_PROTOCOL
        log(f"initialize: client={params.get('clientInfo', {}).get('name', '?')} "
            f"protocol={want} → {ver}")
        return _res(rid, {
            "protocolVersion": ver,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            "instructions": (
                "사내 메일 지식그래프. 답은 반드시 이 도구들의 조회 결과에만 근거하고, "
                "결과에 없는 내용은 추측하지 않는다. 방향을 모르면 mail_graph_overview "
                "부터 호출한다. 인물은 mail_find_person 으로 주소를, 사안은 "
                "mail_list_cases 로 id 를 먼저 확정한 뒤 상세 도구를 쓴다. "
                "답변 끝에는 출처 메일 제목·일자·id 를 '근거:' 로 밝힌다."),
        })

    if method in ("notifications/initialized", "initialized", "notifications/cancelled"):
        return None                      # 알림에는 응답하지 않는다

    if method == "ping":
        return _res(rid, {})

    if method == "tools/list":
        return _res(rid, {"tools": TOOLS})

    if method == "tools/call":
        name = params.get("name", "")
        args = params.get("arguments") or {}
        log(f"call: {name}({json.dumps(args, ensure_ascii=False)})")
        return _res(rid, run_tool(name, args))

    if method in ("resources/list", "prompts/list"):
        key = "resources" if method.startswith("resources") else "prompts"
        return _res(rid, {key: []})

    if rid is None:
        return None
    return {"jsonrpc": "2.0", "id": rid,
            "error": {"code": -32601, "message": f"지원하지 않는 메서드: {method}"}}


def _res(rid, result) -> dict:
    return {"jsonrpc": "2.0", "id": rid, "result": result}


def main():
    global DB_PATH
    if "--db" in sys.argv:
        DB_PATH = sys.argv[sys.argv.index("--db") + 1]
    log(f"{SERVER_NAME} {SERVER_VERSION} · DB={Path(DB_PATH).resolve()} · "
        f"도구 {len(TOOLS)}개")

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError as e:
            log("parse error:", e)
            sys.stdout.write(json.dumps(
                {"jsonrpc": "2.0", "id": None,
                 "error": {"code": -32700, "message": f"Parse error: {e}"}}) + "\n")
            sys.stdout.flush()
            continue
        try:
            resp = handle(req)
        except Exception as e:
            log("handler error:", traceback.format_exc())
            resp = {"jsonrpc": "2.0", "id": req.get("id"),
                    "error": {"code": -32603, "message": f"Internal error: {e}"}}
        if resp is not None:
            sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
