# goose 붙이기

메일 지식그래프를 **MCP 서버**(`mcp_server.py`)로 감싸 goose 확장으로 등록합니다.
질의 도구 9종이 goose 안에서 그대로 도구로 뜹니다. 추가 패키지 반입은 없습니다 —
MCP stdio는 줄 단위 JSON-RPC라 표준 라이브러리로 구현했습니다.

```
goose  ──stdio(JSON-RPC)──▶  mcp_server.py  ──▶  mail.db (그래프)
  │
  └──HTTP──▶ LiteLLM :4000 ──▶ Qwen
```

---

## 0. 전제 조건 — 먼저 이것부터 확인

**goose는 tool calling에 전적으로 의존합니다.** 모델이 tool calling을 못 하면
확장을 전부 꺼야 하고, 그러면 이 연동 자체가 무의미합니다.

```bash
python run.py doctor
```

`네이티브 tool calling: 미지원` 이 뜨면 goose를 붙여도 도구를 못 씁니다.
vLLM 백엔드라면 아래 옵션을 주고 재기동하세요.

```bash
--enable-auto-tool-choice --tool-call-parser hermes
```

(이 조건이 안 되면 goose 대신 동봉된 `python run.py chat`을 쓰세요.
그쪽은 tool calling이 없어도 JSON 지시 루프로 동작합니다.)

---

## 1. 그래프 준비

```bash
python run.py ingest ./eml_folder
python run.py extract
python run.py build
python run.py stats          # 사안·인물이 잡혔는지 확인
```

`mail.db`의 **절대 경로**를 적어 두세요. goose 설정에 넣습니다.

## 2. MCP 서버 단독 검증

goose에 붙이기 전에 서버가 규약대로 도는지 먼저 확인합니다.
연결이 안 될 때 원인이 goose인지 서버인지 가리는 데 이 단계가 필수입니다.

```bash
python test_mcp.py
```

초기화·도구목록·연쇄호출·오류처리·DB 부재까지 24개 항목을 점검합니다.
전부 통과해야 다음으로 갑니다.

## 3. goose 공급자 설정 (LiteLLM)

goose에는 litellm 전용 공급자가 있습니다.

```bash
export GOOSE_PROVIDER=litellm
export GOOSE_MODEL=qwen3-32b        # LiteLLM config.yaml 의 model_name 별칭
export LITELLM_HOST=http://10.0.0.5:4000
export LITELLM_API_KEY=sk-...
export LITELLM_TIMEOUT=600          # 32B면 기본값이 빠듯합니다
```

openai 호환 공급자로 붙여도 됩니다. **둘을 섞지는 마세요.**

```bash
export GOOSE_PROVIDER=openai
export OPENAI_HOST=http://10.0.0.5:4000
export OPENAI_BASE_PATH=v1/chat/completions   # 404면 여기가 원인
export OPENAI_API_KEY=sk-...
```

키는 `goose configure` → Configure Providers 로 넣으면 OS 키체인에 저장됩니다.
`config.yaml`에 직접 적지 마세요.

## 4. 확장 등록

### 대화형

```bash
goose configure
```

```
◇  What would you like to configure?     │  Add Extension
◇  What type of extension?               │  Command-line Extension
◇  What would you like to call this?     │  mailkg
◇  What command should be run?           │  python /opt/mailkg/mcp_server.py
◇  Please set the timeout (in secs):     │  120
◆  Would you like to add environment variables?  │  Yes
   MAILKG_DB = /opt/mailkg/mail.db
```

### 직접 편집

`~/.config/goose/config.yaml` (Windows: `%APPDATA%\goose\config.yaml`)

```yaml
extensions:
  mailkg:
    name: mailkg
    type: stdio
    enabled: true
    cmd: python
    args:
      - /opt/mailkg/mcp_server.py
    envs:
      MAILKG_DB: /opt/mailkg/mail.db
    timeout: 120
```

전체 예시는 `goose/config.yaml.example` 참고.

> **경로는 반드시 절대경로로.** goose가 서버를 띄우는 작업 디렉터리는
> 여러분이 goose를 실행한 위치와 다를 수 있습니다. 상대경로 `mail.db`는
> "DB가 없습니다" 오류의 1순위 원인입니다.

> `python`이 PATH에 없거나 버전이 여럿이면 `cmd`에 인터프리터 절대경로를 쓰세요
> (`/usr/bin/python3.11`, Windows는 `C:\Python311\python.exe`).

## 5. 프로젝트 지침 붙이기

`goose/.goosehints`를 goose를 실행할 작업 디렉터리에 복사하세요.
답변 원칙(근거 인용, 추측 금지), 도구 사용 순서, 데이터의 한계를 담고 있습니다.
**소형 모델일수록 이 힌트 유무의 차이가 큽니다.**

## 6. 확인

```bash
goose session
```

```
( O)>  메일 그래프에 뭐가 들어있어?
( O)>  차세대 관제 사업 어떻게 흘러왔는지 시간순으로 정리해줘
( O)>  이영희 씨가 아직 안 끝낸 일 뭐 있어?
( O)>  4월 이후에 반려된 건 있어?
```

`goose session --with-extension` 로 일회성 실행도 됩니다.

---

## 도구 목록

전부 **읽기 전용**입니다. 그래프를 바꾸는 도구는 노출하지 않습니다.

| 도구 | 용도 |
|---|---|
| `mail_graph_overview` | 규모·기간·주요 사안 — 방향을 모를 때 첫 호출 |
| `mail_find_person` | 이름 → 메일주소 확정 (인물 관련 도구의 선행 단계) |
| `mail_person_network` | 협업 관계망 + 관여 사안 |
| `mail_list_cases` | 사안 목록 + 표기 흔들림 통합 결과 |
| `mail_case_timeline` | 사안 하나의 전체 이력 (메일·결정·업무·일정) |
| `mail_open_action_items` | 미완료 업무 (담당자·기한 필터) |
| `mail_decisions_about` | 의사결정 조회 (근거 원문 + 출처 메일 id 포함) |
| `mail_search_messages` | 본문 전문검색 — 그래프로 못 찾을 때의 차선책 |
| `mail_read_message` | 메일 원문 — 근거 확인용 |

도구 설명에 **호출 순서**를 적어 뒀습니다("addr은 mail_find_person으로 먼저 확정한다").
인자를 빠뜨리면 오류 메시지가 어떤 도구를 먼저 부르라고 알려줍니다 —
소형 모델이 스스로 복구하도록 만든 장치입니다.

---

## 안 될 때

| 증상 | 원인 |
|---|---|
| 확장이 목록에 안 뜸 | `cmd` 경로 오타, 또는 `python`이 PATH에 없음. 터미널에서 `python /opt/mailkg/mcp_server.py` 를 직접 실행해 보세요 — 즉시 종료되면 그게 원인입니다 |
| "그래프 DB가 없습니다" | `MAILKG_DB`가 상대경로이거나 `run.py build`를 안 함 |
| 도구는 뜨는데 모델이 안 씀 | 모델의 tool calling 미지원(0번 확인) 또는 도구가 너무 많음 — `developer` 등 기본 확장을 끄세요 |
| 연결 직후 끊김 | 서버가 stdout에 프로토콜 외 문자를 출력. 이 서버는 로그를 전부 stderr로 보내지만, `mailkg/` 모듈을 수정했다면 `print()`를 넣지 않았는지 확인 |
| 타임아웃 | `timeout: 120` 을 올리고, `LITELLM_TIMEOUT`도 함께 올리세요 |
| 404 | `OPENAI_BASE_PATH` 또는 모델 별칭 오타 |

서버 로그는 stderr로 나갑니다. 단독으로 띄워 확인하세요.

```bash
MAILKG_DB=/opt/mailkg/mail.db python mcp_server.py 2>server.log
```

---

## 다른 클라이언트

MCP 표준이라 goose 전용이 아닙니다. Claude Desktop, Cline 등도
같은 `cmd`/`args`/`envs` 3개만 각자 형식으로 옮겨 적으면 그대로 붙습니다.
