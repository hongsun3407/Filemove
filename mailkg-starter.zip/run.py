"""
mail-kg 실행 진입점 (LiteLLM 프록시 연결판)

  # 0) 최초 1회 — 게이트웨이 설정과 연결 점검
  python run.py config --url http://10.0.0.5:4000 --model qwen3-32b
  export MAILKG_API_KEY=sk-...            # 키는 환경변수로만 (Windows: set)
  python run.py doctor

  # 1~4) 본 처리
  python run.py ingest ./eml_folder
  python run.py extract                    # LiteLLM 사용
  python run.py extract --workers 4        # 병렬 (게이트웨이 부하 확인 후)
  python run.py extract --rule             # LLM 없이 규칙 기반 (배관 검증용)
  python run.py build
  python run.py stats / todo / timeline <case_id>
  python run.py ask "3월 이후 승인된 건 뭐야?"
  python run.py chat
  python run.py owl > mail.ttl
"""
import json
import os
import sys

from mailkg.parse import connect, ingest_dir
from mailkg import extract as ex
from mailkg import graph as gr
from mailkg import query as q
from mailkg import ontology as onto
from mailkg.llm import LLM, LLMConfig, CONFIG_FILE

DB = "mail.db"


def _arg(flag, default=None):
    return sys.argv[sys.argv.index(flag) + 1] if flag in sys.argv else default


def cmd_config():
    cfg = LLMConfig.load()
    if "--url" in sys.argv:
        cfg.base_url = _arg("--url")
    if "--model" in sys.argv:
        cfg.model = _arg("--model")
    if "--timeout" in sys.argv:
        cfg.timeout = int(_arg("--timeout"))
    if "--no-verify-ssl" in sys.argv:
        cfg.verify_ssl = False
    if "--ca" in sys.argv:
        cfg.ca_bundle = _arg("--ca")
    if "--thinking" in sys.argv:
        cfg.disable_thinking = False
    # 감지 결과는 저장하지 않고 매번 새로 확인
    cfg.supports_json_schema = cfg.supports_json_object = cfg.supports_tools = None
    cfg.save()
    print(f"저장됨 → {CONFIG_FILE}  (API 키는 파일에 저장하지 않습니다)")
    shown = {f: getattr(cfg, f) for f in cfg.__dataclass_fields__
             if getattr(cfg, f) is not None}
    if shown.get("api_key"):                     # 콘솔·로그에 키를 남기지 않는다
        shown["api_key"] = "****(환경변수에서 읽음)"
    print(json.dumps(shown, ensure_ascii=False, indent=2))
    if not (os.environ.get("MAILKG_API_KEY") or os.environ.get("LITELLM_API_KEY")):
        print("\n⚠️  API 키가 환경변수에 없습니다. 아래를 실행하세요:")
        print("    export MAILKG_API_KEY=sk-...     (Windows: set MAILKG_API_KEY=sk-...)")


def cmd_extract(db):
    if "--rule" in sys.argv:
        print("규칙 기반 추출 (LLM 미사용)")
        n = ex.extract_all(db, llm=ex.rule_extract)
        print(f"추출 {n}통")
        return
    client = LLM()
    if "--model" in sys.argv:
        client.cfg.model = _arg("--model")
    caps = client.probe()
    print(f"게이트웨이: {client.cfg.base_url} · 모델: {client.cfg.model}")
    print(f"구조화 출력: "
          f"{'json_schema' if caps['json_schema'] else 'json_object' if caps['json_object'] else '프롬프트 폴백'}")
    workers = int(_arg("--workers", "1"))
    limit = int(_arg("--limit", "0")) or None
    if workers > 1:
        n = extract_parallel(db, client, workers, limit)
    else:
        n = ex.extract_all(db, llm=ex.make_llm(client), limit=limit)
    print(f"추출 {n}통")


def extract_parallel(db, client, workers, limit=None):
    """게이트웨이가 동시 요청을 감당할 때만. SQLite 쓰기는 메인 스레드에서만 한다."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    llm = ex.make_llm(client)
    ids = [r[0] for r in db.execute(
        "SELECT id FROM message WHERE extracted=0 ORDER BY sent_at").fetchall()]
    if limit:
        ids = ids[:limit]
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        # 읽기는 스레드마다 별도 커넥션으로
        futures = {pool.submit(_extract_one, mid, llm): mid for mid in ids}
        for i, fut in enumerate(as_completed(futures), 1):
            mid = futures[fut]
            try:
                data = fut.result()
            except Exception as e:
                print(f"[{i}/{len(ids)}] 실패 {mid}: {str(e)[:120]}")
                continue
            db.execute("UPDATE message SET extracted=1 WHERE id=?", (mid,))
            db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                       (f"raw::{mid}", "_Extraction", mid,
                        json.dumps(data, ensure_ascii=False)))
            db.commit()
            done += 1
            if i % 20 == 0:
                print(f"  {i}/{len(ids)} 처리")
    return done


def _extract_one(mid, llm):
    local = connect(DB)                      # 스레드별 읽기 전용 커넥션
    try:
        return ex.extract_message(local, mid, llm=llm)
    finally:
        local.close()


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    cmd = sys.argv[1]

    if cmd == "config":
        cmd_config()
        return
    if cmd == "doctor":
        from mailkg.doctor import run
        sys.exit(0 if run() else 1)

    db = connect(DB)

    if cmd == "ingest":
        print(f"적재 {ingest_dir(db, sys.argv[2])}통")

    elif cmd == "extract":
        cmd_extract(db)

    elif cmd == "build":
        gr.build(db)

    elif cmd == "stats":
        for cls, c in db.execute(
                "SELECT class,COUNT(*) FROM node WHERE class NOT LIKE '\\_%' "
                "ESCAPE '\\' GROUP BY class ORDER BY 2 DESC"):
            print(f"  {cls:14s} {c}")
        print("\n[사안]")
        for c in q.list_cases(db, 10):
            print(f"  {c['메일수']:3d}건  {c['사안']}  {c['다른표기']}")

    elif cmd == "timeline":
        print(json.dumps(q.case_timeline(db, sys.argv[2]),
                         ensure_ascii=False, indent=2))

    elif cmd == "todo":
        for a in q.open_action_items(db):
            print(f"  {a['기한'] or '기한없음':10s} {a['담당']:8s} {a['내용'][:50]}")

    elif cmd == "ask":
        from mailkg.agent import chat
        print(chat(db, sys.argv[2]))

    elif cmd == "chat":
        from mailkg.agent import repl
        repl(DB)

    elif cmd == "owl":
        print(onto.to_turtle())

    else:
        print(__doc__)


if __name__ == "__main__":
    main()
