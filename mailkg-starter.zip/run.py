"""
mail-kg 실행 진입점

  python run.py ingest  ./eml_folder      # 1) .eml 적재
  python run.py extract --rule            # 2) 추출 (--rule: LLM 없이 규칙 기반)
  python run.py extract --model qwen3:32b # 2) 추출 (Ollama)
  python run.py build                     # 3) 그래프 구축
  python run.py stats                     # 확인
  python run.py ask "3월 이후 승인된 건 뭐야?"   # 4) 에이전트 질의
  python run.py chat                      # 4) 대화형
  python run.py owl > mail.ttl            # 온톨로지 RDF 내보내기
"""
import sys
import json
from mailkg.parse import connect, ingest_dir
from mailkg import extract as ex
from mailkg import graph as gr
from mailkg import query as q
from mailkg import ontology as onto

DB = "mail.db"


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    cmd = sys.argv[1]
    db = connect(DB)

    if cmd == "ingest":
        print(f"적재 {ingest_dir(db, sys.argv[2])}통")

    elif cmd == "extract":
        if "--rule" in sys.argv:
            n = ex.extract_all(db, llm=ex.rule_extract)
        else:
            model = (sys.argv[sys.argv.index("--model") + 1]
                     if "--model" in sys.argv else ex.MODEL)
            n = ex.extract_all(db, model=model)
        print(f"추출 {n}통")

    elif cmd == "build":
        gr.build(db)

    elif cmd == "stats":
        for cls, c in db.execute(
                "SELECT class,COUNT(*) FROM node WHERE class NOT LIKE '\\_%' "
                "ESCAPE '\\' GROUP BY class ORDER BY 2 DESC"):
            print(f"  {cls:14s} {c}")
        print("\n[사안]")
        for c in q.list_cases(db, 10):
            print(f"  {c['메일수']:3d}건  {c['사안']}  {c['다른표기']}")

    elif cmd == "timeline":
        print(json.dumps(q.case_timeline(db, sys.argv[2]),
                         ensure_ascii=False, indent=2))

    elif cmd == "todo":
        for a in q.open_action_items(db):
            print(f"  {a['기한'] or '기한없음':10s} {a['담당']:8s} {a['내용'][:50]}")

    elif cmd == "ask":
        from mailkg.agent import chat
        print(chat(db, sys.argv[2]))

    elif cmd == "chat":
        from mailkg.agent import repl
        repl(DB)

    elif cmd == "owl":
        print(onto.to_turtle())

    else:
        print(__doc__)


if __name__ == "__main__":
    main()
