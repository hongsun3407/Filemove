# mail-kg — 폐쇄망 .eml 온톨로지 에이전트

.eml 메일 묶음을 온톨로지 기반 지식그래프로 만들고, 로컬 LLM 에이전트가
그 그래프를 조회해서 답하게 하는 최소 실행 골격입니다.
외부 네트워크 없이 동작하며, 표준 라이브러리 + SQLite 만으로 그래프가 돌아갑니다.

## 왜 이 구조인가

메일에 RAG(벡터검색)만 붙이면 "누가 언제 뭘 승인했는지"를 못 답합니다.
그건 검색 문제가 아니라 **관계 문제**이기 때문입니다. 그래서 3층으로 나눕니다.

| 층 | 담당 | 정확도 |
|---|---|---|
| 구조층 | From/To/Cc/References → 발신·수신·스레드·소속 | 100% (규칙, LLM 미사용) |
| 의미층 | 본문 → 사안·의사결정·액션아이템·일정 | LLM 추출 + 근거 검증 |
| 파생층 | 그래프 연산 → 협업관계·사안참여도 | 계산값 |

핵심은 **LLM에게 그래프 전체를 맡기지 않는 것**입니다.
헤더로 확정할 수 있는 건 전부 규칙으로 확정하고, LLM은 본문 안에만 있는
사실 추출에만 씁니다. 폐쇄망 소형 모델에서 이 분리가 품질을 좌우합니다.

## 실행

```bash
# 0) 게이트웨이 연결 (LiteLLM 프록시) — 자세한 내용은 CONNECT.md
python run.py config --url http://<IP>:4000 --model <LiteLLM 모델명>
export MAILKG_API_KEY=sk-...
python run.py doctor                   # 연결·인증·기능·추출까지 한 번에 점검

python make_samples.py                 # 샘플 .eml 생성 (동작 확인용)
python run.py ingest ./samples         # 1) 파싱·정규화·SQLite 적재
python run.py extract                  # 2) 추출 (LiteLLM)
python run.py extract --workers 4      # 2') 병렬 추출
python run.py extract --rule           # 2'') LLM 없이 규칙 기반 - 배관 검증용
python run.py build                    # 3) 온톨로지 트리플 + 그래프 구축
python run.py stats                    # 확인
python run.py todo                     # 미완료 액션아이템
python run.py chat                     # 4) 대화형 에이전트
python run.py owl > mail.ttl           # 온톨로지 RDF 내보내기 (Protégé 검토용)
```

`--rule` 모드는 LLM 없이 전 구간을 돌려볼 수 있게 넣은 규칙 기반 대체기입니다.
품질은 낮지만 파싱·엔티티해소·그래프·질의 배관이 맞는지 먼저 확인할 수 있습니다.
반입 전 개발 PC에서 이걸로 검증하고, 폐쇄망에서 모델만 갈아끼우면 됩니다.

## 파일

```
mailkg/ontology.py   온톨로지 단일 정의 (클래스·관계·JSON스키마·프롬프트·OWL)
mailkg/parse.py      .eml 파싱, euc-kr/cp949, 인용문·서명 제거, 스레드 묶기
mailkg/llm.py        LiteLLM 프록시 클라이언트 (인증·재시도·기능감지·3단 폴백)
mailkg/extract.py    LLM 구조화 추출 + 근거 검증(환각 필터) + 규칙 대체기
mailkg/graph.py      엔티티 해소(사안 표기 통합, 이름→메일주소) + 트리플 적재
mailkg/query.py      에이전트에 노출할 안전한 질의 도구 8종
mailkg/agent.py      tool-calling 루프 (네이티브 + JSON 폴백 자동 선택)
mailkg/doctor.py     연결 진단 — 실패 지점과 조치를 함께 출력
run.py               CLI 진입점
mcp_server.py        MCP stdio 서버 — goose 등 MCP 클라이언트 연동 (의존성 0)
test_mcp.py          MCP 프로토콜 왕복 테스트 (24개 항목)
mock_gateway.py      모의 LiteLLM 서버 (폴백 경로 검증용)
goose/               goose config.yaml 예시 + .goosehints
CONNECT.md           게이트웨이 연결 가이드
GOOSE.md             goose 연동 가이드
```

## goose 에 붙이기

```bash
python test_mcp.py                      # MCP 서버 단독 검증
goose configure                         # Add Extension → Command-line Extension
#   command: python /opt/mailkg/mcp_server.py
#   env:     MAILKG_DB=/opt/mailkg/mail.db
```

전제: **모델이 tool calling을 지원해야 합니다**(`python run.py doctor` 로 확인).
자세한 내용은 `GOOSE.md`.

## 폐쇄망 반입 체크리스트

USB로 옮길 것 — 순서대로.

1. **Python 3.11+** (오프라인 설치본). 이 골격은 표준 라이브러리만 씁니다.
2. **Ollama 설치 파일** + 모델 GGUF
   - 인터넷 PC: `ollama pull <모델>` 후 `~/.ollama/models` 폴더 통째로 복사
   - 또는 Hugging Face에서 GGUF 파일 받아 `Modelfile`로 `ollama create`
3. **모델 선택**
   - 상용/업무 활용: Qwen3 계열 27~32B (Apache-2.0). 라이선스 부담 없음
   - 한국어 최우선: EXAONE 4.5 (LG AI) — **라이선스가 NC(비상용)**이므로
     사내 업무 활용 전 법무 확인 필수
   - VRAM 24GB → 30B급 Q4_K_M(약 18GB) 무난. 12GB → 8~14B급으로 낮추고
     추출 프롬프트를 항목별로 쪼개세요
4. (선택) **임베딩 모델** — 의미 검색을 추가할 때만. BGE-M3 등 다국어 모델을
   `sentence-transformers`로 로컬 로드. 수천 통 규모면 numpy 브루트포스로 충분해
   벡터DB는 불필요합니다.
5. 파이썬 패키지가 필요해지면 인터넷 PC에서
   `pip download -d wheels -r requirements.txt` → 폴더 반입 →
   `pip install --no-index --find-links=wheels -r requirements.txt`

## 규모별 권장

| 메일 수 | 저장소 | 비고 |
|---|---|---|
| ~5천 | SQLite (현재 구성) | 그대로 사용. 그래프 순회는 SQL 재귀 CTE로 충분 |
| 5천~5만 | SQLite + networkx 인메모리 | 그래프 알고리즘(중심성·경로) 필요할 때 |
| 5만+ | 별도 그래프DB 검토 | Kuzu는 2025년 유지보수 모드 전환됨. Neo4j Community 또는 포크판 확인 |

## 정확도를 올리는 순서

1. **인용문 제거** (`parse.strip_quotes_and_sig`) — 가장 큰 효과.
   안 하면 같은 문장이 스레드 길이만큼 중복 추출됩니다.
   조직 메일 클라이언트의 인용 패턴을 `QUOTE_MARKERS`에 추가하세요.
2. **사안 목록 사전화** — 조직의 실제 과제명 목록이 있다면
   `graph.CaseResolver`에 시드로 넣으세요. 자동 클러스터링보다 훨씬 정확합니다.
3. **인사 데이터 연결** — 이름·직위·부서 명부가 있으면
   `person` 테이블에 조인. 도메인 기반 소속 추정보다 정확합니다.
4. **골든셋 50통** — 사람이 직접 정답을 단 50통을 만들어 두고,
   프롬프트나 모델을 바꿀 때마다 재현율/정밀도를 비교하세요.
   이게 없으면 "좋아진 것 같다"에서 못 벗어납니다.

## 주의

- LLM 추출 결과에는 반드시 `evidence`(본문 원문 인용)를 요구하고,
  본문에 없는 근거는 버립니다(`extract._verify`). 환각 차단의 최전선입니다.
- 에이전트에게 자유 SQL 생성을 시키지 않습니다. `query.TOOLS`의 정해진
  함수 8개만 노출합니다. 소형 모델일수록 이쪽이 안정적입니다.
- 메일 원문은 삭제하지 마세요. 답변의 근거를 항상 원문으로 되돌아가
  확인할 수 있어야 업무에 쓸 수 있습니다.
