"""
3단계: 추출 결과 → 온톨로지 트리플 → 그래프

엔티티 해소(Entity Resolution)가 이 단계의 본질이다.
LLM이 "차세대 관제시스템", "차세대관제", "관제 고도화 사업"을 각각 뱉으면
그래프는 세 개의 다른 사안이 되어 쓸모없어진다. 아래 3중 정규화로 묶는다.
 1) 문자열 정규화(공백/괄호/접미어 제거) + 완전일치
 2) 문자 3-gram Jaccard 유사도 (외부 의존성 0)
 3) (선택) 임베딩 코사인 유사도 — sentence-transformers 반입 시 활성화
인물은 메일주소가 유일키이므로 본문 이름 → 주소 매핑만 하면 된다.
"""

from __future__ import annotations
import json
import re
import sqlite3
from collections import Counter, defaultdict

from .ontology import validate_triple

SUFFIX = re.compile(r"(사업|과제|프로젝트|건|관련|추진|구축|개선|고도화|시스템|의건)+$")
PREFIX = re.compile(r"^(re|fw|fwd|답장|회신|전달)+", re.I)


def norm_case(name: str) -> str:
    s = re.sub(r"[\s\-_·,()\[\]{}:]", "", name or "")
    s = PREFIX.sub("", s)
    s = re.sub(r"^\d{4}년?", "", s)
    return SUFFIX.sub("", s) or s


def tri(s: str) -> set[str]:
    s = f"  {s}  "
    return {s[i:i + 3] for i in range(len(s) - 2)}


def jaccard(a: str, b: str) -> float:
    A, B = tri(a), tri(b)
    return len(A & B) / len(A | B) if A | B else 0.0


class CaseResolver:
    """사안 표기 흔들림을 canonical id 하나로 접는다."""

    def __init__(self, threshold: float = 0.62):
        self.canon: dict[str, str] = {}     # norm → canonical id
        self.labels: dict[str, Counter] = defaultdict(Counter)
        self.th = threshold

    def resolve(self, name: str) -> str | None:
        if not name or len(name.strip()) < 2:
            return None
        n = norm_case(name)
        if not n:
            return None
        if n in self.canon:
            cid = self.canon[n]
        else:
            best, score = None, 0.0
            for other, cid0 in self.canon.items():
                s = jaccard(n, other)
                if s > score:
                    best, score = cid0, s
            cid = best if score >= self.th else f"case::{n[:48]}"
            self.canon[n] = cid
        self.labels[cid][name.strip()] += 1
        return cid

    def label(self, cid: str) -> str:
        return self.labels[cid].most_common(1)[0][0] if self.labels[cid] else cid


class PersonResolver:
    """본문에 등장한 '홍길동 팀장' → 메일주소로 연결."""

    def __init__(self, db: sqlite3.Connection):
        self.by_name: dict[str, list[str]] = defaultdict(list)
        for addr, name in db.execute("SELECT addr,name FROM person").fetchall():
            key = re.sub(r"\s|(님|씨|팀장|과장|부장|대리|차장|사원|이사|본부장|실장|"
                         r"선임|책임|수석|교수|박사|대표)$", "", name or "")
            if key:
                self.by_name[key].append(addr)
            self.by_name[addr] = [addr]

    def resolve(self, name: str, context_addrs: list[str] | None = None) -> str | None:
        if not name:
            return None
        key = re.sub(r"\s|(님|씨|팀장|과장|부장|대리|차장|사원|이사|본부장|실장|"
                     r"선임|책임|수석|교수|박사|대표)$", "", name.strip())
        cands = self.by_name.get(key, [])
        if not cands:
            for k, v in self.by_name.items():
                if key and (key in k or k in key) and len(k) >= 2:
                    cands = v
                    break
        if not cands:
            return None
        if len(cands) > 1 and context_addrs:          # 동명이인은 메일 참여자 우선
            inctx = [c for c in cands if c in context_addrs]
            if inctx:
                return inctx[0]
        return cands[0]


def _add(db, s, sc, p, o, oc, mid, ev="", conf=1.0):
    if not (s and o):
        return
    if not validate_triple(sc, p, oc):        # 온톨로지 위반 트리플은 버린다
        return
    db.execute("INSERT OR REPLACE INTO triple VALUES(?,?,?,?,?,?,?,?)",
               (s, sc, p, o, oc, mid, ev[:400], conf))


def build(db: sqlite3.Connection, verbose: bool = True) -> dict:
    db.execute("DELETE FROM triple")
    db.execute("DELETE FROM node WHERE class!='_Extraction'")

    # ---------- 1. 구조 관계 (헤더에서 확정, 신뢰도 1.0)
    for mid, thread, subj, sent in db.execute(
            "SELECT id,thread_id,subject,sent_at FROM message").fetchall():
        db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                   (mid, "Message", subj, json.dumps({"sent_at": sent},
                                                     ensure_ascii=False)))
        _add(db, mid, "Message", "partOfThread", f"thread::{thread}", "Thread", mid)
    for tid, in db.execute("SELECT DISTINCT thread_id FROM message").fetchall():
        row = db.execute("SELECT subject_norm,MIN(sent_at),MAX(sent_at),COUNT(*) "
                         "FROM message WHERE thread_id=?", (tid,)).fetchone()
        db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                   (f"thread::{tid}", "Thread", row[0],
                    json.dumps({"first_at": row[1], "last_at": row[2],
                                "count": row[3]}, ensure_ascii=False)))

    for addr, name, org in db.execute("SELECT addr,name,org FROM person").fetchall():
        db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                   (f"person::{addr}", "Person", name,
                    json.dumps({"email": addr, "org": org}, ensure_ascii=False)))
        db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                   (f"org::{org}", "Organization", org,
                    json.dumps({"domain": org}, ensure_ascii=False)))
        _add(db, f"person::{addr}", "Person", "memberOf", f"org::{org}",
             "Organization", "")

    rel_of = {"from": "sentBy", "to": "sentTo", "cc": "copiedTo"}
    for mid, addr, role in db.execute(
            "SELECT message_id,addr,role FROM participant").fetchall():
        _add(db, mid, "Message", rel_of[role], f"person::{addr}", "Person", mid)

    for mid, fn, mime, size, sha in db.execute(
            "SELECT message_id,filename,mime,size,sha256 FROM attachment").fetchall():
        aid = f"att::{sha[:12]}::{fn}"
        db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                   (aid, "Attachment", fn,
                    json.dumps({"mime": mime, "size": size}, ensure_ascii=False)))
        _add(db, mid, "Message", "hasAttachment", aid, "Attachment", mid)

    # ---------- 2. 의미 관계 (LLM 추출 결과 적재 + 엔티티 해소)
    cr, pr = CaseResolver(), PersonResolver(db)
    rows = db.execute("SELECT label,props FROM node WHERE class='_Extraction'").fetchall()
    # 1차 패스: 사안 canonical id 확보 (등장 순서 무관하게 안정화)
    for mid, props in rows:
        for c in json.loads(props).get("cases", []):
            cr.resolve(c.get("name", ""))

    n_dec = n_act = n_evt = 0
    for mid, props in rows:
        data = json.loads(props)
        sent = db.execute("SELECT sent_at FROM message WHERE id=?", (mid,)).fetchone()[0]
        ctx = [r[0] for r in db.execute(
            "SELECT addr FROM participant WHERE message_id=?", (mid,)).fetchall()]
        sender = db.execute("SELECT from_addr FROM message WHERE id=?", (mid,)).fetchone()[0]

        msg_cases = []
        for c in data.get("cases", []):
            cid = cr.resolve(c.get("name", ""))
            if not cid:
                continue
            msg_cases.append(cid)
            _add(db, mid, "Message", "aboutCase", cid, "Case", mid, c.get("evidence", ""))
        primary = msg_cases[0] if msg_cases else None

        def case_of(item):
            return cr.resolve(item.get("case", "")) or primary

        for i, d in enumerate(data.get("decisions", [])):
            did = f"decision::{mid}::{i}"
            db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                       (did, "Decision", d.get("statement", "")[:120],
                        json.dumps({"kind": d.get("kind", ""), "decided_at": sent,
                                    "statement": d.get("statement", "")},
                                   ensure_ascii=False)))
            _add(db, mid, "Message", "statesDecision", did, "Decision", mid,
                 d.get("evidence", ""))
            who = pr.resolve(d.get("decided_by", ""), ctx) or sender
            _add(db, did, "Decision", "decidedBy", f"person::{who}", "Person", mid)
            _add(db, did, "Decision", "relatesToCase", case_of(d), "Case", mid)
            n_dec += 1

        for i, a in enumerate(data.get("action_items", [])):
            aid = f"action::{mid}::{i}"
            db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                       (aid, "ActionItem", a.get("statement", "")[:120],
                        json.dumps({"due": a.get("due", ""), "asked_at": sent,
                                    "statement": a.get("statement", ""),
                                    "status": "요청됨"}, ensure_ascii=False)))
            _add(db, mid, "Message", "requestsItem", aid, "ActionItem", mid,
                 a.get("evidence", ""))
            asg = pr.resolve(a.get("assigned_to", ""), ctx)
            if not asg:                    # 담당자 미기재 → 수신자 단독이면 그 사람
                tos = [r[0] for r in db.execute(
                    "SELECT addr FROM participant WHERE message_id=? AND role='to'",
                    (mid,)).fetchall()]
                asg = tos[0] if len(tos) == 1 else None
            _add(db, aid, "ActionItem", "assignedTo", f"person::{asg}" if asg else "",
                 "Person", mid)
            req = pr.resolve(a.get("requested_by", ""), ctx) or sender
            _add(db, aid, "ActionItem", "requestedBy", f"person::{req}", "Person", mid)
            _add(db, aid, "ActionItem", "itemOfCase", case_of(a), "Case", mid)
            n_act += 1

        for i, e in enumerate(data.get("events", [])):
            eid = f"event::{mid}::{i}"
            db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                       (eid, "Event", e.get("title", "")[:80],
                        json.dumps({"starts_at": e.get("starts_at", ""),
                                    "location": e.get("location", "")},
                                   ensure_ascii=False)))
            _add(db, mid, "Message", "announcesEvent", eid, "Event", mid,
                 e.get("evidence", ""))
            _add(db, eid, "Event", "eventOfCase", case_of(e), "Case", mid)
            n_evt += 1

    for cid in set(cr.canon.values()):
        db.execute("INSERT OR REPLACE INTO node VALUES(?,?,?,?)",
                   (cid, "Case", cr.label(cid),
                    json.dumps({"aliases": list(cr.labels[cid].keys())},
                               ensure_ascii=False)))

    # ---------- 3. 파생 관계
    _derive(db)
    db.commit()
    stats = {"메일": db.execute("SELECT COUNT(*) FROM message").fetchone()[0],
             "인물": db.execute("SELECT COUNT(*) FROM person").fetchone()[0],
             "사안": len(set(cr.canon.values())),
             "의사결정": n_dec, "액션아이템": n_act, "일정": n_evt,
             "트리플": db.execute("SELECT COUNT(*) FROM triple").fetchone()[0]}
    if verbose:
        print(" | ".join(f"{k} {v}" for k, v in stats.items()))
    return stats


def _derive(db: sqlite3.Connection) -> None:
    """협업 관계·사안 참여도 계산."""
    pairs: Counter = Counter()
    for tid, in db.execute("SELECT DISTINCT thread_id FROM message").fetchall():
        people = sorted({r[0] for r in db.execute(
            "SELECT p.addr FROM participant p JOIN message m ON p.message_id=m.id "
            "WHERE m.thread_id=?", (tid,)).fetchall()})
        for i in range(len(people)):
            for j in range(i + 1, len(people)):
                pairs[(people[i], people[j])] += 1
    for (a, b), w in pairs.items():
        _add(db, f"person::{a}", "Person", "collaboratesWith", f"person::{b}",
             "Person", "", f"공동 스레드 {w}건", float(w))
        _add(db, f"person::{b}", "Person", "collaboratesWith", f"person::{a}",
             "Person", "", f"공동 스레드 {w}건", float(w))

    inv: Counter = Counter()
    for mid, cid in db.execute(
            "SELECT message_id,o FROM triple WHERE p='aboutCase'").fetchall():
        for (addr,) in db.execute(
                "SELECT addr FROM participant WHERE message_id=?", (mid,)).fetchall():
            inv[(addr, cid)] += 1
    for (addr, cid), w in inv.items():
        _add(db, f"person::{addr}", "Person", "involvedInCase", cid, "Case", "",
             f"참여 메일 {w}건", float(w))
