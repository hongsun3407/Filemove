"""
5단계: 질의 에이전트 (Ollama tool-calling 루프)

에이전트 규칙
 - 그래프 도구 결과에 없는 사실은 말하지 않는다.
 - 답변에는 반드시 출처 메일 id / 근거 문장을 붙인다.
 - 도구 호출은 최대 6회. 그 안에 못 찾으면 "찾지 못함"이라고 답한다.
"""

from __future__ import annotations
import json
import sqlite3
import urllib.request

from .query import call_tool, tool_specs

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "qwen3:32b"

AGENT_SYSTEM = """당신은 사내 메일 지식그래프를 조회해 답하는 업무 비서다.

지켜야 할 것:
1. 답은 반드시 도구 조회 결과에만 근거한다. 결과에 없는 내용은 추측하지 않는다.
2. 사람을 다룰 땐 find_person 으로 메일주소를 먼저 확정한 뒤 person_network 를 쓴다.
3. 사안을 다룰 땐 list_cases 로 id 를 확인한 뒤 case_timeline 을 쓴다.
4. 그래프에서 못 찾으면 search_messages 로 원문을 검색한다.
5. 답변 끝에 "근거:" 로 출처 메일 제목·일자·id 를 나열한다.
6. 확실하지 않으면 확실하지 않다고 말한다. 지어내는 것이 가장 큰 실패다.
7. 한국어로, 표나 목록으로 간결하게 답한다.
"""


def chat(db: sqlite3.Connection, question: str, model: str = MODEL,
         max_steps: int = 6, verbose: bool = True) -> str:
    messages = [{"role": "system", "content": AGENT_SYSTEM},
                {"role": "user", "content": question}]
    for step in range(max_steps):
        payload = {"model": model, "messages": messages, "stream": False,
                   "tools": tool_specs(), "options": {"temperature": 0.1}}
        req = urllib.request.Request(
            OLLAMA_URL, data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=300) as r:
            msg = json.loads(r.read())["message"]
        messages.append(msg)
        calls = msg.get("tool_calls") or []
        if not calls:
            return msg.get("content", "")
        for c in calls:
            fn = c["function"]["name"]
            args = c["function"].get("arguments") or {}
            if isinstance(args, str):
                args = json.loads(args)
            if verbose:
                print(f"  ↳ {fn}({args})")
            try:
                result = call_tool(db, fn, args)
            except Exception as e:
                result = {"오류": str(e)}
            messages.append({"role": "tool", "name": fn,
                             "content": json.dumps(result, ensure_ascii=False)[:6000]})
    return "도구 호출 한도 내에 답을 찾지 못했습니다."


def repl(db_path: str = "mail.db", model: str = MODEL):
    from .parse import connect
    db = connect(db_path)
    print("메일 지식그래프 에이전트. 종료는 빈 줄 입력.\n")
    while True:
        try:
            q = input("질문> ").strip()
        except EOFError:
            break
        if not q:
            break
        print("\n" + chat(db, q, model) + "\n")


if __name__ == "__main__":
    import sys
    repl(sys.argv[1] if len(sys.argv) > 1 else "mail.db")
