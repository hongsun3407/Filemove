"""
5단계: 질의 에이전트 — LiteLLM 프록시(OpenAI 호환) 기반

두 가지 모드를 자동 선택합니다.
  A. 네이티브 tool calling — 게이트웨이가 tools/tool_calls 를 지원할 때
  B. JSON 지시 루프      — 지원하지 않을 때 (llama.cpp 서버, 툴 파서 미탑재 vLLM 등)
B 모드는 모델에게 "도구를 쓰려면 {"tool":..,"args":..} 만 출력하라"고 지시하고
응답을 파싱해 같은 도구를 호출합니다. 결과 품질은 A가 낫지만 B도 실용 수준입니다.

에이전트 규칙
 - 그래프 도구 결과에 없는 사실은 말하지 않는다.
 - 답변에는 반드시 출처 메일 id / 근거 문장을 붙인다.
 - 도구 호출은 최대 6회. 그 안에 못 찾으면 "찾지 못함"이라고 답한다.
"""

from __future__ import annotations
import json
import sqlite3

from .llm import LLM, _loads
from .query import TOOLS, call_tool, tool_specs

AGENT_SYSTEM = """당신은 사내 메일 지식그래프를 조회해 답하는 업무 비서다.

지켜야 할 것:
1. 답은 반드시 도구 조회 결과에만 근거한다. 결과에 없는 내용은 추측하지 않는다.
2. 사람을 다룰 땐 find_person 으로 메일주소를 먼저 확정한 뒤 person_network 를 쓴다.
3. 사안을 다룰 땐 list_cases 로 id 를 확인한 뒤 case_timeline 을 쓴다.
4. 그래프에서 못 찾으면 search_messages 로 원문을 검색한다.
5. 답변 끝에 "근거:" 로 출처 메일 제목·일자·id 를 나열한다.
6. 확실하지 않으면 확실하지 않다고 말한다. 지어내는 것이 가장 큰 실패다.
7. 한국어로, 표나 목록으로 간결하게 답한다.
"""

# B 모드용 추가 지시
JSON_TOOL_RULE = """
[도구 사용 방법]
도구를 쓰려면 아래 JSON 객체 하나만 출력한다. 다른 문장을 절대 함께 쓰지 않는다.
{"tool": "도구이름", "args": {"인자": "값"}}

조회가 끝나 최종 답을 할 때는 JSON 없이 평범한 한국어 문장으로만 답한다.

사용 가능한 도구:
%s
"""


def _tool_menu() -> str:
    import inspect
    lines = []
    for name, (fn, desc, req) in TOOLS.items():
        params = list(inspect.signature(fn).parameters)[1:]
        lines.append(f'- {name}({", ".join(params)}) : {desc}'
                     + (f'  [필수: {", ".join(req)}]' if req else ""))
    return "\n".join(lines)


def chat(db: sqlite3.Connection, question: str, client: LLM | None = None,
         max_steps: int = 6, verbose: bool = True) -> str:
    client = client or LLM()
    caps = client.probe()
    if caps.get("tools"):
        return _chat_native(db, question, client, max_steps, verbose)
    return _chat_json(db, question, client, max_steps, verbose)


# ------------------------------------------------------------- A. 네이티브
def _chat_native(db, question, client, max_steps, verbose):
    messages = [{"role": "system", "content": AGENT_SYSTEM},
                {"role": "user", "content": question}]
    specs = tool_specs()
    for _ in range(max_steps):
        msg = client.chat(messages, tools=specs)
        calls = msg.get("tool_calls") or []
        messages.append({k: v for k, v in msg.items() if not k.startswith("_")})
        if not calls:
            return msg.get("content") or "(빈 응답)"
        for c in calls:
            fn = c["function"]["name"]
            args = c["function"].get("arguments") or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {}
            if verbose:
                print(f"  ↳ {fn}({args})")
            result = _safe_call(db, fn, args)
            messages.append({
                "role": "tool",
                "tool_call_id": c.get("id", fn),
                "name": fn,
                "content": json.dumps(result, ensure_ascii=False)[:6000]})
    return "도구 호출 한도 내에 답을 찾지 못했습니다."


# ------------------------------------------------------------- B. JSON 루프
def _chat_json(db, question, client, max_steps, verbose):
    system = AGENT_SYSTEM + JSON_TOOL_RULE % _tool_menu()
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": question}]
    for _ in range(max_steps):
        text = client.chat(messages)["content"]
        call = _parse_call(text)
        if call is None:
            return text or "(빈 응답)"
        fn, args = call
        if verbose:
            print(f"  ↳ {fn}({args})")
        result = _safe_call(db, fn, args)
        messages.append({"role": "assistant", "content": text})
        messages.append({"role": "user",
                         "content": "[도구 결과]\n"
                                    + json.dumps(result, ensure_ascii=False)[:6000]
                                    + "\n\n이 결과로 답하거나, 필요하면 다음 도구를 호출해."})
    return "도구 호출 한도 내에 답을 찾지 못했습니다."


def _parse_call(text: str):
    """응답이 도구 호출이면 (이름, 인자), 최종 답이면 None."""
    if "{" not in text or '"tool"' not in text:
        return None
    try:
        obj = _loads(text)
    except Exception:
        return None
    name = obj.get("tool")
    if name not in TOOLS:
        return None
    args = obj.get("args") or {}
    return name, (args if isinstance(args, dict) else {})


def _safe_call(db, fn, args):
    if fn not in TOOLS:
        return {"오류": f"없는 도구: {fn}. 사용 가능: {', '.join(TOOLS)}"}
    try:
        return call_tool(db, fn, args)
    except TypeError as e:
        return {"오류": f"인자가 맞지 않습니다: {e}"}
    except Exception as e:
        return {"오류": str(e)}


def repl(db_path: str = "mail.db"):
    from .parse import connect
    client = LLM()
    caps = client.probe()
    mode = "네이티브 tool calling" if caps.get("tools") else "JSON 지시 루프"
    db = connect(db_path)
    print(f"메일 지식그래프 에이전트 — {client.cfg.model} @ {client.cfg.base_url}")
    print(f"도구 호출 모드: {mode}. 종료는 빈 줄 입력.\n")
    while True:
        try:
            q = input("질문> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not q:
            break
        try:
            print("\n" + chat(db, q, client) + "\n")
        except Exception as e:
            print(f"\n오류: {e}\n")


if __name__ == "__main__":
    import sys
    repl(sys.argv[1] if len(sys.argv) > 1 else "mail.db")
