"""
1단계: .eml 파싱 → 정규화 → SQLite 적재

폐쇄망 국내 메일에서 실제로 문제되는 것만 골라서 처리한다.
 - 헤더 인코딩: =?EUC-KR?B?...?= / =?UTF-8?B?...?= 혼재
 - 본문 charset: euc-kr, cp949(=euc-kr 상위호환), ks_c_5601-1987(= cp949 별칭)
 - Outlook/한메일 회신 인용문 제거 (이걸 안 하면 같은 문장이 N번 중복 추출된다)
 - 서명 블록 제거 (직위/전화번호가 매 메일마다 엔티티로 잡히는 것 방지)
 - 스레드 키: References > In-Reply-To > 정규화 제목 순
"""

from __future__ import annotations
import email
import email.policy
import hashlib
import re
import sqlite3
from datetime import datetime, timezone
from email.header import decode_header, make_header
from pathlib import Path

# ks_c_5601-1987 등 파이썬이 모르는 별칭 등록
import codecs
_ALIASES = {"ks_c_5601-1987": "cp949", "ks_c_5601_1987": "cp949",
            "ksc5601": "cp949", "korean": "cp949", "euckr": "euc-kr",
            "unicode-1-1-utf-8": "utf-8", "utf8": "utf-8"}


def _lookup(name):
    real = _ALIASES.get(name.lower().replace("_", "-"))
    return codecs.lookup(real) if real else None


codecs.register(_lookup)

SUBJ_PREFIX = re.compile(
    r"^\s*(?:\[[^\]]{0,40}\]\s*)?(?:(re|fw|fwd|답장|회신|전달|답신)\s*:\s*)+",
    re.IGNORECASE)

# 회신 인용문 시작 지점들
QUOTE_MARKERS = [
    re.compile(r"^-{2,}\s*(original message|원본 메시지|-----)", re.I | re.M),
    re.compile(r"^\s*보낸\s*사람\s*:", re.M),
    re.compile(r"^\s*From:\s.*\nSent:", re.M),
    re.compile(r"^.{0,80}(작성하셨습니다|wrote:)\s*$", re.M),
    re.compile(r"^\s*>{1,}\s?", re.M),
]
SIG_MARKER = re.compile(r"^\s*(--\s*$|={3,}\s*$|[-—]{3,}\s*$)", re.M)


def _dec_header(raw: str | None) -> str:
    if not raw:
        return ""
    try:
        return str(make_header(decode_header(raw))).strip()
    except Exception:
        return raw.strip()


def _body_text(msg) -> str:
    """text/plain 우선, 없으면 text/html 태그 제거."""
    plain, html = None, None
    for part in msg.walk():
        if part.get_content_maintype() == "multipart":
            continue
        if part.get_content_disposition() == "attachment":
            continue
        ct = part.get_content_type()
        try:
            payload = part.get_payload(decode=True)
            if payload is None:
                continue
            cs = part.get_content_charset() or "utf-8"
            try:
                txt = payload.decode(cs, errors="replace")
            except LookupError:
                txt = payload.decode("cp949", errors="replace")
        except Exception:
            continue
        if ct == "text/plain" and plain is None:
            plain = txt
        elif ct == "text/html" and html is None:
            html = txt
    if plain:
        return plain
    if html:
        html = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
        html = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>", "\n", html)
        html = re.sub(r"(?s)<[^>]+>", " ", html)
        import html as _h
        return _h.unescape(html)
    return ""


def strip_quotes_and_sig(body: str) -> str:
    """새로 작성된 부분만 남긴다. 이 함수가 추출 품질의 절반을 좌우한다."""
    cut = len(body)
    for pat in QUOTE_MARKERS:
        m = pat.search(body)
        if m and m.start() < cut:
            cut = m.start()
    new = body[:cut]
    m = SIG_MARKER.search(new)
    if m and m.start() > 40:          # 본문이 너무 짧으면 서명 절단 안 함
        new = new[:m.start()]
    new = re.sub(r"\n{3,}", "\n\n", new)
    return new.strip()


def norm_subject(subj: str) -> str:
    prev = None
    s = subj or ""
    while prev != s:
        prev = s
        s = SUBJ_PREFIX.sub("", s)
    return re.sub(r"\s+", " ", s).strip()


def parse_addr_list(raw: str | None) -> list[tuple[str, str]]:
    """(표시이름, 메일주소) 목록."""
    out = []
    if not raw:
        return out
    for name, addr in email.utils.getaddresses([_dec_header(raw)]):
        addr = (addr or "").strip().lower()
        if not addr or "@" not in addr:
            continue
        out.append((_dec_header(name), addr))
    return out


SCHEMA = """
CREATE TABLE IF NOT EXISTS message(
  id TEXT PRIMARY KEY,           -- Message-ID 또는 파일 해시
  path TEXT, subject TEXT, subject_norm TEXT,
  sent_at TEXT, thread_id TEXT,
  body TEXT,                     -- 인용문·서명 제거된 신규 본문
  raw_body TEXT,
  from_addr TEXT, from_name TEXT,
  in_reply_to TEXT, refs TEXT,
  extracted INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS participant(
  message_id TEXT, addr TEXT, name TEXT, role TEXT,  -- from|to|cc
  PRIMARY KEY(message_id, addr, role)
);
CREATE TABLE IF NOT EXISTS attachment(
  message_id TEXT, filename TEXT, mime TEXT, size INTEGER, sha256 TEXT
);
CREATE TABLE IF NOT EXISTS person(
  addr TEXT PRIMARY KEY, name TEXT, org TEXT, role TEXT, msg_count INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS node(               -- Case/Decision/ActionItem/Event
  id TEXT PRIMARY KEY, class TEXT, label TEXT, props TEXT
);
CREATE TABLE IF NOT EXISTS triple(             -- 온톨로지 관계 저장소
  s TEXT, s_class TEXT, p TEXT, o TEXT, o_class TEXT,
  message_id TEXT, evidence TEXT, confidence REAL DEFAULT 1.0,
  PRIMARY KEY(s, p, o, message_id)
);
CREATE INDEX IF NOT EXISTS ix_tri_s ON triple(s);
CREATE INDEX IF NOT EXISTS ix_tri_o ON triple(o);
CREATE INDEX IF NOT EXISTS ix_tri_p ON triple(p);
CREATE INDEX IF NOT EXISTS ix_msg_thread ON message(thread_id);
CREATE VIRTUAL TABLE IF NOT EXISTS msg_fts USING fts5(
  id UNINDEXED, subject, body, tokenize='unicode61');
"""


def connect(db_path: str | Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(db_path))
    con.executescript(SCHEMA)
    return con


def ingest_dir(db: sqlite3.Connection, root: str | Path) -> int:
    root = Path(root)
    files = sorted(root.rglob("*.eml"))
    n = 0
    for f in files:
        try:
            n += ingest_file(db, f)
        except Exception as e:            # 한 통 깨져도 전체 중단 금지
            print(f"[skip] {f.name}: {e}")
    db.commit()
    _link_threads(db)
    _rollup_people(db)
    db.commit()
    return n


def ingest_file(db: sqlite3.Connection, path: Path) -> int:
    raw = path.read_bytes()
    msg = email.message_from_bytes(raw, policy=email.policy.compat32)

    mid = _dec_header(msg.get("Message-ID")) or hashlib.sha256(raw).hexdigest()[:32]
    if db.execute("SELECT 1 FROM message WHERE id=?", (mid,)).fetchone():
        return 0                                    # 중복 .eml 제거

    subject = _dec_header(msg.get("Subject"))
    date_raw = msg.get("Date")
    try:
        dt = email.utils.parsedate_to_datetime(date_raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        sent_at = dt.astimezone(timezone.utc).isoformat()
    except Exception:
        sent_at = ""

    raw_body = _body_text(msg)
    body = strip_quotes_and_sig(raw_body)

    frm = parse_addr_list(msg.get("From"))
    from_name, from_addr = (frm[0][0], frm[0][1]) if frm else ("", "")

    db.execute(
        "INSERT INTO message(id,path,subject,subject_norm,sent_at,thread_id,body,"
        "raw_body,from_addr,from_name,in_reply_to,refs) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (mid, str(path), subject, norm_subject(subject), sent_at, "", body, raw_body,
         from_addr, from_name, _dec_header(msg.get("In-Reply-To")),
         _dec_header(msg.get("References"))))
    db.execute("INSERT INTO msg_fts(id,subject,body) VALUES(?,?,?)",
               (mid, subject, body))

    for role, hdr in (("from", "From"), ("to", "To"), ("cc", "Cc")):
        for name, addr in parse_addr_list(msg.get(hdr)):
            db.execute("INSERT OR IGNORE INTO participant VALUES(?,?,?,?)",
                       (mid, addr, name, role))
            db.execute("INSERT OR IGNORE INTO person(addr,name) VALUES(?,?)",
                       (addr, name))

    for part in msg.walk():
        if part.get_content_disposition() != "attachment":
            continue
        fn = _dec_header(part.get_filename()) or "(unnamed)"
        payload = part.get_payload(decode=True) or b""
        db.execute("INSERT INTO attachment VALUES(?,?,?,?,?)",
                   (mid, fn, part.get_content_type(), len(payload),
                    hashlib.sha256(payload).hexdigest()))
    return 1


def _link_threads(db: sqlite3.Connection) -> None:
    """References 우선, 없으면 정규화 제목으로 스레드 묶기 (union-find)."""
    parent: dict[str, str] = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    rows = db.execute("SELECT id,subject_norm,in_reply_to,refs FROM message").fetchall()
    by_subj: dict[str, str] = {}
    for mid, subj, irt, refs in rows:
        find(mid)
        for ref in re.findall(r"<[^>]+>", refs or "") + re.findall(r"<[^>]+>", irt or ""):
            union(ref, mid)
        if subj:
            if subj in by_subj:
                union(by_subj[subj], mid)
            else:
                by_subj[subj] = mid
    for mid, *_ in rows:
        db.execute("UPDATE message SET thread_id=? WHERE id=?", (find(mid), mid))


def _rollup_people(db: sqlite3.Connection) -> None:
    """대표 표시이름(최빈값)과 도메인 기반 소속을 채운다."""
    for (addr,) in db.execute("SELECT addr FROM person").fetchall():
        row = db.execute(
            "SELECT name, COUNT(*) c FROM participant WHERE addr=? AND name!='' "
            "GROUP BY name ORDER BY c DESC LIMIT 1", (addr,)).fetchone()
        name = row[0] if row else addr.split("@")[0]
        cnt = db.execute("SELECT COUNT(*) FROM participant WHERE addr=?",
                         (addr,)).fetchone()[0]
        db.execute("UPDATE person SET name=?, org=?, msg_count=? WHERE addr=?",
                   (name, addr.split("@")[-1], cnt, addr))


if __name__ == "__main__":
    import sys
    db = connect(sys.argv[2] if len(sys.argv) > 2 else "mail.db")
    n = ingest_dir(db, sys.argv[1])
    print(f"적재 완료: {n}통")
