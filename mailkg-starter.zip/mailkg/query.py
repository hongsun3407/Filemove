"""
4단계: 그래프 질의 도구 모음 (에이전트의 tool 이 되는 함수들)

에이전트에게 "SQL을 짜라"고 시키지 않는다. 온톨로지에 맞춰 미리 만든
안전한 질의 함수 8개만 노출한다. 폐쇄망 소형 모델일수록 이 방식이
자유 SQL 생성보다 훨씬 안정적이고, 주입·오작동 위험도 없다.
"""

from __future__ import annotations
import json
import sqlite3


def _label(db, nid):
    r = db.execute("SELECT label FROM node WHERE id=?", (nid,)).fetchone()
    return r[0] if r else nid


# ------------------------------------------------------------------ 도구들
def find_person(db: sqlite3.Connection, name: str) -> list[dict]:
    """이름·메일 일부로 인물 찾기."""
    rows = db.execute(
        "SELECT addr,name,org,msg_count FROM person "
        "WHERE name LIKE ? OR addr LIKE ? ORDER BY msg_count DESC LIMIT 10",
        (f"%{name}%", f"%{name}%")).fetchall()
    return [{"addr": a, "name": n, "org": o, "메일수": c} for a, n, o, c in rows]


def person_network(db: sqlite3.Connection, addr: str, top: int = 10) -> dict:
    """한 사람의 협업 관계망 + 관여 사안."""
    peers = db.execute(
        "SELECT o, confidence FROM triple WHERE s=? AND p='collaboratesWith' "
        "ORDER BY confidence DESC LIMIT ?", (f"person::{addr}", top)).fetchall()
    cases = db.execute(
        "SELECT o, confidence FROM triple WHERE s=? AND p='involvedInCase' "
        "ORDER BY confidence DESC LIMIT ?", (f"person::{addr}", top)).fetchall()
    return {
        "인물": _label(db, f"person::{addr}"),
        "자주 함께 일한 사람": [{"이름": _label(db, p), "공동스레드": int(w)}
                        for p, w in peers],
        "관여 사안": [{"사안": _label(db, c), "메일수": int(w)} for c, w in cases],
    }


def list_cases(db: sqlite3.Connection, top: int = 20) -> list[dict]:
    """사안 목록 (메일 수 순)."""
    rows = db.execute(
        "SELECT o, COUNT(DISTINCT message_id) c FROM triple WHERE p='aboutCase' "
        "GROUP BY o ORDER BY c DESC LIMIT ?", (top,)).fetchall()
    out = []
    for cid, c in rows:
        props = json.loads(db.execute("SELECT props FROM node WHERE id=?",
                                      (cid,)).fetchone()[0] or "{}")
        out.append({"사안": _label(db, cid), "id": cid, "메일수": c,
                    "다른표기": props.get("aliases", [])[:5]})
    return out


def case_timeline(db: sqlite3.Connection, case_id: str) -> dict:
    """한 사안의 시간순 이력: 메일 · 결정 · 업무 · 일정."""
    msgs = db.execute(
        "SELECT m.sent_at, m.subject, m.from_name, m.id FROM triple t "
        "JOIN message m ON m.id=t.message_id "
        "WHERE t.p='aboutCase' AND t.o=? ORDER BY m.sent_at", (case_id,)).fetchall()
    decs = db.execute(
        "SELECT n.id,n.label,n.props FROM triple t JOIN node n ON n.id=t.s "
        "WHERE t.p='relatesToCase' AND t.o=? AND n.class='Decision'",
        (case_id,)).fetchall()
    acts = db.execute(
        "SELECT n.id,n.label,n.props FROM triple t JOIN node n ON n.id=t.s "
        "WHERE t.p='itemOfCase' AND t.o=? AND n.class='ActionItem'",
        (case_id,)).fetchall()
    evts = db.execute(
        "SELECT n.id,n.label,n.props FROM triple t JOIN node n ON n.id=t.s "
        "WHERE t.p='eventOfCase' AND t.o=? AND n.class='Event'", (case_id,)).fetchall()

    def who(nid, rel):
        r = db.execute("SELECT o FROM triple WHERE s=? AND p=?", (nid, rel)).fetchone()
        return _label(db, r[0]) if r else ""

    return {
        "사안": _label(db, case_id),
        "기간": f"{msgs[0][0][:10]} ~ {msgs[-1][0][:10]}" if msgs else "",
        "메일": [{"일자": s[:10], "제목": sub, "발신": frm, "id": mid}
                for s, sub, frm, mid in msgs],
        "의사결정": [{"내용": lb, "구분": json.loads(p or "{}").get("kind", ""),
                  "시점": json.loads(p or "{}").get("decided_at", "")[:10],
                  "결정자": who(i, "decidedBy")} for i, lb, p in decs],
        "액션아이템": [{"내용": lb, "기한": json.loads(p or "{}").get("due", ""),
                   "담당": who(i, "assignedTo") or "미지정",
                   "요청": who(i, "requestedBy")}
                  for i, lb, p in acts],
        "일정": [{"제목": lb, "일시": json.loads(p or "{}").get("starts_at", "")}
               for i, lb, p in evts],
    }


def open_action_items(db: sqlite3.Connection, addr: str = "",
                      before: str = "") -> list[dict]:
    """미완료 액션아이템. addr 지정 시 담당자 필터, before 지정 시 기한 이전."""
    q = ("SELECT n.id,n.label,n.props FROM node n WHERE n.class='ActionItem'")
    rows = db.execute(q).fetchall()
    out = []
    for nid, label, props in rows:
        p = json.loads(props or "{}")
        asg = db.execute("SELECT o FROM triple WHERE s=? AND p='assignedTo'",
                         (nid,)).fetchone()
        if addr and (not asg or asg[0] != f"person::{addr}"):
            continue
        if before and (not p.get("due") or p["due"] > before):
            continue
        case = db.execute("SELECT o FROM triple WHERE s=? AND p='itemOfCase'",
                          (nid,)).fetchone()
        out.append({"내용": label, "기한": p.get("due", ""),
                    "담당": _label(db, asg[0]) if asg else "미지정",
                    "사안": _label(db, case[0]) if case else "",
                    "상태": p.get("status", "")})
    out.sort(key=lambda x: (x["기한"] == "", x["기한"]))
    return out[:50]


def decisions_about(db: sqlite3.Connection, keyword: str = "",
                    since: str = "") -> list[dict]:
    """키워드/기간으로 의사결정 조회."""
    rows = db.execute(
        "SELECT n.id,n.label,n.props FROM node n WHERE n.class='Decision' "
        "AND n.label LIKE ?", (f"%{keyword}%",)).fetchall()
    out = []
    for nid, label, props in rows:
        p = json.loads(props or "{}")
        if since and p.get("decided_at", "") < since:
            continue
        w = db.execute("SELECT o FROM triple WHERE s=? AND p='decidedBy'",
                       (nid,)).fetchone()
        c = db.execute("SELECT o FROM triple WHERE s=? AND p='relatesToCase'",
                       (nid,)).fetchone()
        ev = db.execute("SELECT evidence,message_id FROM triple "
                        "WHERE o=? AND p='statesDecision'", (nid,)).fetchone()
        out.append({"결정": label, "구분": p.get("kind", ""),
                    "시점": p.get("decided_at", "")[:10],
                    "결정자": _label(db, w[0]) if w else "",
                    "사안": _label(db, c[0]) if c else "",
                    "근거": ev[0] if ev else "", "출처메일": ev[1] if ev else ""})
    out.sort(key=lambda x: x["시점"], reverse=True)
    return out[:40]


def search_messages(db: sqlite3.Connection, q: str, limit: int = 10) -> list[dict]:
    """전문검색(FTS5). 그래프에 안 잡힌 내용을 원문에서 찾을 때."""
    rows = db.execute(
        "SELECT m.id,m.sent_at,m.subject,m.from_name,snippet(msg_fts,2,'[',']','…',20) "
        "FROM msg_fts f JOIN message m ON m.id=f.id "
        "WHERE msg_fts MATCH ? ORDER BY rank LIMIT ?", (q, limit)).fetchall()
    return [{"id": i, "일자": s[:10], "제목": sub, "발신": frm, "발췌": sn}
            for i, s, sub, frm, sn in rows]


def read_message(db: sqlite3.Connection, message_id: str) -> dict:
    """메일 원문 확인 (근거 제시용)."""
    r = db.execute("SELECT subject,sent_at,from_name,from_addr,body,path "
                   "FROM message WHERE id=?", (message_id,)).fetchone()
    if not r:
        return {"오류": "해당 메일 없음"}
    to = [f"{n or a}" for n, a in db.execute(
        "SELECT name,addr FROM participant WHERE message_id=? AND role='to'",
        (message_id,)).fetchall()]
    return {"제목": r[0], "일자": r[1][:16], "발신": f"{r[2]} <{r[3]}>",
            "수신": to, "본문": r[4][:3000], "파일": r[5]}


TOOLS = {
    "find_person": (find_person, "이름이나 메일 일부로 인물 검색", ["name"]),
    "person_network": (person_network, "인물의 협업 관계망과 관여 사안", ["addr"]),
    "list_cases": (list_cases, "사안 목록을 메일 수 순으로", []),
    "case_timeline": (case_timeline, "사안 하나의 전체 이력(메일/결정/업무/일정)", ["case_id"]),
    "open_action_items": (open_action_items, "미완료 액션아이템 조회", []),
    "decisions_about": (decisions_about, "키워드/기간으로 의사결정 조회", []),
    "search_messages": (search_messages, "메일 본문 전문검색", ["q"]),
    "read_message": (read_message, "메일 원문 읽기", ["message_id"]),
}


def tool_specs() -> list[dict]:
    """Ollama tools= 인자용 스펙."""
    specs = []
    for name, (fn, desc, req) in TOOLS.items():
        import inspect
        params = {}
        for pname, p in list(inspect.signature(fn).parameters.items())[1:]:
            t = "integer" if p.annotation is int else "string"
            params[pname] = {"type": t}
        specs.append({"type": "function", "function": {
            "name": name, "description": desc,
            "parameters": {"type": "object", "properties": params, "required": req}}})
    return specs


def call_tool(db: sqlite3.Connection, name: str, args: dict):
    fn = TOOLS[name][0]
    return fn(db, **args)
