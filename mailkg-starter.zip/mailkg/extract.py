"""
2단계: 본문 → 온톨로지 인스턴스 추출

설계 요점
---------
* 구조 관계(발신/수신/참조/스레드)는 절대 LLM에 맡기지 않는다. 헤더로 확정.
  LLM은 "본문 안에만 있는 것"(사안·결정·업무·일정)만 담당한다.
* Ollama의 format=<JSON Schema> 로 구조화 출력을 강제한다.
  스키마는 ontology.py 한 곳에서 나온다.
* 모든 추출 항목은 evidence(본문 원문 인용)를 갖는다.
  → 근거 문자열이 실제 본문에 없으면 환각으로 보고 버린다. (아래 _verify)
* 실패/타임아웃은 건너뛰고 extracted=0 으로 남겨 재실행 시 이어서 처리한다.
"""

from __future__ import annotations
import json
import re
import sqlite3
from datetime import datetime

from .llm import LLM
from .ontology import SYSTEM_PROMPT, extraction_json_schema


# ------------------------------------------------------------------ LLM 호출
def make_llm(client: LLM | None = None):
    """LiteLLM 프록시를 쓰는 추출기를 만든다.
    반환 함수는 rule_extract 와 동일한 시그니처라 서로 갈아끼울 수 있다."""
    client = client or LLM()

    def _call(system: str, user: str, schema: dict | None = None,
              model: str | None = None) -> str:
        if schema is None:
            return client.complete(system, user)
        return json.dumps(client.structured(system, user, schema,
                                            name="mail_extraction"),
                          ensure_ascii=False)
    return _call


def _norm(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def _verify(item: dict, body: str) -> bool:
    """근거 검증: evidence 가 본문에 실제로 존재해야 채택."""
    ev = _norm(item.get("evidence", ""))
    if len(ev) < 6:
        return False
    return ev[:60] in _norm(body)


def build_user_prompt(subject: str, sent_at: str, sender: str,
                      recipients: str, body: str) -> str:
    return (f"[발신자] {sender}\n"
            f"[수신자] {recipients}\n"
            f"[발신일] {sent_at}\n"
            f"[제목] {subject}\n"
            f"[본문]\n{body[:6000]}\n")


def extract_message(db: sqlite3.Connection, mid: str, model: str | None = None,
                    llm=None) -> dict:
    llm = llm or make_llm()
    row = db.execute(
        "SELECT subject, sent_at, from_name, from_addr, body FROM message WHERE id=?",
        (mid,)).fetchone()
    subject, sent_at, fname, faddr, body = row
    if len((body or "").strip()) < 15:
        return {"cases": [], "decisions": [], "action_items": [],
                "events": [], "people": []}

    recips = ", ".join(
        f"{n or a}" for n, a in db.execute(
            "SELECT name, addr FROM participant WHERE message_id=? AND role IN"
            "('to','cc')", (mid,)).fetchall())

    prompt = build_user_prompt(subject, sent_at[:10], f"{fname} <{faddr}>",
                              recips, body)
    raw = llm(SYSTEM_PROMPT, prompt, extraction_json_schema(), model)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", raw, re.S)
        data = json.loads(m.group()) if m else {}

    # 환각 필터: 근거가 제목/본문 어디에도 없는 항목 제거
    source = f"{subject}\n{body}"
    for key in ("cases", "decisions", "action_items", "events"):
        data[key] = [it for it in data.get(key, []) if _verify(it, source)]
    data.setdefault("people", [])
    return data


def extract_all(db: sqlite3.Connection, model: str | None = None, llm=None,
                limit: int | None = None, verbose: bool = True) -> int:
    llm = llm or make_llm()
    ids = [r[0] for r in db.execute(
        "SELECT id FROM message WHERE extracted=0 ORDER BY sent_at").fetchall()]
    if limit:
        ids = ids[:limit]
    done = fail = 0
    for i, mid in enumerate(ids, 1):
        try:
            data = extract_message(db, mid, model, llm)
        except Exception as e:
            fail += 1
            if verbose:
                print(f"[{i}/{len(ids)}] 실패 {mid}: {str(e)[:160]}")
            if fail >= 5 and done == 0:
                raise RuntimeError(
                    "연속 실패. `python run.py doctor` 로 게이트웨이 연결을 먼저 점검하세요.")
            continue
        db.execute("UPDATE message SET extracted=1 WHERE id=?", (mid,))
        db.execute("INSERT OR REPLACE INTO node(id,class,label,props) VALUES(?,?,?,?)",
                   (f"raw::{mid}", "_Extraction", mid, json.dumps(data, ensure_ascii=False)))
        db.commit()
        done += 1
        if verbose and i % 20 == 0:
            print(f"  {i}/{len(ids)} 처리")
    return done


# ------------------------------------------------------------- 규칙 기반 대체기
# LLM 없이 파이프라인 전체를 검증하거나, LLM 결과를 교차검증할 때 쓴다.
_DEC = re.compile(r"(승인|반려|확정|보류|취소|변경)(합니다|하였습니다|했습니다|됨|되었습니다|드립니다)")
_REQ = re.compile(r"(해\s?주(시기|시길|세요|십시오|시면)|부탁(드립니다|드려요)|요청(드립니다|합니다)|"
                  r"까지\s?(제출|회신|송부|완료|공유))")
_DUE = re.compile(r"(\d{1,2})\s*월\s*(\d{1,2})\s*일|(\d{4})[-./](\d{1,2})[-./](\d{1,2})")
_EVT = re.compile(r"(회의|미팅|킥오프|점검회의|보고회|워크숍|간담회|설명회)")
_KIND = {"승인": "승인", "반려": "반려", "확정": "확정", "보류": "보류",
         "취소": "변경", "변경": "변경"}


def rule_extract(system, user, schema=None, model=None) -> str:
    """ollama_chat 과 동일한 시그니처의 규칙 기반 추출기."""
    body = user.split("[본문]\n", 1)[-1]
    subject = re.search(r"\[제목\]\s*(.*)", user)
    subject = subject.group(1).strip() if subject else ""
    sent = re.search(r"\[발신일\]\s*(\S+)", user)
    year = sent.group(1)[:4] if sent else str(datetime.now().year)

    from .parse import norm_subject
    base = norm_subject(subject)
    m_tag = re.match(r"^\[([^\]]{2,40})\]", base)     # [사업명] 말머리 우선
    case_name = (m_tag.group(1) if m_tag
                 else re.split(r"[-–—:|]", base)[0]).strip()[:40]
    cases, decisions, actions, events = [], [], [], []
    if len(case_name) >= 4:
        cases.append({"name": case_name, "aliases": [], "evidence": subject})

    for line in [l.strip() for l in body.splitlines() if l.strip()]:
        if _DEC.search(line):
            k = _DEC.search(line).group(1)
            decisions.append({"statement": line[:120], "kind": _KIND.get(k, "확정"),
                              "decided_by": "", "case": case_name, "evidence": line})
        if _REQ.search(line):
            d = _DUE.search(line)
            due = ""
            if d:
                due = (f"{year}-{int(d.group(1)):02d}-{int(d.group(2)):02d}"
                       if d.group(1) else
                       f"{d.group(3)}-{int(d.group(4)):02d}-{int(d.group(5)):02d}")
            actions.append({"statement": line[:120], "assigned_to": "",
                            "requested_by": "", "due": due, "case": case_name,
                            "evidence": line})
        if _EVT.search(line) and _DUE.search(line):
            d = _DUE.search(line)
            starts = (f"{year}-{int(d.group(1)):02d}-{int(d.group(2)):02d}"
                      if d.group(1) else
                      f"{d.group(3)}-{int(d.group(4)):02d}-{int(d.group(5)):02d}")
            events.append({"title": _EVT.search(line).group(1), "starts_at": starts,
                           "location": "", "case": case_name, "evidence": line})
    return json.dumps({"cases": cases, "decisions": decisions,
                       "action_items": actions, "events": events, "people": []},
                      ensure_ascii=False)
