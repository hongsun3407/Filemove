"""
LLM 접속 계층 — LiteLLM 프록시(OpenAI 호환) 전용

폐쇄망 게이트웨이는 배포마다 지원 범위가 다릅니다. 같은 Qwen이어도
백엔드가 vLLM이냐 llama.cpp냐, 구동 옵션에 --enable-auto-tool-choice가
붙었느냐에 따라 아래 세 가지가 되기도 하고 안 되기도 합니다.

    · response_format = json_schema   (구조화 출력 강제)
    · response_format = json_object   (JSON만 강제)
    · tools = [...]                   (네이티브 tool calling)

그래서 이 모듈은 "되는 것부터 쓰고, 안 되면 자동으로 한 단계 내려가는"
구조로 만듭니다. 한 번 감지한 결과는 캐시해서 매 호출마다 재시도하지 않습니다.
설정은 환경변수 또는 mailkg.config.json 한 곳에서만 읽습니다.
"""

from __future__ import annotations
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

CONFIG_FILE = Path(os.environ.get("MAILKG_CONFIG", "mailkg.config.json"))

# Qwen3 계열은 사고 과정을 <think>...</think> 로 흘립니다. 게이트웨이가
# 걸러주지 않는 경우가 많아 클라이언트에서 제거합니다.
THINK = re.compile(r"<think>.*?</think>\s*", re.S)
THINK_OPEN = re.compile(r"<think>.*", re.S)


class LLMError(RuntimeError):
    pass


@dataclass
class LLMConfig:
    base_url: str = "http://localhost:4000"
    api_key: str = ""
    model: str = "qwen3-32b"
    timeout: int = 300
    max_retries: int = 3
    temperature: float = 0.0
    max_tokens: int = 2048
    verify_ssl: bool = True
    ca_bundle: str = ""            # 사설 인증서 경로 (사내 HTTPS 프록시)
    # 자동 감지 결과를 여기에 고정할 수도 있다 (감지 생략)
    supports_json_schema: bool | None = None
    supports_json_object: bool | None = None
    supports_tools: bool | None = None
    disable_thinking: bool = True  # Qwen3 하이브리드 사고 모드 끄기

    @property
    def chat_url(self) -> str:
        base = self.base_url.rstrip("/")
        if base.endswith("/v1"):
            return base + "/chat/completions"
        return base + "/v1/chat/completions"

    @property
    def models_url(self) -> str:
        base = self.base_url.rstrip("/")
        return (base + "/models") if base.endswith("/v1") else (base + "/v1/models")

    @classmethod
    def load(cls, path: Path | str = CONFIG_FILE) -> "LLMConfig":
        data: dict = {}
        p = Path(path)
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
        # 환경변수가 파일보다 우선 (운영 시 키를 파일에 남기지 않기 위함)
        env = {
            "base_url": os.environ.get("MAILKG_BASE_URL") or os.environ.get("LITELLM_BASE_URL"),
            "api_key": os.environ.get("MAILKG_API_KEY") or os.environ.get("LITELLM_API_KEY"),
            "model": os.environ.get("MAILKG_MODEL"),
        }
        data.update({k: v for k, v in env.items() if v})
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})

    def save(self, path: Path | str = CONFIG_FILE) -> None:
        d = {k: getattr(self, k) for k in self.__dataclass_fields__}
        d["api_key"] = ""          # 키는 파일에 저장하지 않는다
        Path(path).write_text(json.dumps(d, ensure_ascii=False, indent=2),
                              encoding="utf-8")


def _ssl_ctx(cfg: LLMConfig):
    if not cfg.base_url.lower().startswith("https"):
        return None
    if cfg.ca_bundle:
        return ssl.create_default_context(cafile=cfg.ca_bundle)
    if not cfg.verify_ssl:
        c = ssl.create_default_context()
        c.check_hostname = False
        c.verify_mode = ssl.CERT_NONE
        return c
    return ssl.create_default_context()


def _post(cfg: LLMConfig, url: str, body: dict) -> dict:
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if cfg.api_key:
        headers["Authorization"] = f"Bearer {cfg.api_key}"
        headers["api-key"] = cfg.api_key          # 일부 게이트웨이는 이 헤더를 씀
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    last = None
    for attempt in range(cfg.max_retries):
        try:
            with urllib.request.urlopen(req, timeout=cfg.timeout,
                                        context=_ssl_ctx(cfg)) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:600]
            if e.code in (401, 403):
                raise LLMError(f"인증 실패({e.code}). API 키를 확인하세요.\n{detail}")
            if e.code == 400:
                raise LLMError(f"요청 거부(400): {detail}")   # 기능 미지원 판정에 사용
            if e.code == 404:
                raise LLMError(f"경로/모델 없음(404): {detail}")
            last = LLMError(f"HTTP {e.code}: {detail}")
        except urllib.error.URLError as e:
            last = LLMError(f"접속 실패: {e.reason} → {url}")
        except TimeoutError:
            last = LLMError(f"응답 시간 초과({cfg.timeout}s)")
        if attempt < cfg.max_retries - 1:
            time.sleep(1.5 * (attempt + 1))
    raise last or LLMError("알 수 없는 오류")


def list_models(cfg: LLMConfig) -> list[str]:
    headers = {}
    if cfg.api_key:
        headers["Authorization"] = f"Bearer {cfg.api_key}"
    req = urllib.request.Request(cfg.models_url, headers=headers)
    with urllib.request.urlopen(req, timeout=30, context=_ssl_ctx(cfg)) as r:
        data = json.loads(r.read().decode("utf-8"))
    return [m.get("id", "") for m in data.get("data", [])]


def _clean(text: str) -> str:
    """<think> 블록 제거. 닫히지 않은 채 잘린 경우까지 처리."""
    text = THINK.sub("", text or "")
    if "<think>" in text:
        text = THINK_OPEN.sub("", text)
    return text.strip()


def _extra(cfg: LLMConfig) -> dict:
    """Qwen3 사고 모드 억제. 미지원 게이트웨이는 이 필드를 그냥 무시합니다."""
    if not cfg.disable_thinking:
        return {}
    return {"chat_template_kwargs": {"enable_thinking": False}}


class LLM:
    """LiteLLM 프록시 클라이언트. 기능 지원 여부를 한 번만 감지해 캐시합니다."""

    def __init__(self, cfg: LLMConfig | None = None):
        self.cfg = cfg or LLMConfig.load()
        self._probed = False

    # ---------------------------------------------------------- 기본 대화
    def chat(self, messages: list[dict], tools: list[dict] | None = None,
             response_format: dict | None = None, temperature: float | None = None,
             max_tokens: int | None = None) -> dict:
        body = {
            "model": self.cfg.model,
            "messages": messages,
            "temperature": self.cfg.temperature if temperature is None else temperature,
            "max_tokens": max_tokens or self.cfg.max_tokens,
            "stream": False,
            **_extra(self.cfg),
        }
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"
        if response_format:
            body["response_format"] = response_format
        resp = _post(self.cfg, self.cfg.chat_url, body)
        try:
            msg = resp["choices"][0]["message"]
        except (KeyError, IndexError):
            raise LLMError(f"응답 형식이 예상과 다릅니다: {str(resp)[:400]}")
        msg["content"] = _clean(msg.get("content") or "")
        msg["_usage"] = resp.get("usage", {})
        return msg

    def complete(self, system: str, user: str, **kw) -> str:
        return self.chat([{"role": "system", "content": system},
                          {"role": "user", "content": user}], **kw)["content"]

    # ---------------------------------------------------------- 기능 감지
    def probe(self, verbose: bool = False) -> dict:
        """게이트웨이가 무엇까지 지원하는지 한 번만 확인하고 캐시."""
        if self._probed:
            return self.capabilities
        c = self.cfg
        tiny = [{"role": "user", "content": '{"ok":true} 만 출력해.'}]

        if c.supports_json_schema is None:
            schema = {"type": "object", "properties": {"ok": {"type": "boolean"}},
                      "required": ["ok"]}
            try:
                out = self.chat(tiny, response_format={
                    "type": "json_schema",
                    "json_schema": {"name": "probe", "schema": schema, "strict": True}},
                    max_tokens=64)
                json.loads(out["content"])
                c.supports_json_schema = True
            except Exception as e:
                c.supports_json_schema = False
                if verbose:
                    print(f"  json_schema 미지원: {str(e)[:120]}")

        if c.supports_json_object is None:
            if c.supports_json_schema:
                c.supports_json_object = True
            else:
                try:
                    out = self.chat(tiny, response_format={"type": "json_object"},
                                    max_tokens=64)
                    json.loads(out["content"])
                    c.supports_json_object = True
                except Exception as e:
                    c.supports_json_object = False
                    if verbose:
                        print(f"  json_object 미지원: {str(e)[:120]}")

        if c.supports_tools is None:
            probe_tool = [{"type": "function", "function": {
                "name": "get_time", "description": "현재 시각을 반환",
                "parameters": {"type": "object", "properties": {}}}}]
            try:
                out = self.chat([{"role": "user", "content": "지금 몇 시야? 도구를 써."}],
                                tools=probe_tool, max_tokens=128)
                c.supports_tools = bool(out.get("tool_calls"))
            except Exception as e:
                c.supports_tools = False
                if verbose:
                    print(f"  tools 미지원: {str(e)[:120]}")

        self._probed = True
        return self.capabilities

    @property
    def capabilities(self) -> dict:
        return {"json_schema": self.cfg.supports_json_schema,
                "json_object": self.cfg.supports_json_object,
                "tools": self.cfg.supports_tools}

    # ------------------------------------------------- 구조화 출력 (3단 폴백)
    def structured(self, system: str, user: str, schema: dict,
                   name: str = "output") -> dict:
        """스키마에 맞는 dict 를 반드시 돌려준다. 게이트웨이 지원 수준에 맞춰 하강."""
        self.probe()
        c = self.cfg

        if c.supports_json_schema:
            try:
                txt = self.complete(system, user, response_format={
                    "type": "json_schema",
                    "json_schema": {"name": name, "schema": schema, "strict": False}})
                return _loads(txt)
            except Exception:
                c.supports_json_schema = False      # 한 번 실패하면 강등

        hint = ("\n\n반드시 아래 JSON 스키마에 맞는 JSON 객체 하나만 출력한다. "
                "설명 문장, 코드펜스, 주석 금지.\n"
                + json.dumps(schema, ensure_ascii=False))
        if c.supports_json_object:
            try:
                txt = self.complete(system + hint, user,
                                    response_format={"type": "json_object"})
                return _loads(txt)
            except Exception:
                c.supports_json_object = False

        txt = self.complete(system + hint, user)
        return _loads(txt)


def _loads(text: str) -> dict:
    """코드펜스·앞뒤 잡담이 섞여도 JSON 객체를 건져낸다."""
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    depth, start = 0, -1
    for i, ch in enumerate(text):
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                try:
                    return json.loads(text[start:i + 1])
                except json.JSONDecodeError:
                    start = -1
    raise LLMError(f"JSON 파싱 실패: {text[:300]}")
