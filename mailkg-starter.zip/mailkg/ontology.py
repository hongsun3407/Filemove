"""
mail-kg 온톨로지 정의 (Ontology-as-code)

핵심 원칙
---------
1) 온톨로지는 '코드 한 곳'에서만 정의한다. 여기서 정의한 스키마가
   - LLM 추출 프롬프트의 JSON 스키마
   - SQLite 트리플 저장소의 검증 규칙
   - 그래프 질의 도구의 어휘
   세 곳에 그대로 재사용된다. (스키마 드리프트 방지)

2) 클래스/관계 이름은 한국어 업무 용어를 그대로 쓰되, IRI는 영문으로 둔다.
   폐쇄망 조직 용어에 맞춰 label 만 바꾸면 된다.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal

NS = "http://local.kg/mail#"


@dataclass(frozen=True)
class ClassDef:
    name: str
    label: str
    desc: str
    props: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class RelDef:
    name: str
    label: str
    domain: str
    range: str
    desc: str
    # derived=True 인 관계는 LLM이 뽑지 않고 그래프 연산으로 만든다
    derived: bool = False


# ---------------------------------------------------------------- 클래스
CLASSES: list[ClassDef] = [
    ClassDef("Person", "인물", "메일 송수신 주체인 개인",
             {"name": "표시 이름", "email": "대표 메일주소", "org": "소속(추정)",
              "role": "직위/역할(본문에서 추정)"}),
    ClassDef("Organization", "조직", "부서·기관·업체",
             {"name": "조직명", "domain": "메일 도메인", "kind": "내부부서|외부기관|업체"}),
    ClassDef("Message", "메일", "개별 .eml 한 통",
             {"subject": "제목", "sent_at": "발신시각", "thread_id": "스레드 키",
              "path": "원본 파일 경로"}),
    ClassDef("Thread", "스레드", "제목/References 로 묶인 대화 묶음",
             {"subject_norm": "정규화 제목", "first_at": "최초", "last_at": "최종"}),
    ClassDef("Case", "사안", "프로젝트·과제·안건 등 지속되는 업무 단위",
             {"name": "사안명", "aliases": "약칭 목록", "status": "진행|보류|종료"}),
    ClassDef("Decision", "의사결정", "확정·승인·반려 등 결정 사실",
             {"statement": "결정 내용 한 문장", "decided_at": "결정 시점",
              "kind": "승인|반려|확정|변경|보류"}),
    ClassDef("ActionItem", "액션아이템", "요청받은/지시된 실행 업무",
             {"statement": "업무 내용", "due": "기한(YYYY-MM-DD)",
              "status": "요청됨|진행중|완료|기한초과"}),
    ClassDef("Event", "일정", "회의·마감·방문 등 시점이 있는 사건",
             {"title": "일정명", "starts_at": "시작", "location": "장소"}),
    ClassDef("Attachment", "첨부", "첨부 파일",
             {"filename": "파일명", "mime": "MIME", "size": "바이트", "sha256": "해시"}),
]

# ---------------------------------------------------------------- 관계
RELATIONS: list[RelDef] = [
    # --- 구조 관계: 헤더에서 100% 규칙으로 확정 (LLM 불필요, 오류 0)
    RelDef("sentBy",      "발신",      "Message", "Person", "From"),
    RelDef("sentTo",      "수신",      "Message", "Person", "To"),
    RelDef("copiedTo",    "참조",      "Message", "Person", "Cc"),
    RelDef("inReplyTo",   "회신대상",  "Message", "Message", "In-Reply-To/References"),
    RelDef("partOfThread","스레드소속","Message", "Thread", "스레드 묶음"),
    RelDef("hasAttachment","첨부보유", "Message", "Attachment", "첨부 파일"),
    RelDef("memberOf",    "소속",      "Person", "Organization", "메일 도메인/서명 기반"),

    # --- 의미 관계: LLM이 본문에서 추출 (근거 문장 필수)
    RelDef("aboutCase",   "사안관련",  "Message", "Case", "이 메일이 다루는 사안"),
    RelDef("statesDecision","결정포함","Message", "Decision", "본문에 담긴 결정"),
    RelDef("requestsItem","업무요청",  "Message", "ActionItem", "본문의 요청/지시"),
    RelDef("announcesEvent","일정공지","Message", "Event", "본문의 일정"),
    RelDef("decidedBy",   "결정자",    "Decision", "Person", "결정 주체"),
    RelDef("assignedTo",  "담당자",    "ActionItem", "Person", "수행 주체"),
    RelDef("requestedBy", "요청자",    "ActionItem", "Person", "요청 주체"),
    RelDef("relatesToCase","사안귀속", "Decision", "Case", "결정이 속한 사안"),
    RelDef("itemOfCase",  "사안귀속",  "ActionItem", "Case", "업무가 속한 사안"),
    RelDef("eventOfCase", "사안귀속",  "Event", "Case", "일정이 속한 사안"),
    RelDef("supersededBy","후속결정",  "Decision", "Decision", "번복/갱신된 결정"),

    # --- 파생 관계: 그래프 연산으로 계산
    RelDef("collaboratesWith", "협업", "Person", "Person",
           "동일 스레드 공동 참여 횟수 가중", derived=True),
    RelDef("involvedInCase", "사안참여", "Person", "Case",
           "사안 메일 참여 빈도", derived=True),
]

CLASS_BY_NAME = {c.name: c for c in CLASSES}
REL_BY_NAME = {r.name: r for r in RELATIONS}

# LLM이 추출해야 하는 의미 관계만 추린 목록
EXTRACTED_RELATIONS = [r for r in RELATIONS if not r.derived
                       and r.name in {"aboutCase", "statesDecision", "requestsItem",
                                      "announcesEvent", "decidedBy", "assignedTo",
                                      "requestedBy"}]


def validate_triple(s_class: str, rel: str, o_class: str) -> bool:
    """온톨로지 정합성 검사. LLM 환각을 그래프 적재 직전에 거른다."""
    r = REL_BY_NAME.get(rel)
    if r is None:
        return False
    return r.domain == s_class and r.range == o_class


def to_turtle() -> str:
    """RDF/OWL 로 내보내기 (Protege 등에서 열어 검토·수정할 때 사용)."""
    lines = [
        "@prefix mail: <%s> ." % NS,
        "@prefix owl:  <http://www.w3.org/2002/07/owl#> .",
        "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .",
        "",
    ]
    for c in CLASSES:
        lines.append(f"mail:{c.name} a owl:Class ;")
        lines.append(f'    rdfs:label "{c.label}"@ko ;')
        lines.append(f'    rdfs:comment "{c.desc}"@ko .')
        lines.append("")
    for r in RELATIONS:
        lines.append(f"mail:{r.name} a owl:ObjectProperty ;")
        lines.append(f'    rdfs:label "{r.label}"@ko ;')
        lines.append(f"    rdfs:domain mail:{r.domain} ;")
        lines.append(f"    rdfs:range  mail:{r.range} .")
        lines.append("")
    return "\n".join(lines)


def extraction_json_schema() -> dict:
    """LLM 구조화 출력용 JSON Schema. Ollama format= 인자에 그대로 넣는다."""
    return {
        "type": "object",
        "properties": {
            "cases": {
                "type": "array",
                "description": "이 메일이 다루는 사안/과제. 없으면 빈 배열.",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "사안 정식 명칭"},
                        "aliases": {"type": "array", "items": {"type": "string"}},
                        "evidence": {"type": "string", "description": "근거가 된 본문 원문"},
                    },
                    "required": ["name", "evidence"],
                },
            },
            "decisions": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "statement": {"type": "string"},
                        "kind": {"type": "string",
                                 "enum": ["승인", "반려", "확정", "변경", "보류"]},
                        "decided_by": {"type": "string", "description": "결정한 사람 이름"},
                        "case": {"type": "string"},
                        "evidence": {"type": "string"},
                    },
                    "required": ["statement", "kind", "evidence"],
                },
            },
            "action_items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "statement": {"type": "string"},
                        "assigned_to": {"type": "string"},
                        "requested_by": {"type": "string"},
                        "due": {"type": "string", "description": "YYYY-MM-DD, 모르면 빈 문자열"},
                        "case": {"type": "string"},
                        "evidence": {"type": "string"},
                    },
                    "required": ["statement", "evidence"],
                },
            },
            "events": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "starts_at": {"type": "string",
                                      "description": "YYYY-MM-DD HH:MM, 모르면 날짜만"},
                        "location": {"type": "string"},
                        "case": {"type": "string"},
                        "evidence": {"type": "string"},
                    },
                    "required": ["title", "evidence"],
                },
            },
            "people": {
                "type": "array",
                "description": "본문에서 언급된 인물의 이름·직위·소속",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "role": {"type": "string"},
                        "org": {"type": "string"},
                    },
                    "required": ["name"],
                },
            },
        },
        "required": ["cases", "decisions", "action_items", "events", "people"],
    }


SYSTEM_PROMPT = """당신은 사내 이메일에서 지식그래프용 사실을 추출하는 도구다.

규칙:
1. 주어진 온톨로지에 정의된 항목만 추출한다. 새로운 항목 유형을 만들지 않는다.
2. 본문에 명시되지 않은 내용은 절대 추론해서 채우지 않는다. 모르면 빈 문자열/빈 배열.
3. 모든 항목에는 반드시 근거(evidence)로 본문 원문을 그대로 인용한다. 요약·의역 금지.
4. 인용 부호(>)로 시작하는 이전 메일 인용문에서는 추출하지 않는다. 새로 쓴 본문만 본다.
5. 날짜는 메일 발신일 기준으로 해석해 절대 날짜(YYYY-MM-DD)로 정규화한다.
   ("다음 주 화요일" → 발신일 기준 계산)
6. 출력은 지정된 JSON 스키마만. 설명 문장을 덧붙이지 않는다.

온톨로지 항목 정의:
- 사안(Case): 여러 메일에 걸쳐 지속되는 프로젝트/과제/안건. 일회성 잡담은 사안이 아니다.
- 의사결정(Decision): 승인/반려/확정/변경/보류가 실제로 일어난 사실. 제안·의견은 결정이 아니다.
- 액션아이템(ActionItem): 특정인에게 요청·지시된 실행 업무. 단순 정보 공유는 아니다.
- 일정(Event): 시점이 있는 회의·마감·방문.
"""
