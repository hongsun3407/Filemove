"""
연결 진단 — 폐쇄망에서 "왜 안 되는지"를 5분 안에 좁힌다.

점검 순서는 실패 원인이 갈리는 순서대로다.
  1) 네트워크 도달   → 방화벽/포트/호스트 문제
  2) 인증           → API 키 문제
  3) 모델 목록       → 모델 별칭(alias) 오타
  4) 한국어 응답     → 모델 자체 문제
  5) JSON 스키마     → 추출 단계 동작 방식 결정
  6) tool calling   → 에이전트 동작 방식 결정
  7) 실제 추출 1건   → 전 구간 확인
"""

from __future__ import annotations
import json
import socket
import time
import urllib.parse

from .llm import LLM, LLMConfig, LLMError, list_models
from .ontology import SYSTEM_PROMPT, extraction_json_schema

OK, NO, WARN = "  ✅", "  ❌", "  ⚠️ "

SAMPLE = """[발신자] 김철수 팀장 <cs.kim@corp.go.kr>
[수신자] 이영희
[발신일] 2026-03-18
[제목] [차세대 관제시스템] 킥오프 회의 결과
[본문]
킥오프 회의 결과 공유드립니다.
1. 요구사항 정의서 v0.1 승인합니다.
2. 외부 연계 방식은 REST 로 확정합니다.
이영희 선임은 3월 27일까지 연계 규격서를 송부해 주세요.
"""


def run(cfg: LLMConfig | None = None) -> bool:
    cfg = cfg or LLMConfig.load()
    print(f"\n대상: {cfg.base_url}  ·  모델: {cfg.model}  "
          f"·  키: {'설정됨' if cfg.api_key else '없음'}\n")

    # 1) 도달성 -------------------------------------------------------------
    u = urllib.parse.urlparse(cfg.base_url)
    host = u.hostname or "localhost"
    port = u.port or (443 if u.scheme == "https" else 80)
    print("1. 네트워크 도달")
    t0 = time.time()
    try:
        with socket.create_connection((host, port), timeout=5):
            print(f"{OK} {host}:{port} 접속 가능 ({(time.time()-t0)*1000:.0f}ms)")
    except Exception as e:
        print(f"{NO} {host}:{port} 접속 불가 — {e}")
        print("     · LiteLLM 프록시가 떠 있는지: curl http://<host>:4000/health")
        print("     · 다른 PC에서 접속한다면 LiteLLM을 --host 0.0.0.0 으로 띄웠는지")
        print("     · 사내 방화벽에서 4000 포트가 열려 있는지")
        return False

    client = LLM(cfg)

    # 2~3) 인증 + 모델 목록 --------------------------------------------------
    print("\n2. 인증 및 모델 목록")
    try:
        models = list_models(cfg)
        print(f"{OK} 인증 성공 · 등록된 모델 {len(models)}개")
        for m in models[:12]:
            mark = " ←현재 설정" if m == cfg.model else ""
            print(f"     - {m}{mark}")
        if models and cfg.model not in models:
            print(f"{WARN}설정한 모델 '{cfg.model}' 이 목록에 없습니다.")
            print(f"     LiteLLM config.yaml 의 model_name 값을 그대로 쓰세요.")
            print(f"     예: python run.py config --model {models[0]}")
    except Exception as e:
        print(f"{WARN}모델 목록 조회 실패 — {str(e)[:200]}")
        print("     (일부 게이트웨이는 /v1/models 를 막아둡니다. 계속 진행합니다.)")

    # 4) 한국어 응답 ---------------------------------------------------------
    print("\n3. 한국어 응답")
    try:
        t0 = time.time()
        out = client.complete("간결하게 답하라.", "대한민국의 수도는? 한 단어로.",
                              max_tokens=64)
        dt = time.time() - t0
        if not out:
            print(f"{NO} 빈 응답. max_tokens 또는 사고 모드 설정을 확인하세요.")
            return False
        print(f"{OK} 응답 OK ({dt:.1f}s) → {out[:60]!r}")
        if dt > 20:
            print(f"{WARN}응답이 느립니다. 8통만 추출해도 {dt*8/60:.0f}분 이상 걸립니다.")
    except LLMError as e:
        print(f"{NO} {e}")
        return False

    # 5~6) 기능 감지 ---------------------------------------------------------
    print("\n4. 게이트웨이 기능 감지")
    caps = client.probe(verbose=False)
    print(f"{OK if caps['json_schema'] else WARN} "
          f"json_schema 구조화 출력: {'지원' if caps['json_schema'] else '미지원'}")
    print(f"{OK if caps['json_object'] else WARN} "
          f"json_object 강제:        {'지원' if caps['json_object'] else '미지원'}")
    print(f"{OK if caps['tools'] else WARN} "
          f"네이티브 tool calling:   {'지원' if caps['tools'] else '미지원'}")

    if not caps["json_schema"] and not caps["json_object"]:
        print("     → 추출은 프롬프트 지시 + JSON 추출 폴백으로 동작합니다.")
        print("       vLLM 백엔드라면 구동 옵션에 --guided-decoding-backend 를 켜면")
        print("       추출 안정성이 눈에 띄게 올라갑니다.")
    if not caps["tools"]:
        print("     → 에이전트는 JSON 지시 루프로 동작합니다(실용 수준).")
        print("       vLLM 이라면 --enable-auto-tool-choice --tool-call-parser hermes")
        print("       두 옵션을 주고 재기동하면 네이티브 모드가 켜집니다.")

    # 7) 실제 추출 1건 -------------------------------------------------------
    print("\n5. 실제 추출 시연 (샘플 메일 1통)")
    try:
        t0 = time.time()
        data = client.structured(SYSTEM_PROMPT, SAMPLE, extraction_json_schema(),
                                 name="mail_extraction")
        dt = time.time() - t0
        n = {k: len(data.get(k, [])) for k in
             ("cases", "decisions", "action_items", "events")}
        print(f"{OK} 추출 성공 ({dt:.1f}s) — 사안 {n['cases']} · 결정 {n['decisions']}"
              f" · 업무 {n['action_items']} · 일정 {n['events']}")
        for d in data.get("decisions", [])[:3]:
            print(f"     [결정/{d.get('kind','?')}] {d.get('statement','')[:50]}")
        for a in data.get("action_items", [])[:3]:
            print(f"     [업무] {a.get('statement','')[:40]} "
                  f"· 담당 {a.get('assigned_to','?')} · 기한 {a.get('due','?')}")
        if n["decisions"] == 0 and n["action_items"] == 0:
            print(f"{WARN}아무것도 못 뽑았습니다. 모델이 너무 작거나 "
                  f"프롬프트 언어 대응이 약할 수 있습니다.")
        est = dt * 1.15
        print(f"\n     예상 처리 시간: 1,000통 ≈ {est*1000/60:.0f}분 "
              f"(순차 기준, 병렬 4로 돌리면 약 {est*1000/60/4:.0f}분)")
    except Exception as e:
        print(f"{NO} 추출 실패 — {str(e)[:300]}")
        return False

    print("\n진단 완료. `python run.py extract` 로 본 처리를 시작하세요.\n")
    return True
