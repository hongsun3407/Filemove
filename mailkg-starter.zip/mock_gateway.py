"""
모의 LiteLLM 게이트웨이 — 실제 서버 없이 연결 계층을 검증한다.

  python mock_gateway.py --port 4000 --mode full     # 전부 지원 (vLLM + 툴파서)
  python mock_gateway.py --port 4001 --mode nojson   # json_schema 미지원
  python mock_gateway.py --port 4002 --mode bare     # JSON도 tools도 미지원
  python mock_gateway.py --port 4003 --mode noauth   # 키 없으면 401

폐쇄망 반입 전 개발 PC에서 폴백 경로가 실제로 동작하는지 확인하는 용도.
"""
import argparse
import json
import re
from http.server import BaseHTTPRequestHandler, HTTPServer

MODE = "full"
KEY = "sk-test-1234"

DEC = re.compile(r"(승인|반려|확정|보류|변경)합니다")
ACT = re.compile(r"(\d{1,2})월\s*(\d{1,2})일까지\s*(.+?)(?:해|송부|제출|회신)")


def fake_extraction(user: str) -> dict:
    """Qwen이 뱉을 법한 결과를 흉내낸다 (본문에서 실제로 근거를 따온다)."""
    body = user.split("[본문]\n", 1)[-1]
    subject = (re.search(r"\[제목\]\s*(.*)", user) or [None, ""])[1]
    m = re.search(r"\[([^\]]+)\]", subject or "")
    cases, decisions, actions = [], [], []
    if m:
        cases.append({"name": m.group(1), "aliases": [], "evidence": subject.strip()})
    for line in [l.strip() for l in body.splitlines() if l.strip()]:
        d = DEC.search(line)
        if d:
            decisions.append({"statement": line, "kind": d.group(1),
                              "decided_by": "김철수 팀장",
                              "case": m.group(1) if m else "", "evidence": line})
        a = ACT.search(line)
        if a:
            actions.append({"statement": line,
                            "assigned_to": line.split()[0].rstrip("은는이가"),
                            "requested_by": "김철수 팀장",
                            "due": f"2026-{int(a.group(1)):02d}-{int(a.group(2)):02d}",
                            "case": m.group(1) if m else "", "evidence": line})
    return {"cases": cases, "decisions": decisions, "action_items": actions,
            "events": [], "people": []}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _auth_ok(self):
        if MODE != "noauth":
            return True
        return self.headers.get("Authorization") == f"Bearer {KEY}"

    def do_GET(self):
        if not self._auth_ok():
            return self._send(401, {"error": {"message": "invalid api key"}})
        if self.path.rstrip("/").endswith("/v1/models"):
            return self._send(200, {"object": "list", "data": [
                {"id": "qwen3-32b", "object": "model"},
                {"id": "qwen3-8b", "object": "model"}]})
        if self.path.startswith("/health"):
            return self._send(200, {"status": "ok"})
        self._send(404, {"error": {"message": "not found"}})

    def do_POST(self):
        if not self._auth_ok():
            return self._send(401, {"error": {"message": "invalid api key"}})
        n = int(self.headers.get("Content-Length", 0))
        req = json.loads(self.rfile.read(n) or b"{}")
        rf = req.get("response_format") or {}
        tools = req.get("tools")

        # --- 기능 미지원 흉내: 400 으로 거절
        if rf.get("type") == "json_schema" and MODE in ("nojson", "bare"):
            return self._send(400, {"error": {
                "message": "response_format json_schema is not supported by this backend"}})
        if rf.get("type") == "json_object" and MODE == "bare":
            return self._send(400, {"error": {
                "message": "response_format json_object is not supported"}})
        if tools and MODE in ("bare", "nojson"):
            return self._send(400, {"error": {
                "message": "tool calling is not enabled (--enable-auto-tool-choice)"}})

        msgs = req.get("messages", [])
        user = next((m["content"] for m in reversed(msgs)
                     if m.get("role") == "user"), "")
        system = next((m["content"] for m in msgs if m.get("role") == "system"), "")

        # --- tool calling 시연 (full 모드)
        if tools and MODE == "full":
            names = [t["function"]["name"] for t in tools]
            if "get_time" in names:                     # probe
                return self._chat({"role": "assistant", "content": "",
                                   "tool_calls": [{"id": "c1", "type": "function",
                                                   "function": {"name": "get_time",
                                                                "arguments": "{}"}}]})
            already = [m for m in msgs if m.get("role") == "tool"]
            if not already and "list_cases" in names:
                return self._chat({"role": "assistant", "content": "",
                                   "tool_calls": [{"id": "c1", "type": "function",
                                                   "function": {"name": "list_cases",
                                                                "arguments": "{}"}}]})
            return self._chat({"role": "assistant",
                               "content": "조회 결과를 바탕으로 답변드립니다.\n"
                                          "근거: 도구 조회 결과"})

        # --- 구조화 추출 요청인지 판별
        if "지식그래프용 사실을 추출" in system or "evidence" in system:
            out = json.dumps(fake_extraction(user), ensure_ascii=False)
            if MODE == "bare":
                out = "요청하신 결과입니다.\n```json\n" + out + "\n```"   # 잡담 섞기
            return self._chat({"role": "assistant", "content": out})

        # --- probe 용 {"ok":true}
        if '{"ok":true}' in user or "ok" in user and len(user) < 40:
            return self._chat({"role": "assistant", "content": '{"ok": true}'})

        # --- 일반 응답 (Qwen3 think 블록 포함시켜 제거 로직 검증)
        body = "<think>사용자가 수도를 물었다.</think>서울"
        if "JSON" in system:
            body = '{"ok": true}'
        self._chat({"role": "assistant", "content": body})

    def _chat(self, message):
        self._send(200, {"id": "chatcmpl-mock", "object": "chat.completion",
                         "model": "qwen3-32b",
                         "choices": [{"index": 0, "message": message,
                                      "finish_reason": "stop"}],
                         "usage": {"prompt_tokens": 100, "completion_tokens": 50,
                                   "total_tokens": 150}})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=4000)
    ap.add_argument("--mode", default="full",
                    choices=["full", "nojson", "bare", "noauth"])
    a = ap.parse_args()
    MODE = a.mode
    print(f"mock LiteLLM :{a.port} mode={a.mode}")
    HTTPServer(("127.0.0.1", a.port), H).serve_forever()
