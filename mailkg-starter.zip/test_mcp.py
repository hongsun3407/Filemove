#!/usr/bin/env python3
"""MCP 서버 프로토콜 왕복 테스트 — goose 에 붙이기 전에 여기서 먼저 통과시킨다."""
import json
import subprocess
import sys

PY = sys.executable
FAILED = []


def rpc(proc, obj, expect_response=True):
    proc.stdin.write(json.dumps(obj, ensure_ascii=False) + "\n")
    proc.stdin.flush()
    if not expect_response:
        return None
    line = proc.stdout.readline()
    if not line:
        raise RuntimeError("서버가 응답 없이 종료됨")
    return json.loads(line)


def check(label, cond, detail=""):
    print(("  ✅ " if cond else "  ❌ ") + label + (f"  {detail}" if detail else ""))
    if not cond:
        FAILED.append(label)


def main(db="mail.db"):
    proc = subprocess.Popen([PY, "mcp_server.py", "--db", db],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, text=True, bufsize=1)
    try:
        print("\n1. initialize")
        r = rpc(proc, {"jsonrpc": "2.0", "id": 1, "method": "initialize",
                       "params": {"protocolVersion": "2025-06-18",
                                  "capabilities": {},
                                  "clientInfo": {"name": "goose", "version": "1.0"}}})
        res = r.get("result", {})
        check("프로토콜 버전 협상", res.get("protocolVersion") == "2025-06-18",
              res.get("protocolVersion", ""))
        check("serverInfo 반환", res.get("serverInfo", {}).get("name") == "mailkg")
        check("tools capability 선언", "tools" in res.get("capabilities", {}))
        check("instructions 제공", len(res.get("instructions", "")) > 50)

        print("\n2. 알 수 없는 프로토콜 버전 처리")
        p2 = subprocess.Popen([PY, "mcp_server.py", "--db", db],
                              stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, text=True, bufsize=1)
        r2 = rpc(p2, {"jsonrpc": "2.0", "id": 1, "method": "initialize",
                      "params": {"protocolVersion": "1999-01-01", "capabilities": {},
                                 "clientInfo": {"name": "x", "version": "1"}}})
        check("미지원 버전은 기본값으로 하강",
              r2["result"]["protocolVersion"] == "2025-06-18",
              r2["result"]["protocolVersion"])
        p2.kill()

        print("\n3. initialized 알림 (응답 없어야 함)")
        rpc(proc, {"jsonrpc": "2.0", "method": "notifications/initialized"},
            expect_response=False)
        check("알림에 응답하지 않음", True)

        print("\n4. tools/list")
        r = rpc(proc, {"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
        tools = r["result"]["tools"]
        check("도구 개수", len(tools) == 9, f"{len(tools)}개")
        names = [t["name"] for t in tools]
        check("모두 mail_ 접두사", all(n.startswith("mail_") for n in names))
        check("모두 inputSchema 보유", all("inputSchema" in t for t in tools))
        check("모두 description 보유",
              all(len(t.get("description", "")) > 30 for t in tools))
        check("모두 읽기전용 annotation",
              all(t.get("annotations", {}).get("readOnlyHint") for t in tools))

        print("\n5. tools/call — 개요")
        r = rpc(proc, {"jsonrpc": "2.0", "id": 3, "method": "tools/call",
                       "params": {"name": "mail_graph_overview", "arguments": {}}})
        res = r["result"]
        check("isError=false", res.get("isError") is False)
        check("text content 반환", res["content"][0]["type"] == "text")
        payload = json.loads(res["content"][0]["text"].split("\n\n[안내]")[0])
        check("메일 건수 포함", payload["규모"]["메일"] > 0, str(payload["규모"]))
        cases = payload.get("주요 사안", [])
        check("사안 목록 포함", len(cases) > 0)

        print("\n6. tools/call — 인물 → 관계망 (2단 연쇄)")
        r = rpc(proc, {"jsonrpc": "2.0", "id": 4, "method": "tools/call",
                       "params": {"name": "mail_find_person",
                                  "arguments": {"name": "김철수"}}})
        people = json.loads(r["result"]["content"][0]["text"])
        check("인물 검색 성공", len(people) > 0, str(people[:1]))
        addr = people[0]["addr"]
        r = rpc(proc, {"jsonrpc": "2.0", "id": 5, "method": "tools/call",
                       "params": {"name": "mail_person_network",
                                  "arguments": {"addr": addr}}})
        net = json.loads(r["result"]["content"][0]["text"])
        check("관계망 반환", len(net["자주 함께 일한 사람"]) > 0)

        print("\n7. tools/call — 사안 이력")
        cid = cases[0]["id"]
        r = rpc(proc, {"jsonrpc": "2.0", "id": 6, "method": "tools/call",
                       "params": {"name": "mail_case_timeline",
                                  "arguments": {"case_id": cid}}})
        tl = json.loads(r["result"]["content"][0]["text"])
        check("메일 이력 포함", len(tl["메일"]) > 0, f"{len(tl['메일'])}건")
        check("의사결정 포함", len(tl["의사결정"]) > 0, f"{len(tl['의사결정'])}건")

        print("\n8. 오류 처리")
        r = rpc(proc, {"jsonrpc": "2.0", "id": 7, "method": "tools/call",
                       "params": {"name": "mail_person_network", "arguments": {}}})
        res = r["result"]
        check("필수 인자 누락 → isError", res.get("isError") is True)
        check("복구 힌트 포함", "mail_find_person" in res["content"][0]["text"],
              res["content"][0]["text"][:70])

        r = rpc(proc, {"jsonrpc": "2.0", "id": 8, "method": "tools/call",
                       "params": {"name": "mail_nope", "arguments": {}}})
        check("없는 도구 → isError", r["result"].get("isError") is True)

        r = rpc(proc, {"jsonrpc": "2.0", "id": 9, "method": "tools/call",
                       "params": {"name": "mail_find_person",
                                  "arguments": {"name": "존재하지않는사람"}}})
        check("빈 결과에 안내 문구", "[안내]" in r["result"]["content"][0]["text"])

        print("\n9. 미지원 메서드 / 잘못된 JSON")
        r = rpc(proc, {"jsonrpc": "2.0", "id": 10, "method": "wat/ever"})
        check("-32601 반환", r.get("error", {}).get("code") == -32601)
        r = rpc(proc, {"jsonrpc": "2.0", "id": 11, "method": "resources/list"})
        check("resources/list 빈 목록", r["result"]["resources"] == [])
        proc.stdin.write("{ 깨진 JSON\n")
        proc.stdin.flush()
        r = json.loads(proc.stdout.readline())
        check("-32700 반환", r.get("error", {}).get("code") == -32700)

        print("\n10. DB 없을 때")
        p3 = subprocess.Popen([PY, "mcp_server.py", "--db", "없는파일.db"],
                              stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, text=True, bufsize=1)
        rpc(p3, {"jsonrpc": "2.0", "id": 1, "method": "initialize",
                 "params": {"protocolVersion": "2025-06-18", "capabilities": {},
                            "clientInfo": {"name": "x", "version": "1"}}})
        r = rpc(p3, {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                     "params": {"name": "mail_list_cases", "arguments": {}}})
        txt = r["result"]["content"][0]["text"]
        check("서버가 죽지 않고 안내 반환", r["result"]["isError"] is True)
        check("복구 방법 안내", "run.py" in txt, txt[:80])
        p3.kill()
    finally:
        proc.kill()

    print("\n" + ("실패: " + ", ".join(FAILED) if FAILED else "전체 통과"))
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "mail.db"))
