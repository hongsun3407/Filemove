"""파이프라인 검증용 한국어 샘플 .eml 생성 (euc-kr/utf-8 혼재, 인용문 포함)."""
from email.message import EmailMessage
from email.utils import format_datetime, make_msgid
from datetime import datetime, timedelta, timezone
from pathlib import Path

KST = timezone(timedelta(hours=9))
OUT = Path(__file__).parent / "samples"
OUT.mkdir(exist_ok=True)

P = {
    "kim": ("김철수 팀장", "cs.kim@corp.go.kr"),
    "lee": ("이영희", "yh.lee@corp.go.kr"),
    "park": ("박민준 과장", "mj.park@corp.go.kr"),
    "jung": ("정수아", "sa.jung@vendor.co.kr"),
    "choi": ("최대표", "ceo@vendor.co.kr"),
}

MAILS = [
    # (일자, 발신, 수신들, 참조, 제목, 본문, 첨부, 인코딩)
    ("2026-03-04 09:12", "kim", ["lee", "park"], [],
     "[차세대 관제시스템] 사업 착수 안내",
     "관제시스템 고도화 사업을 3월부터 착수합니다.\n"
     "이영희 선임은 3월 13일까지 요구사항 정의서 초안을 제출해 주시기 바랍니다.\n"
     "3월 18일 오후 2시 본관 3층 회의실에서 킥오프 회의를 진행합니다.",
     ["요구사항_양식.xlsx"], "utf-8"),

    ("2026-03-11 17:40", "lee", ["kim"], ["park"],
     "RE: [차세대 관제시스템] 사업 착수 안내",
     "요구사항 정의서 초안 첨부드립니다.\n"
     "다만 외부 연계 항목은 업체 확인이 필요해 비워두었습니다.\n\n"
     "보낸 사람: 김철수 팀장\n> 관제시스템 고도화 사업을 3월부터 착수합니다.\n"
     "> 3월 13일까지 요구사항 정의서 초안을 제출해 주시기 바랍니다.",
     ["요구사항정의서_v0.1.docx"], "euc-kr"),

    ("2026-03-18 16:05", "kim", ["lee", "park", "jung"], [],
     "RE: [차세대 관제시스템] 킥오프 회의 결과",
     "킥오프 회의 결과 공유드립니다.\n"
     "1. 요구사항 정의서 v0.1 승인합니다.\n"
     "2. 외부 연계 방식은 REST 로 확정합니다.\n"
     "박민준 과장은 3월 27일까지 연계 규격서를 송부해 주세요.",
     [], "utf-8"),

    ("2026-04-02 11:20", "jung", ["kim", "park"], [],
     "차세대관제 - 연계 규격 검토 의견",
     "보내주신 연계 규격서 검토했습니다.\n"
     "인증 방식 변경이 필요해 기존 규격은 반려합니다.\n"
     "4월 10일까지 수정본 회신 부탁드립니다.",
     ["검토의견서.pdf"], "utf-8"),

    ("2026-04-09 14:33", "park", ["jung"], ["kim", "lee"],
     "RE: 차세대관제 - 연계 규격 검토 의견",
     "수정 규격서 첨부합니다. 인증은 mTLS 로 변경하였습니다.\n"
     "4월 15일 오전 10시 점검회의 요청드립니다.\n\n"
     "-----Original Message-----\n정수아 님이 작성하셨습니다:\n"
     "> 인증 방식 변경이 필요해 기존 규격은 반려합니다.",
     ["연계규격서_v0.2.docx"], "euc-kr"),

    ("2026-05-07 10:00", "choi", ["kim"], ["jung"],
     "[통합보안 개선사업] 견적 제출의 건",
     "통합보안 개선 사업 견적서를 제출합니다.\n"
     "5월 20일까지 계약 여부를 회신해 주시면 감사하겠습니다.",
     ["견적서.pdf"], "utf-8"),

    ("2026-05-21 09:05", "kim", ["choi"], ["lee"],
     "RE: [통합보안 개선사업] 견적 제출의 건",
     "검토 결과 제출하신 견적으로 진행 확정합니다.\n"
     "계약 절차는 이영희 선임이 담당하며, 6월 5일까지 계약서 초안을 작성해 주세요.",
     [], "utf-8"),

    ("2026-06-11 15:47", "lee", ["kim", "park"], [],
     "차세대 관제시스템 사업 - 일정 변경 안내",
     "발주처 사정으로 오픈 일정이 변경되었습니다.\n"
     "기존 8월 오픈에서 10월 오픈으로 변경합니다.\n"
     "7월 2일 오후 3시 일정 조정 회의를 진행합니다.",
     [], "utf-8"),
]


def build():
    for i, (dt, frm, tos, ccs, subj, body, atts, enc) in enumerate(MAILS):
        m = EmailMessage()
        m["Message-ID"] = make_msgid(domain="corp.go.kr")
        m["From"] = f"{P[frm][0]} <{P[frm][1]}>"
        m["To"] = ", ".join(f"{P[t][0]} <{P[t][1]}>" for t in tos)
        if ccs:
            m["Cc"] = ", ".join(f"{P[c][0]} <{P[c][1]}>" for c in ccs)
        m["Subject"] = subj
        m["Date"] = format_datetime(
            datetime.strptime(dt, "%Y-%m-%d %H:%M").replace(tzinfo=KST))
        if i > 0:
            m["In-Reply-To"] = f"<prev{i-1}@corp.go.kr>"
        m.set_content(body, charset=enc)
        for a in atts:
            m.add_attachment(b"DUMMY" * 100, maintype="application",
                             subtype="octet-stream", filename=a)
        (OUT / f"{i:02d}_{frm}.eml").write_bytes(m.as_bytes())
    print(f"샘플 {len(MAILS)}통 생성: {OUT}")


if __name__ == "__main__":
    build()
