using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

namespace VdsNodeLab
{
    /// <summary>
    /// 멤버 이름을 모르는 COM 객체를 IDispatch 후기 바인딩으로 두드려 보는 도우미.
    /// 실패는 예외 대신 false 로 돌려주므로 후보 이름을 순서대로 시도할 수 있다.
    /// </summary>
    internal static class ComProbe
    {
        private static readonly string[] CountNames =
            { "Count", "count", "Length", "length", "Size", "NumChildren", "ChildCount" };

        private static readonly string[] ItemNames =
            { "Item", "item", "get_Item", "GetItem", "At", "Node", "Child", "GetChild" };

        public static bool TryGet(object target, string name, out object value)
        {
            value = null;
            if (target == null || string.IsNullOrEmpty(name)) return false;
            try
            {
                value = target.GetType().InvokeMember(
                    name, BindingFlags.GetProperty, null, target, null);
                return true;
            }
            catch { return false; }
        }

        public static bool TrySet(object target, string name, object value)
        {
            if (target == null || string.IsNullOrEmpty(name)) return false;
            try
            {
                target.GetType().InvokeMember(
                    name, BindingFlags.SetProperty, null, target, new[] { value });
                return true;
            }
            catch { return false; }
        }

        public static bool TryCall(object target, string name, out object result, params object[] args)
        {
            result = null;
            if (target == null || string.IsNullOrEmpty(name)) return false;
            try
            {
                result = target.GetType().InvokeMember(
                    name, BindingFlags.InvokeMethod, null, target, args ?? new object[0]);
                return true;
            }
            catch { return false; }
        }

        /// <summary>속성/메서드 어느 쪽이든 인자를 넘겨 값을 얻는다(인덱서 대응).</summary>
        public static bool TryIndexed(object target, string name, object index, out object value)
        {
            value = null;
            if (target == null) return false;
            try
            {
                value = target.GetType().InvokeMember(
                    name,
                    BindingFlags.GetProperty | BindingFlags.InvokeMethod,
                    null, target, new[] { index });
                return true;
            }
            catch { return false; }
        }

        /// <summary>후보 이름들을 순서대로 시도해서 처음 성공한 값을 돌려준다.</summary>
        public static object FirstOf(object target, IEnumerable<string> names, out string usedName)
        {
            usedName = null;
            if (target == null) return null;

            foreach (var n in names)
            {
                object v;
                if (TryGet(target, n, out v) && v != null) { usedName = n + " (property)"; return v; }
                if (TryCall(target, n, out v) && v != null) { usedName = n + "() (method)"; return v; }
            }
            return null;
        }

        public static bool TryCount(object collection, out int count, out string usedName)
        {
            count = -1;
            usedName = null;
            if (collection == null) return false;

            foreach (var n in CountNames)
            {
                object v;
                if (!TryGet(collection, n, out v) || v == null) continue;
                try
                {
                    count = Convert.ToInt32(v);
                    usedName = n;
                    return count >= 0;
                }
                catch { }
            }
            return false;
        }

        /// <summary>
        /// 컬렉션처럼 보이는 COM 객체에서 원소를 뽑아낸다.
        /// IEnumVARIANT → Count+Item(0기준) → Count+Item(1기준) 순으로 시도.
        /// </summary>
        public static List<object> Enumerate(object collection, out string strategy)
        {
            strategy = null;
            var list = new List<object>();
            if (collection == null) return list;

            var enumerable = collection as IEnumerable;
            if (enumerable != null && !(collection is string))
            {
                try
                {
                    foreach (var o in enumerable)
                        if (o != null) list.Add(o);

                    if (list.Count > 0)
                    {
                        strategy = "IEnumVARIANT";
                        return list;
                    }
                }
                catch { list.Clear(); }
            }

            int count;
            string countName;
            if (!TryCount(collection, out count, out countName)) return list;

            if (count == 0)
            {
                strategy = countName + " = 0";
                return list;
            }

            foreach (var accessor in ItemNames)
            {
                for (var baseIndex = 0; baseIndex <= 1; baseIndex++)
                {
                    list.Clear();
                    var ok = true;

                    for (var i = 0; i < count; i++)
                    {
                        object item;
                        if (TryIndexed(collection, accessor, i + baseIndex, out item) && item != null)
                            list.Add(item);
                        else { ok = false; break; }
                    }

                    if (ok && list.Count == count)
                    {
                        strategy = string.Format("{0} + {1}[{2}..]", countName, accessor, baseIndex);
                        return list;
                    }
                }
            }

            list.Clear();
            return list;
        }

        public static string TypeNameOf(object o)
        {
            if (o == null) return "(null)";
            try
            {
                var t = o.GetType();
                return t.IsCOMObject ? "COM:" + TypeLibDumper.TryGetTypeName(o) : t.Name;
            }
            catch { return "(unknown)"; }
        }
    }
}
