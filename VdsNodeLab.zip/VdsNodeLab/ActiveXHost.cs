using System;
using System.Windows.Forms;

namespace VdsNodeLab
{
    /// <summary>
    /// CLSID 만으로 임의의 등록된 ActiveX 컨트롤을 호스팅한다.
    /// AxInterop.*.dll / Interop.*.dll 이 없어도 동작하므로,
    /// 타입 라이브러리 이름을 모르는 상태에서 탐색용으로 쓰기 좋다.
    /// </summary>
    public sealed class ActiveXHost : AxHost
    {
        public ActiveXHost(string clsid) : base(NormalizeClsid(clsid))
        {
        }

        /// <summary>실제 COM 객체(IDispatch). 핸들 생성 이후에만 유효하다.</summary>
        public object Instance
        {
            get
            {
                try { return GetOcx(); }
                catch { return null; }
            }
        }

        private static string NormalizeClsid(string clsid)
        {
            if (string.IsNullOrWhiteSpace(clsid))
                throw new ArgumentException("CLSID 가 비어 있습니다.", "clsid");

            var g = new Guid(clsid.Trim());
            return g.ToString();
        }
    }
}
