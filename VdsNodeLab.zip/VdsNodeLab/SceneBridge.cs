using System;
using System.Collections.Generic;

namespace VdsNodeLab
{
    public enum VisibilityMode
    {
        NotDetected,
        NodeProperty,        // node.Visible = true/false
        NodePropertyInverted,// node.Hidden = !visible
        ViewerTwoArgs,       // viewer.SetNodeVisible(node, visible)
        ViewerShowHide,      // viewer.ShowNode(node) / viewer.HideNode(node)
        SelectAndCommand,    // 노드 선택 후 ExecuteCommand("...")
        Failed
    }

    /// <summary>
    /// 뷰어 COM 객체를 감싸고, 씬 그래프 접근에 필요한 멤버 이름을 런타임에 찾아낸다.
    /// 한 번 성공한 방식은 캐시해서 이후에는 바로 그 경로만 쓴다.
    /// </summary>
    public sealed class SceneBridge
    {
        private static readonly string[] LoadNames =
            { "LoadFile", "LoadFileAsync", "Load", "OpenFile", "Open", "LoadURL", "LoadDocument" };

        private static readonly string[] SrcPropertyNames =
            { "Src", "SrcUrl", "FileName", "URL", "Url" };

        private static readonly string[] RootNames =
            { "RootNode", "Root", "SceneRoot", "Scene", "SceneTree", "Nodes", "Document",
              "GetRootNode", "GetRoot", "GetScene", "GetSceneRoot", "GetNodes" };

        private static readonly string[] ChildNames =
            { "Children", "children", "ChildNodes", "childNodes", "Nodes", "nodes",
              "SubNodes", "Items", "items", "Parts" };

        private static readonly string[] NameNames =
            { "Name", "name", "NodeName", "DisplayName", "Text", "Label", "Title", "Id", "ID" };

        private static readonly string[] VisiblePropNames =
            { "Visible", "visible", "IsVisible", "Visibility", "Shown", "Show" };

        private static readonly string[] HiddenPropNames =
            { "Hidden", "hidden", "IsHidden", "Invisible" };

        private static readonly string[] TwoArgVisNames =
            { "SetNodeVisible", "SetVisible", "SetNodeVisibility", "SetVisibility", "SetNodeShow" };

        private static readonly string[] SelectNames =
            { "SelectNode", "Select", "SetSelection", "SelectNodes", "AddToSelection" };

        private readonly object _viewer;
        private readonly Action<string> _log;

        private string _childMember;
        private string _nameMember;
        private string _visMember;

        public VisibilityMode Mode { get; private set; }
        public string HideCommand { get; set; }
        public string ShowCommand { get; set; }

        public SceneBridge(object viewer, Action<string> log)
        {
            _viewer = viewer;
            _log = log ?? (s => { });
            Mode = VisibilityMode.NotDetected;
        }

        public object Viewer { get { return _viewer; } }

        // ---------------------------------------------------------------- 로드

        public bool LoadFile(string path)
        {
            foreach (var m in LoadNames)
            {
                object dummy;
                if (ComProbe.TryCall(_viewer, m, out dummy, path))
                {
                    _log("파일 로드 성공: " + m + "(\"" + path + "\")");
                    return true;
                }
            }

            foreach (var p in SrcPropertyNames)
            {
                if (ComProbe.TrySet(_viewer, p, path))
                {
                    _log("파일 로드 성공: " + p + " = \"" + path + "\"");
                    return true;
                }
            }

            _log("파일 로드 실패. 시도한 멤버: " + string.Join(", ", LoadNames) +
                 " / " + string.Join(", ", SrcPropertyNames));
            _log("→ [API 덤프] 로 실제 로드 메서드 이름을 확인하세요.");
            return false;
        }

        // ------------------------------------------------------------ 루트 탐색

        public object FindRoot()
        {
            foreach (var candidate in RootNames)
            {
                object v;
                if (ComProbe.TryGet(_viewer, candidate, out v) && v != null)
                {
                    _log("루트 후보 발견: 속성 " + candidate + " → " + ComProbe.TypeNameOf(v));
                    var resolved = ResolveRoot(v);
                    if (resolved != null) return resolved;
                }

                if (ComProbe.TryCall(_viewer, candidate, out v) && v != null)
                {
                    _log("루트 후보 발견: 메서드 " + candidate + "() → " + ComProbe.TypeNameOf(v));
                    var resolved = ResolveRoot(v);
                    if (resolved != null) return resolved;
                }
            }

            _log("루트 노드를 찾지 못했습니다. [API 덤프] 결과에서 씬/노드 관련 속성을 확인하세요.");
            return null;
        }

        /// <summary>Scene 객체를 받았을 수도 있으니 한 단계 더 파고든다.</summary>
        private object ResolveRoot(object candidate)
        {
            string strategy;
            var direct = GetChildren(candidate, out strategy);
            if (direct.Count > 0)
            {
                _log("  → 자식 " + direct.Count + "개 확인 (" + strategy + "). 루트로 채택.");
                return candidate;
            }

            foreach (var inner in new[] { "RootNode", "Root", "Nodes", "Children" })
            {
                object v;
                if (!ComProbe.TryGet(candidate, inner, out v) || v == null) continue;

                var kids = GetChildren(v, out strategy);
                if (kids.Count > 0)
                {
                    _log("  → " + inner + " 하위에서 자식 " + kids.Count + "개 확인. 루트로 채택.");
                    return v;
                }
            }

            return null;
        }

        // ------------------------------------------------------------ 자식/이름

        public List<object> GetChildren(object node, out string strategy)
        {
            strategy = null;
            var result = new List<object>();
            if (node == null) return result;

            // 이미 확정된 멤버가 있으면 그것만 쓴다
            if (_childMember != null)
            {
                object coll;
                if (ComProbe.TryGet(node, _childMember, out coll) ||
                    ComProbe.TryCall(node, _childMember, out coll))
                {
                    string s;
                    var list = ComProbe.Enumerate(coll, out s);
                    strategy = _childMember + " / " + s;
                    return list;
                }
                return result;
            }

            foreach (var member in ChildNames)
            {
                object coll;
                if (!ComProbe.TryGet(node, member, out coll) &&
                    !ComProbe.TryCall(node, member, out coll)) continue;
                if (coll == null) continue;

                string s;
                var list = ComProbe.Enumerate(coll, out s);
                if (list.Count == 0) continue;

                _childMember = member;
                strategy = member + " / " + s;
                _log("자식 접근 방식 확정: " + strategy);
                return list;
            }

            return result;
        }

        public string GetName(object node, int fallbackIndex)
        {
            if (_nameMember != null)
            {
                object v;
                if (ComProbe.TryGet(node, _nameMember, out v) && v != null)
                {
                    var s = v.ToString();
                    if (!string.IsNullOrEmpty(s)) return s;
                }
            }
            else
            {
                foreach (var member in NameNames)
                {
                    object v;
                    if (!ComProbe.TryGet(node, member, out v) || v == null) continue;

                    var s = v.ToString();
                    if (string.IsNullOrEmpty(s)) continue;

                    _nameMember = member;
                    _log("노드 이름 속성 확정: " + member);
                    return s;
                }
            }

            return "Node_" + fallbackIndex;
        }

        // -------------------------------------------------------------- 가시성

        public bool SetVisible(object node, bool visible)
        {
            if (Mode == VisibilityMode.NotDetected)
                Detect(node, visible);

            switch (Mode)
            {
                case VisibilityMode.NodeProperty:
                    return ComProbe.TrySet(node, _visMember, visible);

                case VisibilityMode.NodePropertyInverted:
                    return ComProbe.TrySet(node, _visMember, !visible);

                case VisibilityMode.ViewerTwoArgs:
                    {
                        object r;
                        return ComProbe.TryCall(_viewer, _visMember, out r, node, visible);
                    }

                case VisibilityMode.ViewerShowHide:
                    {
                        object r;
                        return ComProbe.TryCall(_viewer, visible ? "ShowNode" : "HideNode", out r, node);
                    }

                case VisibilityMode.SelectAndCommand:
                    return SelectAndCommand(node, visible);

                default:
                    return false;
            }
        }

        private void Detect(object node, bool visible)
        {
            _log("── 가시성 제어 방식 탐색 시작 ──");

            // 1) 노드 자체의 Visible 계열 속성
            foreach (var p in VisiblePropNames)
            {
                object before;
                var readable = ComProbe.TryGet(node, p, out before);
                if (!ComProbe.TrySet(node, p, visible)) continue;

                if (readable)
                {
                    object after;
                    if (ComProbe.TryGet(node, p, out after) && !SameBool(after, visible))
                    {
                        _log("  " + p + " 쓰기는 되지만 값이 반영되지 않음. 다음 후보로.");
                        continue;
                    }
                }

                _visMember = p;
                Mode = VisibilityMode.NodeProperty;
                _log("✔ 확정: node." + p + " = bool");
                return;
            }

            // 2) 반대 의미 속성 (Hidden)
            foreach (var p in HiddenPropNames)
            {
                if (!ComProbe.TrySet(node, p, !visible)) continue;

                _visMember = p;
                Mode = VisibilityMode.NodePropertyInverted;
                _log("✔ 확정: node." + p + " = !visible (반전)");
                return;
            }

            // 3) 뷰어의 2인자 메서드
            foreach (var m in TwoArgVisNames)
            {
                object r;
                if (!ComProbe.TryCall(_viewer, m, out r, node, visible)) continue;

                _visMember = m;
                Mode = VisibilityMode.ViewerTwoArgs;
                _log("✔ 확정: viewer." + m + "(node, bool)");
                return;
            }

            // 4) 뷰어의 ShowNode / HideNode 쌍
            {
                object r;
                if (ComProbe.TryCall(_viewer, visible ? "ShowNode" : "HideNode", out r, node))
                {
                    Mode = VisibilityMode.ViewerShowHide;
                    _log("✔ 확정: viewer.ShowNode / HideNode(node)");
                    return;
                }
            }

            // 5) 선택 + ExecuteCommand
            if (!string.IsNullOrWhiteSpace(HideCommand) && SelectAndCommand(node, visible))
            {
                Mode = VisibilityMode.SelectAndCommand;
                _log("✔ 확정: 노드 선택 후 ExecuteCommand 사용");
                return;
            }

            Mode = VisibilityMode.Failed;
            _log("✘ 자동 탐색 실패. [API 덤프] 결과에서 가시성 관련 멤버를 찾아");
            _log("  SceneBridge.cs 의 후보 배열에 이름을 추가하거나, 숨기기/보이기 명령 문자열을 입력하세요.");
        }

        private bool SelectAndCommand(object node, bool visible)
        {
            var selected = false;
            foreach (var s in SelectNames)
            {
                object r;
                if (ComProbe.TryCall(_viewer, s, out r, node)) { selected = true; break; }
            }
            if (!selected) selected = ComProbe.TrySet(node, "Selected", true);
            if (!selected) return false;

            var cmd = visible ? ShowCommand : HideCommand;
            if (string.IsNullOrWhiteSpace(cmd)) return false;

            return ExecuteCommand(cmd);
        }

        public bool ExecuteCommand(string command)
        {
            foreach (var m in new[] { "ExecuteCommand", "ExecCommand", "RunCommand", "DoCommand", "Command" })
            {
                object r;
                if (ComProbe.TryCall(_viewer, m, out r, command))
                {
                    _log(m + "(\"" + command + "\") 호출 성공" +
                         (r == null ? "" : " → " + r));
                    return true;
                }
            }

            _log("명령 실행 실패: \"" + command + "\"");
            return false;
        }

        /// <summary>대량 토글 전후로 리드로우를 잠글 수 있으면 잠근다.</summary>
        public void SetRedraw(bool enabled)
        {
            object r;
            if (ComProbe.TryCall(_viewer, enabled ? "EndUpdate" : "BeginUpdate", out r)) return;
            if (ComProbe.TryCall(_viewer, "SetRedraw", out r, enabled)) return;
            ComProbe.TryCall(_viewer, enabled ? "ResumeRendering" : "SuspendRendering", out r);
        }

        private static bool SameBool(object value, bool expected)
        {
            try { return Convert.ToBoolean(value) == expected; }
            catch { return true; } // 비교 불가면 통과시킨다
        }
    }
}
