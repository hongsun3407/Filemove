using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace VdsNodeLab
{
    public sealed class MainForm : Form
    {
        private const int MaxDepth = 48;
        private const int MaxNodes = 30000;

        private ToolStrip _tool;
        private ToolStripTextBox _txtKeyword;
        private ToolStripComboBox _cboControls;
        private ToolStripButton _btnCreate;
        private ToolStripButton _btnOpen;
        private ToolStripButton _btnBuild;
        private ToolStripButton _btnDump;

        private TreeView _tree;
        private CheckBox _chkCascade;
        private Panel _viewerPanel;
        private TextBox _log;
        private TextBox _txtCommand;
        private TextBox _txtHideCmd;
        private TextBox _txtShowCmd;
        private Label _status;

        private SplitContainer _mainSplit;
        private SplitContainer _rightSplit;

        private ActiveXHost _host;
        private SceneBridge _bridge;
        private Timer _retryTimer;
        private int _retryCount;
        private bool _suppressCheck;
        private bool _quiet;
        private int _nodeCount;

        public MainForm()
        {
            Text = "VDS Node Lab — 씬 트리 가시성 제어 테스트";
            Width = 1280;
            Height = 820;
            StartPosition = FormStartPosition.CenterScreen;

            BuildUi();
            Load += (s, e) =>
            {
                ApplyLayout();
                SearchControls();
            };
            FormClosing += OnClosingForm;
        }

        // ------------------------------------------------------------------ UI

        private void BuildUi()
        {
            _tool = new ToolStrip { GripStyle = ToolStripGripStyle.Hidden };

            _tool.Items.Add(new ToolStripLabel("검색어:"));
            _txtKeyword = new ToolStripTextBox { Width = 230, Text = "deepview,exploration3d,veviewer,visual enterprise" };
            _tool.Items.Add(_txtKeyword);

            var btnSearch = new ToolStripButton("컨트롤 검색");
            btnSearch.Click += (s, e) => SearchControls();
            _tool.Items.Add(btnSearch);

            _cboControls = new ToolStripComboBox { Width = 320, DropDownStyle = ComboBoxStyle.DropDownList };
            _tool.Items.Add(_cboControls);

            _btnCreate = new ToolStripButton("컨트롤 생성");
            _btnCreate.Click += (s, e) => CreateControl();
            _tool.Items.Add(_btnCreate);

            _tool.Items.Add(new ToolStripSeparator());

            _btnOpen = new ToolStripButton("VDS 열기") { Enabled = false };
            _btnOpen.Click += (s, e) => OpenFile();
            _tool.Items.Add(_btnOpen);

            _btnBuild = new ToolStripButton("씬 트리 읽기") { Enabled = false };
            _btnBuild.Click += (s, e) => BuildTree(false);
            _tool.Items.Add(_btnBuild);

            _btnDump = new ToolStripButton("API 덤프") { Enabled = false };
            _btnDump.Click += (s, e) => DumpApi();
            _tool.Items.Add(_btnDump);

            // ---------------- 좌측: 씬 트리
            _tree = new TreeView { Dock = DockStyle.Fill, CheckBoxes = true, HideSelection = false };
            _tree.AfterCheck += Tree_AfterCheck;

            var leftBottom = new Panel { Dock = DockStyle.Bottom, Height = 68 };

            _chkCascade = new CheckBox
            {
                Text = "자식 노드까지 함께 적용",
                Checked = true,
                Left = 6,
                Top = 6,
                Width = 200
            };

            var btnShowAll = new Button { Text = "모두 보이기", Left = 6, Top = 32, Width = 100 };
            btnShowAll.Click += (s, e) => ApplyToAll(true);

            var btnHideAll = new Button { Text = "모두 숨기기", Left = 112, Top = 32, Width = 100 };
            btnHideAll.Click += (s, e) => ApplyToAll(false);

            var btnNodeInfo = new Button { Text = "노드 속성", Left = 218, Top = 32, Width = 90 };
            btnNodeInfo.Click += (s, e) => DumpSelectedNode();

            leftBottom.Controls.AddRange(new Control[] { _chkCascade, btnShowAll, btnHideAll, btnNodeInfo });

            var leftPanel = new Panel { Dock = DockStyle.Fill };
            leftPanel.Controls.Add(leftBottom);
            leftPanel.Controls.Add(_tree);
            _tree.BringToFront();

            // ---------------- 우측 하단: 로그 + 수동 명령
            _viewerPanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(32, 32, 36) };

            var cmdPanel = new Panel { Dock = DockStyle.Top, Height = 62 };

            cmdPanel.Controls.Add(new Label { Text = "숨기기 명령:", Left = 6, Top = 8, Width = 78 });
            _txtHideCmd = new TextBox { Left = 88, Top = 5, Width = 260 };
            cmdPanel.Controls.Add(_txtHideCmd);

            cmdPanel.Controls.Add(new Label { Text = "보이기 명령:", Left = 356, Top = 8, Width = 78 });
            _txtShowCmd = new TextBox { Left = 438, Top = 5, Width = 260 };
            cmdPanel.Controls.Add(_txtShowCmd);

            cmdPanel.Controls.Add(new Label { Text = "직접 실행:", Left = 6, Top = 36, Width = 78 });
            _txtCommand = new TextBox { Left = 88, Top = 33, Width = 610 };
            cmdPanel.Controls.Add(_txtCommand);

            var btnRun = new Button { Text = "실행", Left = 704, Top = 32, Width = 60 };
            btnRun.Click += (s, e) =>
            {
                if (_bridge == null) { Log("컨트롤이 아직 생성되지 않았습니다."); return; }
                _bridge.ExecuteCommand(_txtCommand.Text);
            };
            cmdPanel.Controls.Add(btnRun);

            _log = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = Color.White,
                Font = new Font("Consolas", 9f)
            };

            var bottomPanel = new Panel { Dock = DockStyle.Fill };
            bottomPanel.Controls.Add(cmdPanel);
            bottomPanel.Controls.Add(_log);
            _log.BringToFront();

            _rightSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal
            };
            _rightSplit.Panel1.Controls.Add(_viewerPanel);
            _rightSplit.Panel2.Controls.Add(bottomPanel);

            _mainSplit = new SplitContainer { Dock = DockStyle.Fill };
            _mainSplit.Panel1.Controls.Add(leftPanel);
            _mainSplit.Panel2.Controls.Add(_rightSplit);

            _status = new Label
            {
                Dock = DockStyle.Bottom,
                Height = 22,
                TextAlign = ContentAlignment.MiddleLeft,
                BorderStyle = BorderStyle.Fixed3D,
                Text = "준비"
            };

            Controls.Add(_mainSplit);
            Controls.Add(_status);
            Controls.Add(_tool);
            _mainSplit.BringToFront();
        }

        private void ApplyLayout()
        {
            // SplitterDistance 는 컨트롤이 실제 크기를 가진 뒤에 설정해야 예외가 나지 않는다.
            try { _mainSplit.SplitterDistance = 340; } catch { }
            try { _rightSplit.SplitterDistance = 400; } catch { }
        }

        // -------------------------------------------------------- 컨트롤 준비

        private void SearchControls()
        {
            _cboControls.Items.Clear();
            var found = ControlFinder.Find(_txtKeyword.Text);

            foreach (var c in found)
                _cboControls.Items.Add(c);

            if (found.Count == 0)
            {
                Log("등록된 ActiveX 컨트롤을 찾지 못했습니다.");
                Log("· SAP 3D Visual Enterprise Viewer 가 설치되어 있는지 확인하세요.");
                Log("· 검색어를 비우고 다시 검색하면 등록된 모든 ActiveX 컨트롤이 나옵니다.");
                return;
            }

            _cboControls.SelectedIndex = 0;
            Log("ActiveX 컨트롤 " + found.Count + "개 발견:");
            foreach (var c in found)
                Log("  " + c.ProgId + "  " + c.Clsid + "  " + (c.InprocServer ?? ""));
        }

        private void CreateControl()
        {
            var info = _cboControls.SelectedItem as ControlInfo;
            if (info == null) { Log("컨트롤을 먼저 선택하세요."); return; }

            DisposeHost();

            try
            {
                _host = new ActiveXHost(info.Clsid) { Dock = DockStyle.Fill };
                ((System.ComponentModel.ISupportInitialize)_host).BeginInit();
                _viewerPanel.Controls.Add(_host);
                ((System.ComponentModel.ISupportInitialize)_host).EndInit();
                _host.CreateControl();

                var ocx = _host.Instance;
                if (ocx == null)
                {
                    Log("컨트롤은 생성됐지만 COM 인스턴스를 얻지 못했습니다.");
                    return;
                }

                _bridge = new SceneBridge(ocx, Log);
                _btnOpen.Enabled = true;
                _btnBuild.Enabled = true;
                _btnDump.Enabled = true;

                Log("컨트롤 생성 완료: " + info.ProgId);
                Log("기본 인터페이스: " + TypeLibDumper.TryGetTypeName(ocx));
                SetStatus("컨트롤 준비됨 — " + info.ProgId);

                // 내장 UI 를 숨기고 우리 트리로만 제어한다
                foreach (var el in new[] { "left_toolbar", "right_toolbar", "right_click_menu", "scene_tree" })
                {
                    object r;
                    ComProbe.TryCall(ocx, "ShowGuiElement", out r, el, false);
                }
            }
            catch (Exception ex)
            {
                Log("컨트롤 생성 실패: " + ex.Message);
                Log("· 프로젝트 플랫폼이 x86 인지 확인하세요 (32bit 컨트롤은 AnyCPU 에서 실패합니다).");
            }
        }

        // ------------------------------------------------------------ 파일/트리

        private void OpenFile()
        {
            if (_bridge == null) { Log("컨트롤이 아직 생성되지 않았습니다."); return; }

            using (var dlg = new OpenFileDialog())
            {
                dlg.Filter = "Visual Enterprise 파일 (*.vds;*.rh;*.rhz)|*.vds;*.rh;*.rhz|모든 파일 (*.*)|*.*";
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                _tree.Nodes.Clear();
                if (!_bridge.LoadFile(dlg.FileName)) return;

                SetStatus("로드 중: " + Path.GetFileName(dlg.FileName));
                StartRetry();
            }
        }

        private void StartRetry()
        {
            _retryCount = 0;
            if (_retryTimer == null)
            {
                _retryTimer = new Timer { Interval = 1000 };
                _retryTimer.Tick += (s, e) =>
                {
                    _retryCount++;
                    if (BuildTree(true) || _retryCount >= 20)
                    {
                        _retryTimer.Stop();
                        if (_tree.Nodes.Count == 0)
                            Log("씬 트리를 자동으로 읽지 못했습니다. 모델이 보인 뒤 [씬 트리 읽기]를 눌러 주세요.");
                    }
                };
            }
            _retryTimer.Start();
        }

        private bool BuildTree(bool quiet)
        {
            if (_bridge == null) { Log("컨트롤이 아직 생성되지 않았습니다."); return false; }

            _quiet = quiet;
            try
            {
                var root = _bridge.FindRoot();
                if (root == null) return false;

                var sw = Stopwatch.StartNew();
                _nodeCount = 0;

                _tree.BeginUpdate();
                _tree.Nodes.Clear();

                var rootTn = _tree.Nodes.Add(_bridge.GetName(root, 0));
                rootTn.Tag = root;
                _nodeCount++;
                AddChildren(rootTn, root, 0);

                _suppressCheck = true;
                CheckAll(_tree.Nodes, true);
                _suppressCheck = false;

                _tree.EndUpdate();
                rootTn.Expand();

                _quiet = false;
                Log("씬 트리 생성 완료: 노드 " + _nodeCount + "개, " + sw.ElapsedMilliseconds + "ms");
                SetStatus("노드 " + _nodeCount + "개");
                return true;
            }
            finally
            {
                _quiet = false;
            }
        }

        private void AddChildren(TreeNode parentTn, object parentNode, int depth)
        {
            if (depth >= MaxDepth || _nodeCount >= MaxNodes) return;

            string strategy;
            var children = _bridge.GetChildren(parentNode, out strategy);

            for (var i = 0; i < children.Count; i++)
            {
                if (_nodeCount >= MaxNodes)
                {
                    Log("노드 상한(" + MaxNodes + ") 도달. 트리를 잘라냅니다.");
                    return;
                }

                var child = children[i];
                var tn = parentTn.Nodes.Add(_bridge.GetName(child, i));
                tn.Tag = child;
                _nodeCount++;

                AddChildren(tn, child, depth + 1);
            }
        }

        // -------------------------------------------------------------- 가시성

        private void Tree_AfterCheck(object sender, TreeViewEventArgs e)
        {
            if (_suppressCheck || e.Action == TreeViewAction.Unknown) return;
            ApplyVisibility(e.Node, e.Node.Checked, _chkCascade.Checked);
        }

        private void ApplyVisibility(TreeNode tn, bool visible, bool cascade)
        {
            if (_bridge == null) return;

            _bridge.HideCommand = _txtHideCmd.Text;
            _bridge.ShowCommand = _txtShowCmd.Text;

            var sw = Stopwatch.StartNew();
            var ok = 0;
            var fail = 0;

            _bridge.SetRedraw(false);
            _suppressCheck = true;
            try
            {
                ApplyRecursive(tn, visible, cascade, ref ok, ref fail);
            }
            finally
            {
                _suppressCheck = false;
                _bridge.SetRedraw(true);
            }

            Log(string.Format("{0} → {1}: 성공 {2} / 실패 {3} ({4}ms, 방식={5})",
                tn.Text, visible ? "보이기" : "숨기기", ok, fail, sw.ElapsedMilliseconds, _bridge.Mode));
        }

        private void ApplyRecursive(TreeNode tn, bool visible, bool cascade, ref int ok, ref int fail)
        {
            if (tn.Tag != null)
            {
                if (_bridge.SetVisible(tn.Tag, visible)) ok++;
                else fail++;
            }

            if (!cascade) return;

            foreach (TreeNode child in tn.Nodes)
            {
                child.Checked = visible;
                ApplyRecursive(child, visible, true, ref ok, ref fail);
            }
        }

        private void ApplyToAll(bool visible)
        {
            if (_tree.Nodes.Count == 0) { Log("먼저 씬 트리를 읽어 주세요."); return; }
            foreach (TreeNode tn in _tree.Nodes)
                ApplyVisibility(tn, visible, true);
        }

        private static void CheckAll(TreeNodeCollection nodes, bool value)
        {
            foreach (TreeNode tn in nodes)
            {
                tn.Checked = value;
                CheckAll(tn.Nodes, value);
            }
        }

        // ---------------------------------------------------------------- 덤프

        private void DumpApi()
        {
            if (_bridge == null) return;

            var text = TypeLibDumper.DumpFullTypeLib(_bridge.Viewer);
            var path = Path.Combine(
                Path.GetDirectoryName(Application.ExecutablePath) ?? ".", "api_dump.txt");

            try
            {
                File.WriteAllText(path, text, System.Text.Encoding.UTF8);
                Log("API 덤프 저장: " + path);
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                Log("덤프 저장 실패: " + ex.Message);
                Log(text);
            }
        }

        private void DumpSelectedNode()
        {
            var tn = _tree.SelectedNode;
            if (tn == null || tn.Tag == null) { Log("노드를 먼저 선택하세요."); return; }

            Log("");
            Log(TypeLibDumper.DumpInstanceProperties(tn.Tag));
        }

        // ---------------------------------------------------------------- 기타

        private void Log(string message)
        {
            if (_quiet) return;

            _log.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + message + Environment.NewLine);
        }

        private void SetStatus(string text)
        {
            _status.Text = text;
        }

        private void DisposeHost()
        {
            if (_host == null) return;
            try
            {
                _viewerPanel.Controls.Remove(_host);
                _host.Dispose();
            }
            catch { }
            _host = null;
            _bridge = null;
        }

        private void OnClosingForm(object sender, FormClosingEventArgs e)
        {
            if (_retryTimer != null) _retryTimer.Stop();
            DisposeHost();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }
}
