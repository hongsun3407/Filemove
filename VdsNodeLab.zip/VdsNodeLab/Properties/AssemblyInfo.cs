using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VdsNodeLab")]
[assembly: AssemblyDescription("SAP 3D Visual Enterprise Viewer ActiveX 씬 노드 가시성 테스트 하네스")]
[assembly: AssemblyProduct("VdsNodeLab")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: ComVisible(false)]
[assembly: Guid("8f3a5c21-6b4e-4d7a-9e52-1c0d7b93a410")]
