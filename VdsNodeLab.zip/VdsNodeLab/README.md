# VDS Node Lab

SAP 3D Visual Enterprise Viewer ActiveX 컨트롤을 호스팅하고, VDS 파일의 씬 노드를
**별도 TreeView + 체크박스**로 보이기/숨기기 하는 테스트 하네스입니다.

SDK 문서 없이도 개발을 시작할 수 있도록, 실제 COM 멤버 이름을 **런타임에 찾아내는**
구조로 되어 있습니다. `Interop.Exploration3D.dll` / `AxInterop.*.dll` 이 없어도 빌드됩니다.

---

## 요구 사항

- Windows + SAP 3D Visual Enterprise Viewer 설치 (ActiveX 등록 상태)
- Visual Studio 2022 / .NET Framework 4.8 개발자 팩
- **x86 빌드 필수** — csproj 에 `<PlatformTarget>x86</PlatformTarget>` 로 고정해 두었습니다.
  AnyCPU 로 바꾸면 64bit 프로세스가 되어 32bit 컨트롤 생성이 실패합니다.

## 빌드 & 실행

```
cd VdsNodeLab
dotnet build -c Debug
bin\Debug\net48\VdsNodeLab.exe
```

Visual Studio 에서는 `VdsNodeLab.csproj` 를 그냥 열어서 F5 로 실행해도 됩니다.

---

## 테스트 순서

### 1. 컨트롤 찾기
프로그램을 켜면 레지스트리를 훑어 ActiveX 컨트롤 목록을 채웁니다.
아무것도 안 나오면 **검색어 칸을 비우고 [컨트롤 검색]** 을 누르세요.
등록된 모든 ActiveX 컨트롤이 나오므로 거기서 Viewer 관련 항목을 찾으면 됩니다.
로그에 ProgID / CLSID / DLL 경로가 같이 찍히므로 어느 게 진짜인지 판별할 수 있습니다.

### 2. [컨트롤 생성]
오른쪽 패널에 뷰어가 뜨고, 로그에 기본 인터페이스 이름(예: `IDeepView`)이 찍힙니다.
여기서 실패하면 대부분 **비트수 불일치**입니다.

### 3. [API 덤프] ← 가장 중요
실행 파일 옆에 `api_dump.txt` 를 만들고 자동으로 엽니다.
타입 라이브러리 전체의 인터페이스 / 메서드 / 속성이 시그니처까지 나옵니다.

```
dispinterface IDeepView   {....}
  method   void      LoadFile(bstr fileName)
  get      bool      Visible()
  ...
```

**이 파일이 사실상의 SDK 레퍼런스입니다.** 노드/씬/가시성 관련 이름을 여기서 확인하세요.

### 4. [VDS 열기]
로드 후 1초 간격으로 최대 20회 씬 트리 읽기를 자동 재시도합니다.
자동으로 안 되면 모델이 화면에 보인 뒤 [씬 트리 읽기]를 누르세요.

### 5. 체크박스로 켜고 끄기
왼쪽 트리에서 체크를 풀면 해당 노드가 숨겨집니다.
처음 한 번은 여러 방식을 순서대로 시도하고, 성공한 방식을 로그에 남긴 뒤 캐시합니다.

```
── 가시성 제어 방식 탐색 시작 ──
✔ 확정: node.Visible = bool
Assembly_01 → 숨기기: 성공 132 / 실패 0 (18ms, 방식=NodeProperty)
```

---

## 자동 탐색이 실패했을 때

로그에 `✘ 자동 탐색 실패` 가 뜨면 두 가지 중 하나로 해결합니다.

**A. 멤버 이름을 알아냈을 때** — `SceneBridge.cs` 상단의 후보 배열에 이름만 추가하면 됩니다.

```csharp
private static readonly string[] VisiblePropNames =
    { "Visible", "visible", "IsVisible", "Visibility", "Shown", "Show",
      "여기에_덤프에서_찾은_이름" };
```

**B. 명령 문자열 방식일 때** — 하단의 `숨기기 명령` / `보이기 명령` 칸에
뷰어 메뉴 경로를 입력하면 "노드 선택 → ExecuteCommand" 방식으로 동작합니다.
정확한 문자열은 `직접 실행` 칸에서 하나씩 시험해 보고 확정하세요.

`노드 속성` 버튼은 선택한 노드 객체의 **읽기 가능한 속성을 실제 값과 함께** 덤프합니다.
PLM 파트번호 같은 메타데이터가 어느 속성에 들어있는지 여기서 바로 확인할 수 있습니다.

---

## 구조

| 파일 | 역할 |
|---|---|
| `ActiveXHost.cs` | CLSID 만으로 임의 ActiveX 호스팅 (interop DLL 불필요) |
| `ControlFinder.cs` | 레지스트리에서 ActiveX 컨트롤 검색 |
| `ComProbe.cs` | 후기 바인딩 호출 + 컬렉션 열거 (IEnumVARIANT / Count+Item, 0·1 기준 모두 시도) |
| `TypeLibDumper.cs` | ITypeInfo → ITypeLib 덤프, 인스턴스 속성 값 덤프 |
| `SceneBridge.cs` | 루트·자식·이름·가시성 멤버 탐색 및 캐시 |
| `MainForm.cs` | UI, 트리 구성, 체크 이벤트 처리 |

## 알려진 제약

- 노드 상한 30,000 / 깊이 48 에서 트리 구성을 중단합니다 (`MainForm.cs` 상수).
- 씬 로드 완료를 이벤트가 아니라 폴링으로 감지합니다. 후기 바인딩으로 COM 이벤트를
  받는 건 까다로워서, 실제 제품 코드에서는 interop 을 생성해 `SceneLoaded` 이벤트를
  쓰는 편이 낫습니다.
- 부모를 숨기면 자식도 함께 사라집니다. 체크 상태는 이 프로그램이 따로 관리하므로
  `자식 노드까지 함께 적용` 을 켜 두면 트리와 화면이 어긋나지 않습니다.
