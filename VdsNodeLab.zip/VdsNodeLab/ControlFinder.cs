using System;
using System.Collections.Generic;
using Microsoft.Win32;

namespace VdsNodeLab
{
    public sealed class ControlInfo
    {
        public string ProgId;
        public string Clsid;
        public string Description;
        public string InprocServer;

        public override string ToString()
        {
            var desc = string.IsNullOrEmpty(Description) ? "" : "  —  " + Description;
            return ProgId + desc;
        }
    }

    /// <summary>
    /// HKEY_CLASSES_ROOT 를 훑어 ActiveX 컨트롤(Control 서브키 보유)만 골라낸다.
    /// </summary>
    internal static class ControlFinder
    {
        public static List<ControlInfo> Find(string keywordCsv)
        {
            var result = new List<ControlInfo>();
            var keywords = new List<string>();

            foreach (var raw in (keywordCsv ?? "").Split(','))
            {
                var k = raw.Trim().ToLowerInvariant().Replace(" ", "");
                if (k.Length > 0) keywords.Add(k);
            }

            var hkcr = Registry.ClassesRoot;
            string[] progIds;
            try { progIds = hkcr.GetSubKeyNames(); }
            catch { return result; }

            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var progId in progIds)
            {
                if (progId.StartsWith(".", StringComparison.Ordinal)) continue;

                var norm = progId.ToLowerInvariant().Replace(" ", "");
                if (keywords.Count > 0)
                {
                    var hit = false;
                    foreach (var k in keywords)
                    {
                        if (norm.IndexOf(k, StringComparison.Ordinal) >= 0) { hit = true; break; }
                    }
                    if (!hit) continue;
                }

                string clsid = null;
                try
                {
                    using (var progKey = hkcr.OpenSubKey(progId))
                    {
                        if (progKey == null) continue;
                        using (var clsidKey = progKey.OpenSubKey("CLSID"))
                        {
                            if (clsidKey == null) continue;
                            clsid = clsidKey.GetValue(null) as string;
                        }
                    }
                }
                catch { continue; }

                if (string.IsNullOrEmpty(clsid)) continue;
                if (!seen.Add(progId)) continue;

                var info = new ControlInfo { ProgId = progId, Clsid = clsid };

                try
                {
                    using (var c = hkcr.OpenSubKey("CLSID\\" + clsid))
                    {
                        if (c == null) continue;

                        // ActiveX 컨트롤만 대상으로 한다
                        using (var ctrl = c.OpenSubKey("Control"))
                        {
                            if (ctrl == null) continue;
                        }

                        info.Description = c.GetValue(null) as string;

                        using (var srv = c.OpenSubKey("InprocServer32"))
                        {
                            if (srv != null) info.InprocServer = srv.GetValue(null) as string;
                        }
                    }
                }
                catch { continue; }

                result.Add(info);
            }

            result.Sort((a, b) => string.Compare(a.ProgId, b.ProgId, StringComparison.OrdinalIgnoreCase));
            return result;
        }
    }
}
