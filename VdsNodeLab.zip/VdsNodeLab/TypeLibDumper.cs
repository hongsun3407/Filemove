using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

// System.Runtime.InteropServices 와 ...InteropServices.ComTypes 양쪽에
// TYPEATTR / FUNCDESC / VARDESC / ELEMDESC / INVOKEKIND 가 모두 존재한다.
// (전자는 obsolete 지만 여전히 mscorlib 에 남아 있어 CS0104 모호한 참조가 발생)
// 그래서 ComTypes 는 using 하지 않고 별칭으로만 접근한다.
using CT = System.Runtime.InteropServices.ComTypes;

namespace VdsNodeLab
{
    /// <summary>
    /// 살아있는 COM 객체에서 ITypeInfo → ITypeLib 로 거슬러 올라가
    /// 타입 라이브러리 전체 멤버를 덤프한다. SDK 문서 없이 API 를 찾는 가장 빠른 길.
    /// </summary>
    internal static class TypeLibDumper
    {
        [ComImport]
        [Guid("00020400-0000-0000-C000-000000000046")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDispatchPartial
        {
            // IDispatch 의 앞 두 메서드만 선언한다. 뒤쪽은 호출하지 않으므로 안전.
            void GetTypeInfoCount(out uint pctinfo);

            void GetTypeInfo(uint iTInfo, uint lcid,
                [MarshalAs(UnmanagedType.Interface)] out CT.ITypeInfo ppTInfo);
        }

        public static string TryGetTypeName(object comObject)
        {
            var ti = GetTypeInfo(comObject);
            if (ti == null) return "(ITypeInfo 없음)";

            try
            {
                string name, doc, helpFile;
                int ctx;
                ti.GetDocumentation(-1, out name, out doc, out ctx, out helpFile);
                return name;
            }
            catch { return "(이름 조회 실패)"; }
        }

        private static CT.ITypeInfo GetTypeInfo(object comObject)
        {
            if (comObject == null) return null;
            try
            {
                var disp = comObject as IDispatchPartial;
                if (disp == null) return null;

                uint n;
                disp.GetTypeInfoCount(out n);
                if (n == 0) return null;

                CT.ITypeInfo ti;
                disp.GetTypeInfo(0, 0, out ti);
                return ti;
            }
            catch { return null; }
        }

        /// <summary>객체가 속한 타입 라이브러리 전체를 텍스트로 덤프한다.</summary>
        public static string DumpFullTypeLib(object comObject)
        {
            var sb = new StringBuilder();
            var ti = GetTypeInfo(comObject);

            if (ti == null)
                return "ITypeInfo 를 얻지 못했습니다. 이 컨트롤은 타입 정보를 노출하지 않습니다.\r\n" +
                       "이 경우 OleView.exe 또는 설치 폴더의 .tlb/.olb 파일을 직접 열어 확인하세요.\r\n";

            try
            {
                CT.ITypeLib lib;
                int index;
                ti.GetContainingTypeLib(out lib, out index);

                string libName, libDoc, libHelp;
                int libCtx;
                lib.GetDocumentation(-1, out libName, out libDoc, out libCtx, out libHelp);

                sb.AppendLine("==================================================");
                sb.AppendLine("TypeLib : " + libName);
                sb.AppendLine("설명    : " + libDoc);
                sb.AppendLine("생성일시: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sb.AppendLine("==================================================");
                sb.AppendLine();

                var count = lib.GetTypeInfoCount();
                sb.AppendLine("타입 개수: " + count);
                sb.AppendLine();

                for (var i = 0; i < count; i++)
                {
                    try
                    {
                        CT.ITypeInfo member;
                        lib.GetTypeInfo(i, out member);
                        DumpTypeInfo(member, sb);
                    }
                    catch (Exception ex)
                    {
                        sb.AppendLine("  [" + i + "] 덤프 실패: " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine("TypeLib 덤프 실패: " + ex.Message);
            }

            return sb.ToString();
        }

        private static void DumpTypeInfo(CT.ITypeInfo ti, StringBuilder sb)
        {
            if (ti == null) return;

            string name, doc, helpFile;
            int ctx;
            ti.GetDocumentation(-1, out name, out doc, out ctx, out helpFile);

            var attrPtr = IntPtr.Zero;
            try
            {
                ti.GetTypeAttr(out attrPtr);
                var attr = (CT.TYPEATTR)Marshal.PtrToStructure(attrPtr, typeof(CT.TYPEATTR));

                sb.AppendLine("--------------------------------------------------");
                sb.AppendLine(attr.typekind + "  " + name + "   {" + attr.guid + "}");
                if (!string.IsNullOrEmpty(doc)) sb.AppendLine("  // " + doc);
                sb.AppendLine("--------------------------------------------------");

                for (var f = 0; f < attr.cFuncs; f++)
                {
                    var funcPtr = IntPtr.Zero;
                    try
                    {
                        ti.GetFuncDesc(f, out funcPtr);
                        var fd = (CT.FUNCDESC)Marshal.PtrToStructure(funcPtr, typeof(CT.FUNCDESC));

                        var names = new string[fd.cParams + 1];
                        int got;
                        try { ti.GetNames(fd.memid, names, names.Length, out got); }
                        catch { got = 0; }

                        var memberName = (got > 0 && names[0] != null) ? names[0] : "memid_" + fd.memid;

                        var kind = "method  ";
                        if ((fd.invkind & CT.INVOKEKIND.INVOKE_PROPERTYGET) != 0) kind = "get     ";
                        else if ((fd.invkind & CT.INVOKEKIND.INVOKE_PROPERTYPUT) != 0) kind = "put     ";
                        else if ((fd.invkind & CT.INVOKEKIND.INVOKE_PROPERTYPUTREF) != 0) kind = "putref  ";

                        var pars = new List<string>();
                        var elemSize = Marshal.SizeOf(typeof(CT.ELEMDESC));

                        for (var p = 0; p < fd.cParams; p++)
                        {
                            var elemPtr = new IntPtr(fd.lprgelemdescParam.ToInt64() + p * elemSize);
                            var ed = (CT.ELEMDESC)Marshal.PtrToStructure(elemPtr, typeof(CT.ELEMDESC));
                            var pname = (got > p + 1 && names[p + 1] != null) ? names[p + 1] : "arg" + p;
                            pars.Add(VtName(ed.tdesc.vt) + " " + pname);
                        }

                        sb.AppendLine("  " + kind + VtName(fd.elemdescFunc.tdesc.vt).PadRight(10) +
                                      memberName + "(" + string.Join(", ", pars.ToArray()) + ")");
                    }
                    catch { }
                    finally { if (funcPtr != IntPtr.Zero) ti.ReleaseFuncDesc(funcPtr); }
                }

                for (var v = 0; v < attr.cVars; v++)
                {
                    var varPtr = IntPtr.Zero;
                    try
                    {
                        ti.GetVarDesc(v, out varPtr);
                        var vd = (CT.VARDESC)Marshal.PtrToStructure(varPtr, typeof(CT.VARDESC));

                        string vName, vDoc, vHelp;
                        int vCtx;
                        ti.GetDocumentation(vd.memid, out vName, out vDoc, out vCtx, out vHelp);

                        sb.AppendLine("  field   " + VtName(vd.elemdescVar.tdesc.vt).PadRight(10) + vName);
                    }
                    catch { }
                    finally { if (varPtr != IntPtr.Zero) ti.ReleaseVarDesc(varPtr); }
                }

                sb.AppendLine();
            }
            catch (Exception ex)
            {
                sb.AppendLine("  타입 속성 조회 실패: " + ex.Message);
            }
            finally
            {
                if (attrPtr != IntPtr.Zero) ti.ReleaseTypeAttr(attrPtr);
            }
        }

        /// <summary>
        /// 인스턴스에서 인자 없는 읽기 속성만 골라 실제 값을 읽어 온다.
        /// 노드 객체 하나를 골라 "무슨 정보가 들어있나" 확인할 때 쓴다.
        /// </summary>
        public static string DumpInstanceProperties(object comObject)
        {
            var sb = new StringBuilder();
            var ti = GetTypeInfo(comObject);

            if (ti == null)
            {
                sb.AppendLine("이 객체는 타입 정보를 노출하지 않습니다.");
                return sb.ToString();
            }

            var attrPtr = IntPtr.Zero;
            try
            {
                string tname, tdoc, thelp;
                int tctx;
                ti.GetDocumentation(-1, out tname, out tdoc, out tctx, out thelp);
                sb.AppendLine("[" + tname + "] 읽기 가능한 속성");
                sb.AppendLine(new string('-', 50));

                ti.GetTypeAttr(out attrPtr);
                var attr = (CT.TYPEATTR)Marshal.PtrToStructure(attrPtr, typeof(CT.TYPEATTR));

                for (var f = 0; f < attr.cFuncs; f++)
                {
                    var funcPtr = IntPtr.Zero;
                    try
                    {
                        ti.GetFuncDesc(f, out funcPtr);
                        var fd = (CT.FUNCDESC)Marshal.PtrToStructure(funcPtr, typeof(CT.FUNCDESC));

                        if ((fd.invkind & CT.INVOKEKIND.INVOKE_PROPERTYGET) == 0) continue;
                        if (fd.cParams != 0) continue;

                        var names = new string[1];
                        int got;
                        ti.GetNames(fd.memid, names, 1, out got);
                        if (got == 0 || names[0] == null) continue;

                        object value;
                        var text = ComProbe.TryGet(comObject, names[0], out value)
                            ? Describe(value)
                            : "(읽기 실패)";

                        sb.AppendLine("  " + names[0].PadRight(28) + " = " + text);
                    }
                    catch { }
                    finally { if (funcPtr != IntPtr.Zero) ti.ReleaseFuncDesc(funcPtr); }
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine("속성 덤프 실패: " + ex.Message);
            }
            finally
            {
                if (attrPtr != IntPtr.Zero) ti.ReleaseTypeAttr(attrPtr);
            }

            return sb.ToString();
        }

        private static string Describe(object value)
        {
            if (value == null) return "(null)";
            try
            {
                if (value.GetType().IsCOMObject)
                    return "COM<" + TryGetTypeName(value) + ">";

                var s = value.ToString();
                return s.Length > 120 ? s.Substring(0, 120) + "..." : s;
            }
            catch { return "(표시 불가)"; }
        }

        private static string VtName(short vt)
        {
            try
            {
                var v = (VarEnum)(vt & 0x0FFF);
                var text = v.ToString().Replace("VT_", "").ToLowerInvariant();
                return (vt & 0x4000) != 0 ? text + "*" : text;
            }
            catch { return "vt" + vt; }
        }
    }
}
