'use strict';
/**
 * 스키마 마이그레이션.
 * PRAGMA user_version 으로 현재 버전을 추적하고, 부족한 단계만 순서대로 적용합니다.
 * 새 스키마 변경은 MIGRATIONS 배열 끝에 추가하기만 하면 됩니다. (기존 항목 수정 금지)
 */

const MIGRATIONS = [
  // --- v1 : 사용자 / 세션 / 앱 / 권한 / 로그 ---
  `
  CREATE TABLE users (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    login_id       TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    name           TEXT    NOT NULL DEFAULT '',
    dept           TEXT    NOT NULL DEFAULT '',
    password_hash  TEXT    NOT NULL,
    role           TEXT    NOT NULL DEFAULT 'user',      -- 'admin' | 'user'
    status         TEXT    NOT NULL DEFAULT 'active',    -- 'active' | 'disabled'
    must_change_pw INTEGER NOT NULL DEFAULT 1,
    failed_count   INTEGER NOT NULL DEFAULT 0,
    locked_until   INTEGER,                              -- epoch ms
    created_at     INTEGER NOT NULL,
    updated_at     INTEGER NOT NULL,
    last_login_at  INTEGER
  );

  CREATE TABLE sessions (
    sid          TEXT    PRIMARY KEY,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    data         TEXT    NOT NULL DEFAULT '{}',
    created_at   INTEGER NOT NULL,
    last_seen_at INTEGER NOT NULL,
    expires_at   INTEGER NOT NULL,
    ip           TEXT    NOT NULL DEFAULT '',
    user_agent   TEXT    NOT NULL DEFAULT ''
  );
  CREATE INDEX idx_sessions_user ON sessions(user_id);
  CREATE INDEX idx_sessions_exp  ON sessions(expires_at);

  CREATE TABLE apps (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    slug        TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    title       TEXT    NOT NULL,
    description TEXT    NOT NULL DEFAULT '',
    entry_file  TEXT    NOT NULL DEFAULT 'index.html',
    visibility  TEXT    NOT NULL DEFAULT 'restricted',   -- 'all' | 'restricted'
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  INTEGER NOT NULL,
    updated_at  INTEGER NOT NULL,
    uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE app_permissions (
    app_id     INTEGER NOT NULL REFERENCES apps(id)  ON DELETE CASCADE,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    granted_at INTEGER NOT NULL,
    granted_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    PRIMARY KEY (app_id, user_id)
  );

  CREATE TABLE access_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    login_id   TEXT    NOT NULL DEFAULT '',
    app_id     INTEGER,
    app_slug   TEXT    NOT NULL DEFAULT '',
    path       TEXT    NOT NULL DEFAULT '',
    result     TEXT    NOT NULL,                          -- 'ok' | 'denied' | 'notfound'
    ip         TEXT    NOT NULL DEFAULT '',
    user_agent TEXT    NOT NULL DEFAULT '',
    at         INTEGER NOT NULL
  );
  CREATE INDEX idx_access_at   ON access_logs(at);
  CREATE INDEX idx_access_user ON access_logs(user_id);

  CREATE TABLE audit_logs (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    actor    TEXT    NOT NULL DEFAULT '',
    action   TEXT    NOT NULL,
    target   TEXT    NOT NULL DEFAULT '',
    detail   TEXT    NOT NULL DEFAULT '',
    ip       TEXT    NOT NULL DEFAULT '',
    at       INTEGER NOT NULL
  );
  CREATE INDEX idx_audit_at ON audit_logs(at);
  `,

  // --- v2 : 콘텐츠 정렬 순서와 대표 이미지 ---
  `
  ALTER TABLE apps ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0;
  ALTER TABLE apps ADD COLUMN thumbnail  TEXT    NOT NULL DEFAULT '';
  UPDATE apps SET sort_order = id;
  `,

  // --- v3 : 콘텐츠별 압축 다운로드 허용 여부 ---
  `
  ALTER TABLE apps ADD COLUMN allow_download INTEGER NOT NULL DEFAULT 1;
  `,
];

function migrate(db) {
  const row = db.get('PRAGMA user_version');
  const current = Number(row.user_version || 0);

  for (let v = current; v < MIGRATIONS.length; v++) {
    db.exec('BEGIN');
    try {
      db.exec(MIGRATIONS[v]);
      db.exec(`PRAGMA user_version = ${v + 1}`);
      db.exec('COMMIT');
      console.log(`[db] 마이그레이션 v${v + 1} 적용됨`);
    } catch (err) {
      try { db.exec('ROLLBACK'); } catch { /* noop */ }
      throw err;
    }
  }
}

module.exports = { migrate, MIGRATION_COUNT: MIGRATIONS.length };
