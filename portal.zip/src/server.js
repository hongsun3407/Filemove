'use strict';
/**
 * 포탈 HTTP 서버 — 외부 의존성 없이 Node 내장 모듈만 사용합니다.
 *
 * 요청 처리 순서 (감사하기 쉽도록 명시적으로 나열):
 *   1. URL 파싱
 *   2. 보안 응답 헤더
 *   3. 정적 자원(/static) — 인증 불필요
 *   4. 세션 부착
 *   5. CSRF 토큰 부착
 *   6. 본문 파싱 (POST)
 *   7. CSRF 검증 (상태 변경 요청)
 *   8. 라우팅 — 라우트별 미들웨어가 인증/권한 검사
 *   9. 404 / 405
 */
const http = require('node:http');
const fs = require('node:fs');

const config = require('./config');
const db = require('./db');
const session = require('./session');
const csrf = require('./lib/csrf');
const security = require('./middleware/security');
const staticFiles = require('./middleware/static');
const views = require('./views');
const { Router, responded } = require('./router');
const { readForm, sendHtml, sendText, redirect } = require('./lib/http');
const { requireAuth, requireAdmin, requirePasswordChanged } = require('./middleware/auth');

const multipart = require('./lib/multipart');
const authRoutes = require('./routes/auth');
const homeRoutes = require('./routes/home');
const contentRoutes = require('./routes/content');
const adminUsers = require('./routes/admin-users');
const adminApps = require('./routes/admin-apps');
const adminLogs = require('./routes/admin-logs');
const downloadRoutes = require('./routes/download');

/* ------------------------------ 라우트 정의 ------------------------------ */

const router = new Router();

// 로그인한 일반 사용자용 미들웨어 묶음
const user = [requireAuth, requirePasswordChanged];
// 관리자용 미들웨어 묶음
const admin = [requireAuth, requirePasswordChanged, requireAdmin];

// --- 인증 불필요 ---
router.get('/login', authRoutes.getLogin);
router.post('/login', authRoutes.postLogin);
router.get('/healthz', (req, res) => sendText(res, 'ok'));

// --- 로그인 필요 (비밀번호 변경 강제 대상에서 제외) ---
router.post('/logout', requireAuth, authRoutes.postLogout);
router.get('/change-password', requireAuth, authRoutes.getChangePassword);
router.post('/change-password', requireAuth, authRoutes.postChangePassword);

// --- 일반 사용자 ---
router.get('/', ...user, homeRoutes.getDashboard);
router.get('/view/:slug', ...user, homeRoutes.getViewer);
router.get('/download/:slug', ...user, downloadRoutes.getAppZip);

// --- ★ 보호 콘텐츠 서빙 ★ ---
router.get('/app/:slug', ...user, contentRoutes.redirectToRoot);
router.get('/app/:slug/*', ...user, contentRoutes.serve);

// --- 관리자: 사용자 ---
router.get('/admin/users', ...admin, adminUsers.getUsers);
router.get('/admin/users/new', ...admin, adminUsers.getUserNew);
router.post('/admin/users', ...admin, adminUsers.postUserCreate);
router.get('/admin/users/:id', ...admin, adminUsers.getUserDetail);
router.post('/admin/users/:id', ...admin, adminUsers.postUserUpdate);
router.post('/admin/users/:id/reset', ...admin, adminUsers.postUserReset);
router.post('/admin/users/:id/unlock', ...admin, adminUsers.postUserUnlock);
router.post('/admin/users/:id/kill-sessions', ...admin, adminUsers.postUserKillSessions);
router.post('/admin/users/:id/access', ...admin, adminUsers.postUserAccess);
router.post('/admin/users/:id/delete', ...admin, adminUsers.postUserDelete);

// --- 관리자: 콘텐츠 ---
router.get('/admin/apps', ...admin, adminApps.getApps);
router.get('/admin/apps/new', ...admin, adminApps.getAppNew);
router.post('/admin/apps', ...admin, adminApps.postAppCreate);
router.get('/admin/apps/:id', ...admin, adminApps.getAppDetail);
router.post('/admin/apps/:id', ...admin, adminApps.postAppUpdate);
router.post('/admin/apps/:id/replace', ...admin, adminApps.postAppReplace);
router.post('/admin/apps/:id/toggle', ...admin, adminApps.postAppToggle);
router.post('/admin/apps/:id/access', ...admin, adminApps.postAppAccess);
router.post('/admin/apps/:id/delete', ...admin, adminApps.postAppDelete);
router.post('/admin/apps/:id/move', ...admin, adminApps.postAppMove);
router.post('/admin/apps/:id/files', ...admin, adminApps.postAppAddFiles);
router.post('/admin/apps/:id/files/delete', ...admin, adminApps.postAppDeleteFile);

// --- 관리자: 접근 기록 ---
router.get('/admin/logs', ...admin, adminLogs.getLogs);
router.get('/admin/logs/export', ...admin, adminLogs.getLogsCsv);

// --- 관리자: 백업 ---
router.get('/admin/backup', ...admin, downloadRoutes.getBackupPage);
router.get('/admin/backup/download', ...admin, downloadRoutes.getBackup);
router.get('/admin', ...admin, (req, res) => redirect(res, '/admin/users'));

/* ------------------------------ 요청 처리 ------------------------------ */

async function handle(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const pathname = decodeSafe(url.pathname);
  req.originalUrl = req.url;
  req.pathname = pathname;
  req.query = url.searchParams;

  // 1-1. 디코딩 실패나 널바이트가 섞인 경로는 여기서 끝냅니다.
  //      (보안 헤더 적용보다 먼저 걸러야 pathname 이 null 인 채로 흘러가지 않습니다)
  if (pathname === null) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    return sendHtml(res, views.error({
      req, status: 400, title: '잘못된 요청',
      message: '주소에 사용할 수 없는 문자가 들어 있습니다.',
    }), 400);
  }

  // 2. 보안 헤더
  security.apply(req, res, pathname);

  // 3. 정적 자원
  if (staticFiles.serve(req, res, pathname)) return;

  // 4~5. 세션 + CSRF 토큰
  session.attach(req, res);
  csrf.attach(req, res);

  // 6. 본문 파싱
  req.body = Object.create(null);
  req.bodyAll = Object.create(null);
  req.files = [];

  if (req.method === 'POST') {
    const contentType = String(req.headers['content-type'] || '');

    if (/^multipart\/form-data/i.test(contentType)) {
      // 파일 업로드는 관리자만, 관리자 경로에서만 받습니다.
      // (로그인한 일반 사용자가 아무 경로로나 대용량 본문을 보내 메모리를 소모하는 것을 막습니다)
      if (!req.user || req.user.role !== 'admin' || !pathname.startsWith('/admin/')) {
        req.resume();
        return sendHtml(res, views.error({
          req, status: 403, title: '허용되지 않은 업로드',
        }), 403);
      }
      const parsed = await multipart.parse(req, {
        maxBytes: config.MAX_UPLOAD_BYTES,
        maxFiles: config.MAX_FILES_PER_UPLOAD,
      });
      req.body = parsed.fields;
      req.bodyAll = parsed.all;
      req.files = parsed.files;
    } else {
      const parsed = await readForm(req);
      req.body = parsed.fields;
      req.bodyAll = parsed.all;
    }
  }

  // 7. CSRF 검증
  if (!csrf.verify(req)) {
    console.warn(`[csrf] 거부 ${req.method} ${pathname}`);
    return sendHtml(res, views.error({
      req, status: 403, title: '요청이 거부되었습니다',
      message: '보안 토큰이 유효하지 않습니다. 페이지를 새로고침한 뒤 다시 시도해 주세요.',
    }), 403);
  }

  // 8. 라우팅
  const matched = router.match(req.method, pathname);
  if (matched === 'method-mismatch') {
    return sendHtml(res, views.error({
      req, status: 405, title: '허용되지 않은 방식',
    }), 405);
  }
  if (matched) {
    req.params = matched.params;
    if (await router.run(matched.handlers, req, res)) return;
  }

  // 9. 404 — 이미 응답이 시작된 경우(스트리밍 등)에는 손대지 않습니다.
  if (responded(res)) return;
  sendHtml(res, views.error({
    req, status: 404, title: '페이지를 찾을 수 없습니다',
    message: '주소를 다시 확인해 주세요.',
  }), 404);
}

function decodeSafe(pathname) {
  try {
    const decoded = decodeURIComponent(pathname);
    // 널바이트 등 비정상 문자 차단
    if (decoded.includes('\0')) return null;
    return decoded;
  } catch {
    return null;
  }
}

/* ------------------------------ 서버 기동 ------------------------------ */

const server = http.createServer((req, res) => {
  handle(req, res).catch((err) => {
    const status = err && err.statusCode ? err.statusCode : 500;

    // 사용자에게 그대로 보여도 되는 메시지(업로드 검증 실패 등)는 그대로 전달하고,
    // 그 외 예기치 못한 오류는 내부 사정을 노출하지 않습니다.
    const safeMessage = err && err.userMessage
      ? err.userMessage
      : '잠시 후 다시 시도해 주세요. 문제가 계속되면 관리자에게 알려 주세요.';

    if (status >= 500) console.error(`[error] ${req.method} ${req.url}`, err);
    else console.warn(`[warn] ${req.method} ${req.url} → ${status}: ${err.message}`);

    if (res.headersSent || res.writableEnded) { try { res.end(); } catch { /* noop */ } return; }
    sendHtml(res, views.error({
      req, status,
      title: status === 413 ? '요청이 너무 큽니다' : status >= 500 ? '서버 오류' : '요청을 처리할 수 없습니다',
      message: safeMessage,
    }), status);
  });
});

server.headersTimeout = 20_000;
server.requestTimeout = 60_000;

function start() {
  fs.mkdirSync(config.DATA_DIR, { recursive: true });
  fs.mkdirSync(config.STORAGE_DIR, { recursive: true });
  fs.mkdirSync(config.LOG_DIR, { recursive: true });

  db.open();

  const admins = db.get(`SELECT COUNT(*) AS n FROM users WHERE role = 'admin'`).n;
  if (admins === 0) {
    console.warn('[경고] 관리자 계정이 없습니다. `npm run create-admin` 을 먼저 실행하세요.');
  }

  // 만료 세션 정리
  const sweeper = setInterval(() => {
    try {
      const n = session.sweep();
      if (n) console.log(`[session] 만료 세션 ${n}건 정리`);
    } catch (err) { console.error('[session] 정리 실패:', err.message); }
  }, 10 * 60 * 1000);
  sweeper.unref();

  server.listen(config.PORT, config.HOST, () => {
    console.log(`[portal] http://${config.HOST}:${config.PORT} 에서 대기 중`);
    console.log(`[portal] 데이터: ${config.DATA_DIR}`);
    console.log(`[portal] 콘텐츠: ${config.STORAGE_DIR}`);
    if (!config.SECURE_COOKIE) {
      console.log('[portal] 주의: SECURE_COOKIE=false. 운영 시 HTTPS 뒤에 두고 .env 에서 true 로 바꾸세요.');
    }
  });

  for (const sig of ['SIGINT', 'SIGTERM']) {
    process.on(sig, () => {
      console.log(`\n[portal] ${sig} 수신 — 종료합니다.`);
      server.close(() => { db.close(); process.exit(0); });
      setTimeout(() => process.exit(1), 5000).unref();
    });
  }
}

if (require.main === module) start();

module.exports = { server, start, handle, router };
