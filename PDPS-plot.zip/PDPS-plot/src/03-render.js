/* ═══════════════════════════════════════════════════════════════════
   계층 ③  렌더러 — Canvas 2D
   좌/우 다중 Y축, 축별 독립 범위, X축 index/time 전환, min/max 밴드.
   뷰포트는 항상 "행 인덱스 공간"에서 관리하고, 표시값만 X 파라미터로 매핑한다.
   ═══════════════════════════════════════════════════════════════════ */

function niceTicks(lo,hi,count){
  const span=hi-lo;
  if(!(span>0)||!isFinite(span)) return [lo];
  const s0=span/Math.max(1,count);
  const mag=Math.pow(10,Math.floor(Math.log10(s0)));
  const nrm=s0/mag;
  const step=(nrm<=1?1:nrm<=2?2:nrm<=2.5?2.5:nrm<=5?5:10)*mag;
  const out=[]; const start=Math.ceil(lo/step-1e-9)*step;
  for(let v=start;v<=hi+step*1e-9;v+=step) out.push(Math.abs(v)<step*1e-9?0:v);
  return out;
}
const TIME_STEPS=[1e-3,2e-3,5e-3,1e-2,2e-2,5e-2,.1,.2,.5,1,2,5,10,15,30,60,120,300,600,900,1800,3600,7200,21600,43200,86400];
function timeTicks(lo,hi,count){
  const span=hi-lo; if(!(span>0)) return [lo];
  const want=span/Math.max(1,count);
  const step=TIME_STEPS.find(s=>s>=want)??TIME_STEPS[TIME_STEPS.length-1];
  const out=[]; for(let v=Math.ceil(lo/step)*step;v<=hi+step*1e-9;v+=step) out.push(v);
  return out;
}
function fmtTime(s,step){
  const neg=s<0; s=Math.abs(s);
  const h=Math.floor(s/3600), m=Math.floor(s%3600/60), sec=s%60;
  const p=(n,w=2)=>String(Math.floor(n)).padStart(w,'0');
  let out;
  if(step<1) out=`${p(m)}:${p(sec)}.${p((sec%1)*1000,3)}`;
  else if(h>0) out=`${h}:${p(m)}:${p(sec)}`;
  else out=`${p(m)}:${p(sec)}`;
  return (neg?'-':'')+out;
}
function fmtNum(v,dec,radix){
  if(v===null||v===undefined||Number.isNaN(v)) return '—';
  if(radix&&radix!==10){
    const i=Math.round(v);
    return (i<0?'-':'')+Math.abs(i).toString(radix).toUpperCase()+(radix===16?'h':radix===2?'b':'o');
  }
  const a=Math.abs(v);
  if(a!==0&&(a<1e-4||a>=1e7)) return v.toExponential(2);
  return v.toFixed(dec??3).replace(/\.?0+$/,m=>m.includes('.')?'':m);
}
function fmtTick(v,step){
  if(v===0) return '0';
  const a=Math.abs(v);
  if(a<1e-4||a>=1e6) return v.toExponential(1);
  const d=Math.max(0,Math.min(6,-Math.floor(Math.log10(Math.abs(step)))+ (Math.abs(step)<1?1:0)));
  return v.toFixed(step>=1?0:d);
}

/* ── 축 범위 계산 ────────────────────────────────────────────────── */
function resolveRange(rng,dataLo,dataHi,axesResolved){
  let lo=dataLo,hi=dataHi;
  if(!isFinite(lo)||!isFinite(hi)){ lo=0; hi=1; }
  switch(rng?.mode){
    case 'manual':  return [Number(rng.min),Number(rng.max)];
    case 'manual-partial':
      return [rng.min===''||rng.min==null?lo:Number(rng.min), rng.max===''||rng.max==null?hi:Number(rng.max)];
    case 'symmetric':{ const m=Math.max(Math.abs(lo),Math.abs(hi))||1; return [-m,m]; }
    case 'nice':{ const t=niceTicks(lo,hi,rng.targetTicks||5); const st=t.length>1?t[1]-t[0]:1;
      return [Math.floor(lo/st)*st,Math.ceil(hi/st)*st]; }
    case 'shared':{ const o=axesResolved&&axesResolved[rng.withAxisId]; if(o) return [o[0],o[1]]; break; }
    case 'auto': break;
    case 'auto-padded': default:{
      const pad=(hi-lo)*((rng?.padPct??5)/100)||Math.abs(hi||1)*0.05||1;
      return [lo-pad,hi+pad];
    }
  }
  if(lo===hi){ const d=Math.abs(lo)*0.05||1; return [lo-d,hi+d]; }
  return [lo,hi];
}

/* ── 패널 뷰 ─────────────────────────────────────────────────────── */
class PlotView{
  constructor(host,app,panel){
    this.app=app; this.panel=panel;
    this.cv=document.createElement('canvas');
    host.appendChild(this.cv);
    this.ctx=this.cv.getContext('2d');
    this.hover=null; this.drag=null; this.geom=null; this.localVp=null;
    this._bind();
  }
  destroy(){ this.cv.remove(); }
  vp(){ return (this.app.tpl.layout.syncXZoom===false && this.localVp) ? this.localVp : this.app.viewport; }

  _bind(){
    const cv=this.cv;
    cv.style.cursor='crosshair';
    cv.addEventListener('mousemove',e=>{
      const r=cv.getBoundingClientRect(); const x=e.clientX-r.left,y=e.clientY-r.top;
      if(this.drag){
        if(this.drag.mode==='pan'){
          const g=this.geom; if(g){
            const dIdx=(this.drag.x-x)/g.pw*(this.drag.to-this.drag.from);
            this.app.setViewport(this.drag.from+dIdx,this.drag.to+dIdx,this);
          }
        } else { this.drag.x2=x; this.app.requestDraw(); }
      }
      this.hover={x,y}; this.app.setCursor(this.idxAt(x),this);
    });
    cv.addEventListener('mouseleave',()=>{ this.hover=null; this.app.setCursor(null,this); });
    cv.addEventListener('mousedown',e=>{
      const r=cv.getBoundingClientRect(); const x=e.clientX-r.left;
      const vp=this.vp();
      this.drag=e.shiftKey||e.button===1
        ? {mode:'pan',x,from:vp[0],to:vp[1]}
        : {mode:'sel',x1:x,x2:x};
      e.preventDefault();
    });
    window.addEventListener('mouseup',()=>{
      if(this.drag&&this.drag.mode==='sel'){
        const {x1,x2}=this.drag, g=this.geom;
        if(g&&Math.abs(x2-x1)>6){
          const a=this.idxAt(Math.min(x1,x2)), b=this.idxAt(Math.max(x1,x2));
          if(a!=null&&b!=null) this.app.setViewport(a,b,this);
        }
      }
      if(this.drag){ this.drag=null; this.app.requestDraw(); }
    });
    cv.addEventListener('dblclick',()=>this.app.resetViewport());
    cv.addEventListener('wheel',e=>{
      e.preventDefault();
      const g=this.geom; if(!g) return;
      const r=cv.getBoundingClientRect();
      const f=(e.clientX-r.left-g.x0)/g.pw;
      const k=e.deltaY>0?1.25:0.8;
      const [a,b]=this.vp(), span=b-a, ns=span*k;
      const c=a+span*Math.max(0,Math.min(1,f));
      this.app.setViewport(c-ns*Math.max(0,Math.min(1,f)), c+ns*(1-Math.max(0,Math.min(1,f))), this);
    },{passive:false});
  }
  idxAt(px){
    const g=this.geom; if(!g) return null;
    const [a,b]=this.vp();
    const t=(px-g.x0)/g.pw;
    if(t<-0.02||t>1.02) return null;
    return a+t*(b-a);
  }

  draw(){
    const app=this.app, P=this.panel, cat=app.catalog, tpl=app.tpl;
    const dpr=Math.min(2,window.devicePixelRatio||1);
    const W=this.cv.clientWidth, H=this.cv.clientHeight;
    if(W<10||H<10) return;
    if(this.cv.width!==Math.round(W*dpr)||this.cv.height!==Math.round(H*dpr)){
      this.cv.width=Math.round(W*dpr); this.cv.height=Math.round(H*dpr);
    }
    const c=this.ctx;
    c.setTransform(dpr,0,0,dpr,0,0);
    c.clearRect(0,0,W,H);
    const CSS=getComputedStyle(document.documentElement);
    const COL={fg:'#e6edf3',fg2:'#9fb0c3',fg3:'#6b7f95',line:'#2b3644',bg:'#161b22'};

    const tD0=performance.now();
    const [vf,vt]=this.vp();
    const series=(P.series||[]).filter(s=>s.visible!==false&&cat.get(s.paramId));
    const axes=(P.yAxes||[]).filter(a=>a.visible!==false);

    /* 1) 각 축의 데이터 범위 → 표시 범위 */
    const axData={}, blocks=new Map();
    const bucketsGuess=Math.max(64,Math.round(W));
    for(const s of series){
      const rec=cat.tryCompute(s.paramId); if(!rec) continue;
      const q=rec.pyr.query(vf,vt,bucketsGuess);
      blocks.set(s.id,q);
      let lo=Infinity,hi=-Infinity;
      for(let i=0;i<q.n;i++){ if(q.lo[i]<lo)lo=q.lo[i]; if(q.hi[i]>hi)hi=q.hi[i]; }
      const sc=s.yScale??1, of=s.yOffset??0;
      lo=lo*sc+of; hi=hi*sc+of;
      const d=axData[s.axisId]||(axData[s.axisId]=[Infinity,-Infinity]);
      if(lo<d[0])d[0]=lo; if(hi>d[1])d[1]=hi;
    }
    this.tQuery=performance.now()-tD0;
    const axRange={};
    for(const a of axes){ const d=axData[a.id]||[0,1]; axRange[a.id]=resolveRange(a.range,d[0],d[1],axRange); }

    /* 2) 레이아웃 — 축 폭은 눈금 라벨 실측으로 결정 */
    c.font='11px ui-monospace,Menlo,Consolas,monospace';
    const axInfo=axes.map(a=>{
      const [lo,hi]=axRange[a.id];
      const ticks=niceTicks(lo,hi,Math.max(2,Math.floor(H/46)));
      const st=ticks.length>1?ticks[1]-ticks[0]:1;
      const labs=ticks.map(v=>fmtTick(v,st));
      let w=0; for(const l of labs) w=Math.max(w,c.measureText(l).width);
      const title=axisTitle(a,P,cat);
      return {a,ticks,labs,w:Math.min(78,Math.max(30,w))+9+(title?14:0),title,lo,hi};
    });
    const L=axInfo.filter(i=>i.a.side!=='right'), R=axInfo.filter(i=>i.a.side==='right');
    const padL=L.reduce((s,i)=>s+i.w,0)+6, padR=R.reduce((s,i)=>s+i.w,0)+8;
    const padT=8, padB=(tpl.x.title&&tpl.x.title.mode!=='none')?38:26;
    const x0=padL, x1=W-padR, y0=padT, y1=H-padB, pw=x1-x0, ph=y1-y0;
    if(pw<20||ph<20) return;
    this.geom={x0,x1,y0,y1,pw,ph};

    const X=i=>x0+(i-vf)/(vt-vf)*pw;
    const Y=(v,id)=>{ const [lo,hi]=axRange[id]||[0,1]; return y1-(v-lo)/(hi-lo||1)*ph; };

    /* 3) 배경 · 격자 */
    c.fillStyle='#12171e'; c.fillRect(x0,y0,pw,ph);

    const xv=app.xVec();
    const xLo=app.xDisplay(vf), xHi=app.xDisplay(vt);
    const isTime=tpl.x.mode==='time'&&!!xv;
    const xt=(isTime?timeTicks:niceTicks)(xLo,xHi,Math.max(2,Math.floor(pw/95)));
    const xstep=xt.length>1?xt[1]-xt[0]:1;

    if(tpl.x.grid!==false){
      c.strokeStyle=COL.line; c.lineWidth=1; c.beginPath();
      for(const v of xt){ const px=Math.round(x0+(v-xLo)/((xHi-xLo)||1)*pw)+.5;
        if(px>x0&&px<x1){ c.moveTo(px,y0); c.lineTo(px,y1);} }
      c.stroke();
    }
    const gridAx=axInfo.find(i=>i.a.grid!==false)||axInfo[0];
    if(gridAx){
      c.strokeStyle=COL.line; c.beginPath();
      for(const v of gridAx.ticks){ const py=Math.round(Y(v,gridAx.a.id))+.5;
        if(py>y0&&py<y1){ c.moveTo(x0,py); c.lineTo(x1,py);} }
      c.stroke();
    }

    /* 4) 시리즈 */
    for(const s of series){
      const q=blocks.get(s.id); if(!q||!q.n) continue;
      const sc=s.yScale??1, of=s.yOffset??0;
      c.save();
      c.beginPath(); c.rect(x0,y0,pw,ph); c.clip();
      c.strokeStyle=s.color||'#4da3ff'; c.lineWidth=s.width||1.4;
      c.globalAlpha=s.opacity??1;
      c.setLineDash(s.dash||[]);
      c.lineJoin='round'; c.lineCap='round';

      if(s.style==='points'||(q.exact&&s.style==='points')){
        c.fillStyle=c.strokeStyle;
        for(let i=0;i<q.n;i++){ const v=q.lo[i]*sc+of; if(Number.isNaN(v))continue;
          c.fillRect(X(q.idx[i])-1,Y(v,s.axisId)-1,2.4,2.4); }
      } else if(q.exact){
        c.beginPath(); let pen=false;
        for(let i=0;i<q.n;i++){
          const v=q.lo[i]*sc+of;
          if(Number.isNaN(v)){ pen=false; continue; }
          const px=X(q.idx[i]), py=Y(v,s.axisId);
          if(!pen){ c.moveTo(px,py); pen=true; }
          else if(s.style==='step'){ c.lineTo(px,c.__ly??py); c.lineTo(px,py); }
          else c.lineTo(px,py);
          c.__ly=py;
        }
        if(s.style==='area'){ c.lineTo(X(q.idx[q.n-1]),y1); c.lineTo(X(q.idx[0]),y1); c.closePath();
          c.globalAlpha=(s.opacity??1)*.22; c.fillStyle=c.strokeStyle; c.fill(); c.globalAlpha=s.opacity??1; }
        c.stroke();
      } else {
        // min/max 밴드: 버킷마다 [min,max] 세로선을 이어 그린다 → 스파이크 보존
        c.beginPath(); let pen=false;
        for(let i=0;i<q.n;i++){
          const a=q.lo[i]*sc+of, b=q.hi[i]*sc+of;
          if(Number.isNaN(a)){ pen=false; continue; }
          const px=Math.round(X(q.idx[i]))+.5, pa=Y(a,s.axisId), pb=Y(b,s.axisId);
          if(!pen){ c.moveTo(px,pa); pen=true; }
          else c.lineTo(px,pa);
          c.lineTo(px,pb);
        }
        if(s.style==='area'){
          c.save(); c.globalAlpha=(s.opacity??1)*.2; c.fillStyle=c.strokeStyle;
          c.lineTo(X(q.idx[q.n-1]),y1); c.lineTo(X(q.idx[0]),y1); c.closePath(); c.fill(); c.restore();
        }
        c.stroke();
      }
      c.restore();
    }

    /* 5) Y축 */
    let lx=x0;
    for(const info of L){
      lx-=info.w;
      drawYAxis(c,info,lx,info.w,y0,y1,'left',Y,COL);
    }
    let rx=x1;
    for(const info of R){
      drawYAxis(c,info,rx,info.w,y0,y1,'right',Y,COL);
      rx+=info.w;
    }

    /* 6) X축 */
    c.strokeStyle=COL.line; c.lineWidth=1;
    c.beginPath(); c.moveTo(x0,y1+.5); c.lineTo(x1,y1+.5); c.stroke();
    c.fillStyle=COL.fg2; c.textAlign='center'; c.textBaseline='top';
    c.font='11px ui-monospace,Menlo,Consolas,monospace';
    for(const v of xt){
      const px=x0+(v-xLo)/((xHi-xLo)||1)*pw;
      if(px<x0-1||px>x1+1) continue;
      c.beginPath(); c.moveTo(Math.round(px)+.5,y1); c.lineTo(Math.round(px)+.5,y1+4); c.stroke();
      c.fillText(isTime?fmtTime(v,xstep):fmtTick(v,xstep),px,y1+6);
    }
    const xt2=xAxisTitle(tpl,cat);
    if(xt2){ c.fillStyle=COL.fg3; c.font='11px var(--sans)'; c.fillText(xt2,(x0+x1)/2,y1+21); }

    /* 7) 커서 */
    const ci=app.cursorIdx;
    if(ci!=null&&ci>=vf&&ci<=vt){
      const px=Math.round(X(ci))+.5;
      c.save(); c.strokeStyle='#ffffff55'; c.setLineDash([3,3]); c.lineWidth=1;
      c.beginPath(); c.moveTo(px,y0); c.lineTo(px,y1); c.stroke(); c.restore();
      for(const s of series){
        const rec=app.catalog.values.get(s.paramId); if(!rec) continue;
        const i=Math.round(ci); if(i<0||i>=rec.values.length) continue;
        const v=rec.values[i]*(s.yScale??1)+(s.yOffset??0);
        if(Number.isNaN(v)) continue;
        const py=Y(v,s.axisId);
        if(py<y0||py>y1) continue;
        c.fillStyle=s.color||'#4da3ff'; c.beginPath(); c.arc(px,py,3,0,7); c.fill();
        c.strokeStyle='#0f1216'; c.lineWidth=1.2; c.stroke();
      }
    }

    /* 8) 선택 드래그 박스 */
    if(this.drag&&this.drag.mode==='sel'&&Math.abs(this.drag.x2-this.drag.x1)>2){
      const a=Math.min(this.drag.x1,this.drag.x2), b=Math.max(this.drag.x1,this.drag.x2);
      c.fillStyle='#4da3ff22'; c.fillRect(a,y0,b-a,ph);
      c.strokeStyle='#4da3ff'; c.lineWidth=1;
      c.beginPath(); c.moveTo(a+.5,y0); c.lineTo(a+.5,y1); c.moveTo(b+.5,y0); c.lineTo(b+.5,y1); c.stroke();
    }

    this.tTotal=performance.now()-tD0;
    /* 9) 데시메이션 배지 */
    const lv=[...blocks.values()][0];
    if(lv){
      const txt=lv.exact?`원본 ${lv.n.toLocaleString()}pt`:`1/${lv.level} 축약 · ${lv.n}버킷`;
      c.font='10px ui-monospace,Menlo,monospace'; c.textAlign='right'; c.textBaseline='top';
      const w=c.measureText(txt).width;
      c.fillStyle='#0f1216cc'; c.fillRect(x1-w-8,y0+3,w+6,14);
      c.fillStyle=COL.fg3; c.fillText(txt,x1-4,y0+5);
    }
  }
}

function drawYAxis(c,info,x,w,y0,y1,side,Y,COL){
  const {a,ticks,labs}=info;
  c.strokeStyle=COL.line; c.lineWidth=1;
  const ax=side==='left'?x+w-.5:x+.5;
  c.beginPath(); c.moveTo(ax,y0); c.lineTo(ax,y1); c.stroke();
  c.font='11px ui-monospace,Menlo,Consolas,monospace';
  c.fillStyle=a.color||COL.fg2;
  c.textAlign=side==='left'?'right':'left';
  c.textBaseline='middle';
  const tw=side==='left'?-5:5;
  for(let i=0;i<ticks.length;i++){
    const py=Y(ticks[i],a.id);
    if(py<y0-1||py>y1+1) continue;
    c.beginPath(); c.moveTo(ax,Math.round(py)+.5); c.lineTo(ax+(side==='left'?-4:4),Math.round(py)+.5); c.stroke();
    c.fillText(labs[i],ax+tw,py);
  }
  if(info.title){
    c.save();
    c.translate(side==='left'?x+9:x+w-4,(y0+y1)/2);
    c.rotate(side==='left'?-Math.PI/2:Math.PI/2);
    c.textAlign='center'; c.textBaseline='middle';
    c.font='11px -apple-system,Segoe UI,sans-serif';
    c.fillStyle=a.color||COL.fg3;
    c.fillText(info.title,0,0);
    c.restore();
  }
}

/* 축 제목: inherit면 붙어 있는 시리즈의 label에서 유도, custom이면 그대로 */
function axisTitle(ax,panel,cat){
  if(ax.title?.mode==='none') return '';
  if(ax.title?.mode==='custom') return ax.title.text||'';
  const ss=(panel.series||[]).filter(s=>s.axisId===ax.id&&s.visible!==false);
  const labs=[],units=new Set();
  for(const s of ss){ const p=cat.get(s.paramId); if(!p) continue;
    labs.push(s.labelOverride||p.label); if(p.unit) units.add(p.unit); }
  if(!labs.length) return ax.id;
  const u=units.size===1?[...units][0]:(units.size>1?'혼합':'');
  const name=labs.length<=2?labs.join(' / '):`${labs[0]} 외 ${labs.length-1}`;
  return ax.showUnit!==false&&u?`${name} [${u}]`:name;
}
function xAxisTitle(tpl,cat){
  if(tpl.x.title?.mode==='none') return '';
  if(tpl.x.title?.mode==='custom') return tpl.x.title.text||'';
  if(tpl.x.mode==='index') return '샘플 인덱스';
  const p=cat.get(tpl.x.paramId);
  return p?(p.unit?`${p.label} [${p.unit}]`:p.label):'X';
}
