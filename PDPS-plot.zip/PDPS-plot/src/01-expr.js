/* ═══════════════════════════════════════════════════════════════════
   계층 ②-a  표현식 엔진
   토크나이저 → Pratt 파서 → 화이트리스트 검증 → 벡터 컴파일
   eval() 없음. 식별자·함수는 전부 화이트리스트로 검증한 뒤에만 실행된다.
   ═══════════════════════════════════════════════════════════════════ */
const Expr = (() => {

/* ── 토크나이저 ─────────────────────────────────────────────────── */
const PUNCT = ['**','<<','>>','<=','>=','==','!=','&&','||','+','-','*','/','%','^','&','|','~','!','<','>','(',')',','];

function tokenize(src){
  const t=[]; let i=0;
  const isD=c=>c>='0'&&c<='9';
  const isI=c=>/[A-Za-z_ㄱ-힝]/.test(c);
  const isIn=c=>/[A-Za-z0-9_.ㄱ-힝]/.test(c);
  while(i<src.length){
    const c=src[i];
    if(/\s/.test(c)){i++;continue;}
    if(isD(c)||(c==='.'&&isD(src[i+1]))){
      let j=i;
      if(c==='0'&&(src[i+1]==='x'||src[i+1]==='X')){ j=i+2; while(j<src.length&&/[0-9A-Fa-f]/.test(src[j]))j++;
        t.push({k:'num',v:parseInt(src.slice(i+2,j),16),p:i}); i=j; continue; }
      if(c==='0'&&(src[i+1]==='b'||src[i+1]==='B')){ j=i+2; while(j<src.length&&/[01]/.test(src[j]))j++;
        t.push({k:'num',v:parseInt(src.slice(i+2,j),2),p:i}); i=j; continue; }
      while(j<src.length&&(isD(src[j])||src[j]==='.'))j++;
      if(src[j]==='e'||src[j]==='E'){ j++; if(src[j]==='+'||src[j]==='-')j++; while(j<src.length&&isD(src[j]))j++; }
      t.push({k:'num',v:parseFloat(src.slice(i,j)),p:i}); i=j; continue;
    }
    if(isI(c)){ let j=i; while(j<src.length&&isIn(src[j]))j++;
      t.push({k:'id',v:src.slice(i,j),p:i}); i=j; continue; }
    if(c==='"'||c==="'"){ const q=c; let j=i+1,s='';
      while(j<src.length&&src[j]!==q){ s+=src[j]; j++; }
      if(j>=src.length) throw new EErr('닫히지 않은 문자열',i);
      t.push({k:'str',v:s,p:i}); i=j+1; continue; }
    const op=PUNCT.find(p=>src.startsWith(p,i));
    if(op){ t.push({k:'op',v:op,p:i}); i+=op.length; continue; }
    throw new EErr(`알 수 없는 문자 '${c}'`,i);
  }
  t.push({k:'eof',v:'',p:src.length});
  return t;
}

class EErr extends Error{ constructor(m,p){ super(m); this.pos=p; } }

/* ── Pratt 파서 ─────────────────────────────────────────────────── */
const BP={'||':1,'&&':2,'|':3,'^':4,'&':5,'==':6,'!=':6,'<':7,'<=':7,'>':7,'>=':7,
          '<<':8,'>>':8,'+':9,'-':9,'*':10,'/':10,'%':10,'**':12};
const RIGHT=new Set(['**']);

function parse(src){
  const tk=tokenize(src); let p=0;
  const peek=()=>tk[p], next=()=>tk[p++];
  const expect=(v)=>{ const t=next(); if(t.v!==v) throw new EErr(`'${v}' 필요 (받은 값: '${t.v||'끝'}')`,t.p); return t; };

  function atom(){
    const t=next();
    if(t.k==='num') return {t:'num',v:t.v,p:t.p};
    if(t.k==='str') return {t:'str',v:t.v,p:t.p};
    if(t.k==='id'){
      if(peek().v==='('&&peek().k==='op'){
        next(); const args=[];
        if(peek().v!==')'){ for(;;){ args.push(expr(0)); if(peek().v===','){next();continue;} break; } }
        expect(')');
        return {t:'call',n:t.v,args,p:t.p};
      }
      return {t:'var',n:t.v,p:t.p};
    }
    if(t.k==='op'){
      if(t.v==='(') { const e=expr(0); expect(')'); return e; }
      if(t.v==='-'||t.v==='+'||t.v==='!'||t.v==='~') return {t:'un',o:t.v,a:expr(11),p:t.p};
    }
    throw new EErr(`예상치 못한 토큰 '${t.v||'끝'}'`,t.p);
  }
  function expr(min){
    let l=atom();
    for(;;){
      const t=peek();
      if(t.k!=='op') break;
      const bp=BP[t.v]; if(bp===undefined||bp<min) break;
      next();
      const r=expr(RIGHT.has(t.v)?bp:bp+1);
      l={t:'bin',o:t.v,a:l,b:r,p:t.p};
    }
    return l;
  }
  const e=expr(0);
  if(peek().k!=='eof') throw new EErr(`남는 토큰 '${peek().v}'`,peek().p);
  return e;
}

/* ── 함수 화이트리스트 ───────────────────────────────────────────── */
// kind: 'ew'  = 요소별(elementwise) — 스칼라 함수를 각 행에 적용
//       'win' = 윈도우 — 벡터 전체를 보고 계산
//       'raw' = 원시 재해석 — 인자가 반드시 컬럼 참조여야 함 (진수 변환)
const FN = {
  // 수학 (요소별)
  abs:{k:'ew',n:1,f:Math.abs},            sqrt:{k:'ew',n:1,f:Math.sqrt},
  cbrt:{k:'ew',n:1,f:Math.cbrt},          exp:{k:'ew',n:1,f:Math.exp},
  ln:{k:'ew',n:1,f:Math.log},             log10:{k:'ew',n:1,f:Math.log10},
  log2:{k:'ew',n:1,f:Math.log2},          sign:{k:'ew',n:1,f:Math.sign},
  floor:{k:'ew',n:1,f:Math.floor},        ceil:{k:'ew',n:1,f:Math.ceil},
  round:{k:'ew',n:1,f:Math.round},        trunc:{k:'ew',n:1,f:Math.trunc},
  sin:{k:'ew',n:1,f:Math.sin},            cos:{k:'ew',n:1,f:Math.cos},
  tan:{k:'ew',n:1,f:Math.tan},            asin:{k:'ew',n:1,f:Math.asin},
  acos:{k:'ew',n:1,f:Math.acos},          atan:{k:'ew',n:1,f:Math.atan},
  degrees:{k:'ew',n:1,f:x=>x*180/Math.PI},radians:{k:'ew',n:1,f:x=>x*Math.PI/180},
  isnan:{k:'ew',n:1,f:x=>Number.isNaN(x)?1:0},
  pow:{k:'ew',n:2,f:Math.pow},            atan2:{k:'ew',n:2,f:Math.atan2},
  nullif:{k:'ew',n:2,f:(a,b)=>a===b?NaN:a},
  clamp:{k:'ew',n:3,f:(x,lo,hi)=>x<lo?lo:x>hi?hi:x},
  if:{k:'ew',n:3,f:(c,a,b)=>c?a:b},
  coalesce:{k:'ew',n:-2,f:(...a)=>{for(const v of a) if(!Number.isNaN(v)) return v; return NaN;}},
  pmin:{k:'ew',n:-2,f:Math.min},  pmax:{k:'ew',n:-2,f:Math.max},
  pmean:{k:'ew',n:-2,f:(...a)=>a.reduce((s,v)=>s+v,0)/a.length},

  // 비트 연산 (32bit 부호없음)
  bitand:{k:'ew',n:2,f:(a,b)=>((a>>>0)&(b>>>0))>>>0},
  bitor :{k:'ew',n:2,f:(a,b)=>((a>>>0)|(b>>>0))>>>0},
  bitxor:{k:'ew',n:2,f:(a,b)=>((a>>>0)^(b>>>0))>>>0},
  bitnot:{k:'ew',n:1,f:a=>(~(a>>>0))>>>0},
  shl:{k:'ew',n:2,f:(a,b)=>((a>>>0)<<b)>>>0},
  shr:{k:'ew',n:2,f:(a,b)=>(a>>>0)>>>b},
  getbit:{k:'ew',n:2,f:(a,b)=>((a>>>0)>>>b)&1},
  bitcount:{k:'ew',n:1,f:a=>{let v=a>>>0,c=0;while(v){c+=v&1;v>>>=1;}return c;}},
  bitfield:{k:'ew',n:3,f:(a,sh,w)=>(((a>>>0)>>>sh)&((1<<w)-1))>>>0},

  // 진수 변환 — 원본 텍스트를 지정 진수로 재해석 (인자는 컬럼 참조여야 함)
  hex2dec:{k:'raw',radix:16}, bin2dec:{k:'raw',radix:2}, oct2dec:{k:'raw',radix:8},
  dec2num:{k:'raw',radix:10}, from_base:{k:'raw',radix:null},

  // 윈도우
  prev:{k:'win',n:-1},  next:{k:'win',n:-1},  diff:{k:'win',n:1},
  cumsum:{k:'win',n:1},  movavg:{k:'win',n:2}, movmin:{k:'win',n:2},
  movmax:{k:'win',n:2},  movstd:{k:'win',n:2}, fillprev:{k:'win',n:1},
  deriv:{k:'win',n:2},
};
const CONST={pi:Math.PI,PI:Math.PI,e:Math.E,E:Math.E,nan:NaN,NaN:NaN,inf:Infinity};

/* ── 검증: 식별자·함수·인자 수 ───────────────────────────────────── */
function collectVars(node,out=new Set()){
  switch(node.t){
    case 'var': if(!(node.n in CONST)&&node.n!=='idx'&&node.n!=='n') out.add(node.n); break;
    case 'un': collectVars(node.a,out); break;
    case 'bin': collectVars(node.a,out); collectVars(node.b,out); break;
    case 'call': node.args.forEach(a=>collectVars(a,out)); break;
  }
  return out;
}

function validate(node,resolve){
  switch(node.t){
    case 'num': case 'str': return;
    case 'var':
      if(node.n in CONST||node.n==='idx'||node.n==='n') return;
      if(!resolve(node.n)) throw new EErr(`알 수 없는 식별자 '${node.n}'`,node.p);
      return;
    case 'un': return validate(node.a,resolve);
    case 'bin': validate(node.a,resolve); validate(node.b,resolve); return;
    case 'call':{
      const f=FN[node.n];
      if(!f) throw new EErr(`알 수 없는 함수 '${node.n}()'`,node.p);
      if(f.k==='raw'){
        const need=f.radix===null?2:1;
        if(node.args.length!==need) throw new EErr(`${node.n}()는 인자 ${need}개가 필요합니다`,node.p);
        if(node.args[0].t!=='var') throw new EErr(`${node.n}()의 첫 인자는 컬럼/파라미터 이름이어야 합니다 (원본 텍스트를 재해석하므로)`,node.p);
        return;
      }
      if(f.k==='win'){
        const ok = node.n==='prev'||node.n==='next' ? (node.args.length===1||node.args.length===2)
                 : node.args.length===f.n;
        if(!ok) throw new EErr(`${node.n}()는 인자 ${f.n}개가 필요합니다`,node.p);
      } else {
        if(f.n>=0 && node.args.length!==f.n) throw new EErr(`${node.n}()는 인자 ${f.n}개가 필요합니다 (받은 값: ${node.args.length})`,node.p);
        if(f.n<0  && node.args.length< -f.n) throw new EErr(`${node.n}()는 인자가 최소 ${-f.n}개 필요합니다`,node.p);
      }
      node.args.forEach(a=>validate(a,resolve));
      return;
    }
  }
}

/* ── 벡터 실행기 ─────────────────────────────────────────────────
   각 노드는 {v: Float64Array|number, tmp: bool} 를 반환한다.
   tmp=true 인 배열은 재사용해서 쓴다 → 중간 배열 할당을 최소화.        */
function makeRunner(ast,N,ctx){
  const alloc=()=>new Float64Array(N);
  const asVec=(r)=>{ if(typeof r.v==='number'){ const a=alloc(); a.fill(r.v); return {v:a,tmp:true}; } return r; };

  function ew(fn,parts){
    // 전부 스칼라면 스칼라로 접기
    if(parts.every(p=>typeof p.v==='number')) return {v:fn(...parts.map(p=>p.v)),tmp:false};
    let out=null;
    for(const p of parts) if(p.tmp&&typeof p.v!=='number'){ out=p.v; break; }
    if(!out) out=alloc();
    const k=parts.length;
    if(k===1){ const a=parts[0]; const av=a.v,as=typeof av==='number';
      for(let i=0;i<N;i++) out[i]=fn(as?av:av[i]);
    } else if(k===2){ const a=parts[0].v,b=parts[1].v, as=typeof a==='number', bs=typeof b==='number';
      for(let i=0;i<N;i++) out[i]=fn(as?a:a[i], bs?b:b[i]);
    } else if(k===3){ const a=parts[0].v,b=parts[1].v,c=parts[2].v,
        as=typeof a==='number',bs=typeof b==='number',cs=typeof c==='number';
      for(let i=0;i<N;i++) out[i]=fn(as?a:a[i], bs?b:b[i], cs?c:c[i]);
    } else { const vs=parts.map(p=>p.v), ss=vs.map(v=>typeof v==='number'), buf=new Array(k);
      for(let i=0;i<N;i++){ for(let j=0;j<k;j++) buf[j]=ss[j]?vs[j]:vs[j][i]; out[i]=fn(...buf); }
    }
    return {v:out,tmp:true};
  }

  const OPS={
    '+':(a,b)=>a+b,'-':(a,b)=>a-b,'*':(a,b)=>a*b,'/':(a,b)=>a/b,'%':(a,b)=>a%b,
    '**':(a,b)=>Math.pow(a,b),
    '<':(a,b)=>a<b?1:0,'<=':(a,b)=>a<=b?1:0,'>':(a,b)=>a>b?1:0,'>=':(a,b)=>a>=b?1:0,
    '==':(a,b)=>a===b?1:0,'!=':(a,b)=>a!==b?1:0,
    '&&':(a,b)=>(a&&b)?1:0,'||':(a,b)=>(a||b)?1:0,
    '&':(a,b)=>((a>>>0)&(b>>>0))>>>0,'|':(a,b)=>((a>>>0)|(b>>>0))>>>0,
    '^':(a,b)=>((a>>>0)^(b>>>0))>>>0,
    '<<':(a,b)=>((a>>>0)<<b)>>>0,'>>':(a,b)=>(a>>>0)>>>b,
  };

  function win(name,args){
    const src=asVec(args[0]).v;
    const out=alloc();
    const p=(k)=>typeof args[k]?.v==='number'?args[k].v:(args[k]?args[k].v[0]:undefined);
    switch(name){
      case 'prev':{ const k=args.length>1?Math.max(1,p(1)|0):1;
        for(let i=0;i<N;i++) out[i]= i>=k?src[i-k]:NaN; break; }
      case 'next':{ const k=args.length>1?Math.max(1,p(1)|0):1;
        for(let i=0;i<N;i++) out[i]= i+k<N?src[i+k]:NaN; break; }
      case 'diff': out[0]=NaN; for(let i=1;i<N;i++) out[i]=src[i]-src[i-1]; break;
      case 'deriv':{ const dt=p(1)||1; out[0]=NaN; for(let i=1;i<N;i++) out[i]=(src[i]-src[i-1])/dt; break; }
      case 'cumsum':{ let s=0; for(let i=0;i<N;i++){ const v=src[i]; if(!Number.isNaN(v)) s+=v; out[i]=s; } break; }
      case 'movavg':{ const w=Math.max(1,p(1)|0); let s=0,cnt=0;
        for(let i=0;i<N;i++){ const v=src[i]; if(!Number.isNaN(v)){s+=v;cnt++;}
          if(i>=w){ const o=src[i-w]; if(!Number.isNaN(o)){s-=o;cnt--;} }
          out[i]=cnt?s/cnt:NaN; } break; }
      case 'movstd':{ const w=Math.max(2,p(1)|0); let s=0,s2=0,cnt=0;
        for(let i=0;i<N;i++){ const v=src[i]; if(!Number.isNaN(v)){s+=v;s2+=v*v;cnt++;}
          if(i>=w){ const o=src[i-w]; if(!Number.isNaN(o)){s-=o;s2-=o*o;cnt--;} }
          out[i]= cnt>1 ? Math.sqrt(Math.max(0,(s2-s*s/cnt)/(cnt-1))) : NaN; } break; }
      case 'movmin': case 'movmax':{ const w=Math.max(1,p(1)|0); const mx=name==='movmax';
        const dq=[]; // 단조 덱: O(n)
        for(let i=0;i<N;i++){
          while(dq.length&&dq[0]<=i-w) dq.shift();
          const v=src[i];
          while(dq.length && (mx? src[dq[dq.length-1]]<=v : src[dq[dq.length-1]]>=v)) dq.pop();
          dq.push(i); out[i]=src[dq[0]];
        } break; }
      case 'fillprev':{ let last=NaN; for(let i=0;i<N;i++){ const v=src[i]; if(!Number.isNaN(v)) last=v; out[i]=last; } break; }
      default: throw new EErr(`윈도우 함수 '${name}' 미구현`,0);
    }
    return {v:out,tmp:true};
  }

  function run(node){
    switch(node.t){
      case 'num': return {v:node.v,tmp:false};
      case 'str': return {v:NaN,tmp:false};
      case 'var':
        if(node.n in CONST) return {v:CONST[node.n],tmp:false};
        if(node.n==='n') return {v:N,tmp:false};
        if(node.n==='idx') return {v:ctx.index(),tmp:false};
        return {v:ctx.column(node.n),tmp:false};
      case 'un':{
        const a=run(node.a);
        if(node.o==='+') return a;
        const f = node.o==='-'?(x=>-x) : node.o==='!'?(x=>x?0:1) : (x=>(~(x>>>0))>>>0);
        return ew(f,[a]);
      }
      case 'bin':{
        const a=run(node.a), b=run(node.b);
        return ew(OPS[node.o],[a,b]);
      }
      case 'call':{
        const f=FN[node.n];
        if(f.k==='raw'){
          const radix = f.radix!==null ? f.radix : (run(node.args[1]).v|0);
          if(!(radix>=2&&radix<=36)) throw new EErr('진법은 2~36 사이여야 합니다',node.p);
          return {v:ctx.columnRaw(node.args[0].n,radix),tmp:false};
        }
        const args=node.args.map(run);
        if(f.k==='win') return win(node.n,args);
        return ew(f.f,args);
      }
    }
  }
  return run;
}

/* ── 공개 API ───────────────────────────────────────────────────── */
function compile(src,resolve){
  const ast=parse(src);
  validate(ast,resolve);
  return { ast, deps:[...collectVars(ast)] };
}
function evaluate(compiled,N,ctx){
  const r=makeRunner(compiled.ast,N,ctx)(compiled.ast);
  if(typeof r.v==='number'){ const a=new Float64Array(N); a.fill(r.v); return a; }
  return r.v;
}

return { compile, evaluate, parse, collectVars, FN, CONST, EErr };
})();
