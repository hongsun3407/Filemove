import { chromium } from 'playwright';

const N = parseInt(process.argv[2] || '3600000');
const OUT = process.argv[3] || '/home/claude/shots';

const b = await chromium.launch({ args:['--js-flags=--max-old-space-size=6144','--no-sandbox',
  '--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader'] });
const pg = await b.newPage({ viewport:{width:1600,height:940}, deviceScaleFactor:2 });
const errs=[];
pg.on('console', m => { if(m.type()==='error') errs.push(m.text()); });
pg.on('pageerror', e => errs.push('PAGEERROR: '+e.message));

await pg.goto('file:///home/claude/pdps-plot.html');
await pg.waitForTimeout(300);

/* ── 1. 표현식 엔진 단위 테스트 ─────────────────────────────── */
const unit = await pg.evaluate(() => {
  const N=8;
  const cols={ A:Float64Array.from([1,2,3,4,5,6,7,8]), B:Float64Array.from([10,20,30,40,50,60,70,80]) };
  const ctx={ index:()=>Float64Array.from([0,1,2,3,4,5,6,7]),
              column:n=>cols[n], columnRaw:(n,r)=>cols[n] };
  const run=(src)=>{ const c=Expr.compile(src,n=>cols[n]?{}:null); return Array.from(Expr.evaluate(c,N,ctx)); };
  const T=[];
  const rd=a=>a.map(v=>+(+v).toFixed(6));
  const eq=(name,got,want)=>T.push({name,ok:JSON.stringify(rd(got))===JSON.stringify(rd(want)),got:got.slice(0,4),want:want.slice(0,4)});
  eq('사칙연산',        run('A*2 + B/10 - 1'),      [1*2+1-1,2*2+2-1,3*2+3-1,4*2+4-1,5*2+5-1,6*2+6-1,7*2+7-1,8*2+8-1]);
  eq('연산자 우선순위',  run('1 + 2 * A ** 2'),      [3,9,19,33,51,73,99,129]);
  eq('괄호/단항',       run('-(A - 3)'),            [2,1,0,-1,-2,-3,-4,-5]);
  eq('비트 AND/시프트', run('bitand(B, 0x0F)'),     [10,4,14,8,2,12,6,0]);
  eq('shr + mask',      run('(B >> 2) & 7'),        [2,5,7,2,4,7,1,4]);
  eq('getbit',          run('getbit(A, 0)'),        [1,0,1,0,1,0,1,0]);
  eq('bitcount',        run('bitcount(A)'),         [1,1,2,1,2,2,3,1]);
  eq('조건/클램프',      run('clamp(if(A>4, B, 0), 0, 55)'), [0,0,0,0,50,55,55,55]);
  eq('다중 조합',        run('pmean(A, B, A*B)'),    [(1+10+10)/3,(2+20+40)/3,(3+30+90)/3,(4+40+160)/3,(5+50+250)/3,(6+60+360)/3,(7+70+490)/3,(8+80+640)/3]);
  eq('차분',            run('diff(B)').slice(1),   [10,10,10,10,10,10,10]);
  eq('누적합',          run('cumsum(A)'),          [1,3,6,10,15,21,28,36]);
  eq('이동평균 w=3',     run('movavg(A,3)'),        [1,1.5,2,3,4,5,6,7]);
  eq('이동최대 w=3',     run('movmax(A,3)'),        [1,2,3,4,5,6,7,8]);
  eq('prev',            run('prev(A,2)').slice(2), [1,2,3,4,5,6]);
  const errCases=[['A +','문법'],['FOO*2','미지 식별자'],['bogus(A)','미지 함수'],['clamp(A,1)','인자수']];
  const caught=errCases.map(([src,lab])=>{ try{ Expr.compile(src,n=>cols[n]?{}:null); return {lab,ok:false}; }
                                           catch(e){ return {lab,ok:true,msg:e.message}; } });
  return {T,caught};
});

console.log('\n── 표현식 엔진 단위 테스트 ─────────────────────');
let fail=0;
for(const t of unit.T){ if(!t.ok) fail++; console.log(` ${t.ok?'✓':'✗'} ${t.name}${t.ok?'':'   got='+JSON.stringify(t.got)+' want='+JSON.stringify(t.want)}`); }
for(const c of unit.caught){ if(!c.ok) fail++; console.log(` ${c.ok?'✓':'✗'} 에러검출: ${c.lab}${c.ok?'  → "'+c.msg+'"':''}`); }

/* ── 2. 대용량 데이터 생성 + 로드 ────────────────────────────── */
console.log(`\n── ${N.toLocaleString()}행 파이프라인 ─────────────────────`);
const perf = await pg.evaluate(async (N) => {
  const t={};
  let t0=performance.now();
  const txt = await genDemo(N);
  t.generate = performance.now()-t0;
  t.bytes = txt.length;
  t0=performance.now();
  await App.loadText(txt, `demo_${N}.csv`);
  for(const v of App.views) v.draw();          // 기본 템플릿에 쓰이는 파라미터만 지연 계산됨
  t.firstPlot = performance.now()-t0;
  t.shown = App.tpl.panels.flatMap(P=>P.series.map(x=>x.paramId));
  // 모든 파라미터 계산 (진수변환·파생식 포함)
  t0=performance.now();
  const params={};
  for(const p of App.catalog.params){
    const r=App.catalog.tryCompute(p.id);
    params[p.id]= r ? {label:p.label, unit:p.unit, min:r.range[0], max:r.range[1],
                       pyrLevels:r.pyr.levels.map(l=>l.ratio), err:null}
                    : {label:p.label, err:App.catalog.errors.get(p.id)};
  }
  t.computeAll = performance.now()-t0;
  return {t, params, rows:App.ds.nRows, cols:App.ds.nCols};
}, N);

console.log(` 데이터 생성      ${perf.t.generate.toFixed(0)} ms   (${(perf.t.bytes/1048576).toFixed(1)} MB)`);
console.log(` 적재 → 첫 화면   ${perf.t.firstPlot.toFixed(0)} ms   → ${perf.rows.toLocaleString()}행 × ${perf.cols}열 (표시 ${perf.t.shown.length}계열만 지연계산)`);
console.log(` 나머지 전 파라미터 ${perf.t.computeAll.toFixed(0)} ms  (총 ${Object.keys(perf.params).length}개 · 수식+피라미드 포함)`);

console.log('\n── 파라미터 카탈로그 ───────────────────────────');
for(const [id,p] of Object.entries(perf.params)){
  if(p.err){ console.log(` ✗ ${id.padEnd(14)} ${p.label.padEnd(22)} ERROR: ${p.err}`); fail++; }
  else console.log(` ✓ ${id.padEnd(14)} ${(p.label+(p.unit?` [${p.unit}]`:'')).padEnd(24)} [${p.min.toFixed(2)} … ${p.max.toFixed(2)}]`);
}

/* ── 3. 진수 변환 정확성: 원문 hex ↔ 계산된 rpm ─────────────── */
const radixChk = await pg.evaluate(() => {
  const ds=App.ds, rec=App.catalog.compute('P_RPM');
  const out=[];
  for(const r of [0, 1234, 999999, ds.nRows-1]){
    if(r>=ds.nRows) continue;
    const H=ds.field(r, ds.colByName('CAN_RPM_H').idx);
    const L=ds.field(r, ds.colByName('CAN_RPM_L').idx);
    const expect=(parseInt(H,16)*256+parseInt(L,16))*0.25;
    out.push({r,H,L,expect,got:rec.values[r],ok:Math.abs(expect-rec.values[r])<1e-6});
  }
  // 2진 STATUS → 비트 추출
  const flt=App.catalog.compute('P_FLT');
  let bitOk=true, spikes=0;
  for(let r=0;r<Math.min(20000,ds.nRows);r++){
    const S=ds.field(r, ds.colByName('STATUS').idx);
    const want=(parseInt(S,2)>>2)&1;
    if(want) spikes++;
    if(want!==flt.values[r]){ bitOk=false; break; }
  }
  return {out,bitOk,spikes};
});
console.log('\n── 진수 변환 검증 ─────────────────────────────');
for(const o of radixChk.out){ if(!o.ok) fail++;
  console.log(` ${o.ok?'✓':'✗'} row ${String(o.r).padStart(7)}  hex ${o.H}${o.L} → ${o.got.toFixed(2)} rpm  (기대 ${o.expect.toFixed(2)})`); }
if(!radixChk.bitOk) fail++;
console.log(` ${radixChk.bitOk?'✓':'✗'} 2진 STATUS 비트2 추출 20,000행 일치 (플래그 ${radixChk.spikes}회)`);

/* ── 4. min/max 데시메이션이 스파이크를 보존하는가 ───────────── */
const spike = await pg.evaluate(() => {
  const rec=App.catalog.compute('P_VIB');
  const N=rec.values.length;
  let trueMax=-Infinity, at=-1;
  for(let i=0;i<N;i++) if(rec.values[i]>trueMax){trueMax=rec.values[i];at=i;}
  const res=[];
  for(const B of [1600,800,400,200]){
    const q=rec.pyr.query(0,N-1,B);
    let m=-Infinity; for(let i=0;i<q.n;i++) if(q.hi[i]>m)m=q.hi[i];
    res.push({B,buckets:q.n,level:q.level,seenMax:m,keptPct:m/trueMax*100});
  }
  // LTTB 대신 단순 스텝 샘플링이면 무엇을 놓치는가 (대조군)
  const step=Math.floor(N/1600);
  let naive=-Infinity; for(let i=0;i<N;i+=step) if(rec.values[i]>naive)naive=rec.values[i];
  return {trueMax,at,N,res,naive};
});
console.log('\n── min/max 데시메이션: 스파이크 보존 ────────────');
console.log(` 원본 최댓값 ${spike.trueMax.toFixed(3)} g @ 인덱스 ${spike.at.toLocaleString()} (${(spike.at/1000).toFixed(1)}s)`);
for(const r of spike.res){
  const ok=r.keptPct>99.9; if(!ok) fail++;
  console.log(` ${ok?'✓':'✗'} ${String(r.B).padStart(4)}버킷 → 1/${r.level||1} 축약, 관측 최댓값 ${r.seenMax.toFixed(3)} (${r.keptPct.toFixed(1)}% 보존)`);
}
const naiveLoss=(1-spike.naive/spike.trueMax)*100;
console.log(` ─ 대조군: 단순 등간격 샘플링은 ${spike.naive.toFixed(3)} 까지만 관측 → 피크의 ${naiveLoss.toFixed(0)}% 소실`);

/* ── 5. 렌더 · 줌 성능 ──────────────────────────────────────── */
const draw = await pg.evaluate(async () => {
  const med=a=>{const b=[...a].sort((x,y)=>x-y);return b[b.length>>1];};
  // (a) draw() 자체의 동기 실행 시간 — rAF 16.7ms 바닥에 가려지지 않도록 직접 측정
  const sync=()=>{ const t0=performance.now(); for(const v of App.views) v.draw(); return performance.now()-t0; };
  const N=App.ds.nRows, zoom=[];
  for(const span of [N, N/10, N/100, N/1000, 2000, 200]){
    App.viewport=[Math.floor(N/2-span/2), Math.floor(N/2+span/2)];
    const a=[],q=[];
    for(let i=0;i<11;i++){ a.push(sync()); q.push(App.views.reduce((s,v)=>s+(v.tQuery||0),0)); }
    zoom.push({span:Math.round(span), ms:med(a.slice(3)), q:med(q.slice(3))});
  }
  // (b) 지속 프레임률 — 연속 팬 120프레임의 실제 경과시간
  const step=Math.max(1,Math.floor(N/600));
  App.viewport=[0, Math.floor(N/6)];
  const w0=performance.now(); let frames=0;
  await new Promise(res=>{
    const loop=()=>{ App.viewport=[frames*step, Math.floor(N/6)+frames*step];
      for(const v of App.views) v.draw();
      if(++frames<120) requestAnimationFrame(loop); else res(); };
    requestAnimationFrame(loop);
  });
  const fps=frames/((performance.now()-w0)/1000);
  App.resetViewport(); for(const v of App.views) v.draw();
  return {zoom,fps};
});
console.log('\n── 렌더 성능 (2패널 · 4계열 · 1600×940 @2x, GPU 경로) ──');
for(const z of draw.zoom){
  const ok=z.ms<33; if(!ok) fail++;
  console.log(` ${ok?'✓':'✗'} 뷰포트 ${String(z.span.toLocaleString()).padStart(9)}pt  →  draw() ${z.ms.toFixed(1)} ms  (데이터질의 ${z.q.toFixed(2)} / 나머지 ${(z.ms-z.q).toFixed(1)})`);
}
console.log(` ─ 연속 팬 지속 프레임률 ${draw.fps.toFixed(1)} fps  ※ 이 컨테이너는 GPU가 없어 소프트웨어 래스터라이저로`);
console.log(`   2576×1572 캔버스 2장을 매 프레임 그린다. 이 수치는 환경 한계이며 draw() 시간과 무관하다.`);

/* ── 6. 스크린샷 ────────────────────────────────────────────── */
import { mkdirSync } from 'fs';
mkdirSync(OUT,{recursive:true});
await pg.evaluate(()=>{ App.resetViewport(); });
await pg.waitForTimeout(400);
await pg.screenshot({path:`${OUT}/01-overview.png`});

await pg.evaluate(()=>{ document.querySelector('#main').classList.add('insp'); App.renderInspector(); });
await pg.waitForTimeout(300);
await pg.screenshot({path:`${OUT}/02-inspector.png`});

// 스파이크 구간으로 줌 + 커서
await pg.evaluate((at)=>{ document.querySelector('#main').classList.remove('insp');
  App.setViewport(at-3000, at+3000); App.cursorIdx=at; }, spike.at);
await pg.waitForTimeout(400);
await pg.screenshot({path:`${OUT}/03-zoom-spike.png`});

// 원본 해상도까지 줌인
await pg.evaluate((at)=>{ App.setViewport(at-120, at+120); App.cursorIdx=at; }, spike.at);
await pg.waitForTimeout(400);
await pg.screenshot({path:`${OUT}/04-raw-resolution.png`});

console.log('\n── 콘솔 에러 ──────────────────────────────────');
console.log(errs.length? errs.slice(0,10).join('\n') : ' (없음)');
if(errs.length) fail+=errs.length;

console.log(`\n${'═'.repeat(50)}\n${fail? '✗ 실패 '+fail+'건' : '✓ 전체 통과'}\n${'═'.repeat(50)}`);
await b.close();
process.exit(fail?1:0);
