/* ═══════════════════════════════════════════════════════════════════
   앱 — 상태 · UI · 템플릿
   ═══════════════════════════════════════════════════════════════════ */
const $=s=>document.querySelector(s);
const el=(t,a={},...ch)=>{const n=document.createElement(t);
  for(const[k,v]of Object.entries(a)){ if(k==='cls')n.className=v; else if(k.startsWith('on'))n.addEventListener(k.slice(2),v);
    else if(k==='html')n.innerHTML=v; else if(v!=null&&v!==false)n.setAttribute(k,v==true?'':v); }
  for(const c of ch.flat()) if(c!=null) n.append(c.nodeType?c:document.createTextNode(c));
  return n;};

function toast(m){ const t=$('#toast'); t.textContent=m; t.classList.add('on'); clearTimeout(t._h); t._h=setTimeout(()=>t.classList.remove('on'),2200); }
function busy(on,msg,pct){ const b=$('#busy'); b.classList.toggle('on',!!on); if(msg)$('#busyMsg').textContent=msg; $('#busyBar').style.width=(pct??0)+'%'; }
const raf=()=>new Promise(r=>requestAnimationFrame(()=>setTimeout(r,0)));

const App={
  ds:null, catalog:new Catalog(), tpl:null,
  viewport:[0,1], cursorIdx:null, views:[], selPanel:0, selParam:null,
  _pending:false, _t0:0, lastMs:0,

  /* ── 템플릿 ─────────────────────────────────────────────── */
  newTemplate(){
    return { version:1, id:'tpl_'+Date.now(), name:'기본 뷰',
      layout:{rows:1,cols:1,syncCursor:true,syncXZoom:true},
      x:{mode:'index',paramId:null,title:{mode:'inherit'},grid:true},
      panels:[this.newPanel(0)] };
  },
  newPanel(i){
    return { id:'pnl'+(i+1), title:'패널 '+(i+1),
      yAxes:[{id:'yL1',side:'left',title:{mode:'inherit'},showUnit:true,
              range:{mode:'auto-padded',padPct:5},scaleType:'linear',grid:true,visible:true,color:''}],
      series:[], legend:{show:true} };
  },
  newAxis(P){
    const n=P.yAxes.length;
    const side=n%2?'right':'left';
    const c=P.yAxes.filter(a=>a.side===side).length+1;
    return {id:(side==='left'?'yL':'yR')+c,side,title:{mode:'inherit'},showUnit:true,
            range:{mode:'auto-padded',padPct:5},scaleType:'linear',grid:n===0,visible:true,color:''};
  },

  /* ── 데이터 적재 ────────────────────────────────────────── */
  async loadText(text,name){
    busy(true,'CSV 파싱 중…',15); await raf();
    const t0=performance.now();
    this.ds=new Dataset(text);
    busy(true,'파라미터 카탈로그 구성 중…',60); await raf();
    this.catalog=new Catalog(); this.catalog.setDataset(this.ds);
    this.buildCatalog();
    this.tpl=this.newTemplate();
    this.autoTemplate();
    this.viewport=[0,Math.max(1,this.ds.nRows-1)];
    this.cursorIdx=null; this.selParam=this.catalog.params[0]?.id||null;
    busy(true,'렌더링…',90); await raf();
    this.rebuildGrid(); this.renderSidebar(); this.renderInspector(); this.requestDraw();
    const ms=Math.round(performance.now()-t0);
    busy(false);
    toast(`${name} · ${this.ds.nRows.toLocaleString()}행 × ${this.ds.nCols}열 · ${ms}ms`);
    this.loadMs=ms; this.fileName=name;
  },

  buildCatalog(){
    const used=new Set();
    const mkid=(n)=>{ let s='P_'+String(n).toUpperCase().replace(/[^A-Z0-9_ㄱ-힝]/g,'_').replace(/_+/g,'_').replace(/^_|_$/g,'');
      if(!s||s==='P_')s='P_COL'; let id=s,k=1; while(used.has(id))id=s+'_'+(++k); used.add(id); return id; };
    for(const c of this.ds.cols){
      if(c.kind==='empty'||c.kind==='text') continue;
      this.catalog.add({id:mkid(c.name),label:c.name,kind:'source',column:c.name,radix:c.radix,
        scale:1,offset:0,unit:'',decimals:3});
    }
    // 데모 파일이면 파생 파라미터를 함께 넣어 전처리 기능을 보여준다
    if(this.ds.colByName('CAN_RPM_H')&&this.ds.colByName('CAN_RPM_L')){
      const t=this.catalog.get('P_TIME_MS'); if(t){ t.label='시간'; t.unit='s'; t.scale=0.001; t.precision='f64'; t.decimals=3; }
      const tq=this.catalog.get('P_TQ_RAW'); if(tq){ tq.label='토크'; tq.unit='Nm'; tq.scale=0.1; tq.decimals=1; }
      const vb=this.catalog.get('P_VIB'); if(vb){ vb.label='진동'; vb.unit='g'; vb.decimals=2; }
      for(const id of ['P_CAN_RPM_H','P_CAN_RPM_L','P_TEMP_RAW','P_STATUS']){ const p=this.catalog.get(id); if(p){ p._aux=true; p.label=p.column+' (원본)'; } }
      const st=this.catalog.get('P_STATUS'); if(st) st.displayRadix=2;
      this.catalog.add({id:'P_RPM',label:'엔진 회전수',unit:'rpm',kind:'derived',decimals:0,
        expr:'(hex2dec(CAN_RPM_H) * 256 + hex2dec(CAN_RPM_L)) * 0.25'});
      this.catalog.add({id:'P_TEMP',label:'냉각수온',unit:'°C',kind:'derived',decimals:1,
        expr:'P_TEMP_RAW * 0.75 - 48'});
      this.catalog.add({id:'P_PWR',label:'출력',unit:'kW',kind:'derived',decimals:1,
        expr:'P_RPM * P_TQ_RAW * 0.1 / 9550'});
      this.catalog.add({id:'P_FLT',label:'고장 플래그',unit:'',kind:'derived',decimals:0,
        expr:'getbit(bin2dec(STATUS), 2)'});
      this.catalog.add({id:'P_RPM_AVG',label:'회전수(0.5s 이동평균)',unit:'rpm',kind:'derived',decimals:0,
        expr:'movavg(P_RPM, 500)'});
    }
  },

  autoTemplate(){
    const ps=this.catalog.params.filter(p=>!p._aux);
    const t=ps.find(p=>/time|시간|시각|sec|초/i.test(p.label)||/TIME/i.test(p.column||''));
    if(t){ this.tpl.x.mode='time'; this.tpl.x.paramId=t.id; }
    const pick=(...ids)=>ids.map(i=>this.catalog.get(i)).filter(Boolean);
    let P=this.tpl.panels[0];
    let pool=pick('P_RPM','P_TQ_RAW');
    if(!pool.length) pool=ps.filter(p=>p.id!==t?.id).slice(0,2);
    if(pool.length>1) P.yAxes.push(this.newAxis(P));
    pool.forEach((p,i)=>P.series.push(this.newSeries(P,p.id,P.yAxes[Math.min(i,P.yAxes.length-1)].id)));
    if(this.catalog.get('P_RPM')){
      this.tpl.layout={rows:2,cols:1,syncCursor:true,syncXZoom:true};
      const P2=this.newPanel(1); P2.title='진동 · 수온';
      P2.yAxes.push(this.newAxis(P2));
      P2.series.push(this.newSeries(P2,'P_VIB','yL1'));
      P2.series.push(this.newSeries(P2,'P_TEMP','yR1'));
      this.tpl.panels.push(P2);
      P.title='회전수 · 토크';
    }
  },
  newSeries(P,paramId,axisId){
    const p=this.catalog.get(paramId);
    const used=new Set(P.series.map(s=>s.color));
    const color=PALETTE.find(c=>!used.has(c))||PALETTE[P.series.length%PALETTE.length];
    if(p) p.color=color;                       // 사이드바 점 색과 범례 색을 일치시킨다
    return {id:'s'+Math.random().toString(36).slice(2,8),paramId,axisId:axisId||P.yAxes[0].id,
      color,width:1.4,style:'line',visible:true,opacity:1,yScale:1,yOffset:0};
  },

  /* ── 뷰포트 ────────────────────────────────────────────── */
  setViewport(a,b,src){
    const N=this.ds?this.ds.nRows-1:1;
    let lo=Math.max(0,Math.min(a,b)), hi=Math.min(N,Math.max(a,b));
    if(hi-lo<2){ const c=(lo+hi)/2; lo=Math.max(0,c-1); hi=Math.min(N,c+1); }
    if(this.tpl.layout.syncXZoom===false && src) src.localVp=[lo,hi];
    else { this.viewport=[lo,hi]; for(const v of this.views) v.localVp=null; }
    this.requestDraw();
  },
  resetViewport(){ if(!this.ds) return; for(const v of this.views) v.localVp=null;
    this.viewport=[0,this.ds.nRows-1]; this.requestDraw(); },
  setCursor(i){ this.cursorIdx=i; this.requestDraw(); this.renderStatus(); },
  xVec(){ const id=this.tpl?.x?.paramId; if(!id||this.tpl.x.mode==='index') return null;
    const r=this.catalog.tryCompute(id); return r?r.values:null; },
  xDisplay(idx){
    const v=this.xVec(); if(!v) return idx;
    const i=Math.max(0,Math.min(v.length-1,idx));
    const a=Math.floor(i),b=Math.min(v.length-1,a+1),f=i-a;
    return v[a]*(1-f)+v[b]*f;
  },

  /* ── 그리기 ────────────────────────────────────────────── */
  requestDraw(){
    if(this._pending) return; this._pending=true;
    requestAnimationFrame(()=>{ this._pending=false; const t=performance.now();
      for(const v of this.views) try{ v.draw(); }catch(e){ console.error(e); }
      this.lastMs=performance.now()-t; this.renderLegends(); this.renderStatus(); });
  },

  rebuildGrid(){
    const g=$('#grid'); g.innerHTML=''; this.views=[];
    const {rows,cols}=this.tpl.layout;
    g.style.gridTemplateColumns=`repeat(${cols},minmax(240px,1fr))`;
    g.style.gridTemplateRows=`repeat(${rows},minmax(170px,1fr))`;
    g.style.height = rows>1 ? (rows*290)+'px' : '100%';
    g.style.minHeight='100%';
    this.tpl.panels.forEach((P,i)=>{
      const top=el('div',{cls:'ptop'},
        el('div',{cls:'ptitle'},P.title||('패널 '+(i+1))),
        el('span',{cls:'chip'},`${P.series.filter(s=>s.visible!==false).length}계열 / ${P.yAxes.length}축`),
        el('button',{cls:'sm',onclick:()=>{this.selPanel=i;this.renderInspector();$('#main').classList.add('insp');}},'설정')
      );
      const cvw=el('div',{cls:'pcv'});
      const lg=el('div',{cls:'legend'});
      const node=el('div',{cls:'panel'+(i===this.selPanel?' sel':''),onmousedown:()=>{ if(this.selPanel!==i){this.selPanel=i;this.rebuildGridSel();this.renderInspector();} }},top,cvw,lg);
      g.append(node);
      const view=new PlotView(cvw,this,P); view.legendEl=lg; view.node=node;
      this.views.push(view);
    });
  },
  rebuildGridSel(){ [...$('#grid').children].forEach((n,i)=>n.classList.toggle('sel',i===this.selPanel)); },

  renderLegends(){
    this.views.forEach((v,pi)=>{
      const P=v.panel, lg=v.legendEl; if(!lg) return;
      lg.innerHTML='';
      for(const s of P.series){
        const p=this.catalog.get(s.paramId); if(!p) continue;
        const err=this.catalog.errors.get(s.paramId);
        let val='';
        if(this.cursorIdx!=null){
          const rec=this.catalog.values.get(s.paramId);
          if(rec){ const i=Math.round(this.cursorIdx);
            if(i>=0&&i<rec.values.length) val=fmtNum(rec.values[i],p.decimals,p.displayRadix); }
        }
        const item=el('div',{cls:'lgi'+(s.visible===false?' off':''),title:err||p.id,
          onclick:()=>{ s.visible=s.visible===false; this.requestDraw(); this.renderInspector(); }},
          el('i',{cls:'lgs',style:`background:${err?'#f85149':s.color}`}),
          el('span',{},(s.labelOverride||p.label)+(p.unit?` [${p.unit}]`:'')),
          val?el('span',{cls:'lgv'},val):null,
          err?el('span',{style:'color:#f85149'},'⚠'):null
        );
        lg.append(item);
      }
    });
  },

  renderStatus(){
    const s=$('#status');
    if(!this.ds){ s.innerHTML='<span class="muted">데이터 없음 — "데모 데이터 생성"으로 시작하세요</span>'; return; }
    const [a,b]=(this.views[this.selPanel]?this.views[this.selPanel].vp():this.viewport), span=b-a+1;
    const xa=this.xDisplay(a), xb=this.xDisplay(b);
    const isT=this.tpl.x.mode==='time'&&this.xVec();
    const f=v=>isT?fmtTime(v,(xb-xa)/8):fmtTick(v,(xb-xa)/8);
    const parts=[
      `${this.fileName||'data'}`,
      `${this.ds.nRows.toLocaleString()}행 × ${this.ds.nCols}열`,
      `${(this.ds.text.length/1048576).toFixed(1)}MB`,
      `뷰 ${f(xa)} ~ ${f(xb)} (${span.toLocaleString()}pt)`,
      `줌 ×${(this.ds.nRows/span).toFixed(1)}`,
      `그리기 ${this.lastMs.toFixed(1)}ms`,
    ];
    if(this.cursorIdx!=null) parts.push(`커서 #${Math.round(this.cursorIdx).toLocaleString()} @ ${f(this.xDisplay(this.cursorIdx))}`);
    s.innerHTML=parts.map(p=>`<span>${p}</span>`).join('<span class="muted">│</span>');
  },

  /* ── 사이드바: 파라미터 카탈로그 ──────────────────────────── */
  renderSidebar(){
    const list=$('#plist'); list.innerHTML='';
    for(const p of this.catalog.params){
      const err=this.catalog.errors.get(p.id);
      list.append(el('div',{cls:'pitem'+(p.id===this.selParam?' sel':''),
        onclick:()=>{this.selParam=p.id;this.renderSidebar();this.renderParamEditor();}},
        el('i',{cls:'pdot',style:`background:${err?'#f85149':p.color}`}),
        el('div',{cls:'pname'},el('div',{},p.label||p.id),el('div',{cls:'pid'},p.id)),
        el('span',{cls:'ptag'+(p.kind==='derived'?' d':'')},p.kind==='derived'?'수식':(p.radix!==10?'r'+p.radix:'원본'))
      ));
    }
    this.renderParamEditor();
    // X축 파라미터 선택기
    const xp=$('#xParam'); xp.innerHTML='';
    for(const p of this.catalog.params) xp.append(el('option',{value:p.id},p.label));
    if(this.tpl?.x?.paramId) xp.value=this.tpl.x.paramId;
    $('#xMode').value=this.tpl?.x?.mode||'index';
    xp.disabled=(this.tpl?.x?.mode!=='time');
    $('#layoutSel').value=`${this.tpl.layout.rows}x${this.tpl.layout.cols}`;
  },

  renderParamEditor(){
    const sect=$('#editSect'), f=$('#editForm');
    const p=this.catalog.get(this.selParam);
    if(!p){ sect.style.display='none'; return; }
    sect.style.display=''; $('#editTitle').textContent=`편집 — ${p.id}`;
    f.innerHTML='';
    const upd=(k,v,recalc=true)=>{ p[k]=v; if(recalc)this.catalog.invalidate(p.id);
      this.catalog.invalidateAll(); this.renderSidebar(); this.requestDraw(); };
    const row=(lab,node)=>el('div',{cls:'fr'},el('label',{},lab),node);

    f.append(el('div',{cls:'f2'},
      row('표시명 (label)',el('input',{value:p.label,oninput:e=>{p.label=e.target.value;this.renderSidebar();this.requestDraw();}})),
      row('단위',el('input',{value:p.unit||'',oninput:e=>{p.unit=e.target.value;this.requestDraw();}}))
    ));
    f.append(el('div',{cls:'f3'},
      row('색상',el('input',{type:'color',value:p.color,oninput:e=>{p.color=e.target.value;
        for(const P of this.tpl.panels) for(const s of P.series) if(s.paramId===p.id) s.color=e.target.value;
        this.renderSidebar();this.requestDraw();}})),
      row('소수 자릿수',el('input',{type:'number',min:0,max:8,value:p.decimals??3,oninput:e=>{p.decimals=+e.target.value;this.requestDraw();}})),
      row('표시 진법',el('select',{onchange:e=>{p.displayRadix=+e.target.value;this.requestDraw();}},
        ...[10,16,2,8].map(r=>el('option',{value:r,selected:(p.displayRadix||10)===r},r+'진'))))
    ));

    if(p.kind==='source'){
      f.append(el('div',{cls:'f2'},
        row('원본 컬럼',el('select',{onchange:e=>upd('column',e.target.value)},
          ...this.ds.cols.map(c=>el('option',{value:c.name,selected:c.name===p.column},c.name)))),
        row('원본 진법 (해석)',el('select',{onchange:e=>upd('radix',+e.target.value)},
          ...[10,16,2,8].map(r=>el('option',{value:r,selected:(p.radix||10)===r},r+'진'))))
      ));
      f.append(el('div',{cls:'f2'},
        row('스케일 ×',el('input',{type:'number',step:'any',value:p.scale??1,oninput:e=>upd('scale',parseFloat(e.target.value)||0)})),
        row('오프셋 +',el('input',{type:'number',step:'any',value:p.offset??0,oninput:e=>upd('offset',parseFloat(e.target.value)||0)}))
      ));
      f.append(el('div',{cls:'hint'},'물리량 = 원본값 × 스케일 + 오프셋. 원본이 16진 문자열이면 진법을 16으로 두세요.'));
      const smp=this.ds?[0,1,2].map(r=>this.ds.field(r,this.ds.colByName(p.column)?.idx??0)).join(' · '):'';
      f.append(el('div',{cls:'hint mono'},'원본 샘플: '+smp));
    } else {
      const ta=el('textarea',{spellcheck:'false'},p.expr||'');
      const out=el('div',{});
      const check=()=>{
        p.expr=ta.value; this.catalog.invalidateAll();
        try{
          Expr.compile(ta.value,n=>this.catalog.resolve(n));
          const rec=this.catalog.compute(p.id);
          const v=rec.values, prev=[0,1,2,3].filter(i=>i<v.length).map(i=>fmtNum(v[i],p.decimals,p.displayRadix));
          out.className='okbox'; out.textContent=`OK · 범위 [${fmtNum(rec.range[0],2)} … ${fmtNum(rec.range[1],2)}]\n앞 4개: ${prev.join(', ')}`;
          this.renderSidebar(); this.requestDraw();
        }catch(e){ out.className='errbox'; out.textContent='✕ '+(e.message||e); this.requestDraw(); }
      };
      ta.addEventListener('input',()=>{ clearTimeout(ta._h); ta._h=setTimeout(check,350); });
      f.append(row('수식',ta),out);
      f.append(el('div',{cls:'hint'},'파라미터 ID 또는 원본 컬럼명을 직접 참조할 수 있습니다. hex2dec()/bin2dec()는 원본 텍스트를 해당 진법으로 다시 읽습니다.'));
      setTimeout(check,0);
    }
    f.append(el('div',{cls:'row'},
      el('div',{cls:'grow'}),
      el('button',{cls:'sm danger',onclick:()=>{ this.catalog.remove(p.id);
        for(const P of this.tpl.panels) P.series=P.series.filter(s=>s.paramId!==p.id);
        this.selParam=this.catalog.params[0]?.id||null;
        this.renderSidebar();this.renderInspector();this.rebuildGrid();this.requestDraw(); }},'파라미터 삭제')
    ));
  },

  /* ── 인스펙터: 패널 / 축 / 시리즈 ─────────────────────────── */
  renderInspector(){
    const I=$('#inspector'); I.innerHTML='';
    if(!this.tpl){ return; }
    const P=this.tpl.panels[this.selPanel]; if(!P) return;
    const refresh=()=>{ this.renderInspector(); this.rebuildGrid(); this.requestDraw(); };
    const soft=()=>{ this.requestDraw(); this.renderLegends(); };
    const row=(lab,node)=>el('div',{cls:'fr'},el('label',{},lab),node);

    I.append(el('div',{cls:'tabs'},
      ...this.tpl.panels.map((p,i)=>el('div',{cls:'tab'+(i===this.selPanel?' on':''),
        onclick:()=>{this.selPanel=i;this.renderInspector();this.rebuildGridSel();}},p.title||('패널 '+(i+1))))
    ));

    /* 패널 */
    const s1=el('div',{cls:'sect'},el('h2',{},'패널'),
      el('div',{cls:'sbody',style:'padding-top:10px'},el('div',{cls:'f'},
        row('패널 제목',el('input',{value:P.title||'',oninput:e=>{P.title=e.target.value;
          $('#grid').children[this.selPanel].querySelector('.ptitle').textContent=e.target.value;}})),
      ))
    );
    I.append(s1);

    /* X축 */
    const X=this.tpl.x;
    I.append(el('div',{cls:'sect'},el('h2',{},'X축 (전 패널 공통)'),
      el('div',{cls:'sbody',style:'padding-top:10px'},el('div',{cls:'f'},
        el('div',{cls:'f2'},
          row('모드',el('select',{onchange:e=>{X.mode=e.target.value;this.renderSidebar();soft();}},
            el('option',{value:'index',selected:X.mode==='index'},'인덱스'),
            el('option',{value:'time',selected:X.mode==='time'},'시간/파라미터'))),
          row('파라미터',el('select',{disabled:X.mode!=='time',onchange:e=>{X.paramId=e.target.value;soft();}},
            ...this.catalog.params.map(p=>el('option',{value:p.id,selected:p.id===X.paramId},p.label))))
        ),
        row('제목',el('div',{cls:'row'},
          el('select',{style:'width:auto',onchange:e=>{X.title={mode:e.target.value,text:X.title?.text||''};refresh();}},
            ...['inherit','custom','none'].map(m=>el('option',{value:m,selected:(X.title?.mode||'inherit')===m},
              m==='inherit'?'상속':m==='custom'?'직접':'없음'))),
          el('input',{disabled:(X.title?.mode||'inherit')!=='custom',value:X.title?.text||'',
            oninput:e=>{X.title.text=e.target.value;soft();}}))),
        el('label',{cls:'row'},el('input',{type:'checkbox',checked:X.grid!==false,
          onchange:e=>{X.grid=e.target.checked;soft();}}),' 세로 격자')
      ))
    ));

    /* Y축 */
    const axBody=el('div',{cls:'sbody',style:'padding-top:10px'});
    P.yAxes.forEach((a)=>{
      const card=el('div',{cls:'axcard'});
      card.append(el('div',{cls:'row'},
        el('b',{cls:'mono'},a.id),
        el('select',{style:'width:auto',onchange:e=>{a.side=e.target.value;refresh();}},
          el('option',{value:'left',selected:a.side!=='right'},'왼쪽'),
          el('option',{value:'right',selected:a.side==='right'},'오른쪽')),
        el('div',{cls:'grow'}),
        el('button',{cls:'sm danger',onclick:()=>{ if(P.yAxes.length<2) return toast('축은 최소 1개 필요합니다');
          P.yAxes=P.yAxes.filter(x=>x!==a); P.series.forEach(s=>{if(s.axisId===a.id)s.axisId=P.yAxes[0].id;}); refresh(); }},'삭제')
      ));
      card.append(el('div',{cls:'f'},
        row('축 제목',el('div',{cls:'row'},
          el('select',{style:'width:auto',onchange:e=>{a.title={mode:e.target.value,text:a.title?.text||''};refresh();}},
            ...['inherit','custom','none'].map(m=>el('option',{value:m,selected:(a.title?.mode||'inherit')===m},
              m==='inherit'?'상속':m==='custom'?'직접':'없음'))),
          el('input',{disabled:(a.title?.mode||'inherit')!=='custom',value:a.title?.text||'',
            oninput:e=>{a.title.text=e.target.value;soft();}}))),
        el('div',{cls:'f2'},
          row('범위 모드',el('select',{onchange:e=>{
              const m=e.target.value;
              const cur=this.viewAxisRange(P,a);
              a.range = m==='manual'?{mode:'manual',min:+cur[0].toPrecision(4),max:+cur[1].toPrecision(4)}
                      : m==='auto-padded'?{mode:'auto-padded',padPct:5}
                      : m==='nice'?{mode:'nice',targetTicks:5} : {mode:m};
              refresh();}},
            ...[['auto-padded','자동(여백)'],['auto','자동(밀착)'],['nice','자동(눈금정렬)'],
                ['manual','수동 고정'],['symmetric','0중심 대칭']]
              .map(([v,t])=>el('option',{value:v,selected:(a.range?.mode||'auto-padded')===v},t)))),
          row('스케일',el('select',{onchange:e=>{a.scaleType=e.target.value;soft();}},
            el('option',{value:'linear',selected:a.scaleType!=='log'},'선형'),
            el('option',{value:'log',selected:a.scaleType==='log'},'로그')))
        ),
        a.range?.mode==='manual'?el('div',{cls:'f2'},
          row('최소',el('input',{type:'number',step:'any',value:a.range.min,oninput:e=>{a.range.min=parseFloat(e.target.value);soft();}})),
          row('최대',el('input',{type:'number',step:'any',value:a.range.max,oninput:e=>{a.range.max=parseFloat(e.target.value);soft();}}))
        ):null,
        a.range?.mode==='auto-padded'?row('여백 %',el('input',{type:'number',step:'any',value:a.range.padPct??5,
          oninput:e=>{a.range.padPct=parseFloat(e.target.value)||0;soft();}})):null,
        el('div',{cls:'row'},
          el('label',{cls:'row'},el('input',{type:'checkbox',checked:a.grid!==false,onchange:e=>{a.grid=e.target.checked;soft();}}),' 격자'),
          el('label',{cls:'row'},el('input',{type:'checkbox',checked:a.showUnit!==false,onchange:e=>{a.showUnit=e.target.checked;soft();}}),' 단위표기'),
          el('label',{cls:'row'},el('input',{type:'checkbox',checked:a.visible!==false,onchange:e=>{a.visible=e.target.checked;soft();}}),' 표시'))
      ));
      axBody.append(card);
    });
    axBody.append(el('button',{cls:'sm',onclick:()=>{P.yAxes.push(this.newAxis(P));refresh();}},'＋ Y축 추가'));
    I.append(el('div',{cls:'sect'},el('h2',{},'Y축'),axBody));

    /* 시리즈 */
    const seBody=el('div',{cls:'sbody',style:'padding-top:10px'});
    P.series.forEach(s=>{
      const p=this.catalog.get(s.paramId);
      const card=el('div',{cls:'axcard'});
      card.append(el('div',{cls:'row'},
        el('input',{type:'color',style:'width:32px',value:s.color,oninput:e=>{s.color=e.target.value;soft();}}),
        el('select',{onchange:e=>{s.paramId=e.target.value;refresh();}},
          ...this.catalog.params.map(q=>el('option',{value:q.id,selected:q.id===s.paramId},q.label))),
        el('div',{cls:'grow'}),
        el('button',{cls:'sm danger',onclick:()=>{P.series=P.series.filter(x=>x!==s);refresh();}},'✕')
      ));
      card.append(el('div',{cls:'f'},
        el('div',{cls:'f3'},
          row('Y축 귀속',el('select',{onchange:e=>{s.axisId=e.target.value;soft();}},
            ...P.yAxes.map(a=>el('option',{value:a.id,selected:a.id===s.axisId},a.id+(a.side==='right'?' (우)':' (좌)'))))),
          row('스타일',el('select',{onchange:e=>{s.style=e.target.value;soft();}},
            ...[['line','선'],['step','계단'],['area','면적'],['points','점']]
              .map(([v,t])=>el('option',{value:v,selected:(s.style||'line')===v},t)))),
          row('굵기',el('input',{type:'number',step:'0.2',min:'0.5',max:'5',value:s.width??1.4,
            oninput:e=>{s.width=parseFloat(e.target.value)||1;soft();}}))
        ),
        row('이 패널에서의 이름 (선택)',el('input',{placeholder:p?p.label:'',value:s.labelOverride||'',
          oninput:e=>{s.labelOverride=e.target.value||undefined;soft();}}))
      ));
      seBody.append(card);
    });
    seBody.append(el('button',{cls:'sm',onclick:()=>{
      const used=new Set(P.series.map(s=>s.paramId));
      const p=this.catalog.params.find(q=>!used.has(q.id)&&!q._aux)||this.catalog.params[0];
      if(p){P.series.push(this.newSeries(P,p.id,P.yAxes[0].id));refresh();}
    }},'＋ 시리즈 추가'));
    I.append(el('div',{cls:'sect'},el('h2',{},'시리즈'),seBody));
  },

  viewAxisRange(P,a){
    let lo=Infinity,hi=-Infinity;
    for(const s of P.series){ if(s.axisId!==a.id||s.visible===false) continue;
      const r=this.catalog.tryCompute(s.paramId); if(!r) continue;
      if(r.range[0]<lo)lo=r.range[0]; if(r.range[1]>hi)hi=r.range[1]; }
    if(!isFinite(lo)) return [0,1];
    return [lo,hi];
  },

  /* ── 템플릿 입출력 ──────────────────────────────────────── */
  exportTemplate(){
    const doc={ kind:'pdps-view', version:1, savedAt:new Date().toISOString(),
      catalog:this.catalog.params.map(({id,label,unit,kind,column,radix,scale,offset,expr,decimals,displayRadix,color,precision,_aux})=>
        ({id,label,unit,kind,column,radix,scale,offset,expr,decimals,displayRadix,color,precision,_aux})),
      template:this.tpl };
    const blob=new Blob([JSON.stringify(doc,null,2)],{type:'application/json'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
    a.download=(this.tpl.name||'view').replace(/\s+/g,'_')+'.pdps-view.json'; a.click();
    setTimeout(()=>URL.revokeObjectURL(a.href),2000);
    toast('템플릿을 저장했습니다');
  },
  importTemplate(doc){
    if(doc.kind!=='pdps-view') return toast('PDPS 뷰 파일이 아닙니다');
    if(!this.ds) return toast('먼저 데이터를 불러오세요');
    // 바인딩 검증: 컬럼이 없으면 알려준다
    const missing=[];
    this.catalog=new Catalog(); this.catalog.setDataset(this.ds);
    for(const p of doc.catalog){
      if(p.kind==='source'&&!this.ds.colByName(p.column)) missing.push(`${p.id} → '${p.column}'`);
      this.catalog.params.push(Object.assign({},p));
    }
    this.tpl=doc.template;
    this.selPanel=0; this.selParam=this.catalog.params[0]?.id||null;
    this.resetViewport(); this.rebuildGrid(); this.renderSidebar(); this.renderInspector(); this.requestDraw();
    toast(missing.length?`불러왔습니다 · 미연결 바인딩 ${missing.length}건: ${missing[0]}…`:'템플릿을 불러왔습니다');
  },
};

/* ═══════════════════════════════════════════════════════════════════
   데모 데이터 생성기 — 엔진 시험 프로파일
   16진 CAN 바이트, 2진 상태 비트, 스파이크가 있는 진동 신호를 포함한다.
   (스파이크는 min/max 데시메이션의 합격 여부를 눈으로 확인하기 위한 것)
   ═══════════════════════════════════════════════════════════════════ */
async function genDemo(N){
  const hdr='TIME_MS,CAN_RPM_H,CAN_RPM_L,TQ_RAW,TEMP_RAW,STATUS,VIB\n';
  const chunks=[hdr];
  const CH=100000;
  let buf=[];
  const H2=v=>v.toString(16).toUpperCase().padStart(2,'0');
  let rnd=12345;
  const rand=()=>{ rnd=(rnd*1103515245+12345)&0x7fffffff; return rnd/0x7fffffff; };
  for(let i=0;i<N;i++){
    const t=i/1000;
    // 회전수: 360초(6분) 주기의 램프-홀드-감속 프로파일 → 1시간에 10사이클
    const ph=t%360;
    let rpm = ph<30  ? 800
            : ph<120 ? 800+(ph-30)/90*5200
            : ph<210 ? 6000+Math.sin((ph-120)*0.18)*180
            : ph<270 ? 6000-(ph-210)/60*4200
            : ph<315 ? 1800+Math.sin((ph-270)*0.4)*260
            : 800;
    rpm += (rand()-0.5)*45 + Math.sin(t*37)*12;
    rpm = Math.max(0,Math.min(16000,rpm));
    const raw=Math.round(rpm*4);
    // 토크: 회전수와 상관, 감속 구간에 음수(엔진 브레이크)
    let tq = (ph>120&&ph<210) ? 320+Math.sin(t*0.5)*22
           : (ph>=210&&ph<270) ? -60+Math.sin(t*0.8)*18
           : 40+rpm*0.045;
    tq += (rand()-0.5)*7;
    // 수온: 27분에 걸쳐 완만 상승 + 서모스탯 리플. TEMP_RAW가 정수라 0.75℃ 양자화된다.
    const temp = 22 + Math.min(74,t*0.045) + Math.sin(t*0.02)*1.8 + (rand()-0.5)*0.5;
    const traw = Math.round((temp+48)/0.75);
    // 진동: 회전수 상관 노이즈 + 120초마다 2샘플짜리 스파이크.
    // 1시간 뷰(1/4096 축약)에서도 이 스파이크가 보여야 min/max 데시메이션이 제 역할을 한 것이다.
    const spike = (i%120000)<2;
    let vib = 0.35 + Math.abs(Math.sin(t*11))*0.35 + rpm/16000*1.5 + (rand()-0.5)*0.35;
    if(spike) vib += 9+rand()*5;
    // 상태 비트: b0=런, b1=고회전, b2=고장(스파이크 동반), b3=냉간
    const bits=(1) | ((rpm>5000?1:0)<<1) | ((spike?1:0)<<2) | ((temp<60?1:0)<<3);
    buf.push(`${i},${H2((raw>>8)&255)},${H2(raw&255)},${Math.round(tq*10)},${traw},${bits.toString(2).padStart(8,'0')},${vib.toFixed(3)}`);
    if(buf.length>=CH){ chunks.push(buf.join('\n')+'\n'); buf=[];
      busy(true,`데모 데이터 생성 중… ${((i/N)*100).toFixed(0)}%`,(i/N)*100); await raf(); }
  }
  if(buf.length) chunks.push(buf.join('\n')+'\n');
  busy(true,'문자열 결합 중…',99); await raf();
  return chunks.join('');
}

/* ═══════════════════════════════════════════════════════════════════
   부팅
   ═══════════════════════════════════════════════════════════════════ */
function fxTable(){
  const t=$('#fxTable');
  const rows=[
    ['+ - * / % **','사칙연산 · 거듭제곱'],
    ['& | ^ ~ << >>','비트 AND/OR/XOR/NOT/시프트'],
    ['hex2dec(C)','컬럼 C를 16진으로 재해석'],
    ['bin2dec(C) oct2dec(C)','2진 / 8진 재해석'],
    ['from_base(C, r)','임의 진법(2~36) 재해석'],
    ['getbit(x,n) bitfield(x,sh,w)','비트 추출 · 비트필드'],
    ['bitcount(x) shl/shr(x,n)','비트 수 · 시프트'],
    ['abs sqrt exp ln log10 log2','수학'],
    ['sin cos tan atan2 degrees','삼각'],
    ['round floor ceil trunc sign','반올림류'],
    ['clamp(x,lo,hi) if(c,a,b)','제한 · 조건'],
    ['pmin pmax pmean coalesce','다중 파라미터 조합'],
    ['diff(x) deriv(x,dt) cumsum(x)','차분 · 미분 · 누적'],
    ['movavg(x,w) movmin movmax movstd','이동 통계'],
    ['prev(x,n) next(x,n) fillprev(x)','시프트 · 보간'],
    ['idx, n, pi, e','상수'],
  ];
  t.innerHTML=''; for(const [a,b] of rows) t.append(el('tr',{},el('td',{},a),el('td',{cls:'muted'},b)));
}

function boot(){
  fxTable();
  App.tpl=App.newTemplate();
  $('#btnDemo').onclick=async()=>{
    const n=prompt('생성할 행 수를 입력하세요.\n\n  1000000  = 1000Hz × 1000초\n  3600000  = 1000Hz × 1시간 (전체 규모 검증)','1000000');
    if(!n) return;
    const N=Math.max(1000,Math.min(6000000,parseInt(n)||1000000));
    busy(true,'데모 데이터 생성 중…',0); await raf();
    const txt=await genDemo(N);
    await App.loadText(txt,`demo_${N.toLocaleString()}rows.csv`);
  };
  $('#btnOpen').onclick=()=>$('#fileIn').click();
  $('#fileIn').onchange=async e=>{
    const f=e.target.files[0]; if(!f) return;
    busy(true,'파일 읽는 중…',5); await raf();
    const txt=await f.text();
    await App.loadText(txt,f.name);
    e.target.value='';
  };
  $('#btnReset').onclick=()=>App.resetViewport();
  $('#btnInsp').onclick=()=>$('#main').classList.toggle('insp');
  $('#btnExport').onclick=()=>App.exportTemplate();
  $('#btnImport').onclick=()=>$('#tplIn').click();
  $('#tplIn').onchange=async e=>{ const f=e.target.files[0]; if(!f)return;
    try{ App.importTemplate(JSON.parse(await f.text())); }catch(err){ toast('불러오기 실패: '+err.message); }
    e.target.value=''; };
  $('#xMode').onchange=e=>{ App.tpl.x.mode=e.target.value; $('#xParam').disabled=e.target.value!=='time';
    if(e.target.value==='time'&&!App.tpl.x.paramId) App.tpl.x.paramId=$('#xParam').value;
    App.requestDraw(); App.renderInspector(); };
  $('#xParam').onchange=e=>{ App.tpl.x.paramId=e.target.value; App.requestDraw(); };
  $('#syncX').onchange=e=>{ App.tpl.layout.syncXZoom=e.target.checked; };
  $('#layoutSel').onchange=e=>{
    const [r,c]=e.target.value.split('x').map(Number);
    App.tpl.layout.rows=r; App.tpl.layout.cols=c;
    const want=r*c;
    while(App.tpl.panels.length<want) App.tpl.panels.push(App.newPanel(App.tpl.panels.length));
    while(App.tpl.panels.length>want) App.tpl.panels.pop();
    App.selPanel=Math.min(App.selPanel,want-1);
    App.rebuildGrid(); App.renderInspector(); App.requestDraw();
  };
  window.addEventListener('resize',()=>App.requestDraw());
  window.addEventListener('keydown',e=>{
    if(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA') return;
    if(e.key==='r'||e.key==='R') App.resetViewport();
    if(e.key==='i') $('#main').classList.toggle('insp');
  });
  App.rebuildGrid(); App.renderStatus();
  window.App=App; window.Expr=Expr;
}
document.addEventListener('DOMContentLoaded',boot);
