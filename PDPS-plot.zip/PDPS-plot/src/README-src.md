# 소스

`pdps-plot.html` 은 이 폴더의 조각들을 이어붙인 결과물입니다.

| 파일 | 역할 |
|---|---|
| `00-head.html` | HTML 구조 + CSS |
| `01-expr.js` | 표현식 엔진 — 토크나이저 · Pratt 파서 · 화이트리스트 검증 · 벡터 실행기 |
| `02-data.js` | CSV 적재(원문+행오프셋) · 파라미터 카탈로그 · min/max 피라미드 |
| `03-render.js` | Canvas 2D 렌더러 — 다중 Y축 · 축 범위 · min/max 밴드 · 줌/팬/커서 |
| `04-app.js` | 상태 · UI · 템플릿 입출력 · 데모 데이터 생성기 |

## 빌드

```
node src/build.mjs
```

## 테스트 (Playwright 필요)

```
npm i -D playwright && npx playwright install chromium
node src/test.mjs 3600000 ./shots
```

표현식 엔진 단위 테스트 18건, 진수 변환 정확성, min/max 스파이크 보존,
렌더 성능, 콘솔 에러를 검사하고 스크린샷을 남깁니다.
실패가 있으면 종료 코드 1을 반환합니다.

> 테스트는 GPU가 없는 환경을 고려해 `--use-angle=swiftshader` 로 실행합니다.
> "연속 팬 프레임률" 수치는 소프트웨어 래스터라이저의 한계라 실제 PC와 무관합니다.
