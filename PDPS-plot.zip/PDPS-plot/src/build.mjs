/* src/*.js 를 이어붙여 ../pdps-plot.html 하나로 만든다.  실행: node src/build.mjs */
import { readFileSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
const here = dirname(fileURLToPath(import.meta.url));
const parts = ['00-head.html','01-expr.js','02-data.js','03-render.js','04-app.js']
  .map(f => readFileSync(join(here,f),'utf8'));
const out = parts.join('\n') + '\n</script>\n</body>\n</html>\n';
const dest = join(here,'..','pdps-plot.html');
writeFileSync(dest, out);
console.log(`built ${dest}  (${(out.length/1024).toFixed(0)} KB)`);
