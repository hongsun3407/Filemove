/* ═══════════════════════════════════════════════════════════════════
   계층 ①  SOURCE — CSV 적재
   원문 텍스트 + 행 오프셋 인덱스만 유지하고, 컬럼은 요청될 때 디코딩한다.
   덕분에 같은 컬럼을 다른 진법으로 언제든 재해석할 수 있다.
   ═══════════════════════════════════════════════════════════════════ */

/* 문자열 슬라이스 할당 없이 [a,b) 구간을 숫자로 파싱한다.
   3,600,000행 × 여러 컬럼에서 slice+parseFloat 대비 5~10배 빠르다. */
function parseNumAt(s,a,b,radix){
  while(a<b){ const c=s.charCodeAt(a); if(c===32||c===9||c===34) a++; else break; }
  while(b>a){ const c=s.charCodeAt(b-1); if(c===32||c===9||c===13||c===34) b--; else break; }
  if(a>=b) return NaN;
  let neg=false, c0=s.charCodeAt(a);
  if(c0===45){neg=true;a++;} else if(c0===43){a++;}
  if(a>=b) return NaN;
  if(radix!==10){
    let v=0;
    for(let i=a;i<b;i++){
      const c=s.charCodeAt(i);
      let d;
      if(c>=48&&c<=57) d=c-48;
      else if(c>=65&&c<=90) d=c-55;
      else if(c>=97&&c<=122) d=c-87;
      else return NaN;
      if(d>=radix) return NaN;
      v=v*radix+d;
    }
    return neg?-v:v;
  }
  let v=0, seen=false;
  let i=a;
  for(;i<b;i++){ const c=s.charCodeAt(i); if(c>=48&&c<=57){ v=v*10+(c-48); seen=true; } else break; }
  if(i<b && s.charCodeAt(i)===46){
    i++; let f=0.1;
    for(;i<b;i++){ const c=s.charCodeAt(i); if(c>=48&&c<=57){ v+=(c-48)*f; f*=0.1; seen=true; } else break; }
  }
  if(!seen) return NaN;
  if(i<b){ const c=s.charCodeAt(i);
    if(c===101||c===69){
      i++; let en=false, ev=0;
      if(i<b){ const sg=s.charCodeAt(i); if(sg===45){en=true;i++;} else if(sg===43){i++;} }
      let any=false;
      for(;i<b;i++){ const cc=s.charCodeAt(i); if(cc>=48&&cc<=57){ ev=ev*10+(cc-48); any=true; } else break; }
      if(any) v*=Math.pow(10,en?-ev:ev);
    }
  }
  if(i<b) return NaN;
  return neg?-v:v;
}

class Dataset{
  constructor(text){
    this.text=text;
    this.cache=new Map();          // "colIdx:radix" → Float64Array
    this._parse();
  }
  _parse(){
    const s=this.text;
    // 1) 헤더 줄
    let e0=s.indexOf('\n'); if(e0<0) e0=s.length;
    let head=s.slice(0,e0).replace(/\r$/,'');
    // 2) 구분자 추론
    const cand=[',','\t',';','|'];
    this.delim=cand.reduce((b,c)=>(head.split(c).length>head.split(b).length?c:b),',');
    this.headers=head.split(this.delim).map(h=>h.trim().replace(/^"|"$/g,''));
    this.nCols=this.headers.length;
    // 3) 행 오프셋 인덱스 — 2패스(개수 세기 → 채우기)로 박싱 배열을 피한다
    let cnt=0;
    for(let i=e0+1;i<s.length;){ cnt++; let j=s.indexOf('\n',i); if(j<0) j=s.length; i=j+1; }
    const off=new Uint32Array(cnt); let k=0;
    for(let i=e0+1;i<s.length;){ off[k++]=i; let j=s.indexOf('\n',i); if(j<0) j=s.length; i=j+1; }
    this.rowOff=off;
    this.nRows=cnt;
    this.rowEnd=(r)=>{ let e = r+1<this.nRows ? this.rowOff[r+1]-1 : this.text.length;
                       while(e>this.rowOff[r] && (this.text.charCodeAt(e-1)===13||this.text.charCodeAt(e-1)===10)) e--;
                       return e; };
    // 4) 컬럼 메타: 진법 자동 감지
    this.cols=this.headers.map((name,idx)=>({name,idx,radix:10,kind:'num'}));
    this._detect();
  }
  _detect(){
    const SAMP=Math.min(500,this.nRows);
    for(const c of this.cols){
      let dec=0,hex=0,bin=0,txt=0,seen=0,lead0=0; const lens=new Set();
      for(let r=0;r<SAMP;r++){
        const t=this.field(r,c.idx).trim();
        if(!t) continue;
        seen++; lens.add(t.length);
        if(/^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(t)) dec++;
        if(/^[01]{4,}$/.test(t)) bin++;
        if(/^[0-9A-Fa-f]+$/.test(t)&&/[A-Fa-f]/.test(t)) hex++;
        if(!/^[0-9A-Fa-f+\-.eE]+$/.test(t)) txt++;
        if(t.length>1&&t[0]==='0'&&t[1]!=='.') lead0++;
      }
      if(!seen){ c.kind='empty'; continue; }
      const uniform=lens.size===1, padded=lead0>seen*0.2;
      if(txt>seen*0.2){ c.kind='text'; c.radix=10; }
      else if(hex>seen*0.6){ c.radix=16; c.kind='num'; }
      // 균일 길이 + 앞자리 0 → 10진 숫자가 아니라 비트필드로 본다
      else if(bin>=seen*0.9 && uniform && padded){ c.radix=2; c.kind='num'; }
      else if(dec>=seen*0.9){ c.radix=10; c.kind='num'; }
      else if(bin>=seen*0.9){ c.radix=2; c.kind='num'; }
      else { c.radix=10; c.kind='num'; }
    }
  }
  /** r행 c열의 원본 문자열 */
  field(r,c){
    const s=this.text, st=this.rowOff[r], en=this.rowEnd(r), d=this.delim;
    let k=0,a=st;
    for(let i=st;i<=en;i++){
      if(i===en||s[i]===d){
        if(k===c) return s.slice(a,i);
        k++; a=i+1;
      }
    }
    return '';
  }
  /** 컬럼을 지정 진법으로 디코딩 (캐시됨) */
  decode(colIdx,radix){
    const key=colIdx+':'+radix;
    const hit=this.cache.get(key); if(hit) return hit;
    const N=this.nRows, s=this.text, d=this.delim.charCodeAt(0), off=this.rowOff, L=s.length;
    const out=new Float64Array(N);
    for(let r=0;r<N;r++){
      const st=off[r];
      let en = r+1<N ? off[r+1]-1 : L;
      while(en>st){ const cc=s.charCodeAt(en-1); if(cc===13||cc===10) en--; else break; }
      let k=0,a=st,b=-1;
      for(let i=st;i<=en;i++){
        if(i===en||s.charCodeAt(i)===d){
          if(k===colIdx){ b=i; break; }
          k++; a=i+1;
        }
      }
      out[r]= b<0 ? NaN : parseNumAt(s,a,b,radix);
    }
    if(this.cache.size>40) this.cache.clear();
    this.cache.set(key,out);
    return out;
  }
  colByName(name){
    let c=this.cols.find(c=>c.name===name);
    if(!c) c=this.cols.find(c=>c.name.toLowerCase()===String(name).toLowerCase());
    return c||null;
  }
  stats(){ return {rows:this.nRows,cols:this.nCols,bytes:this.text.length}; }
}

/* ═══════════════════════════════════════════════════════════════════
   계층 ②-b  파라미터 카탈로그
   id(불변) ↔ label(자유 변경) 분리. 컬럼명을 아는 곳은 binding 뿐.
   ═══════════════════════════════════════════════════════════════════ */
class Catalog{
  constructor(){ this.params=[]; this.ds=null; this.values=new Map(); this.errors=new Map(); }

  setDataset(ds){ this.ds=ds; this.invalidateAll(); }
  get(id){ return this.params.find(p=>p.id===id)||null; }
  byLabel(l){ return this.params.find(p=>p.label===l)||null; }
  resolve(name){                       // 수식 식별자 해석: 파라미터 id → label → 원본 컬럼
    return this.get(name)||this.byLabel(name)||(this.ds&&this.ds.colByName(name))||null;
  }
  add(p){
    const base=p.id||'P_NEW'; let id=base,k=1;
    while(this.get(id)) id=base+'_'+(++k);
    const q=Object.assign({
      id, label:id, unit:'', kind:'source', column:null, radix:10, scale:1, offset:0,
      expr:'', displayRadix:10, decimals:3, color:PALETTE[this.params.length%PALETTE.length],
      precision:'f32'
    },p,{id});
    this.params.push(q); this.invalidateAll(); return q;
  }
  remove(id){
    const i=this.params.findIndex(p=>p.id===id);
    if(i>=0){ this.params.splice(i,1); this.invalidateAll(); }
  }
  invalidate(id){ this.values.delete(id); this.errors.delete(id);
    // 이 파라미터에 의존하는 것들도 무효화
    for(const p of this.params) if(p.kind==='derived'&&p.expr&&p.expr.includes(id)) { this.values.delete(p.id); this.errors.delete(p.id); }
  }
  invalidateAll(){ this.values.clear(); this.errors.clear(); }

  /** 파라미터 값 벡터를 얻는다 (지연 계산 + 캐시 + 순환참조 검출) */
  compute(id,stack=[]){
    if(this.values.has(id)) return this.values.get(id);
    if(stack.includes(id)) throw new Expr.EErr(`순환 참조: ${[...stack,id].join(' → ')}`,0);
    const p=this.get(id);
    if(!p) throw new Expr.EErr(`알 수 없는 파라미터 '${id}'`,0);
    if(!this.ds) throw new Expr.EErr('데이터가 없습니다',0);
    const N=this.ds.nRows;
    let vec;
    if(p.kind==='source'){
      const c=this.ds.colByName(p.column);
      if(!c) throw new Expr.EErr(`컬럼 '${p.column}' 을(를) 찾을 수 없습니다`,0);
      const raw=this.ds.decode(c.idx, p.radix||10);
      const sc=Number(p.scale)||0, of=Number(p.offset)||0;
      if(sc===1&&of===0) vec=raw;
      else { vec=new Float64Array(N); for(let i=0;i<N;i++) vec[i]=raw[i]*sc+of; }
    } else {
      const self=this;
      const compiled=Expr.compile(p.expr||'0', n=>self.resolve(n));
      const ctx={
        index:()=>{ const a=new Float64Array(N); for(let i=0;i<N;i++)a[i]=i; return a; },
        column:(name)=>{
          const t=self.resolve(name);
          if(!t) throw new Expr.EErr(`알 수 없는 식별자 '${name}'`,0);
          if(t.id!==undefined) return self.compute(t.id,[...stack,id]).values;  // 파라미터 → 값 벡터
          return self.ds.decode(t.idx, t.radix||10);                       // 원본 컬럼
        },
        columnRaw:(name,radix)=>{                                          // 진수 재해석
          const t=self.resolve(name);
          if(!t) throw new Expr.EErr(`알 수 없는 식별자 '${name}'`,0);
          const ci = t.id!==undefined ? (t.column?self.ds.colByName(t.column):null) : t;
          if(!ci) throw new Expr.EErr(`'${name}' 은(는) 원본 컬럼이 아니어서 진수 재해석을 할 수 없습니다`,0);
          return self.ds.decode(ci.idx,radix);
        },
      };
      vec=Expr.evaluate(compiled,N,ctx);
    }
    const store = p.precision==='f64' ? (vec instanceof Float64Array?vec:Float64Array.from(vec))
                                      : Float32Array.from(vec);
    const rec={values:store,pyr:new Pyramid(store),range:minMax(store)};
    this.values.set(id,rec);
    return rec;
  }
  /** 에러를 던지지 않는 안전판 */
  tryCompute(id){
    try{ const r=this.compute(id); this.errors.delete(id); return r; }
    catch(e){ this.errors.set(id,e.message||String(e)); return null; }
  }
}

function minMax(a){
  let lo=Infinity,hi=-Infinity;
  for(let i=0;i<a.length;i++){ const v=a[i]; if(v<lo)lo=v; if(v>hi)hi=v; }
  if(!isFinite(lo)){lo=0;hi=1;}
  return [lo,hi];
}

/* ═══════════════════════════════════════════════════════════════════
   다단계 min/max 피라미드
   렌더링 정점 수를 줌 레벨과 무관하게 상수로 고정하는 장치.
   LTTB와 달리 구간 극값(스파이크)이 절대 소실되지 않는다.
   ═══════════════════════════════════════════════════════════════════ */
const PYR_RATIOS=[8,64,512,4096,32768];

class Pyramid{
  constructor(src){
    this.src=src; this.N=src.length; this.levels=[];
    for(const r of PYR_RATIOS){
      if(this.N/r < 64) break;
      const m=Math.ceil(this.N/r);
      const lo=new Float32Array(m), hi=new Float32Array(m);
      const prev=this.levels.length?this.levels[this.levels.length-1]:null;
      if(!prev){
        for(let b=0;b<m;b++){
          const s=b*r, e=Math.min(s+r,this.N);
          let a=Infinity,z=-Infinity;
          for(let i=s;i<e;i++){ const v=src[i]; if(v<a)a=v; if(v>z)z=v; }
          lo[b]=a; hi[b]=z;
        }
      } else {                                   // 하위 레벨에서 유도 → 훨씬 빠름
        const k=r/prev.ratio;
        for(let b=0;b<m;b++){
          const s=b*k, e=Math.min(s+k,prev.n);
          let a=Infinity,z=-Infinity;
          for(let i=s;i<e;i++){ if(prev.lo[i]<a)a=prev.lo[i]; if(prev.hi[i]>z)z=prev.hi[i]; }
          lo[b]=a; hi[b]=z;
        }
      }
      this.levels.push({ratio:r,n:m,lo,hi});
    }
  }
  /** [from,to] 구간을 buckets개로 축약. 반환: {i0[],lo[],hi[],k} */
  query(from,to,buckets){
    from=Math.max(0,Math.floor(from)); to=Math.min(this.N-1,Math.ceil(to));
    const span=to-from+1;
    if(span<=0) return {n:0,idx:new Float64Array(0),lo:new Float32Array(0),hi:new Float32Array(0),level:0,exact:true};
    if(span<=buckets){                             // 충분히 줌인 → 원본 그대로
      const n=span, idx=new Float64Array(n), lo=new Float32Array(n), hi=new Float32Array(n);
      for(let i=0;i<n;i++){ idx[i]=from+i; lo[i]=hi[i]=this.src[from+i]; }
      return {n,idx,lo,hi,level:0,exact:true};
    }
    // 이 구간에서 buckets개를 만들기에 충분한 해상도를 가진 가장 거친 레벨
    let L=null;
    for(const lv of this.levels){ if(span/lv.ratio >= buckets*2) L=lv; else break; }
    const B=buckets;
    const idx=new Float64Array(B), lo=new Float32Array(B), hi=new Float32Array(B);
    if(!L){
      for(let b=0;b<B;b++){
        const s=from+Math.floor(b*span/B), e=from+Math.floor((b+1)*span/B);
        let a=Infinity,z=-Infinity;
        for(let i=s;i<e;i++){ const v=this.src[i]; if(v<a)a=v; if(v>z)z=v; }
        idx[b]=(s+e-1)/2; lo[b]=a; hi[b]=z;
      }
      return {n:B,idx,lo,hi,level:0,exact:true};
    }
    const r=L.ratio, j0=Math.floor(from/r), j1=Math.min(L.n-1,Math.floor(to/r)), m=j1-j0+1;
    for(let b=0;b<B;b++){
      const s=j0+Math.floor(b*m/B), e=Math.max(s+1,j0+Math.floor((b+1)*m/B));
      let a=Infinity,z=-Infinity;
      for(let i=s;i<=Math.min(e-1,j1);i++){ if(L.lo[i]<a)a=L.lo[i]; if(L.hi[i]>z)z=L.hi[i]; }
      idx[b]=(s*r+e*r-1)/2; lo[b]=a; hi[b]=z;
    }
    return {n:B,idx,lo,hi,level:r,exact:false};
  }
}

const PALETTE=['#4da3ff','#ff9f40','#3fd07a','#ff6a6a','#c792ea','#ffd866',
               '#4dd0e1','#f78fb3','#a3e635','#fb923c','#818cf8','#2dd4bf'];
