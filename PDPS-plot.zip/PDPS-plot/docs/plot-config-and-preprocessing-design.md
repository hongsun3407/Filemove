# 플롯 설정 · 전처리 엔진 설계

**버전** 0.1
**작성일** 2026-08-24
**관계** `realtime-plot-design.md` v0.1의 §5·§6을 확장·대체. 스트리밍은 그 문서, 파일 기반 분석과 설정 모델은 이 문서.

---

## 0. 한 문장 요약

> **CSV를 DuckDB-WASM에 올리고, "파라미터 카탈로그"가 전처리(사칙연산·조합·진수변환)를 담당하며,
> "플롯 템플릿" JSON이 축·시리즈·레이아웃을 선언한다. 둘은 파라미터 ID로만 연결되고,
> 데이터 계층은 어떤 경우에도 `{x[], min[], max[]}` 하나의 계약으로 렌더러에 넘긴다.**

기능을 하나씩 코드로 박아 넣는 대신, **선언적 설정 + 표현식 엔진 + 단일 렌더 계약**
세 가지로 요구사항 전체를 포괄한다.

---

## 1. 핵심 아이디어 — 3계층 분리

요구사항을 그대로 구현하면 "CSV 컬럼명"이 차트 코드까지 스며들어서,
컬럼 이름이 다른 파일이 들어오는 순간 설정이 전부 깨진다. 실무에서 이게 가장 흔한 실패다.

```
┌─────────────────────────────────────────────────────────────────┐
│ ① SOURCE   물리적 데이터                                          │
│    CSV / XLSX 파일, 또는 WebSocket 스트림                          │
│    "raw_rpm_hi", "raw_rpm_lo", "TIME_MS" ← 파일마다 이름이 다름     │
└───────────────────────────┬─────────────────────────────────────┘
                            │  바인딩 (Binding) — 여기서만 컬럼명을 안다
┌───────────────────────────▼─────────────────────────────────────┐
│ ② CATALOG  파라미터 카탈로그  ★전처리가 사는 곳                     │
│    P_RPM   = (hex2dec(raw_rpm_hi) << 8 | hex2dec(raw_rpm_lo)) * 0.25 │
│    P_TEMP  = raw_temp * 0.1 - 40                                 │
│    P_POWER = P_RPM * P_TORQUE / 9550                             │
│    각 파라미터: id(불변) / label(자유변경) / unit / dtype           │
└───────────────────────────┬─────────────────────────────────────┘
                            │  파라미터 ID로만 참조 (컬럼명 모름)
┌───────────────────────────▼─────────────────────────────────────┐
│ ③ VIEW     플롯 템플릿 (JSON)                                     │
│    패널 배치 / 좌·우 Y축 / 축별 시리즈 할당 / 축 제목 / 범위        │
│    X축 모드(index·time) / 색상 / 선 스타일                         │
└─────────────────────────────────────────────────────────────────┘
```

**이 분리가 주는 것**

| 얻는 것 | 설명 |
|---|---|
| 템플릿 재사용 | 컬럼명이 다른 새 CSV가 와도 **바인딩만 다시 매핑**하면 기존 템플릿이 그대로 동작 |
| 파라미터명 변경 | `label`만 바꾸면 됨. `id`는 불변이라 템플릿이 깨지지 않음 |
| 파생 파라미터 | 카탈로그에서만 정의. 템플릿은 원본/파생을 구분할 필요조차 없음 |
| 스트리밍 통합 | ①만 교체하면 ②③은 그대로. 파일 모드와 실시간 모드가 같은 UI를 쓴다 |

---

## 2. 계층 ① SOURCE — 데이터 적재

### 2.1 엔진 선택: DuckDB-WASM

| 후보 | CSV 파싱 | 전처리 | 진수 변환 | 대용량 | 판정 |
|---|---|---|---|---|---|
| **DuckDB-WASM** | `read_csv` 내장, 타입 자동추론 | **SQL 전체** | `to_base`/`hex`/`bin`/비트연산자 | 컬럼 저장, 벡터화 | **채택** |
| Papa Parse + JS | 문자열 파싱, 느림 | 직접 구현 | 직접 구현 | 360만 행에서 GC 폭발 | ✕ |
| Arrow JS만 | CSV 미지원 | 직접 구현 | 직접 구현 | 저장은 좋음 | △ (전송 포맷으로만 사용) |
| SQLite-WASM | 있음 | SQL | 제한적 | 행 저장이라 분석에 불리 | △ |

> **DuckDB-WASM 하나가 "CSV 읽기 + 사칙연산 + 파라미터 조합 + 진수 변환 + 데시메이션"을
> 전부 커버한다.** 이 요구사항 목록에 이보다 잘 맞는 도구가 없다.

### 2.2 적재 파이프라인

```
파일 선택 (File API / drag&drop)
   ↓
registerFileHandle()  ← 파일을 복사하지 않고 핸들만 등록 (메모리 절약)
   ↓
CREATE TABLE raw AS SELECT * FROM read_csv('data.csv', header=true, sample_size=-1)
   ↓
[선택] COPY raw TO 'cache.parquet'  → OPFS에 저장
   ↓
재방문 시 Parquet에서 즉시 로드 (CSV 재파싱 생략, 5~10배 빠름)
```

**대용량 CSV 처리 지침**

- `sample_size=-1`: 전체 스캔으로 타입 추론. 뒤쪽에만 나타나는 이상값 때문에
  타입 오추론이 나는 사고를 막는다. 느리면 `columns={...}`로 스키마를 명시.
- 파일 핸들 등록 방식(`registerFileHandle`)을 쓰면 파일 전체를 메모리에 올리지 않는다.
- **OPFS Parquet 캐시**를 반드시 넣을 것. 사용자가 같은 파일로 설정을 반복 조정하는 것이
  이 도구의 주 사용 패턴이고, 매번 CSV를 다시 파싱하면 체감이 무너진다.
- duckdb-wasm은 단일 스레드 / 멀티 스레드(COI) 번들이 따로 있다. 멀티 스레드는
  `Cross-Origin-Opener-Policy` + `Cross-Origin-Embedder-Policy` 헤더가 필요하다.
  **1단계는 단일 스레드로 시작하고, 벤치 후 필요할 때 전환**한다.

### 2.3 XLSX에 대한 현실적 경고

> **Excel(.xlsx)의 시트당 최대 행 수는 1,048,576행이다.**
> 1000Hz × 1시간 = 360만 행은 **애초에 xlsx에 담기지 않는다.**

따라서:

- **CSV를 1차 포맷으로 확정**한다.
- xlsx 지원은 "설정 파일·메타데이터·소규모 요약 시트" 용도로 한정하고,
  SheetJS(`xlsx`)로 읽어 DuckDB에 INSERT하는 별도 경로로 처리한다.
- 대용량 xlsx를 업로드하면 **행 수를 감지해 CSV 변환을 안내**하는 UX를 넣는다.

---

## 3. 계층 ② CATALOG — 파라미터와 전처리 ★

### 3.1 파라미터 스키마

```ts
type Parameter = {
  id: string;              // 'P_RPM' — 불변 키. 템플릿·수식이 참조하는 유일한 이름
  label: string;           // '엔진 회전수' — 사용자가 자유롭게 변경 (요구사항: 파라미터명 변경)
  unit?: string;           // 'rpm'
  description?: string;
  dtype: 'f32' | 'f64' | 'i32' | 'u32' | 'bool';
  decimals?: number;       // 표시 자릿수
  kind: 'source' | 'derived';

  // kind === 'source'
  binding?: {
    column: string;        // CSV 컬럼명 — 컬럼명이 등장하는 유일한 지점
    radix?: 2 | 8 | 10 | 16;   // 원본이 진수 문자열일 때
    scale?: number;        // 물리량 변환: physical = raw * scale + offset
    offset?: number;
    bitField?: { shift: number; mask: number };  // 비트필드 추출
    invalidValues?: number[];  // 예: 65535 → NaN 처리
  };

  // kind === 'derived'
  expr?: string;           // 'P_RPM * P_TORQUE / 9550'
};
```

**설계 포인트 3가지**

1. `id`와 `label`을 분리한 것이 "파라미터명 변경" 요구사항의 답이다.
   화면에 보이는 이름을 아무리 바꿔도 수식과 템플릿은 `id`를 보므로 절대 깨지지 않는다.
2. `scale`/`offset`/`bitField`/`radix`를 **선언적 필드로 제공**한다. DAQ 데이터의 90%는
   `(raw >> shift) & mask) * scale + offset` 이 한 줄로 끝난다. 매번 수식을 타이핑하게
   만들지 말 것.
3. 그 밖의 임의 변환은 `expr`로 열어 둔다. 선언적 필드는 편의, 수식은 탈출구.

### 3.2 표현식 엔진

**절대 `eval()`이나 문자열 SQL 연결을 쓰지 않는다.** 파싱 → 검증 → 컴파일 3단계.

```
사용자 수식  "P_RPM * P_TQ / 9550"
    ↓ ① 파서 (Pratt parser, ~300줄 자작 또는 acorn 서브셋)
   AST
    ↓ ② 검증기
      • 식별자가 카탈로그에 존재하는가
      • 함수가 화이트리스트에 있는가
      • 순환 참조가 없는가 (P_A → P_B → P_A)
      • 인자 개수·타입이 맞는가
    ↓ ③ 컴파일러
   DuckDB SQL 표현식  "(P_RPM * P_TQ) / 9550.0"
    ↓
CREATE VIEW params AS SELECT idx, <expr1> AS P_A, <expr2> AS P_B, ... FROM raw
```

- **뷰(VIEW)로 만들고 실체화하지 않는다.** 수식을 고칠 때마다 360만 행을 다시 계산해
  저장하면 편집이 느려진다. DuckDB가 질의 시점에 필요한 컬럼만 벡터화 계산한다.
- 예외: 수식이 무겁고 반복 조회되면 해당 파라미터만 `CREATE TABLE ... AS`로 실체화하는
  옵션을 준다 (사용자에게 "고정(pin)" 버튼으로 노출).
- 파생 파라미터 간 의존은 **위상 정렬**해서 SELECT 절 순서를 정하거나, 중첩 뷰로 쌓는다.

### 3.3 함수 화이트리스트

| 분류 | 함수 |
|---|---|
| **사칙연산** | `+ - * / % ^` (괄호, 단항 `-`) |
| 수학 | `abs sqrt cbrt exp ln log10 log2 pow round floor ceil trunc sign clamp(x,lo,hi)` |
| 삼각 | `sin cos tan asin acos atan atan2 degrees radians` |
| 논리·조건 | `> >= < <= == != and or not` , `if(cond, a, b)` , `coalesce(a, b)` |
| **진수 변환** | `dec2hex dec2bin dec2oct to_base(x, radix)` / `hex2dec bin2dec oct2dec from_base(s, radix)` |
| **비트 연산** | `bitand bitor bitxor bitnot shl(x,n) shr(x,n) getbit(x,n) bitcount(x)` |
| 시계열(윈도우) | `prev(p, n) next(p, n) diff(p) cumsum(p) movavg(p, n) movmax(p, n) rate(p)` |
| 결측 처리 | `isnan(x) nullif(x, v) fillprev(p) interp(p)` |
| 통계(스칼라화) | `pmin(a,b,...) pmax(a,b,...) pmean(a,b,...)` — **다중 파라미터 조합** |

> 시계열 윈도우 함수는 DuckDB의 `lag/lead/sum() OVER/avg() OVER`로 컴파일된다.
> 이게 있어야 "미분", "이동평균", "누적" 같은 실제 분석이 가능해진다. 초기부터 넣을 것.

### 3.4 진수 변환 레시피

DuckDB 내장 기능 (확인됨):

| 목적 | SQL |
|---|---|
| 10진 → 임의 진수 문자열 | `to_base(255, 16)` → `'FF'` , `to_base(255, 2)` → `'11111111'` |
| 문자열 → 16진 표현 | `hex('Hello')` → `'48656C6C6F'` |
| 문자열 → 2진 표현 | `bin('Aa')` → `'0100000101100001'` |
| 16진 문자열 → BLOB | `unhex('FF1A')` (별칭 `from_hex`) |
| 비트 AND / OR / XOR | `91 & 15` , `32 \| 3` , `xor(17, 5)` |
| 시프트 | `1 << 4` → `16` , `8 >> 2` → `2` |
| 비트 반전 / 카운트 | `~15` → `-16` , `bit_count(31)` → `5` |
| 특정 비트 추출 | `get_bit(bitstring, i)` |

**16진 문자열 → 정수** 는 DuckDB 버전에 따라 캐스팅 지원이 갈린다. 세 가지 후보를
벤치 후 택일한다 (§9 검증 항목).

```sql
-- (A) 직접 캐스팅 — 동작하면 가장 빠르고 간단. 버전 확인 필요
SELECT ('0x' || raw_hex)::UBIGINT;

-- (B) 리스트 람다 — 내장 기능만으로 항상 동작. 자릿수 무관
SELECT list_reduce(
         [ strpos('0123456789ABCDEF', ch) - 1
           FOR ch IN string_split(upper(raw_hex), '') ],
         (acc, d) -> acc * 16 + d
       );

-- (C) 적재 시 1회 변환 — JS parseInt(s,16)으로 컬럼을 만들어 두고 이후엔 정수로만 취급
--     수식 편집 때마다 재계산하지 않으므로 실사용에서 가장 유리할 수 있음
```

**DAQ 실무 표준 레시피** — 대부분의 "진수 변환"은 사실 이 형태다.

```
P_COOLANT_TEMP:
  binding: { column: 'CAN_0x1A0', radix: 16, bitField: { shift: 8, mask: 0xFF },
             scale: 0.75, offset: -48 }

→ 컴파일 결과:
  ((hex2dec("CAN_0x1A0") >> 8) & 255) * 0.75 + (-48)
```

### 3.5 워크드 예제

**입력 CSV** (`run_2026-08-24.csv`)

```csv
TIME_MS,CAN_RPM_H,CAN_RPM_L,TQ_RAW,STATUS
0,0A,F0,1250,00000101
1,0A,F2,1251,00000101
2,0A,F5,1249,00000111
```

**카탈로그**

```json
{
  "parameters": [
    { "id": "P_T",   "label": "시간",     "unit": "s",   "kind": "source",
      "dtype": "f64", "binding": { "column": "TIME_MS", "scale": 0.001 } },

    { "id": "P_RPM", "label": "엔진 회전수", "unit": "rpm", "kind": "derived",
      "dtype": "f32", "decimals": 0,
      "expr": "(hex2dec(CAN_RPM_H) * 256 + hex2dec(CAN_RPM_L)) * 0.25" },

    { "id": "P_TQ",  "label": "토크",     "unit": "Nm",  "kind": "source",
      "dtype": "f32", "binding": { "column": "TQ_RAW", "scale": 0.1 } },

    { "id": "P_PWR", "label": "출력",     "unit": "kW",  "kind": "derived",
      "dtype": "f32", "decimals": 1,
      "expr": "P_RPM * P_TQ / 9550" },

    { "id": "P_ERR", "label": "고장 플래그", "kind": "derived",
      "dtype": "bool",
      "expr": "getbit(bin2dec(STATUS), 1) == 1" }
  ]
}
```

**컴파일된 뷰**

```sql
CREATE OR REPLACE VIEW params AS
SELECT
  row_number() OVER () - 1                            AS idx,
  "TIME_MS" * 0.001                                   AS P_T,
  (hex2dec("CAN_RPM_H") * 256 + hex2dec("CAN_RPM_L")) * 0.25  AS P_RPM,
  "TQ_RAW" * 0.1                                      AS P_TQ,
  ((hex2dec("CAN_RPM_H") * 256 + hex2dec("CAN_RPM_L")) * 0.25)
    * ("TQ_RAW" * 0.1) / 9550                         AS P_PWR,
  ((bin2dec("STATUS") >> 1) & 1) = 1                  AS P_ERR
FROM raw;
```

> `P_PWR`가 `P_RPM`의 정의를 인라인으로 전개한 점에 주목. 컴파일러가 의존 그래프를
> 위상 정렬해 치환한다. 뷰 중첩(`CREATE VIEW lvl2 AS SELECT ... FROM lvl1`)으로 해도
> DuckDB 옵티마이저가 어차피 평탄화하므로 어느 쪽이든 성능은 같다.

---

## 4. 계층 ③ VIEW — 플롯 템플릿

### 4.1 스키마 전문

```ts
type PlotTemplate = {
  version: 1;
  id: string;
  name: string;                    // '엔진 성능 표준 뷰'

  layout: {
    rows: number;
    cols: number;
    gap: number;
    heights?: number[];            // 행별 비율 [2,1,1]
    syncCursor: boolean;           // 패널 간 커서 동기화
    syncXZoom: boolean;            // 패널 간 X축 줌/팬 동기화
  };

  // ── X축: 전 패널 공통 (요구사항: index 또는 time) ──────────────
  x: {
    mode: 'index' | 'time' | 'param';
    paramId?: string;              // mode='time'|'param' 일 때 사용할 파라미터
    title: { mode: 'inherit' } | { mode: 'custom'; text: string };
    unit?: string;
    timeFormat?: string;           // 'HH:mm:ss.SSS' | 'mm:ss' | 'auto'
    range: Range;
    grid: boolean;
  };

  panels: Panel[];
  defaults?: { palette: string[]; lineWidth: number };
};

type Panel = {
  id: string;
  grid: { row: number; col: number; rowSpan?: number; colSpan?: number };
  title?: string;
  yAxes: YAxis[];                  // 요구사항: 좌·우 Y축 추가
  series: Series[];
  legend: { show: boolean; position: 'top' | 'right' | 'bottom' | 'inside' };
  cursorReadout: boolean;
};

// ── Y축 ────────────────────────────────────────────────────────
type YAxis = {
  id: string;                      // 'yL1' | 'yR1' — 패널 내 유일
  side: 'left' | 'right';          // 좌/우 배치
  order?: number;                  // 같은 쪽에 여러 축일 때 안쪽부터 0,1,2
  title: { mode: 'inherit' } | { mode: 'custom'; text: string };  // 요구사항: 축 제목 변경
  showUnit: boolean;               // 제목 뒤에 '[rpm]' 자동 부착
  range: Range;                    // 요구사항: Y축 범위 정의
  scaleType: 'linear' | 'log' | 'symlog';
  grid: boolean;
  tickCount?: number;
  tickFormat?: string;             // '0.00' | 'sci' | 'auto'
  color?: string;                  // 축 라벨을 시리즈 색과 맞출 때
  visible: boolean;
};

// ── 범위 정의 ───────────────────────────────────────────────────
type Range =
  | { mode: 'auto' }                                   // 데이터 min/max
  | { mode: 'auto-padded'; padPct: number }            // ±n% 여백
  | { mode: 'manual'; min: number; max: number }       // 고정
  | { mode: 'manual-partial'; min?: number; max?: number } // 한쪽만 고정
  | { mode: 'nice'; targetTicks: number }              // 눈금이 딱 떨어지게
  | { mode: 'symmetric' }                              // 0 중심 대칭
  | { mode: 'shared'; withAxisId: string }             // 다른 축과 동일 스케일
  | { mode: 'percentile'; lo: number; hi: number };    // 아웃라이어 무시 (1%~99%)

// ── 시리즈: 파라미터를 축에 할당 ──────────────────────────────────
type Series = {
  id: string;
  paramId: string;                 // 카탈로그 참조
  axisId: string;                  // ★ 요구사항: 파라미터를 특정 Y축에 귀속
  labelOverride?: string;          // 이 패널에서만 다른 표시명
  color: string;
  width: number;
  style: 'line' | 'step' | 'spline' | 'points' | 'area' | 'bar' | 'minmax-band';
  dash?: number[];
  opacity?: number;
  visible: boolean;
  yOffset?: number;                // 오버레이 시 세로 분리
  yScale?: number;                 // 표시 전용 배율 (원본 불변)
};
```

### 4.2 "상속(inherit)"의 정의

축 제목과 X축 제목의 기본 동작:

```
title.mode = 'inherit'
  → 해당 축에 붙은 visible 시리즈들의 label을 수집
  → 1개면          "엔진 회전수 [rpm]"
  → 2개 이상 동일 unit이면  "회전수/목표회전수 [rpm]"
  → unit이 섞이면   "(복합)"
  → 사용자가 한 글자라도 고치는 순간 mode = 'custom'으로 자동 전환
```

파라미터명(`label`)을 바꾸면 inherit 축의 제목이 **자동으로 따라 바뀐다.**
이게 "파라미터를 축에 상속시킨다"의 구현이다.

### 4.3 uPlot 매핑

템플릿 → uPlot 옵션은 순수 함수 하나로 변환한다.

```ts
function toUPlotOpts(panel: Panel, tpl: PlotTemplate, catalog: Catalog): uPlot.Options {
  return {
    title: panel.title,
    scales: {
      x: {
        time: tpl.x.mode === 'time',              // ★ index/time 전환은 이 플래그 하나
        range: rangeFn(tpl.x.range),
      },
      ...Object.fromEntries(panel.yAxes.map(ax => [
        ax.id, { range: rangeFn(ax.range), distr: ax.scaleType === 'log' ? 3 : 1 }
      ])),
    },
    axes: [
      { scale: 'x', label: resolveTitle(tpl.x, catalog), grid: { show: tpl.x.grid } },
      ...panel.yAxes.filter(a => a.visible).map(ax => ({
        scale: ax.id,
        side: ax.side === 'left' ? 3 : 1,          // uPlot: 0=top 1=right 2=bottom 3=left
        label: resolveTitle(ax, panel, catalog),
        grid:  { show: ax.grid },
        stroke: ax.color,
        splits: ax.tickCount ? splitsFor(ax) : undefined,
      })),
    ],
    series: [
      {},                                          // index 0 = x
      ...panel.series.filter(s => s.visible).map(s => ({
        scale:  s.axisId,                          // ★ 파라미터 → 축 귀속
        label:  s.labelOverride ?? catalog[s.paramId].label,
        stroke: s.color,
        width:  s.width,
        dash:   s.dash,
        paths:  pathBuilder(s.style),              // minmax-band는 커스텀 렌더러
      })),
    ],
    cursor: tpl.layout.syncCursor ? { sync: { key: tpl.id } } : undefined,
  };
}
```

**uPlot이 이 요구사항에 맞는 이유** — 다중 named scale, 축의 `side` 지정, 축별 독립 range,
차트 간 커서 동기화(`cursor.sync`)가 전부 **네이티브 기능**이다. 별도 구현이 필요한 것은
`minmax-band` 렌더러 하나뿐이다.

### 4.4 다중 패널 레이아웃

- CSS Grid로 `layout.rows × layout.cols` 배치. 패널마다 uPlot 인스턴스 1개.
- **X축 동기화**: `syncXZoom`이면 한 패널의 줌/팬 이벤트를 store에 반영 → 전 패널이
  같은 `[from, to]`로 재질의. 각 패널이 독립적으로 DuckDB에 질의하지 않도록
  **뷰포트 변경당 1회 배치 질의**로 묶는다 (§5).
- 사용자 리사이즈가 필요하면 `react-mosaic` 또는 `react-resizable-panels` 도입.
  MVP는 고정 그리드로 충분.

### 4.5 템플릿 저장·공유

```
템플릿(JSON) + 카탈로그(JSON) → 하나의 .pdps-view 파일 (zip 또는 단일 JSON)
  • OPFS / localStorage에 자동 저장 (작업 중 유실 방지)
  • 파일로 내보내기·가져오기 → 팀원 간 공유
  • Zod 스키마로 로드 시 검증 + 버전 마이그레이션 훅
  • 바인딩 불일치 시: "CSV에 'TQ_RAW' 컬럼이 없습니다 → 어느 컬럼에 연결할까요?" 매핑 UI
```

마지막 항목이 §1에서 말한 **템플릿 재사용성의 실질**이다.

---

## 5. 데이터 계층 → 렌더 계층 단일 계약

### 5.1 RenderBlock

파일 모드든 스트리밍 모드든, 렌더러가 받는 것은 **항상 이 구조 하나**다.

```ts
type RenderBlock = {
  seriesId: string;
  level: number;            // 0=원본, 1이상=데시메이션
  x:   Float64Array;        // 길이 N
  min: Float32Array;        // 길이 N — level 0이면 min === max
  max: Float32Array;
  count: number;            // 버킷당 원본 샘플 수 (툴팁 표시용)
  gaps?: Uint32Array;       // 결손 구간 인덱스
};
```

이 계약 덕분에 **렌더러 코드를 두 번 쓰지 않는다.**

| 모드 | RenderBlock 생성 주체 |
|---|---|
| CSV 파일 | DuckDB SQL `GROUP BY` + `min/max` (§5.2) |
| WebSocket | Worker 내 min/max 피라미드 (v0.1 문서 §5) |
| 서버 이력 조회 | Node 게이트웨이의 동일 SQL |

### 5.2 데시메이션 질의

뷰포트가 바뀔 때마다 실행되는 **단 하나의 질의 패턴**:

```sql
WITH win AS (
  SELECT idx, P_RPM, P_TQ, P_PWR          -- 필요한 파라미터만
  FROM params
  WHERE idx BETWEEN $from AND $to
),
b AS (
  SELECT ((idx - $from) * $buckets) / ($to - $from + 1) AS bucket, *
  FROM win
)
SELECT
  bucket,
  min(idx) AS x,
  min(P_RPM) AS P_RPM_lo, max(P_RPM) AS P_RPM_hi,
  min(P_TQ)  AS P_TQ_lo,  max(P_TQ)  AS P_TQ_hi,
  min(P_PWR) AS P_PWR_lo, max(P_PWR) AS P_PWR_hi,
  count(*)   AS n
FROM b
GROUP BY bucket
ORDER BY bucket;
```

- `$buckets = 패널 픽셀 폭` (예: 1600). 결과 행 수가 **줌 레벨과 무관하게 상수**다.
- 전 패널·전 시리즈를 **한 질의에 묶는다.** 패널 6개 × 시리즈 4개를 24회 질의하면
  왕복 오버헤드가 지배한다.
- 결과는 **Arrow 형식**으로 받아 `Float32Array`로 zero-copy 변환 → 그대로 uPlot에 전달.
- `$to - $from`이 `$buckets`보다 작으면(충분히 줌인) 데시메이션을 건너뛰고 원본을 그대로 반환.

### 5.3 응답 크기

| 뷰포트 | 원본 행 수 | 버킷 | 시리즈 4개 응답 |
|---|---|---|---|
| 전체 1시간 | 3,600,000 | 1,600 | ~64 KB |
| 5분 | 300,000 | 1,600 | ~64 KB |
| 2초 | 2,000 | (원본) | ~32 KB |

**어떤 줌에서도 응답이 100KB를 넘지 않는다.** 이것이 v0.1 문서의 피라미드와 동일한 결론이다.

---

## 6. UI 구성

```
┌────────────────────────────────────────────────────────────────────┐
│  파일: run_2026-08-24.csv  (3,600,000행 × 42열)   [템플릿 ▾] [저장] │
├──────────────┬─────────────────────────────────────────────────────┤
│ 파라미터      │                                                     │
│ ┌──────────┐ │   ┌─────────────────┐  ┌─────────────────┐          │
│ │ 검색...   │ │   │ 패널 1           │  │ 패널 2           │         │
│ ├──────────┤ │   │ rpm ┤        ├ Nm │  │  ...            │         │
│ │▣ 엔진회전수│ │   │     │  ╱╲    │    │  │                 │         │
│ │▣ 토크     │ │   │     │ ╱  ╲   │    │  │                 │         │
│ │▢ 출력     │ │   └─────────────────┘  └─────────────────┘          │
│ │▢ 수온     │ │   ┌─────────────────┐  ┌─────────────────┐          │
│ │＋ 파생추가 │ │   │ 패널 3           │  │ 패널 4           │         │
│ └──────────┘ │   └─────────────────┘  └─────────────────┘          │
│              │                                                     │
│ [속성 패널]   │   X축: ◉ 시간  ○ 인덱스     범위 [0 ─────── 3600] s  │
│  label  [  ] │                                                     │
│  unit   [  ] ├─────────────────────────────────────────────────────┤
│  수식   [  ] │  커서 판독  t=124.5s  회전수=3,240  토크=185.2       │
└──────────────┴─────────────────────────────────────────────────────┘
```

**수식 편집기**

- CodeMirror 6 + 커스텀 자동완성(카탈로그 파라미터 `label`을 보여주고 `id`를 삽입).
- 입력 중 300ms 디바운스로 **선두 1,000행에만 미리 실행**해 결과·에러를 즉시 표시.
  전체 360만 행에 대고 실시간 검증하면 편집이 불가능해진다.
- 에러는 AST 위치를 그대로 에디터 마커로 표시.

---

## 7. 기술 스택

| 계층 | 선택 | 비고 |
|---|---|---|
| 런타임 | React 18 + TypeScript + Vite | |
| 데이터 | **@duckdb/duckdb-wasm** | CSV·전처리·데시메이션 전담 |
| 전송 | **apache-arrow** | DuckDB → JS zero-copy |
| 렌더 | **uPlot** | 다중 축·커서 동기화 네이티브 |
| 워커 통신 | **Comlink** | postMessage 보일러플레이트 제거 |
| 상태 | **Zustand** | 카탈로그·템플릿·뷰포트. **샘플 데이터는 금지** |
| 검증 | **Zod** | 템플릿/카탈로그 JSON 스키마 + 마이그레이션 |
| 수식 편집 | **CodeMirror 6** | 자동완성·에러 마커 |
| XLSX | **SheetJS** | 소규모 시트 한정 (§2.3) |
| 레이아웃 | CSS Grid → 필요 시 react-resizable-panels | |

전부 MIT/Apache 계열. 상용 라이선스 없음.

---

## 8. 구현 단계

| 단계 | 범위 | 완료 기준 |
|---|---|---|
| **P0** | DuckDB-WASM + CSV 로드 + 단일 패널 uPlot + §5.2 데시메이션 질의 | 360만 행 CSV를 열어 줌/팬이 33ms 이내 |
| **P1** | 파라미터 카탈로그 UI (label/unit 편집, 바인딩 매핑) | 컬럼명이 다른 CSV에 기존 설정 재적용 성공 |
| **P2** | 표현식 엔진 (파서·검증기·컴파일러) + 사칙연산·진수변환·비트연산 | §3.5 워크드 예제가 그대로 동작 |
| **P3** | 플롯 템플릿 — 좌·우 Y축, 축 제목, 범위 모드, X축 index/time 전환 | 템플릿 JSON 저장 → 새로고침 후 완전 복원 |
| **P4** | 멀티 패널 레이아웃 + 커서·줌 동기화 + 템플릿 내보내기/가져오기 | 6패널 동시 조작 시 55fps 유지 |
| **P5** | 윈도우 함수, 통계·FFT, 내보내기 | |
| **P6** | WebSocket 스트리밍 소스 통합 (v0.1 문서) | 파일 모드와 동일 UI로 실시간 표시 |

> **P0가 이 프로젝트의 기술적 관문**이다. DuckDB-WASM이 브라우저에서 360만 행 CSV를
> 감당하는지, §5.2 질의가 33ms 안에 끝나는지를 먼저 실측해야 한다.
> 여기가 통과되면 나머지는 전부 "설정 UI 만들기"이고 기술적 불확실성이 없다.

---

## 9. 검증 필요 항목

| # | 항목 | 확인 방법 |
|---|---|---|
| 1 | 360만 행 × 42열 CSV의 DuckDB-WASM 로드 시간 | 실측. 30초 초과 시 Parquet 사전 변환 도입 |
| 2 | §5.2 데시메이션 질의 응답 시간 | 33ms 목표. 초과 시 Parquet + 사전 집계 테이블 |
| 3 | `'0x1F'::UBIGINT` 캐스팅 지원 여부 | §3.4 (A)(B)(C) 중 택일 |
| 4 | 단일 스레드 vs COI 멀티 스레드 성능 차 | 헤더 설정 비용 대비 이득 판단 |
| 5 | OPFS Parquet 캐시 용량 한계 | 브라우저별 쿼터 확인 |
| 6 | uPlot `minmax-band` 커스텀 렌더러 성능 | 1,600 버킷 × 시리즈 8개 기준 |
| 7 | 파생 파라미터 중첩 깊이 한계 | 5단계 이상 체인 시 질의 플랜 확인 |

## 10. 미결정 사항 (사용자 확인 필요)

1. **CSV 실제 규모** — 행 수, 컬럼 수, 파일 크기. 파일 하나 샘플이 있으면 P0 설계가 확정된다.
2. **파일 여러 개 동시 비교**가 필요한가? (여러 주행 세션 오버레이 → 카탈로그에 `sourceId` 축 추가 필요)
3. **진수 변환의 구체적 형태** — 16진 문자열 컬럼인가, 비트필드 추출인가, 아니면 표시 포맷만 16진인가?
4. **템플릿 공유 범위** — 개인 로컬 저장으로 충분한가, 팀 서버 저장이 필요한가?
5. **오프라인 동작** — 사내망에서 CDN 없이 동작해야 하는가? (DuckDB-WASM 번들 자체 호스팅 필요)
