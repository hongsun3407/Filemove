# 1000Hz 실시간 스트리밍 데이터 분석 웹앱 — 설계 문서

**버전** 0.1 (초안)
**작성일** 2026-08-24
**대상** 1000Hz 신호를 WebSocket으로 수신하여 최대 1시간(360만 포인트/채널) 구간을 브라우저에서 플롯·분석

---

## 1. 요구사항 및 규모 산정

### 1.1 기능 요구사항

| ID | 요구사항 |
|---|---|
| F-1 | WebSocket으로 1000Hz 샘플을 실시간 수신 |
| F-2 | 라이브 모드: 최근 N초 슬라이딩 윈도우를 60fps로 갱신 |
| F-3 | 히스토리 모드: 최대 1시간 구간 전체를 표시, 자유 줌/팬 |
| F-4 | 줌인 시 해당 구간을 원본 해상도(1000Hz)로 표시 |
| F-5 | 다채널 오버레이 / 스택 뷰, 채널별 on-off |
| F-6 | 커서 판독, 듀얼 커서 Δt·Δy |
| F-7 | 선택 구간 통계(min/max/mean/RMS/std), FFT 스펙트럼 |
| F-8 | 선택 구간 CSV/바이너리 내보내기 |
| F-9 | 연결 끊김 자동 재접속 및 결손 구간 표시 |

### 1.2 규모 산정 (채널 1개 기준)

```
샘플레이트        1,000 Hz
보존 기간         3,600 s
총 샘플 수        3,600,000
Float32 크기      14.4 MB
Float64 크기      28.8 MB   ← 쓰지 않음
```

**핵심 제약**: 화면 가로 해상도는 최대 ~2,000 px. 360만 점을 그대로 그리면
픽셀당 1,800개가 중첩되어 **시각적으로 얻는 것이 0이면서 렌더링만 1,800배 느려진다.**
따라서 이 설계의 중심은 차트 라이브러리가 아니라 **다단계 min/max 데시메이션**이다.

### 1.3 메모리 예산

| 채널 수 | 원본(L0) | 피라미드(L1~L3) | 합계 |
|---|---|---|---|
| 1 | 14.4 MB | 3.2 MB | 17.6 MB |
| 4 | 57.6 MB | 12.8 MB | 70.4 MB |
| 8 | 115.2 MB | 25.6 MB | 140.8 MB |
| 16 | 230.4 MB | 51.2 MB | 281.6 MB |

> **판단 기준**: 브라우저 탭당 실질 상한은 1~2GB이지만, 500MB를 넘기면
> 모바일·저사양 PC에서 탭이 죽는다. **8채널 / 1시간이 클라이언트 전량 보존의 실용적 한계**.
> 그 이상이 필요하면 §7의 서버 사이드 데시메이션으로 전환한다.

---

## 2. 아키텍처 개요

```
┌──────────────┐   binary frame   ┌─────────────────────────────────────────┐
│  장비/DAQ    │  (50~100ms 배치)  │            브라우저 (탭)                 │
│      ↓       │                  │                                          │
│  Node 게이트웨이 │ ══ WebSocket ══▶ │  ┌────────────────────────────────────┐ │
│  (TypeScript)│                  │  │  Web Worker (data-worker.ts)        │ │
└──────────────┘                  │  │   • WebSocket 클라이언트              │ │
                                  │  │   • 링 버퍼 (Float32Array, 고정 크기)  │ │
                                  │  │   • min/max 피라미드 증분 갱신         │ │
                                  │  │   • 뷰포트 질의 → 데시메이션 결과 반환  │ │
                                  │  │   • FFT / 통계 계산                   │ │
                                  │  └──────────────┬─────────────────────┘ │
                                  │        postMessage(transferable)         │
                                  │  ┌──────────────▼─────────────────────┐ │
                                  │  │  Main Thread (React)                │ │
                                  │  │   • uPlot 인스턴스 (ref, non-React)  │ │
                                  │  │   • UI 크롬 (채널 토글, 커서, 마커)   │ │
                                  │  └────────────────────────────────────┘ │
                                  └──────────────────────────────────────────┘
```

**설계 원칙 3가지**

1. **메인 스레드는 원본 샘플을 절대 만지지 않는다.** WebSocket 수신, 파싱, 링 버퍼,
   데시메이션 전부 Worker에서. 메인 스레드가 받는 것은 프레임당 최대 ~4,000개의
   렌더링용 Float32Array뿐.
2. **JSON을 쓰지 않는다.** 1000Hz에서 JSON 파싱은 그 자체로 병목이자 GC 폭탄.
   전 구간 바이너리(ArrayBuffer / Float32Array).
3. **React state에 샘플 데이터를 넣지 않는다.** 차트 인스턴스는 `useRef`로 관리하고
   React는 UI 크롬만 담당. 이 경계를 어기면 어떤 라이브러리를 써도 느려진다.

---

## 3. 전송 계층 (WebSocket 프로토콜)

### 3.1 배칭 정책

1000Hz를 샘플당 1메시지로 보내면 초당 1,000회 이벤트 → 메시지 오버헤드만으로 CPU가 포화된다.

| 배치 주기 | 배치당 샘플 | 초당 메시지 | 추가 지연 |
|---|---|---|---|
| 10 ms | 10 | 100 | 10 ms |
| **50 ms** | **50** | **20** | **50 ms** ← 권장 |
| 100 ms | 100 | 10 | 100 ms |

> 60fps 렌더링과 궁합이 맞는 지점은 50ms. 사람 눈에 지연이 인지되지 않으면서
> 메시지 수는 초당 20회로 떨어진다. 오실로스코프급 저지연이 필요하면 10ms로 낮춘다.

### 3.2 바이너리 프레임 포맷

```
offset  size  type      field
------  ----  --------  -----------------------------------------
 0       4    uint32    magic       0x50445053 ('PDPS')
 4       1    uint8     version     = 1
 5       1    uint8     msgType     1=DATA, 2=META, 3=GAP, 4=EVENT
 6       2    uint16    channelCount
 8       4    uint32    sampleCount   (채널당 샘플 수)
12       8    float64   t0            첫 샘플의 epoch ms
20       4    float32   dt            샘플 간격 ms (= 1.0)
24       4    uint32    seq           프레임 시퀀스 번호
28      ...   float32[] payload       channel-major:
                                        ch0[0..n-1], ch1[0..n-1], ...
```

- 헤더 28바이트 고정 → `DataView`로 파싱, payload는 `new Float32Array(buf, 28, ...)`로
  **복사 없이** 뷰만 생성.
- **채널 우선(channel-major) 배치**가 인터리브보다 낫다. 링 버퍼 채널별 복사가
  `subarray` + `set` 한 번으로 끝난다.
- **대역폭**: 1000Hz × 4B × 8ch = **32 KB/s**. 네트워크는 전혀 문제가 아니다.

### 3.3 신뢰성

| 항목 | 처리 |
|---|---|
| 재접속 | 지수 백오프 (0.5s → 1 → 2 → 4 → 최대 30s), jitter 추가 |
| 결손 감지 | `seq` 불연속 → 해당 구간을 `NaN`으로 채우고 차트에 gap으로 렌더 |
| 이력 복구 | 재접속 시 `{lastSeq}` 전송 → 서버가 최근 N초 링 버퍼에서 재전송 |
| 백프레셔 | 클라 처리 지연 시 `ws.bufferedAmount` 감시. 서버는 느린 클라이언트에게 자동 데시메이션 모드로 전환 |
| Keep-alive | 서버 → 클라 ping 15s, 3회 무응답 시 강제 종료 |

---

## 4. 저장 계층 — 링 버퍼

### 4.1 구조

```ts
class ChannelRing {
  readonly capacity: number;        // 3_600_000
  readonly data: Float32Array;      // 고정 할당, 절대 재할당 없음
  private writeIdx = 0;             // 다음 쓰기 위치
  private totalWritten = 0;         // 누적 샘플 수 (절대 인덱스 계산용)
  readonly t0: number;              // 스트림 시작 epoch ms
  readonly dt: number;              // 1.0 ms
}
```

**타임스탬프를 샘플마다 저장하지 않는다.** `time(i) = t0 + i * dt`로 계산하면
메모리가 절반이 되고 이진 탐색도 O(1)이 된다. 클럭 드리프트는 §4.3에서 별도 처리.

### 4.2 쓰기 경로 (프레임당 1회)

```ts
push(samples: Float32Array) {
  const n = samples.length;
  const tail = this.capacity - this.writeIdx;
  if (n <= tail) {
    this.data.set(samples, this.writeIdx);
  } else {                                  // 랩어라운드: 2회 복사
    this.data.set(samples.subarray(0, tail), this.writeIdx);
    this.data.set(samples.subarray(tail), 0);
  }
  this.writeIdx = (this.writeIdx + n) % this.capacity;
  this.totalWritten += n;
  this.pyramid.update(samples);             // §5
}
```

- 할당 0, GC 압력 0. 50ms마다 50개 float 복사 → 무시 가능한 비용.

### 4.3 시간축 정합성

장비 클럭과 브라우저 클럭은 반드시 드리프트한다.

- 서버가 프레임마다 `t0`를 실어 보내고, 클라이언트는 **세그먼트 리스트**를 유지한다.
- 세그먼트 = 연속된 샘플 구간 `{startIdx, startTime, sampleCount}`.
- 드리프트가 임계치(예: 5ms)를 넘거나 결손이 생기면 새 세그먼트를 연다.
- 렌더링 시 세그먼트 경계에서 `NaN`을 삽입해 선이 끊기게 한다 (uPlot은 `null`/`NaN`을 gap으로 처리).

---

## 5. 다단계 min/max 피라미드 ★핵심

### 5.1 개념

각 채널마다 원본 외에 **축약 레벨**을 함께 유지한다. 각 레벨은 구간별 (min, max) 쌍.

| 레벨 | 축약비 | 구간 길이 | 1시간 분량 항목 수 | 메모리(Float32) |
|---|---|---|---|---|
| L0 (원본) | 1 | 1 ms | 3,600,000 | 14.40 MB |
| L1 | ×10 | 10 ms | 360,000 쌍 | 2.88 MB |
| L2 | ×100 | 100 ms | 36,000 쌍 | 0.29 MB |
| L3 | ×1000 | 1 s | 3,600 쌍 | 0.03 MB |
| | | | **오버헤드 합** | **3.20 MB (22%)** |

### 5.2 왜 LTTB가 아니라 min/max인가

- **LTTB**는 "보기 좋은" 곡선을 만들지만 구간 내 극값을 버릴 수 있다.
  진동·전류·압력 신호에서 **순간 스파이크를 놓치면 분석 도구로서 실격**이다.
- **min/max**는 픽셀 열마다 세로선(min~max)을 그린다. 다운샘플링해도
  **피크가 절대 사라지지 않는다.** 오실로스코프·DAW가 모두 이 방식이다.
- 비용: 항목당 값 2개 → 메모리 2배, 정점 2배. 그래도 L2/L3에서는 무시 가능.

### 5.3 증분 갱신

```ts
// 새 샘플이 들어올 때 O(n)으로 모든 레벨을 함께 갱신
update(samples: Float32Array) {
  for (const s of samples) {
    for (const lvl of this.levels) {
      lvl.accMin = Math.min(lvl.accMin, s);
      lvl.accMax = Math.max(lvl.accMax, s);
      if (++lvl.accCount === lvl.ratio) {
        lvl.minBuf[lvl.idx] = lvl.accMin;
        lvl.maxBuf[lvl.idx] = lvl.accMax;
        lvl.idx = (lvl.idx + 1) % lvl.capacity;
        lvl.accMin = +Infinity; lvl.accMax = -Infinity; lvl.accCount = 0;
      }
    }
  }
}
```

> 상위 레벨은 하위 레벨의 결과를 다시 축약하면 더 빠르다(L2는 L1의 min/max에서 유도).
> 위 코드는 명확성 우선 버전.

### 5.4 렌더 시 레벨 선택

```ts
function pickLevel(visibleSamples: number, pixelWidth: number) {
  const target = pixelWidth * 2;            // 픽셀당 min/max 1쌍
  for (const lvl of levels) {               // L0 → L3 순
    if (visibleSamples / lvl.ratio <= target) return lvl;
  }
  return levels[levels.length - 1];
}
```

| 뷰포트 | 원본 샘플 수 | 선택 레벨 | 실제 렌더 정점 수 |
|---|---|---|---|
| 1시간 | 3,600,000 | L3 | 7,200 |
| 5분 | 300,000 | L2 | 6,000 |
| 30초 | 30,000 | L1 | 6,000 |
| 2초 | 2,000 | L0 | 2,000 |

**어떤 줌 레벨에서도 렌더링 정점 수가 ~7,000을 넘지 않는다.**
이것이 이 설계 전체의 요지다. 이 조건에서는 WebGL조차 필요 없다.

---

## 6. 렌더링 계층

### 6.1 라이브러리 선택: uPlot (권장)

| 후보 | 판정 |
|---|---|
| **uPlot** (MIT, 48KB) | **채택.** 16만점 콜드스타트 25ms, 이후 ~10만점/ms. 축·커서·범례·줌·다중 y축·차트 간 커서 동기화 내장. 커스텀 path renderer로 min/max 밴드 직접 구현 가능 |
| ECharts (Apache 2) | 대안. UI가 더 풍부하나 번들 1MB, 자체 데시메이션(LTTB)이 우리 피라미드와 중복·충돌 |
| webgl-plot (MIT) | 축·라벨·툴팁이 전무. 피라미드가 있으면 이 속도가 불필요 |
| Plotly.js scattergl | 초기화·메모리 부담. 이 규모엔 부적합 |
| SciChart.js / LightningChart | 상용. 채널 32개 이상 또는 피라미드 구현을 외주화하고 싶을 때만 |

> **결론**: §5의 피라미드가 렌더 부하를 상수로 만들기 때문에, 렌더러의 raw 성능은
> 더 이상 병목이 아니다. 그러면 남는 선택 기준은 **API 품질과 번들 크기**이고 uPlot이 이긴다.

### 6.2 min/max 밴드 렌더링

각 x 픽셀마다 `(min, max)` 세로선. uPlot 커스텀 path renderer로 구현:

```ts
const minMaxPath = (u, seriesIdx, idx0, idx1) => {
  const p = new Path2D();
  const { min, max } = u.data[seriesIdx];   // 두 개의 Float32Array
  for (let i = idx0; i <= idx1; i++) {
    const x = Math.round(u.valToPos(u.data[0][i], 'x', true));
    p.moveTo(x, u.valToPos(min[i], 'y', true));
    p.lineTo(x, u.valToPos(max[i], 'y', true));
  }
  return { stroke: p };
};
```

- L0(원본) 구간에서는 일반 선 렌더러로 전환한다. 스파이크 표현이 필요 없는 해상도이므로.

### 6.3 렌더 루프

```
WS 메시지 (20 Hz)  →  Worker: 링 버퍼 + 피라미드 갱신, dirty 플래그만 세움
                       ↓ (렌더 요청은 별개 주기)
rAF (최대 60 Hz)   →  Main: dirty면 Worker에 뷰포트 질의 → 결과로 uPlot.setData()
```

- **메시지마다 렌더하지 않는다.** 수신 주기와 렌더 주기를 분리해야 부하 급증 시에도 UI가 살아있다.
- 라이브 모드: x축을 `[now - window, now]`로 슬라이딩. `uPlot.setScale()` 사용.
- 일시정지 시 rAF 루프 중단 → CPU 0%.

### 6.4 Worker ↔ Main 데이터 전달

```ts
// Worker
const payload = { x: xs.buffer, min: mins.buffer, max: maxs.buffer, level, t0, t1 };
self.postMessage(payload, [xs.buffer, mins.buffer, maxs.buffer]);  // transferable
```

- **transferable**로 보내면 복사가 아니라 소유권 이전 → 0-copy.
- 이전된 버퍼는 Worker에서 무효화되므로, Worker 측은 렌더 버퍼 풀을 두고 재사용한다.
- SharedArrayBuffer는 COOP/COEP 헤더가 필요해 배포 난이도가 올라간다.
  **1단계에서는 transferable로 충분하며, 프로파일링 후 필요할 때만 도입한다.**

---

## 7. 백엔드 (Node.js / TypeScript)

Python 미사용 요구에 따라 게이트웨이는 Node + TypeScript로 구성한다.

### 7.1 구성 요소

```
장비 (Serial / TCP / UDP)
   ↓
수집기 (node-serialport 또는 net.Socket)
   ↓
정규화 → Float32 변환 → 50ms 배칭
   ↓
브로드캐스터 (ws 또는 uWebSockets.js)
   ↓  ├─ 실시간 구독자 (WS)
   ↓  └─ 아카이버 → Parquet / 시계열 DB
REST/WS 이력 조회 API
```

| 항목 | 선택 | 사유 |
|---|---|---|
| WS 서버 | `ws` (1단계) → `uWebSockets.js` (필요 시) | `ws`는 단순하고 충분. 동시 접속 100+에서 uWS 검토 |
| 런타임 | Node 22 LTS | |
| 아카이브 | Parquet (`parquet-wasm` / `hyparquet`) | 컬럼 포맷 + 압축. Float32 시계열에서 CSV 대비 5~10배 작음 |
| 장기 저장 | ClickHouse 또는 TimescaleDB | 1시간 초과 이력·다중 세션 비교가 필요해질 때 |

### 7.2 이력 조회 API (브라우저 메모리 초과 시)

클라이언트 보존 한계(§1.3)를 넘는 구간을 볼 때는 서버가 데시메이션해서 준다.

```
GET /api/range?ch=0,1&from=<epochMs>&to=<epochMs>&px=1920
→ 200, Content-Type: application/octet-stream
   PDPS 바이너리 프레임 (msgType=5 RANGE), 채널당 정확히 px*2개의 min/max
```

- 서버는 동일한 피라미드 로직을 Parquet 위에서 수행한다(클라와 코드 공유 가능 —
  TypeScript 단일 언어의 이점).
- 응답 크기: 1920 × 2 × 4B × 2ch ≈ **31 KB**. 구간 길이와 무관하게 상수.

---

## 8. 프론트엔드 구조 (React)

### 8.1 디렉터리

```
src/
  workers/
    data-worker.ts        # WS 클라이언트 + 링 버퍼 + 피라미드 + 질의
    ring-buffer.ts
    pyramid.ts
    protocol.ts           # 프레임 인코딩/디코딩 (서버와 공유)
    analysis/
      fft.ts
      stats.ts
  chart/
    PlotCanvas.tsx        # uPlot 래퍼 (React 밖에서 인스턴스 관리)
    minmax-renderer.ts
    useViewport.ts        # 줌/팬 상태 → Worker 질의
  ui/
    ChannelPanel.tsx
    CursorReadout.tsx
    StatsPanel.tsx
    SpectrumPanel.tsx
    ConnectionStatus.tsx
  state/
    store.ts              # Zustand — UI 상태만. 샘플 데이터는 절대 넣지 않음
```

### 8.2 React 경계 규칙

| 항목 | 위치 | 이유 |
|---|---|---|
| 원본 샘플 | Worker 전용 | 메인 스레드 진입 금지 |
| uPlot 인스턴스 | `useRef` | 리렌더로 재생성되면 안 됨 |
| 뷰포트(from/to) | store | 변경 시 Worker 질의 트리거 |
| 커서 값 | store, **10Hz로 throttle** | 60Hz로 setState하면 React가 병목 |
| 채널 on/off, 색상 | store | 저빈도, 안전 |

```tsx
function PlotCanvas({ channels }) {
  const ref = useRef<HTMLDivElement>(null);
  const plot = useRef<uPlot>();

  useEffect(() => {
    plot.current = new uPlot(makeOpts(channels), emptyData, ref.current!);
    return () => plot.current?.destroy();
  }, []);                                   // 의존성 비움: 재생성 금지

  useEffect(() => {                          // 데이터는 명령형으로 주입
    const unsub = onWorkerData(d => plot.current?.setData(d, false));
    return unsub;
  }, []);

  return <div ref={ref} />;
}
```

---

## 9. 분석 기능

| 기능 | 구현 | 실행 위치 |
|---|---|---|
| 통계 (min/max/mean/RMS/std) | 개략값은 피라미드에서 즉시, 정확값은 L0 순회 | Worker |
| FFT 스펙트럼 | radix-2, Hann 창, 2^n 패딩. 1000Hz → Nyquist 500Hz | Worker |
| 스펙트로그램 | 슬라이딩 STFT → 오프스크린 캔버스에 ImageData로 직접 기록 | Worker + OffscreenCanvas |
| 듀얼 커서 Δt/Δy | 뷰포트 좌표 변환만 | Main |
| 이벤트/트리거 검출 | 임계 교차 스캔, 결과를 마커 리스트로 | Worker |
| 필터 (LPF/HPF/BPF) | Biquad 계수 직접 구현, 표시용 사본에 적용 (원본 불변) | Worker |
| 내보내기 | 선택 구간 → CSV 또는 Float32 바이너리 → Blob 다운로드 | Worker |

> FFT는 **선택 구간이 확정된 뒤에만** 실행한다. 실시간 연속 FFT가 필요하면
> 별도 Worker로 분리하고 최대 10Hz로 갱신 제한을 건다.

---

## 10. 성능 목표 및 검증 항목

### 10.1 목표

| 지표 | 목표 |
|---|---|
| 라이브 렌더 프레임률 | ≥ 55 fps (8채널, 10초 윈도우) |
| 1시간 전체 뷰 초기 렌더 | ≤ 100 ms |
| 줌/팬 응답 | ≤ 33 ms (1프레임) |
| WS 수신 → 화면 반영 지연 | ≤ 100 ms |
| 메인 스레드 long task | 50ms 초과 0건 |
| 1시간 연속 구동 후 힙 증가 | ≤ 10% (누수 없음) |

### 10.2 검증 계획

1. **더미 신호 생성기**: sine + 노이즈 + 주기적 스파이크 조합으로 360만 점 생성.
   스파이크가 1시간 뷰(L3)에서도 **보이는지**가 min/max 데시메이션의 합격 기준.
2. **부하 테스트**: Node 게이트웨이가 8ch × 1000Hz를 60분간 무결손 전송하는지 (seq 갭 0).
3. **메모리 프로파일**: Chrome DevTools 힙 스냅샷 3회(0분/30분/60분) 비교.
4. **저사양 검증**: CPU 4x 스로틀 + 저사양 노트북에서 프레임률 재측정.
5. **네트워크 장애**: WS 강제 종료 → 재접속 → 결손 구간이 gap으로 렌더되는지.

---

## 11. 구현 단계

| 단계 | 범위 | 산출물 |
|---|---|---|
| **P0** | 더미 데이터 생성기 + 링 버퍼 + 피라미드 + uPlot 단일 채널 | 360만 점 줌/팬 데모 |
| **P1** | Worker 분리, 바이너리 프로토콜, Node WS 게이트웨이, 재접속 | 실시간 단일 채널 |
| **P2** | 다채널, 스택/오버레이 뷰, 채널 패널, 커서·마커 | 실사용 가능 버전 |
| **P3** | 통계 / FFT / 스펙트로그램 / 내보내기 | 분석 도구 완성 |
| **P4** | 이력 조회 API + Parquet 아카이브 (1시간 초과 대응) | 장기 운용 |

> **P0를 먼저 만들어 §10.1의 두 지표(1시간 뷰 초기 렌더, 줌 응답)를 측정하는 것을 권장.**
> 여기서 목표를 못 맞추면 아키텍처 문제이고, 맞추면 나머지는 기능 추가일 뿐이다.

---

## 12. 미결정 사항

| # | 항목 | 확인 필요 |
|---|---|---|
| 1 | 채널 수 | 최종 몇 채널인가? 8 초과 시 §1.3 재검토 |
| 2 | 데이터 타입 | Float32로 충분한가? (24bit ADC까지는 무손실) |
| 3 | 보존 정책 | 1시간 초과 시 오래된 데이터 폐기 vs 서버 조회 |
| 4 | 배포 환경 | 사내망 전용인가? HTTPS/WSS 인증서 필요 여부 |
| 5 | 동시 접속자 수 | 100 이상이면 `ws` → uWebSockets.js |
| 6 | 세션 비교 | 과거 세션과 현재를 겹쳐 보는 기능이 필요한가? |
| 7 | 브라우저 지원 범위 | Chrome 전용인가, Safari/Firefox 포함인가 |
