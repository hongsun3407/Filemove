# 사내 HTML 배포 포탈

로그인한 사용자만 접근할 수 있는 HTML 콘텐츠 배포 포탈입니다.
Windows Server + Node.js 22 LTS 환경을 대상으로 하며, **외부 npm 패키지를 하나도 쓰지 않습니다.**
`npm install` 없이 파일만 복사하면 바로 실행됩니다.

현재 상태: **Phase 3 완료 + 다운로드·백업** — 인증 · 사용자 관리 · 콘텐츠 업로드 · 보호 서빙 · 접근 기록
(통합 테스트 116건 통과)

---

## 빠른 시작 (Windows)

### 1. Node.js 설치

<https://nodejs.org> 에서 **22 LTS 이상**을 설치합니다. 설치 후 확인:

```
node -v
```

`v22.5.0` 이상이면 됩니다. (내장 SQLite 를 쓰기 때문에 이 버전이 필요합니다.)

### 2. 설정 파일 준비

```
cd D:\portal
copy .env.example .env
notepad .env
```

최소한 `PORT` 와 `BRAND` 를 확인하고, HTTPS 를 붙이기 전까지는 `SECURE_COOKIE=false` 로 둡니다.

### 3. 관리자 계정 생성

```
npm run create-admin
```

아이디와 이름을 입력하면 **임시 비밀번호가 화면에 한 번만 표시**됩니다. 반드시 옮겨 적어 두세요.

한 줄로 만들 수도 있습니다:

```
npm run create-admin -- --id hslim --name "임홍순" --dept "정보시스템팀"
```

### 4. 실행

`start.bat` 을 더블클릭하거나:

```
npm start
```

브라우저에서 `http://localhost:3000` 으로 접속해 임시 비밀번호로 로그인하면
비밀번호 변경 화면이 강제로 뜹니다.

### 5. 사용해 보기

1. 상단 **관리자 → 콘텐츠 → 콘텐츠 올리기** 에서 HTML 을 올립니다
2. **관리자 → 사용자 → 계정 만들기** 로 사용자를 추가합니다 (임시 비밀번호가 한 번 표시됩니다)
3. 콘텐츠 상세 화면의 **접근 권한** 에서 그 사용자를 체크합니다
4. 그 사용자로 로그인하면 대시보드에 콘텐츠가 보입니다

---

## 화면 구성

로그인하면 **왼쪽에 콘텐츠 목록이 고정**되고, 클릭하면 오른쪽 영역에서 열립니다.
목록으로 돌아가지 않고 바로 다른 콘텐츠로 넘어갈 수 있습니다.

```
┌────────────────────────────────────────────────┐
│ 사내 포탈            관리자 · 홍길동 · 로그아웃 │
├──────────────┬─────────────────────────────────┤
│ ≡ 전체 보기  │  2026 영업 실적    새 창으로 열기│
│ ▣ 영업 대시보드 ├───────────────────────────────│
│ ▣ 품질 리포트│                                 │
│ ▣ 재고 현황판│   여기에 올리신 HTML 이 그대로  │
│              │   표시됩니다                    │
└──────────────┴─────────────────────────────────┘
```

왼쪽 목록의 순서는 **관리자 → 콘텐츠** 화면에서 ↑↓ 버튼으로 정합니다.
콘텐츠마다 대표 이미지를 지정하면 목록에 작게 표시됩니다.

---

## 콘텐츠 올리는 방법

### 올릴 수 있는 형태

| 형태 | 설명 |
|---|---|
| HTML 파일 하나 | 외부 파일이 없는 경우. `index.html` 로 저장됩니다 |
| HTML + 이미지 여러 개 | 파일 선택 창에서 **Ctrl 을 누른 채 여러 개 선택**. HTML 에서 `./사진.png` 로 참조합니다 |
| ZIP | 폴더 구조가 있을 때. 루트에 `index.html` 이 있어야 합니다 |

올린 뒤에도 콘텐츠 상세 화면의 **파일 관리**에서 전체를 다시 올리지 않고
이미지 한 장만 추가하거나 지울 수 있습니다.

### 설명란 서식

콘텐츠 설명에는 간단한 서식과 이미지를 넣을 수 있습니다.

```
**굵게** 와 *기울임*

![차트 설명](chart.png)

- 목록 항목
- 또 다른 항목
```

이미지는 **그 콘텐츠에 함께 올린 파일만** 참조할 수 있습니다.
외부 주소(`https://…`)나 상위 경로(`../`)는 거부됩니다.
원본 HTML 태그는 허용되지 않고 글자 그대로 표시됩니다.

### 지켜야 할 규칙

1. **ZIP 은 루트에 `index.html`** — 폴더로 한 번 더 감싸면 안 됩니다.
   `myapp/index.html` (X) → `index.html` (O)

2. **경로는 상대경로로.** 콘텐츠는 `/app/<주소>/` 아래에 붙으므로 절대경로는 깨집니다.

   ```html
   <script src="/js/app.js"></script>    <!-- X 깨짐 -->
   <script src="./js/app.js"></script>   <!-- O -->
   ```

3. **외부 CDN 은 폐쇄망에서 안 잡힙니다.** 라이브러리는 ZIP 에 함께 넣으세요.
   (CSP 도 외부 출처를 차단합니다.)

4. **실행 파일은 거부됩니다.** `.exe`, `.bat`, `.ps1`, `.php` 등이 하나라도 있으면
   업로드 전체가 거부됩니다. 어떤 파일이 문제인지 화면에 표시됩니다.

5. **교체는 안전합니다.** 새 파일을 올리다 검증에 실패하면 기존 버전이 그대로 유지됩니다.

### 로그인한 사용자 정보 쓰기

포탈이 HTML 문서마다 `window.__PORTAL_USER__` 를 주입합니다.
워터마크를 그리거나 화면을 개인화할 때 쓸 수 있습니다.

```html
<script>
  const me = window.__PORTAL_USER__;
  // { loginId, name, dept, role, app: {slug, title}, servedAt }
  document.getElementById('who').textContent = `${me.name} (${me.dept})`;
</script>
```

### 공개 범위

| 설정 | 의미 |
|---|---|
| 지정한 사용자만 | 콘텐츠 상세 화면에서 체크한 사용자만 열람 (기본값) |
| 로그인한 모든 사용자 | 계정이 있는 사람은 누구나 열람 |
| 숨김 | 관리자를 포함해 아무도 열 수 없음 (주소를 알아도 404) |

관리자는 권한 지정과 무관하게 모든 콘텐츠를 볼 수 있습니다.

---

## 압축 다운로드

권한이 있는 사용자는 콘텐츠를 ZIP 으로 내려받을 수 있습니다.
홈 카드의 "압축 다운로드" 또는 뷰어 화면 오른쪽 위 버튼입니다.

### 콘텐츠별로 끄고 켜기

콘텐츠 상세 화면의 **"사용자가 ZIP 으로 내려받을 수 있게 허용"** 체크박스로 정합니다.
기본값은 켜짐입니다.

- **끄면** 그 콘텐츠는 화면에서 보기만 가능하고 버튼도 사라집니다
- **관리자는** 이 설정과 무관하게 언제나 받을 수 있습니다 (백업·이전 목적)
- 받은 기록은 접근 기록에 **"내려받음"** 으로 남고, 거부된 시도도 남습니다

> 다운로드를 허용하면 그 콘텐츠는 포탈 밖으로 나갑니다.
> 나간 뒤에는 통제할 수 없으므로, 민감한 콘텐츠는 스위치를 꺼 두는 편이 안전합니다.
> 대신 "누가 언제 받았는지"는 기록으로 남습니다.

---

## 백업

**관리자 → 백업** 화면에서 ZIP 하나로 전체를 내려받습니다.
서버를 멈추지 않아도 되고, 데이터베이스는 `VACUUM INTO` 로 일관된 스냅샷을 뜹니다.

백업 ZIP 에 들어가는 것:

```
data/portal.db      계정 · 권한 · 접근 기록
storage/apps/…      업로드된 HTML 콘텐츠
콘텐츠목록.csv       어떤 번호가 어떤 콘텐츠인지
복구안내.txt         되돌리는 순서
```

포탈 **소스 코드와 `.env` 는 들어가지 않습니다.** 그건 별도로 챙기세요.

### 복구

1. 포탈을 멈춥니다
2. ZIP 을 `D:\portal` 에 풀어 `data\` 와 `storage\` 를 덮어씁니다
   (기존 `portal.db-wal`, `portal.db-shm` 이 있으면 지웁니다)
3. 포탈을 다시 시작합니다

> 서버를 켜 둔 채 `data\` 폴더를 그냥 복사하면 WAL 때문에 깨진 사본이 나올 수 있습니다.
> 백업 화면을 쓰거나, 서비스를 멈춘 뒤 복사하세요.

`portal.db` 에는 비밀번호 해시와 접근 기록이 들어 있으니
**백업 파일도 원본 서버와 같은 수준으로 보호**해야 합니다.

---

## 폴더 구조

```
D:\portal\
├─ src\                  포탈 소스
│  ├─ server.js          HTTP 서버 · 요청 처리 순서가 여기 다 있습니다
│  ├─ config.js          설정 (.env 읽기)
│  ├─ db.js              SQLite 접근
│  ├─ migrations.js      스키마 정의
│  ├─ session.js         세션 생성/검증/파기
│  ├─ router.js          라우팅
│  ├─ lib\               password, csrf, html, http, audit, ratelimit,
│  │                     multipart, zip, appstore, richtext, format
│  ├─ middleware\        security, static, auth
│  ├─ routes\            auth, home, content ★, download,
│  │                     admin-users, admin-apps, admin-logs
│  └─ views\             index(사용자), admin(관리자)
├─ public\css\           포탈 자체 스타일 (인증 불필요)
├─ storage\apps\         ★ 업로드된 사용자 HTML — 웹으로 직접 노출되지 않음
├─ data\portal.db        SQLite 데이터베이스
├─ logs\
├─ scripts\              create-admin, reset-password
├─ test\                 run(진입) · harness · migration/auth/content/ui/download.spec
├─ .env                  설정 (git 제외)
└─ start.bat
```

---

## 명령어

| 명령 | 설명 |
|---|---|
| `npm start` | 포탈 실행 |
| `npm test` | 통합 테스트 116건 (마이그레이션·인증·권한·업로드·경로탈출·화면·다운로드) |
| `npm run create-admin` | 관리자 계정 생성 |
| `npm run reset-password -- --id <아이디>` | 비밀번호 초기화 + 해당 사용자 세션 강제 종료 |
| `node test/render-preview.js` | 화면 미리보기 HTML 생성 (개발용) |

---

## 보안 설계 요약

### 이 포탈이 막는 것

- 로그인하지 않은 URL 직접 접근 (하위 리소스 포함)
- 검색엔진 색인 (`X-Robots-Tag: noindex`)
- 비활성화된 계정의 기존 세션 — 다음 요청에서 즉시 끊깁니다
- 무차별 대입 — 5회 실패 시 계정 잠금 + IP 기준 속도 제한
- CSRF, 세션 고정, 오픈 리다이렉트, 경로 탈출, XSS

### 이 포탈이 막지 못하는 것

**로그인한 정당한 사용자가 브라우저에서 소스를 보거나 저장하는 것.**
HTML 이 화면에 그려지는 순간 그 내용은 사용자의 브라우저 안에 있습니다.
따라서 실질적 방어선은 "복제 불가"가 아니라 **접근 통제와 추적 가능성**입니다.

### 핵심 원칙 (반드시 지킬 것)

> **업로드된 HTML 은 절대 정적 디렉터리로 서빙하지 않습니다.**

`/static/*` 은 포탈 자체의 CSS 만 다루며, `public\` 폴더 밖으로 나갈 수 없습니다.
사용자 콘텐츠는 `/app/:slug/*` 라우트(`src\routes\content.js`)를 통해서만 나가며,
그 라우트는 세션 검사 → 권한 검사 → 경로 검증 → 로그 기록을 모두 거칩니다.

편의를 위해 `storage\` 를 정적 경로로 노출하는 코드를 추가하는 순간
포탈 전체가 무의미해집니다.

### 적용된 방어 항목

| 항목 | 구현 |
|---|---|
| 비밀번호 | scrypt (N=32768, r=8) · 평문 저장 없음 · 타이밍 안전 비교 |
| 세션 | 256비트 난수 ID · 서버(SQLite) 저장 · 절대 8시간 / 유휴 30분 |
| 세션 쿠키 | HttpOnly · SameSite=Lax · HTTPS 시 Secure |
| 세션 고정 | 로그인 시 ID 재발급 |
| 사용자 열거 | 없는 계정도 동일한 연산 비용 · 동일한 오류 메시지 |
| CSRF | 이중 제출 쿠키 · 로그인/로그아웃 시 토큰 회전 |
| XSS | 템플릿의 모든 삽입값 자동 이스케이프 (`lib/html.js`) |
| 경로 탈출 | `path.resolve` 후 기준 경로 접두 검사 · 확장자 화이트리스트 |
| 오픈 리다이렉트 | `next` 파라미터 정규화 (`safeNext`) |
| 응답 헤더 | CSP · nosniff · X-Frame-Options · Referrer-Policy · no-store |
| 감사 | 로그인·계정변경·업로드·삭제를 `audit_logs`, 콘텐츠 열람을 `access_logs` 에 기록 |
| 업로드 | 확장자 화이트리스트 · zip slip 차단 · zip bomb 상한 · CRC 검증 · 원자적 교체 |
| 업로드 권한 | 관리자만, `/admin/` 경로에서만 multipart 본문을 받음 |
| 콘텐츠 서빙 | 세션 → 권한 → 경로검증 → 기록 → 전송 순서를 반드시 통과 |
| 다운로드 | 열람과 동일한 권한 검사 + 콘텐츠별 허용 스위치 + 기록 |
| 백업 | 관리자 전용 · `VACUUM INTO` 로 일관된 DB 스냅샷 · 감사 기록 |

---

## 문제 해결

**`start.bat` 이 이상한 오류를 내거나 창이 바로 닫힌다**

배치 파일이 CRLF 줄바꿈이 아니면 Windows 가 파싱에 실패합니다.
`start.bat` 을 메모장으로 열어 `다른 이름으로 저장` → 인코딩 `ANSI`,
줄 바꿈 `Windows(CRLF)` 로 저장하면 해결됩니다.

**`'node'은(는) 내부 또는 외부 명령... 이 아닙니다`**

Node.js 가 설치되지 않았거나 PATH 에 없습니다. 설치 후 **명령 프롬프트를 새로 열어야** 인식됩니다.

**`ERR_UNKNOWN_BUILTIN_MODULE: node:sqlite`**

Node 버전이 낮습니다. `node -v` 로 확인해 22.5.0 이상으로 올리세요.

**`node:events:487` 또는 `node:events:497` 로 시작하는 긴 스택이 뜬다**

거의 항상 **포트가 이미 사용 중**(`EADDRINUSE`)이라는 뜻입니다.
포탈이 이미 다른 창에서 돌고 있는데 하나 더 띄우면 이 스택이 나옵니다.
스택 아래쪽에 `Error: listen EADDRINUSE` 가 보이면 확실합니다.

먼저 **다른 명령 프롬프트 창에 포탈이 떠 있지 않은지** 확인하세요.
그래도 안 되면 점유 중인 프로세스를 찾아 종료합니다.

```
netstat -ano | findstr :3000
taskkill /PID <맨 오른쪽에 나오는 번호> /F
```

포트를 바꾸고 싶으면 `.env` 의 `PORT` 를 수정하고 다시 실행하세요.

(이제는 이 상황에서 스택 대신 한국어 안내가 나옵니다. 예전 버전에서만 스택이 보였습니다.)

**로그인 화면에서 비밀번호가 맞는데 계속 로그인 화면으로 돌아온다**

`.env` 의 `SECURE_COOKIE=true` 인데 HTTP 로 접속한 경우입니다.
HTTPS 구성 전에는 `false` 로 두세요.

**화면의 한글이 깨진다**

`.env` 를 저장할 때 인코딩을 `UTF-8` 로 지정하세요. (`BRAND` 값에 한글이 들어갑니다.)

---

## Windows 서비스로 등록 (상시 운영)

`start.bat` 은 창을 닫으면 멈춥니다. 서버 재부팅 후에도 자동으로 뜨게 하려면
[NSSM](https://nssm.cc) 을 사용하는 것이 가장 간단합니다.

```
nssm install SanaePortal "C:\Program Files\nodejs\node.exe" "--disable-warning=ExperimentalWarning D:\portal\src\server.js"
nssm set SanaePortal AppDirectory D:\portal
nssm set SanaePortal AppStdout D:\portal\logs\service.log
nssm set SanaePortal AppStderr D:\portal\logs\service-error.log
nssm set SanaePortal Start SERVICE_AUTO_START
nssm start SanaePortal
```

중지 / 삭제:

```
nssm stop SanaePortal
nssm remove SanaePortal confirm
```

---

## HTTPS 붙이기

포탈 자체는 HTTP 로 `127.0.0.1` 에서만 대기하게 두고, 앞단에 IIS 또는 Nginx 를 세워
TLS 를 종료하고 리버스 프록시하는 구성을 권장합니다.

1. `.env` 에서 `HOST=127.0.0.1`, `SECURE_COOKIE=true`, `TRUST_PROXY=true`
2. IIS 에서 URL Rewrite + ARR 로 `http://127.0.0.1:3000` 으로 전달
3. 프록시가 `X-Forwarded-For` 를 전달하도록 설정

`SECURE_COOKIE=true` 인데 HTTP 로 접속하면 쿠키가 저장되지 않아 **로그인이 되지 않습니다.**
HTTPS 구성이 끝난 뒤에 바꾸세요.

---

---

## 완료된 것 / 남은 것

**완료**

- Phase 1 — 로그인·세션·비밀번호·접근 제어
- Phase 2 — 사용자 관리 (생성·수정·비활성화·잠금해제·비밀번호 초기화·세션 강제 종료)
- Phase 3 — HTML/ZIP 업로드, `/app/:slug/*` 보호 서빙, 앱별 접근 권한, 접근 기록 + CSV

**남은 것**

- **Phase 5** — HTTPS 리버스 프록시 구성, Windows 서비스 등록 (백업은 완료)
- **Phase 6** — 실제 콘텐츠로 인수 검증

**나중에 붙일 수 있는 것**

- 사용자 워터마크 (이름·사번을 콘텐츠 위에 반투명 오버레이)
- 동시 접속 제한 (계정 공유 방지)
- IP 대역 제한
- 부서/그룹 단위 권한
- 콘텐츠 버전 관리 및 롤백
- 사내 SSO(AD/LDAP) 연동

자세한 계획은 `PLAN.md` 를 참고하세요.
