'use strict';
/**
 * 인증 라우트 — 로그인 / 로그아웃 / 비밀번호 변경.
 */
const db = require('../db');
const config = require('../config');
const views = require('../views');
const csrf = require('../lib/csrf');
const audit = require('../lib/audit');
const session = require('../session');
const password = require('../lib/password');
const { createLimiter } = require('../lib/ratelimit');
const { sendHtml, redirect, safeNext, clientIp } = require('../lib/http');

const loginLimiter = createLimiter({
  max: config.LOGIN_RATE_MAX,
  windowMs: config.LOGIN_RATE_WINDOW_MS,
  name: 'login',
});

/**
 * 존재하지 않는 아이디로 로그인을 시도해도 같은 시간이 걸리도록
 * 검증에 쓸 더미 해시를 미리 만들어 둡니다. (사용자 열거 방지)
 */
let dummyHash = null;
async function getDummyHash() {
  if (!dummyHash) dummyHash = await password.hash('this-account-does-not-exist');
  return dummyHash;
}

/* ------------------------------ GET /login ------------------------------ */

function getLogin(req, res) {
  if (req.user) return redirect(res, '/');
  sendHtml(res, views.login({
    req,
    next: safeNext(req.query.get('next')),
    notice: req.query.get('m') || '',
  }));
}

/* ------------------------------ POST /login ------------------------------ */

async function postLogin(req, res) {
  const next = safeNext(req.body.next);
  const loginId = String(req.body.login_id || '').trim();
  const pw = String(req.body.password || '');

  const fail = (message, extra = {}) => sendHtml(res, views.login({
    req, error: message, loginId, next, ...extra,
  }), 401);

  // 1) IP 기준 속도 제한
  const rl = loginLimiter.check(clientIp(req));
  if (!rl.allowed) {
    audit.record({ req, actor: loginId, action: 'login.ratelimited' });
    return sendHtml(res, views.login({
      req, loginId, next,
      error: `로그인 시도가 너무 많습니다. ${Math.ceil(rl.retryAfterMs / 60000)}분 후 다시 시도해 주세요.`,
    }), 429, { 'Retry-After': String(Math.ceil(rl.retryAfterMs / 1000)) });
  }

  if (!loginId || !pw) return fail('아이디와 비밀번호를 입력해 주세요.');

  const user = db.get(
    `SELECT id, login_id, name, password_hash, role, status,
            must_change_pw, failed_count, locked_until
       FROM users WHERE login_id = ?`,
    loginId
  );

  const now = Date.now();

  // 2) 잠금 확인 — 잠긴 계정은 비밀번호가 맞아도 통과시키지 않습니다.
  if (user && user.locked_until && user.locked_until > now) {
    const mins = Math.ceil((user.locked_until - now) / 60000);
    audit.record({ req, actorId: user.id, actor: loginId, action: 'login.locked' });
    return fail(`계정이 잠겨 있습니다. ${mins}분 후 다시 시도하거나 관리자에게 문의하세요.`);
  }

  // 3) 비밀번호 검증 (계정이 없어도 동일한 연산 비용을 소모)
  const stored = user ? user.password_hash : await getDummyHash();
  const ok = await password.verify(pw, stored);

  // 4) 실패 처리
  if (!user || !ok || user.status !== 'active') {
    if (user) {
      const failed = user.failed_count + 1;
      const lock = failed >= config.MAX_FAILED ? now + config.LOCK_MS : null;
      db.run(
        'UPDATE users SET failed_count = ?, locked_until = ?, updated_at = ? WHERE id = ?',
        lock ? 0 : failed, lock, now, user.id
      );
      audit.record({
        req, actorId: user.id, actor: loginId,
        action: user.status !== 'active' ? 'login.disabled' : 'login.fail',
        detail: `failed_count=${failed}`,
      });
      if (lock) {
        return fail(`비밀번호를 ${config.MAX_FAILED}회 틀려 계정이 ${Math.round(config.LOCK_MS / 60000)}분간 잠겼습니다.`);
      }
    } else {
      audit.record({ req, actor: loginId, action: 'login.unknown-user' });
    }
    // 아이디가 없는 경우와 비밀번호가 틀린 경우의 메시지를 구분하지 않습니다.
    return fail('아이디 또는 비밀번호가 올바르지 않습니다.');
  }

  // 5) 성공
  db.run(
    'UPDATE users SET failed_count = 0, locked_until = NULL, last_login_at = ?, updated_at = ? WHERE id = ?',
    now, now, user.id
  );

  // 해시 파라미터가 낡았으면 이 기회에 재해싱
  if (password.needsRehash(user.password_hash)) {
    try {
      const fresh = await password.hash(pw);
      db.run('UPDATE users SET password_hash = ? WHERE id = ?', fresh, user.id);
    } catch { /* 재해싱 실패는 로그인을 막지 않습니다 */ }
  }

  session.create(req, res, user.id);   // 세션 ID 재발급 = 세션 고정 방어
  csrf.rotate(req, res);
  loginLimiter.reset(clientIp(req));
  audit.record({ req, actorId: user.id, actor: loginId, action: 'login.success' });

  redirect(res, user.must_change_pw ? '/change-password' : next);
}

/* ------------------------------ POST /logout ------------------------------ */

function postLogout(req, res) {
  if (req.user) {
    audit.record({ req, actorId: req.user.id, actor: req.user.login_id, action: 'logout' });
  }
  session.destroy(req, res);
  csrf.rotate(req, res);
  redirect(res, '/login?m=logged-out');
}

/* ------------------------------ 비밀번호 변경 ------------------------------ */

function getChangePassword(req, res) {
  sendHtml(res, views.changePassword({ req, forced: !!req.user.must_change_pw }));
}

async function postChangePassword(req, res) {
  const forced = !!req.user.must_change_pw;
  const current = String(req.body.current || '');
  const nextPw = String(req.body.next_pw || '');
  const confirm = String(req.body.confirm || '');

  const fail = (message) => sendHtml(res, views.changePassword({ req, forced, error: message }), 400);

  const row = db.get('SELECT password_hash FROM users WHERE id = ?', req.user.id);
  if (!row) return fail('사용자를 찾을 수 없습니다.');

  if (!await password.verify(current, row.password_hash)) {
    audit.record({ req, actorId: req.user.id, actor: req.user.login_id, action: 'password.change-fail' });
    return fail('현재 비밀번호가 올바르지 않습니다.');
  }
  if (nextPw !== confirm) return fail('새 비밀번호와 확인 값이 일치하지 않습니다.');
  if (nextPw === current) return fail('현재 비밀번호와 다른 비밀번호를 사용해 주세요.');

  const policyError = password.validate(nextPw, req.user.login_id);
  if (policyError) return fail(policyError);

  const hash = await password.hash(nextPw);
  db.run(
    'UPDATE users SET password_hash = ?, must_change_pw = 0, updated_at = ? WHERE id = ?',
    hash, Date.now(), req.user.id
  );

  // 비밀번호를 바꾸면 다른 기기의 세션은 모두 끊고, 현재 세션만 새로 발급합니다.
  session.destroyAllForUser(req.user.id);
  session.create(req, res, req.user.id);
  csrf.rotate(req, res);

  audit.record({ req, actorId: req.user.id, actor: req.user.login_id, action: 'password.change' });
  redirect(res, '/?m=password-changed');
}

module.exports = {
  getLogin, postLogin, postLogout,
  getChangePassword, postChangePassword,
  loginLimiter,
};
