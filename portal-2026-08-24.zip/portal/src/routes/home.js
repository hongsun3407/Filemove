'use strict';
const db = require('../db');
const views = require('../views');
const session = require('../session');
const { canAccess } = require('./content');
const { sendHtml, redirect } = require('../lib/http');

/** 이 사용자가 열 수 있는 앱 목록 (관리자가 정한 순서대로) */
function listAccessibleApps(user) {
  const columns =
    'id, slug, title, description, thumbnail, visibility, is_active, allow_download';
  const order = 'ORDER BY sort_order, title COLLATE NOCASE';

  if (user.role === 'admin') {
    return db.all(`SELECT ${columns} FROM apps WHERE is_active = 1 ${order}`);
  }
  return db.all(
    `SELECT ${columns} FROM apps
      WHERE is_active = 1
        AND ( visibility = 'all'
              OR id IN (SELECT app_id FROM app_permissions WHERE user_id = ?) )
      ${order}`,
    user.id
  );
}

function getDashboard(req, res) {
  sendHtml(res, views.dashboard({
    req,
    apps: listAccessibleApps(req.user),
    notice: req.query.get('m') || '',
    flash: session.takeFlash(req),
  }));
}

/** /view/:slug — 왼쪽 목록을 유지한 채 오른쪽에서 콘텐츠를 엽니다. */
function getViewer(req, res) {
  const apps = listAccessibleApps(req.user);
  const app = apps.find((a) => a.slug === req.params.slug);

  if (!app) {
    // 목록에 없다면 존재하지 않거나 권한이 없는 것 —
    // 어느 쪽인지 알려 주지 않도록 콘텐츠 라우트와 같은 처리를 따릅니다.
    const exists = db.get('SELECT id, slug, is_active, visibility FROM apps WHERE slug = ?',
      req.params.slug);
    if (exists && canAccess(req.user, exists)) return redirect(res, `/app/${exists.slug}/`);
    return sendHtml(res, views.error({
      req, status: 404, title: '콘텐츠를 찾을 수 없습니다',
      message: '주소가 바뀌었거나 접근 권한이 없을 수 있습니다.',
    }), 404);
  }

  sendHtml(res, views.viewer({ req, apps, app }));
}

module.exports = { getDashboard, getViewer, listAccessibleApps };
