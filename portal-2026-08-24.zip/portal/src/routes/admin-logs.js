'use strict';
/**
 * 접근 기록 조회 및 CSV 내보내기.
 * "누가 언제 어떤 콘텐츠를 열었는가" 는 이 포탈의 실질적 방어선 중 하나입니다.
 */
const db = require('../db');
const views = require('../views/admin');
const { sendHtml, NO_STORE } = require('../lib/http');
const { fmtDateTimeSec } = require('../lib/format');

const PAGE_SIZE = 100;
const MAX_EXPORT = 50000;

function readFilters(req) {
  const q = req.query;
  const num = (v) => (/^\d+$/.test(String(v || '')) ? Number(v) : '');
  const result = String(q.get('result') || '');
  return {
    user: num(q.get('user')),
    app: num(q.get('app')),
    result: ['ok', 'download', 'denied', 'notfound'].includes(result) ? result : '',
  };
}

function buildQuery(filters) {
  const where = [];
  const params = [];
  if (filters.user) { where.push('user_id = ?'); params.push(filters.user); }
  if (filters.app) { where.push('app_id = ?'); params.push(filters.app); }
  if (filters.result) { where.push('result = ?'); params.push(filters.result); }
  return {
    clause: where.length ? `WHERE ${where.join(' AND ')}` : '',
    params,
  };
}

function getLogs(req, res) {
  const filters = readFilters(req);
  const pageRaw = Number(req.query.get('page') || 1);
  const page = Number.isFinite(pageRaw) && pageRaw > 0 ? Math.floor(pageRaw) : 1;

  const { clause, params } = buildQuery(filters);

  // 다음 쪽이 있는지 확인하려고 한 건 더 조회합니다.
  const rows = db.all(
    `SELECT id, login_id, app_slug, path, result, ip, at
       FROM access_logs ${clause}
      ORDER BY at DESC LIMIT ? OFFSET ?`,
    ...params, PAGE_SIZE + 1, (page - 1) * PAGE_SIZE
  );

  const hasMore = rows.length > PAGE_SIZE;
  const logs = hasMore ? rows.slice(0, PAGE_SIZE) : rows;

  const apps = db.all('SELECT id, title FROM apps ORDER BY title COLLATE NOCASE');
  const users = db.all(
    'SELECT id, login_id, name FROM users ORDER BY name COLLATE NOCASE');

  sendHtml(res, views.logsList({ req, logs, filters, page, hasMore, apps, users }));
}

/* ------------------------------ CSV ------------------------------ */

function csvCell(value) {
  const s = String(value === null || value === undefined ? '' : value);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function getLogsCsv(req, res) {
  const filters = readFilters(req);
  const { clause, params } = buildQuery(filters);

  const rows = db.all(
    `SELECT login_id, app_slug, path, result, ip, user_agent, at
       FROM access_logs ${clause} ORDER BY at DESC LIMIT ?`,
    ...params, MAX_EXPORT
  );

  const lines = ['시각,아이디,콘텐츠,경로,결과,IP,브라우저'];
  for (const r of rows) {
    lines.push([
      fmtDateTimeSec(r.at), r.login_id, r.app_slug, r.path, r.result, r.ip, r.user_agent,
    ].map(csvCell).join(','));
  }

  // Excel 이 UTF-8 로 인식하도록 BOM 을 붙입니다.
  const body = Buffer.concat([
    Buffer.from([0xef, 0xbb, 0xbf]),
    Buffer.from(lines.join('\r\n'), 'utf8'),
  ]);

  const stamp = new Date().toISOString().slice(0, 10);
  res.writeHead(200, {
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Length': body.length,
    'Content-Disposition': `attachment; filename="access-logs-${stamp}.csv"`,
    'Cache-Control': NO_STORE,
  });
  res.end(body);
}

module.exports = { getLogs, getLogsCsv };
