'use strict';
/**
 * ★ 이 포탈의 핵심 라우트 ★
 *
 * 업로드된 HTML 콘텐츠는 오직 여기를 통해서만 브라우저로 나갑니다.
 * storage/ 폴더는 어떤 정적 미들웨어에도 연결되어 있지 않습니다.
 *
 * 처리 순서 (하나라도 건너뛰면 포탈의 존재 의미가 사라집니다):
 *   1. 로그인 확인      — requireAuth 미들웨어가 앞단에서 처리
 *   2. 앱 조회 / 활성 여부
 *   3. 접근 권한 확인
 *   4. 경로 검증        — 폴더 밖으로 나가는 모든 시도 차단
 *   5. 열람 기록
 *   6. 파일 전송
 *
 * HTML 안의 상대 경로 리소스(./js/app.js 등)도 전부 이 라우트를 타므로
 * 하위 리소스까지 자동으로 같은 검사를 받습니다.
 */
const fs = require('node:fs');
const path = require('node:path');

const db = require('../db');
const views = require('../views');
const audit = require('../lib/audit');
const appstore = require('../lib/appstore');
const { sendHtml, redirect, NO_STORE } = require('../lib/http');

/* ------------------------------ 권한 ------------------------------ */

function canAccess(user, app) {
  if (!app || !app.is_active) return false;
  if (user.role === 'admin') return true;
  if (app.visibility === 'all') return true;
  const row = db.get(
    'SELECT 1 AS ok FROM app_permissions WHERE app_id = ? AND user_id = ?',
    app.id, user.id
  );
  return !!row;
}

/* ------------------------------ 사용자 정보 주입 ------------------------------ */

/**
 * HTML 문서에 window.__PORTAL_USER__ 를 주입합니다.
 * 올리신 HTML 에서 로그인 사용자 이름·부서를 쓰거나 워터마크를 그릴 때 사용합니다.
 *
 * </script> 로 문서를 탈출하지 못하도록 <, >, & 를 유니코드 이스케이프합니다.
 */
function injectPortalContext(html, user, app) {
  const payload = JSON.stringify({
    loginId: user.login_id,
    name: user.name,
    dept: user.dept,
    role: user.role,
    app: { slug: app.slug, title: app.title },
    servedAt: new Date().toISOString(),
  }).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');

  const snippet =
    `<script>window.__PORTAL_USER__=Object.freeze(${payload});</script>`;

  const headMatch = /<head[^>]*>/i.exec(html);
  if (headMatch) {
    const at = headMatch.index + headMatch[0].length;
    return html.slice(0, at) + snippet + html.slice(at);
  }
  const htmlMatch = /<html[^>]*>/i.exec(html);
  if (htmlMatch) {
    const at = htmlMatch.index + htmlMatch[0].length;
    return html.slice(0, at) + snippet + html.slice(at);
  }
  return snippet + html;
}

/* ------------------------------ 라우트 ------------------------------ */

/** /app/:slug → /app/:slug/ 로 정규화 (상대 경로가 깨지지 않도록) */
function redirectToRoot(req, res) {
  redirect(res, `/app/${encodeURIComponent(req.params.slug)}/`, 301);
}

function notFound(req, res, slug, relPath) {
  audit.access({ req, user: req.user, slug, path: relPath, result: 'notfound' });
  sendHtml(res, views.error({
    req, status: 404, title: '콘텐츠를 찾을 수 없습니다',
    message: '주소가 바뀌었거나 콘텐츠가 삭제되었을 수 있습니다.',
  }), 404);
}

async function serve(req, res) {
  const slug = req.params.slug;
  const relRaw = req.params.wildcard || '';

  const app = db.get(
    `SELECT id, slug, title, entry_file, visibility, is_active FROM apps WHERE slug = ?`,
    slug
  );

  // 2. 앱 존재 / 활성 여부
  if (!app || !app.is_active) return notFound(req, res, slug, relRaw);

  // 3. 접근 권한
  if (!canAccess(req.user, app)) {
    audit.access({ req, user: req.user, app, slug, path: relRaw, result: 'denied' });
    return sendHtml(res, views.error({
      req, status: 403, title: '접근 권한이 없습니다',
      message: '이 콘텐츠를 볼 권한이 없습니다. 필요하면 관리자에게 요청하세요.',
    }), 403);
  }

  // 진입 경로면 앱의 시작 파일로
  const relPath = relRaw === '' ? (app.entry_file || 'index.html') : relRaw;

  // 4. 경로 검증 — 폴더 밖으로 나가려는 모든 시도는 여기서 null 이 됩니다.
  const file = appstore.resolveFile(app.id, relPath);
  if (!file) return notFound(req, res, slug, relPath);

  const ext = path.extname(file.absolute).toLowerCase();
  const isHtml = ext === '.html' || ext === '.htm';

  // 5. 열람 기록 — HTML 문서만 남깁니다 (하위 리소스까지 남기면 로그가 폭발)
  if (isHtml) {
    audit.access({ req, user: req.user, app, slug, path: relPath, result: 'ok' });
  }

  // 6. 전송
  const headers = {
    'Content-Type': appstore.mimeFor(file.absolute),
    'Cache-Control': NO_STORE,
    'X-Content-Type-Options': 'nosniff',
  };

  if (isHtml) {
    let html;
    try {
      html = fs.readFileSync(file.absolute, 'utf8');
    } catch {
      return notFound(req, res, slug, relPath);
    }
    const body = Buffer.from(injectPortalContext(html, req.user, app), 'utf8');
    headers['Content-Length'] = body.length;
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    return res.end(body);
  }

  headers['Content-Length'] = file.size;
  res.writeHead(200, headers);
  if (req.method === 'HEAD') return res.end();

  const stream = fs.createReadStream(file.absolute);
  stream.on('error', () => { try { res.destroy(); } catch { /* noop */ } });
  stream.pipe(res);
}

module.exports = { serve, redirectToRoot, canAccess };
