'use strict';
/**
 * Phase 3 — 콘텐츠(HTML 앱) 관리.
 *
 * 업로드 처리 순서
 *   1. 파일 형식 판별 (ZIP 매직바이트 우선, 그다음 확장자)
 *   2. ZIP 이면 해제 — zip slip / zip bomb 방어는 lib/zip.js 에서
 *   3. 확장자 화이트리스트 검증 — 하나라도 걸리면 업로드 전체 거부
 *   4. 임시 폴더에 기록 후 원자적 교체 — 실패 시 기존 버전 유지
 */
const path = require('node:path');

const db = require('../db');
const config = require('../config');
const views = require('../views/admin');
const errorView = require('../views').error;
const zip = require('../lib/zip');
const audit = require('../lib/audit');
const session = require('../session');
const appstore = require('../lib/appstore');
const { sendHtml, redirect } = require('../lib/http');

/* ------------------------------ 업로드 해석 ------------------------------ */

function looksLikeZip(buf) {
  return buf.length > 4 && buf[0] === 0x50 && buf[1] === 0x4b
    && (buf[2] === 0x03 || buf[2] === 0x05 || buf[2] === 0x07);
}

/**
 * 업로드된 파일들을 { name, data } 목록으로 바꿉니다.
 *
 * 세 가지 형태를 받습니다.
 *   1. ZIP 하나            → 압축을 풀어 그대로
 *   2. HTML 하나           → index.html 로 저장
 *   3. HTML + 이미지 여러 개 → 각 파일을 이름 그대로 (HTML 에서 ./파일명 으로 참조)
 *
 * @returns {Array<{name:string,data:Buffer}>}
 */
function entriesFrom(files) {
  const list = (files || []).filter((f) => f.data && f.data.length > 0);
  if (list.length === 0) throw new appstore.StoreError('파일을 선택해 주세요.');

  if (list.length === 1 && looksLikeZip(list[0].data)) {
    return zip.read(list[0].data, {
      maxEntries: config.MAX_ENTRIES,
      maxTotalBytes: config.MAX_EXTRACTED_BYTES,
    });
  }

  const entries = [];
  let total = 0;

  for (const f of list) {
    if (looksLikeZip(f.data)) {
      throw new appstore.StoreError(
        'ZIP 은 다른 파일과 함께 올릴 수 없습니다. ZIP 하나만 올리거나, 개별 파일들만 올려 주세요.');
    }
    const ext = path.extname(f.filename || '').toLowerCase();
    if (ext === '.zip') {
      throw new appstore.StoreError('ZIP 파일이 손상되었거나 ZIP 형식이 아닙니다.');
    }

    // 브라우저가 보낸 파일 이름을 ZIP 항목과 같은 규칙으로 정규화합니다.
    const safe = zip.safeEntryPath(f.filename || '');
    if (!safe) {
      throw new appstore.StoreError(`사용할 수 없는 파일 이름입니다: ${f.filename}`);
    }

    total += f.data.length;
    if (total > config.MAX_EXTRACTED_BYTES) {
      throw new appstore.StoreError(
        `전체 용량이 상한(${Math.round(config.MAX_EXTRACTED_BYTES / 1024 / 1024)}MB)을 넘습니다.`);
    }

    entries.push({ name: safe, data: f.data });
  }

  // HTML 하나만 올린 경우엔 시작 파일을 예측 가능하게 index.html 로 맞춥니다.
  if (entries.length === 1 && /\.html?$/i.test(entries[0].name)) {
    entries[0].name = 'index.html';
  }

  return entries;
}

function uploadedFiles(req) {
  return (req.files || []).filter((f) => f.field === 'file');
}

/** 다음 정렬 순서 값 */
function nextSortOrder() {
  return db.get('SELECT COALESCE(MAX(sort_order), 0) + 1 AS n FROM apps').n;
}

/* ------------------------------ 조회 도우미 ------------------------------ */

function findApp(id) {
  return db.get(
    `SELECT id, slug, title, description, entry_file, visibility, is_active,
            sort_order, thumbnail, allow_download, created_at, updated_at, uploaded_by
       FROM apps WHERE id = ?`,
    Number(id)
  );
}

function notFound(req, res) {
  sendHtml(res, errorView({ req, status: 404, title: '콘텐츠를 찾을 수 없습니다' }), 404);
}

/* ------------------------------ 목록 ------------------------------ */

function getApps(req, res) {
  const rows = db.all(
    `SELECT a.id, a.slug, a.title, a.description, a.visibility, a.is_active,
            a.updated_at, a.sort_order, a.thumbnail,
            (SELECT COUNT(*) FROM app_permissions p WHERE p.app_id = a.id) AS grant_count
       FROM apps a ORDER BY a.sort_order, a.title COLLATE NOCASE`);

  const apps = rows.map((a) => {
    const files = appstore.listFiles(a.id);
    return {
      ...a,
      file_count: files.length,
      total_bytes: files.reduce((sum, f) => sum + f.size, 0),
    };
  });

  sendHtml(res, views.appsList({ req, apps, flash: session.takeFlash(req) }));
}

/* ------------------------------ 생성 ------------------------------ */

function getAppNew(req, res) {
  sendHtml(res, views.appNew({ req }));
}

function postAppCreate(req, res) {
  const title = String(req.body.title || '').trim();
  const description = String(req.body.description || '').trim();
  const visibility = req.body.visibility === 'all' ? 'all' : 'restricted';
  const slugInput = String(req.body.slug || '').trim();
  const form = { title, description, visibility, slug: slugInput };

  const fail = (message) => sendHtml(res, views.appNew({ req, error: message, form }), 400);

  if (!title) return fail('제목을 입력해 주세요.');

  const slug = appstore.normalizeSlug(slugInput || title);
  if (!slug || !appstore.isValidSlug(slug)) {
    return fail('주소는 영문 소문자·숫자·하이픈으로 2자 이상이어야 합니다. 직접 입력해 주세요.');
  }
  if (db.get('SELECT id FROM apps WHERE slug = ?', slug)) {
    return fail(`이미 사용 중인 주소입니다: ${slug}`);
  }

  let entries, entryFile;
  try {
    entries = entriesFrom(uploadedFiles(req));
    ({ entryFile } = appstore.validateEntries(entries));
  } catch (err) {
    return fail(err.userMessage || '업로드한 파일을 처리할 수 없습니다.');
  }

  // 이미지가 하나라도 있으면 첫 번째 이미지를 대표 이미지로 잡아 둡니다 (나중에 변경 가능).
  const firstImage = entries.find((e) => appstore.isImage(e.name));

  const now = Date.now();
  const { lastInsertRowid: appId } = db.run(
    `INSERT INTO apps (slug, title, description, entry_file, visibility, is_active,
                       sort_order, thumbnail, created_at, updated_at, uploaded_by)
     VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)`,
    slug, title, description, entryFile, visibility,
    nextSortOrder(), firstImage ? firstImage.name : '',
    now, now, req.user.id
  );

  let result;
  try {
    result = appstore.install(appId, entries);
  } catch (err) {
    // 파일 저장에 실패하면 DB 행도 되돌립니다.
    db.run('DELETE FROM apps WHERE id = ?', appId);
    return fail(err.userMessage || `파일을 저장하지 못했습니다: ${err.message}`);
  }

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'app.create', target: slug,
    detail: `files=${result.fileCount} bytes=${result.totalBytes} entry=${entryFile}`,
  });

  session.setFlash(req, 'ok',
    `"${title}" 을(를) 등록했습니다. 파일 ${result.fileCount}개, 시작 파일은 ${entryFile} 입니다.`);
  redirect(res, `/admin/apps/${appId}`);
}

/* ------------------------------ 상세 ------------------------------ */

function getAppDetail(req, res, error = null) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  const files = appstore.listFiles(app.id);
  const users = db.all(
    `SELECT id, login_id, name, dept FROM users
      WHERE role != 'admin' ORDER BY name COLLATE NOCASE`);
  const permitted = new Set(
    db.all('SELECT user_id FROM app_permissions WHERE app_id = ?', app.id)
      .map((r) => r.user_id));
  const recent = db.all(
    `SELECT login_id, path, result, at FROM access_logs
      WHERE app_id = ? ORDER BY at DESC LIMIT 20`, app.id);

  sendHtml(res, views.appDetail({
    req, app, files,
    totalBytes: files.reduce((sum, f) => sum + f.size, 0),
    users, permitted, recent,
    flash: session.takeFlash(req),
    error,
  }), error ? 400 : 200);
}

/* ------------------------------ 정보 수정 ------------------------------ */

function postAppUpdate(req, res) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  const title = String(req.body.title || '').trim();
  const description = String(req.body.description || '').trim().slice(0, 4000);
  const visibility = req.body.visibility === 'all' ? 'all' : 'restricted';
  const entryFile = String(req.body.entry_file || app.entry_file);
  const thumbnailInput = String(req.body.thumbnail || '').trim();

  if (!title) return getAppDetail(req, res, '제목을 입력해 주세요.');

  // 시작 파일은 실제로 존재하는 HTML 이어야 합니다.
  const exists = appstore.resolveFile(app.id, entryFile);
  if (!exists || !/\.html?$/i.test(entryFile)) {
    return getAppDetail(req, res, '시작 파일이 올바르지 않습니다.');
  }

  // 대표 이미지는 이 콘텐츠 안에 실제로 있는 이미지 파일이어야 합니다.
  let thumbnail = '';
  if (thumbnailInput) {
    if (!appstore.isImage(thumbnailInput) || !appstore.resolveFile(app.id, thumbnailInput)) {
      return getAppDetail(req, res, '대표 이미지가 올바르지 않습니다.');
    }
    thumbnail = thumbnailInput;
  }

  // 체크박스는 꺼져 있으면 아예 전송되지 않습니다.
  const allowDownload = req.body.allow_download === '1' ? 1 : 0;

  db.run(
    `UPDATE apps SET title = ?, description = ?, entry_file = ?, visibility = ?,
            thumbnail = ?, allow_download = ?, updated_at = ?
      WHERE id = ?`,
    title, description, entryFile, visibility, thumbnail, allowDownload, Date.now(), app.id
  );

  // 전체 공개로 바꾸면 개별 권한은 의미가 없으므로 정리합니다.
  if (visibility === 'all' && app.visibility !== 'all') {
    db.run('DELETE FROM app_permissions WHERE app_id = ?', app.id);
  }

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'app.update', target: app.slug,
    detail: `visibility=${visibility} entry=${entryFile} download=${allowDownload ? 'on' : 'off'}`,
  });

  session.setFlash(req, 'ok', '저장했습니다.');
  redirect(res, `/admin/apps/${app.id}`);
}

/* ------------------------------ 파일 교체 ------------------------------ */

function postAppReplace(req, res) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  let entries, entryFile;
  try {
    entries = entriesFrom(uploadedFiles(req));
    ({ entryFile } = appstore.validateEntries(entries));
  } catch (err) {
    return getAppDetail(req, res, err.userMessage || '업로드한 파일을 처리할 수 없습니다.');
  }

  let result;
  try {
    result = appstore.install(app.id, entries);
  } catch (err) {
    return getAppDetail(req, res,
      `파일을 저장하지 못했습니다. 기존 버전은 그대로 유지됩니다. (${err.message})`);
  }

  // 기존 시작 파일이 새 업로드에 없으면 새로 정한 것으로 바꿉니다.
  const keepEntry = entries.some((e) => e.name === app.entry_file);
  const newEntry = keepEntry ? app.entry_file : entryFile;

  // 대표 이미지가 새 업로드에 없으면 비웁니다 (깨진 이미지 방지).
  const keepThumb = app.thumbnail && entries.some((e) => e.name === app.thumbnail);
  const newThumb = keepThumb
    ? app.thumbnail
    : (entries.find((e) => appstore.isImage(e.name)) || { name: '' }).name;

  db.run('UPDATE apps SET entry_file = ?, thumbnail = ?, updated_at = ? WHERE id = ?',
    newEntry, newThumb, Date.now(), app.id);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'app.replace', target: app.slug,
    detail: `files=${result.fileCount} bytes=${result.totalBytes} entry=${newEntry}`,
  });

  session.setFlash(req, 'ok',
    `파일을 교체했습니다. ${result.fileCount}개, 시작 파일은 ${newEntry} 입니다.`);
  redirect(res, `/admin/apps/${app.id}`);
}

/* ------------------------------ 공개/숨김 ------------------------------ */

function postAppToggle(req, res) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  const next = app.is_active ? 0 : 1;
  db.run('UPDATE apps SET is_active = ?, updated_at = ? WHERE id = ?',
    next, Date.now(), app.id);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: next ? 'app.show' : 'app.hide', target: app.slug,
  });

  session.setFlash(req, 'ok', next
    ? '다시 공개했습니다.'
    : '숨김 처리했습니다. 이제 아무도 열 수 없습니다.');
  redirect(res, `/admin/apps/${app.id}`);
}

/* ------------------------------ 접근 권한 (콘텐츠 쪽) ------------------------------ */

function postAppAccess(req, res) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  const selected = (req.bodyAll.user || []).map(Number).filter(Number.isInteger);

  db.tx(() => {
    db.run('DELETE FROM app_permissions WHERE app_id = ?', app.id);
    const now = Date.now();
    for (const userId of selected) {
      const user = db.get(`SELECT id FROM users WHERE id = ? AND role != 'admin'`, userId);
      if (!user) continue;
      db.run(
        `INSERT OR IGNORE INTO app_permissions (app_id, user_id, granted_at, granted_by)
         VALUES (?, ?, ?, ?)`,
        app.id, userId, now, req.user.id);
    }
  });

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'app.access', target: app.slug, detail: `users=[${selected.join(',')}]`,
  });

  session.setFlash(req, 'ok', `접근 권한을 저장했습니다. (${selected.length}명)`);
  redirect(res, `/admin/apps/${app.id}`);
}

/* ------------------------------ 삭제 ------------------------------ */

function postAppDelete(req, res) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  if (String(req.body.confirm_slug || '').trim() !== app.slug) {
    return getAppDetail(req, res, '확인을 위해 주소를 정확히 입력해 주세요.');
  }

  appstore.remove(app.id);
  db.run('DELETE FROM apps WHERE id = ?', app.id);   // 권한은 FK CASCADE 로 함께 삭제

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'app.delete', target: app.slug, detail: `title=${app.title}`,
  });

  session.setFlash(req, 'ok', `"${app.title}" 을(를) 삭제했습니다.`);
  redirect(res, '/admin/apps');
}

/* ------------------------------ 순서 변경 ------------------------------ */

/**
 * 왼쪽 사이드바에 보일 순서를 한 칸 위/아래로 옮깁니다.
 * 이웃한 콘텐츠와 sort_order 값을 맞바꾸는 방식이라 값이 흐트러지지 않습니다.
 */
function postAppMove(req, res) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  const up = req.body.dir !== 'down';
  const ordered = db.all(
    'SELECT id, sort_order FROM apps ORDER BY sort_order, title COLLATE NOCASE');
  const index = ordered.findIndex((a) => a.id === app.id);
  const neighborIndex = up ? index - 1 : index + 1;

  if (index < 0 || neighborIndex < 0 || neighborIndex >= ordered.length) {
    return redirect(res, '/admin/apps');   // 이미 맨 위/아래
  }

  const neighbor = ordered[neighborIndex];

  db.tx(() => {
    // 두 행의 순서 값이 같을 수 있으므로 전체를 다시 매긴 뒤 맞바꿉니다.
    ordered.forEach((a, i) => db.run('UPDATE apps SET sort_order = ? WHERE id = ?', i + 1, a.id));
    db.run('UPDATE apps SET sort_order = ? WHERE id = ?', neighborIndex + 1, app.id);
    db.run('UPDATE apps SET sort_order = ? WHERE id = ?', index + 1, neighbor.id);
  });

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'app.move', target: app.slug, detail: up ? 'up' : 'down',
  });

  redirect(res, '/admin/apps');
}

/* ------------------------------ 파일 추가 / 삭제 ------------------------------ */

/** 전체를 다시 올리지 않고 이미지 등 파일만 더합니다. */
function postAppAddFiles(req, res) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  const files = uploadedFiles(req).filter((f) => f.data && f.data.length > 0);
  if (files.length === 0) return getAppDetail(req, res, '추가할 파일을 선택해 주세요.');

  const entries = [];
  try {
    for (const f of files) {
      if (looksLikeZip(f.data)) {
        throw new appstore.StoreError(
          'ZIP 은 여기서 풀 수 없습니다. 전체를 바꾸려면 "파일 교체" 를 쓰세요.');
      }
      const safe = zip.safeEntryPath(f.filename || '');
      if (!safe) throw new appstore.StoreError(`사용할 수 없는 파일 이름입니다: ${f.filename}`);
      entries.push({ name: safe, data: f.data });
    }
    var result = appstore.addFiles(app.id, entries);
  } catch (err) {
    return getAppDetail(req, res, err.userMessage || `파일을 추가하지 못했습니다: ${err.message}`);
  }

  db.run('UPDATE apps SET updated_at = ? WHERE id = ?', Date.now(), app.id);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'app.add-files', target: app.slug,
    detail: `added=[${result.added.join(',')}] replaced=[${result.replaced.join(',')}]`,
  });

  const parts = [];
  if (result.added.length) parts.push(`${result.added.length}개 추가`);
  if (result.replaced.length) parts.push(`${result.replaced.length}개 덮어쓰기`);
  session.setFlash(req, 'ok', `파일을 ${parts.join(', ')} 했습니다.`);
  redirect(res, `/admin/apps/${app.id}`);
}

function postAppDeleteFile(req, res) {
  const app = findApp(req.params.id);
  if (!app) return notFound(req, res);

  const target = String(req.body.path || '');

  if (target === app.entry_file) {
    return getAppDetail(req, res,
      '시작 파일은 지울 수 없습니다. 다른 파일을 시작 파일로 지정한 뒤에 지워 주세요.');
  }

  if (!appstore.deleteFile(app.id, target)) {
    return getAppDetail(req, res, '파일을 지우지 못했습니다.');
  }

  // 지운 파일이 대표 이미지였다면 설정을 비웁니다.
  if (app.thumbnail === target) {
    db.run('UPDATE apps SET thumbnail = ? WHERE id = ?', '', app.id);
  }
  db.run('UPDATE apps SET updated_at = ? WHERE id = ?', Date.now(), app.id);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'app.delete-file', target: app.slug, detail: target,
  });

  session.setFlash(req, 'ok', `${target} 을(를) 지웠습니다.`);
  redirect(res, `/admin/apps/${app.id}`);
}

module.exports = {
  getApps, getAppNew, postAppCreate, getAppDetail, postAppUpdate,
  postAppReplace, postAppToggle, postAppAccess, postAppDelete,
  postAppMove, postAppAddFiles, postAppDeleteFile,
};
