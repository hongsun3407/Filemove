'use strict';
/**
 * Phase 2 — 관리자 사용자 관리.
 *
 * 안전장치
 *  - 자기 자신의 권한/상태는 바꿀 수 없음 (스스로 잠기는 사고 방지)
 *  - 마지막 활성 관리자는 강등·비활성·삭제 불가
 *  - 삭제는 아이디를 정확히 입력해야만 진행
 */
const db = require('../db');
const views = require('../views/admin');
const errorView = require('../views').error;
const audit = require('../lib/audit');
const session = require('../session');
const password = require('../lib/password');
const { sendHtml, redirect } = require('../lib/http');

/* ------------------------------ 조회 도우미 ------------------------------ */

function findUser(id) {
  return db.get(
    `SELECT id, login_id, name, dept, role, status, must_change_pw,
            failed_count, locked_until, created_at, updated_at, last_login_at
       FROM users WHERE id = ?`,
    Number(id)
  );
}

function activeAdminCount() {
  return db.get(
    `SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND status = 'active'`
  ).n;
}

/** 이 사용자를 관리자 자리에서 빼도 되는지 (마지막 관리자 보호) */
function wouldRemoveLastAdmin(user) {
  if (user.role !== 'admin' || user.status !== 'active') return false;
  return activeAdminCount() <= 1;
}

function notFound(req, res) {
  sendHtml(res, errorView({
    req, status: 404, title: '사용자를 찾을 수 없습니다',
  }), 404);
}

function sessionCountFor(userId) {
  return db.get('SELECT COUNT(*) AS n FROM sessions WHERE user_id = ?', userId).n;
}

/* ------------------------------ 목록 ------------------------------ */

function getUsers(req, res) {
  const q = String(req.query.get('q') || '').trim();

  const users = q
    ? db.all(
      `SELECT id, login_id, name, dept, role, status, must_change_pw,
                locked_until, last_login_at
           FROM users
          WHERE login_id LIKE ? OR name LIKE ? OR dept LIKE ?
          ORDER BY role DESC, login_id COLLATE NOCASE`,
      `%${q}%`, `%${q}%`, `%${q}%`)
    : db.all(
      `SELECT id, login_id, name, dept, role, status, must_change_pw,
                locked_until, last_login_at
           FROM users ORDER BY role DESC, login_id COLLATE NOCASE`);

  sendHtml(res, views.usersList({ req, users, q, flash: session.takeFlash(req) }));
}

/* ------------------------------ 생성 ------------------------------ */

function getUserNew(req, res) {
  sendHtml(res, views.userNew({ req }));
}

async function postUserCreate(req, res) {
  const loginId = String(req.body.login_id || '').trim();
  const name = String(req.body.name || '').trim();
  const dept = String(req.body.dept || '').trim();
  const role = req.body.role === 'admin' ? 'admin' : 'user';
  const form = { login_id: loginId, name, dept, role };

  const fail = (message) => sendHtml(res, views.userNew({ req, error: message, form }), 400);

  if (!loginId) return fail('아이디를 입력해 주세요.');
  if (loginId.length > 100) return fail('아이디가 너무 깁니다.');
  if (/\s/.test(loginId)) return fail('아이디에 공백을 넣을 수 없습니다.');
  if (!name) return fail('이름을 입력해 주세요.');

  if (db.get('SELECT id FROM users WHERE login_id = ?', loginId)) {
    return fail(`이미 사용 중인 아이디입니다: ${loginId}`);
  }

  const temp = password.generateTemporary(14);
  const hash = await password.hash(temp);
  const now = Date.now();

  const { lastInsertRowid } = db.run(
    `INSERT INTO users (login_id, name, dept, password_hash, role, status,
                        must_change_pw, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 'active', 1, ?, ?)`,
    loginId, name, dept, hash, role, now, now
  );

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'user.create', target: loginId, detail: `role=${role}`,
  });

  session.setFlash(req, 'ok',
    `${name}(${loginId}) 계정을 만들었습니다. 아래 임시 비밀번호를 본인에게 전달하세요. 이 화면을 벗어나면 다시 볼 수 없습니다.`,
    temp);

  redirect(res, `/admin/users/${lastInsertRowid}`);
}

/* ------------------------------ 상세 ------------------------------ */

function getUserDetail(req, res, error = null) {
  const user = findUser(req.params.id);
  if (!user) return notFound(req, res);

  const apps = db.all(
    `SELECT id, slug, title, visibility FROM apps ORDER BY title COLLATE NOCASE`);
  const permitted = new Set(
    db.all('SELECT app_id FROM app_permissions WHERE user_id = ?', user.id)
      .map((r) => r.app_id));
  const recent = db.all(
    `SELECT app_slug, path, result, at FROM access_logs
      WHERE user_id = ? ORDER BY at DESC LIMIT 20`, user.id);

  sendHtml(res, views.userDetail({
    req, user,
    sessionCount: sessionCountFor(user.id),
    apps, permitted, recent,
    flash: session.takeFlash(req),
    error,
  }), error ? 400 : 200);
}

/* ------------------------------ 수정 ------------------------------ */

function postUserUpdate(req, res) {
  const user = findUser(req.params.id);
  if (!user) return notFound(req, res);

  const isSelf = req.user.id === user.id;
  const name = String(req.body.name || '').trim();
  const dept = String(req.body.dept || '').trim();

  if (!name) return getUserDetail(req, res, '이름을 입력해 주세요.');

  // 본인은 이름·부서만 바꿀 수 있습니다.
  const role = isSelf ? user.role : (req.body.role === 'admin' ? 'admin' : 'user');
  const status = isSelf ? user.status : (req.body.status === 'disabled' ? 'disabled' : 'active');

  const losesAdmin = user.role === 'admin' && (role !== 'admin' || status !== 'active');
  if (losesAdmin && wouldRemoveLastAdmin(user)) {
    return getUserDetail(req, res,
      '마지막 관리자입니다. 다른 관리자를 먼저 지정한 뒤에 바꿀 수 있습니다.');
  }

  db.run(
    'UPDATE users SET name = ?, dept = ?, role = ?, status = ?, updated_at = ? WHERE id = ?',
    name, dept, role, status, Date.now(), user.id
  );

  // 비활성화하면 기존 세션을 즉시 끊습니다.
  let killed = 0;
  if (status === 'disabled') killed = session.destroyAllForUser(user.id);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'user.update', target: user.login_id,
    detail: `role=${role} status=${status}` + (killed ? ` sessions_killed=${killed}` : ''),
  });

  session.setFlash(req, 'ok', '저장했습니다.'
    + (killed ? ` 진행 중이던 세션 ${killed}건을 종료했습니다.` : ''));
  redirect(res, `/admin/users/${user.id}`);
}

/* ------------------------------ 비밀번호 초기화 ------------------------------ */

async function postUserReset(req, res) {
  const user = findUser(req.params.id);
  if (!user) return notFound(req, res);

  const temp = password.generateTemporary(14);
  const hash = await password.hash(temp);

  db.run(
    `UPDATE users SET password_hash = ?, must_change_pw = 1,
            failed_count = 0, locked_until = NULL, updated_at = ?
      WHERE id = ?`,
    hash, Date.now(), user.id
  );
  const killed = session.destroyAllForUser(user.id);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'password.reset', target: user.login_id, detail: `sessions_killed=${killed}`,
  });

  session.setFlash(req, 'ok',
    `${user.name}(${user.login_id}) 의 비밀번호를 초기화했습니다. 아래 임시 비밀번호를 전달하세요. 이 화면을 벗어나면 다시 볼 수 없습니다.`,
    temp);
  redirect(res, `/admin/users/${user.id}`);
}

/* ------------------------------ 잠금 해제 / 세션 종료 ------------------------------ */

function postUserUnlock(req, res) {
  const user = findUser(req.params.id);
  if (!user) return notFound(req, res);

  db.run('UPDATE users SET failed_count = 0, locked_until = NULL, updated_at = ? WHERE id = ?',
    Date.now(), user.id);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'user.unlock', target: user.login_id,
  });

  session.setFlash(req, 'ok', '계정 잠금을 해제했습니다.');
  redirect(res, `/admin/users/${user.id}`);
}

function postUserKillSessions(req, res) {
  const user = findUser(req.params.id);
  if (!user) return notFound(req, res);

  const killed = session.destroyAllForUser(user.id);
  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'user.kill-sessions', target: user.login_id, detail: `count=${killed}`,
  });

  session.setFlash(req, 'ok', `세션 ${killed}건을 종료했습니다.`);
  redirect(res, `/admin/users/${user.id}`);
}

/* ------------------------------ 콘텐츠 권한 (사용자 쪽) ------------------------------ */

function postUserAccess(req, res) {
  const user = findUser(req.params.id);
  if (!user) return notFound(req, res);

  const selected = (req.bodyAll.app || []).map(Number).filter(Number.isInteger);

  db.tx(() => {
    db.run('DELETE FROM app_permissions WHERE user_id = ?', user.id);
    const now = Date.now();
    for (const appId of selected) {
      const app = db.get(`SELECT id, visibility FROM apps WHERE id = ?`, appId);
      if (!app || app.visibility === 'all') continue;
      db.run(
        `INSERT OR IGNORE INTO app_permissions (app_id, user_id, granted_at, granted_by)
         VALUES (?, ?, ?, ?)`,
        appId, user.id, now, req.user.id);
    }
  });

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'user.access', target: user.login_id, detail: `apps=[${selected.join(',')}]`,
  });

  session.setFlash(req, 'ok', '접근 권한을 저장했습니다.');
  redirect(res, `/admin/users/${user.id}`);
}

/* ------------------------------ 삭제 ------------------------------ */

function postUserDelete(req, res) {
  const user = findUser(req.params.id);
  if (!user) return notFound(req, res);

  if (req.user.id === user.id) {
    return getUserDetail(req, res, '본인 계정은 삭제할 수 없습니다.');
  }
  if (String(req.body.confirm_id || '').trim() !== user.login_id) {
    return getUserDetail(req, res, '확인을 위해 아이디를 정확히 입력해 주세요.');
  }
  if (wouldRemoveLastAdmin(user)) {
    return getUserDetail(req, res,
      '마지막 관리자는 삭제할 수 없습니다. 다른 관리자를 먼저 지정하세요.');
  }

  session.destroyAllForUser(user.id);
  db.run('DELETE FROM users WHERE id = ?', user.id);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'user.delete', target: user.login_id,
    detail: `name=${user.name} role=${user.role}`,
  });

  session.setFlash(req, 'ok', `${user.login_id} 계정을 삭제했습니다.`);
  redirect(res, '/admin/users');
}

module.exports = {
  getUsers, getUserNew, postUserCreate, getUserDetail, postUserUpdate,
  postUserReset, postUserUnlock, postUserKillSessions, postUserAccess, postUserDelete,
};
