'use strict';
/**
 * 압축 다운로드.
 *
 *   GET /download/:slug   콘텐츠 하나를 ZIP 으로  (권한 있는 사용자)
 *   GET /admin/backup     전체 백업 ZIP           (관리자)
 *
 * 콘텐츠 다운로드도 열람과 똑같이 세션 → 권한 검사를 거치고,
 * 콘텐츠별 "다운로드 허용" 스위치를 한 번 더 확인한 뒤 기록을 남깁니다.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const db = require('../db');
const config = require('../config');
const zip = require('../lib/zip');
const views = require('../views');
const audit = require('../lib/audit');
const appstore = require('../lib/appstore');
const { canAccess } = require('./content');
const { sendHtml, NO_STORE } = require('../lib/http');
const { fmtDateTimeSec, fmtBytes } = require('../lib/format');

/* ------------------------------ 공통 ------------------------------ */

function today() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/**
 * 한글 제목이 들어가도 브라우저가 알아듣도록 두 가지 형식을 함께 보냅니다.
 * (구형 브라우저는 filename, 최신 브라우저는 filename* 를 씁니다)
 */
function contentDisposition(asciiName, prettyName) {
  const safeAscii = asciiName.replace(/[^A-Za-z0-9._-]/g, '_');
  return `attachment; filename="${safeAscii}"; ` +
    `filename*=UTF-8''${encodeURIComponent(prettyName)}`;
}

function sendZip(res, buffer, asciiName, prettyName) {
  res.writeHead(200, {
    'Content-Type': 'application/zip',
    'Content-Length': buffer.length,
    'Content-Disposition': contentDisposition(asciiName, prettyName),
    'Cache-Control': NO_STORE,
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(buffer);
}

/** 콘텐츠 폴더의 파일을 ZIP 항목으로 읽어들입니다. */
function collectAppEntries(appId, prefix = '') {
  const entries = [];
  let total = 0;

  for (const file of appstore.listFiles(appId, 100000)) {
    const resolved = appstore.resolveFile(appId, file.path);
    if (!resolved) continue;               // 경로 검증을 통과하지 못하면 건너뜁니다

    total += resolved.size;
    if (total > config.MAX_DOWNLOAD_BYTES) {
      const limit = Math.round(config.MAX_DOWNLOAD_BYTES / 1024 / 1024);
      throw Object.assign(new Error('too big'), {
        statusCode: 413,
        userMessage: `내려받을 용량이 상한(${limit}MB)을 넘습니다. 관리자에게 문의해 주세요.`,
      });
    }

    entries.push({
      name: prefix + file.path,
      data: fs.readFileSync(resolved.absolute),
      mtime: new Date(resolved.mtimeMs),
    });
  }
  return entries;
}

/* ------------------------------ 콘텐츠 다운로드 ------------------------------ */

function getAppZip(req, res) {
  const slug = req.params.slug;

  const app = db.get(
    `SELECT id, slug, title, is_active, visibility, allow_download FROM apps WHERE slug = ?`,
    slug
  );

  if (!app || !app.is_active) {
    audit.access({ req, user: req.user, slug, path: '(download)', result: 'notfound' });
    return sendHtml(res, views.error({
      req, status: 404, title: '콘텐츠를 찾을 수 없습니다',
    }), 404);
  }

  if (!canAccess(req.user, app)) {
    audit.access({ req, user: req.user, app, slug, path: '(download)', result: 'denied' });
    return sendHtml(res, views.error({
      req, status: 403, title: '접근 권한이 없습니다',
      message: '이 콘텐츠를 볼 권한이 없습니다.',
    }), 403);
  }

  // 관리자는 스위치와 무관하게 받을 수 있습니다 (백업·이전 목적).
  if (!app.allow_download && req.user.role !== 'admin') {
    audit.access({ req, user: req.user, app, slug, path: '(download)', result: 'denied' });
    return sendHtml(res, views.error({
      req, status: 403, title: '다운로드가 허용되지 않은 콘텐츠입니다',
      message: '이 콘텐츠는 화면에서만 볼 수 있습니다. 필요하면 관리자에게 문의하세요.',
    }), 403);
  }

  const entries = collectAppEntries(app.id);
  if (entries.length === 0) {
    return sendHtml(res, views.error({
      req, status: 404, title: '내려받을 파일이 없습니다',
    }), 404);
  }

  const buffer = zip.write(entries);

  audit.access({ req, user: req.user, app, slug, path: '(download)', result: 'download' });

  sendZip(res, buffer, `${app.slug}.zip`, `${app.title}.zip`);
}

/* ------------------------------ 전체 백업 ------------------------------ */

function backupGuide(apps, dbBytes, contentBytes) {
  const lines = [
    '사내 HTML 배포 포탈 — 전체 백업',
    '='.repeat(60),
    '',
    `만든 시각 : ${fmtDateTimeSec(Date.now())}`,
    `데이터베이스 : ${fmtBytes(dbBytes)}`,
    `콘텐츠 : ${apps.length}개, ${fmtBytes(contentBytes)}`,
    '',
    '들어 있는 것',
    '-'.repeat(60),
    '  data/portal.db      계정 · 권한 · 접근 기록 (SQLite 스냅샷)',
    '  storage/apps/<번호>/ 업로드된 HTML 콘텐츠 파일',
    '  콘텐츠목록.csv       어떤 번호가 어떤 콘텐츠인지',
    '',
    '복구 방법',
    '-'.repeat(60),
    '  1. 포탈 서버를 멈춥니다 (start.bat 창을 닫거나 서비스 중지)',
    '  2. 이 ZIP 을 D:\\portal 에 풀어 data\\ 와 storage\\ 를 덮어씁니다',
    '     - 기존 data\\portal.db-wal, portal.db-shm 파일이 있으면 지웁니다',
    '  3. 포탈을 다시 시작합니다',
    '',
    '주의',
    '-'.repeat(60),
    '  portal.db 에는 비밀번호 해시와 접근 기록이 들어 있습니다.',
    '  이 백업 파일은 원본 서버와 같은 수준으로 보호해 주세요.',
    '',
    '  소스 코드는 들어 있지 않습니다. 서버를 새로 꾸릴 때는',
    '  포탈 소스를 먼저 복사한 뒤 이 백업을 덮어쓰면 됩니다.',
    '',
  ];
  return lines.join('\r\n');
}

function csvCell(value) {
  const s = String(value === null || value === undefined ? '' : value);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function getBackup(req, res) {
  const apps = db.all(
    `SELECT id, slug, title, entry_file, visibility, is_active, allow_download, updated_at
       FROM apps ORDER BY sort_order, title COLLATE NOCASE`);

  const entries = [];
  let contentBytes = 0;

  for (const app of apps) {
    const appEntries = collectAppEntries(app.id, `storage/apps/${app.id}/`);
    for (const e of appEntries) contentBytes += e.data.length;
    entries.push(...appEntries);
  }

  // DB 는 VACUUM INTO 로 스냅샷을 떠서 담습니다.
  // 실행 중에 파일을 그냥 복사하면 WAL 때문에 깨진 사본이 나올 수 있습니다.
  const tmpFile = path.join(os.tmpdir(),
    `portal-backup-${crypto.randomBytes(6).toString('hex')}.db`);
  let dbBuffer;
  try {
    db.exec(`VACUUM INTO '${tmpFile.replace(/'/g, "''")}'`);
    dbBuffer = fs.readFileSync(tmpFile);
  } finally {
    try { fs.rmSync(tmpFile, { force: true }); } catch { /* noop */ }
  }

  entries.push({ name: 'data/portal.db', data: dbBuffer });

  const csv = ['번호,주소,제목,시작파일,공개범위,사용중,다운로드허용']
    .concat(apps.map((a) => [
      a.id, a.slug, a.title, a.entry_file,
      a.visibility === 'all' ? '전체공개' : '지정',
      a.is_active ? 'Y' : 'N',
      a.allow_download ? 'Y' : 'N',
    ].map(csvCell).join(',')))
    .join('\r\n');

  entries.push({
    name: '콘텐츠목록.csv',
    data: Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), Buffer.from(csv, 'utf8')]),
  });
  entries.push({
    name: '복구안내.txt',
    data: Buffer.from(backupGuide(apps, dbBuffer.length, contentBytes), 'utf8'),
  });

  const buffer = zip.write(entries);

  audit.record({
    req, actorId: req.user.id, actor: req.user.login_id,
    action: 'backup.download',
    detail: `apps=${apps.length} bytes=${buffer.length}`,
  });

  const name = `portal-backup-${today()}.zip`;
  sendZip(res, buffer, name, name);
}

/* ------------------------------ 백업 안내 화면 ------------------------------ */

function getBackupPage(req, res) {
  const apps = db.all('SELECT id, title FROM apps');
  const contentBytes = apps.reduce((sum, a) => sum + appstore.diskUsage(a.id), 0);

  let dbBytes = 0;
  try {
    dbBytes = fs.statSync(path.join(config.DATA_DIR, 'portal.db')).size;
  } catch { /* 아직 없을 수 있습니다 */ }

  const counts = {
    users: db.get('SELECT COUNT(*) AS n FROM users').n,
    logs: db.get('SELECT COUNT(*) AS n FROM access_logs').n,
  };

  sendHtml(res, require('../views/admin').backupPage({
    req, apps, contentBytes, dbBytes, counts,
  }));
}

module.exports = { getAppZip, getBackup, getBackupPage };
