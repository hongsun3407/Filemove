'use strict';
/**
 * 접근 제어 미들웨어.
 *
 * requireAuth  : 로그인 필수. 아니면 /login 으로 보냅니다.
 * requireAdmin : role='admin' 필수. 아니면 403.
 * requirePasswordChanged : 임시 비밀번호 상태면 변경 화면으로 강제 이동.
 */
const { redirect, sendHtml } = require('../lib/http');
const views = require('../views');

/** 로그인하지 않았으면 응답을 끝냅니다. */
function requireAuth(req, res) {
  if (req.user) return;

  // 폼 전송(POST)이 만료된 세션으로 들어온 경우도 로그인 화면으로 유도
  const next = encodeURIComponent(req.method === 'GET' ? req.originalUrl : '/');
  redirect(res, `/login?next=${next}`);
}

function requireAdmin(req, res) {
  if (res.writableEnded) return;
  if (req.user && req.user.role === 'admin') return;
  sendHtml(res, views.error({
    req,
    status: 403,
    title: '접근 권한 없음',
    message: '이 페이지는 관리자만 사용할 수 있습니다.',
  }), 403);
}

/** 최초 로그인(임시 비밀번호) 사용자는 비밀번호를 바꾸기 전엔 아무것도 못 합니다. */
function requirePasswordChanged(req, res) {
  if (res.writableEnded) return;
  if (!req.user) return;
  if (!req.user.must_change_pw) return;
  redirect(res, '/change-password');
}

module.exports = { requireAuth, requireAdmin, requirePasswordChanged };
