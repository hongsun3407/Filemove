'use strict';
/**
 * 보안 응답 헤더.
 * 포탈 자체 화면과 사용자 HTML 콘텐츠(/app/*)에 서로 다른 CSP 를 적용합니다.
 * 포탈 화면은 인라인 스크립트를 아예 금지하고, 콘텐츠 화면은 기존 HTML 이
 * 동작해야 하므로 인라인을 허용하되 외부 통신은 차단합니다.
 */
const config = require('../config');

// 포탈 화면: 자기 출처만, 인라인 스크립트 금지
const CSP_PORTAL = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self'",
  "img-src 'self' data:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "form-action 'self'",
  "frame-ancestors 'self'",
  "base-uri 'none'",
  "object-src 'none'",
].join('; ');

// 사용자 HTML 콘텐츠: 인라인 허용(기존 HTML 호환), 외부 출처는 차단
const CSP_CONTENT = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "form-action 'self'",
  "frame-ancestors 'self'",
  "base-uri 'self'",
  "object-src 'none'",
].join('; ');

function apply(req, res, pathname) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=(), payment=()');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow, noarchive');
  res.removeHeader('X-Powered-By');

  if (config.SECURE_COOKIE) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }

  const isContent = pathname.startsWith('/app/');
  res.setHeader('Content-Security-Policy', isContent ? CSP_CONTENT : CSP_PORTAL);
}

module.exports = { apply, CSP_PORTAL, CSP_CONTENT };
