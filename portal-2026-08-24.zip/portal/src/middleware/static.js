'use strict';
/**
 * 포탈 자체 정적 자원(/public) 서빙.
 *
 * 중요: 업로드된 사용자 HTML 은 절대 이 경로로 서빙되지 않습니다.
 * 여기서 다루는 것은 포탈의 CSS/로고 등 인증이 필요 없는 파일뿐입니다.
 */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../config');

const MIME = {
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

/** @returns {boolean} 처리했으면 true */
function serve(req, res, pathname) {
  if (!pathname.startsWith('/static/')) return false;
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;

  const rel = pathname.slice('/static/'.length);
  const base = path.resolve(config.PUBLIC_DIR);
  const target = path.resolve(base, rel);

  // 디렉터리 탈출 방지
  if (target !== base && !target.startsWith(base + path.sep)) {
    res.writeHead(403).end();
    return true;
  }

  const ext = path.extname(target).toLowerCase();
  if (!MIME[ext]) { res.writeHead(404).end(); return true; }

  let stat;
  try {
    stat = fs.statSync(target);
    if (!stat.isFile()) throw new Error('not a file');
  } catch {
    res.writeHead(404).end();
    return true;
  }

  const etag = `W/"${stat.size}-${stat.mtimeMs}"`;
  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304, { ETag: etag }).end();
    return true;
  }

  res.writeHead(200, {
    'Content-Type': MIME[ext],
    'Content-Length': stat.size,
    'Cache-Control': 'public, max-age=3600',
    ETag: etag,
  });

  if (req.method === 'HEAD') { res.end(); return true; }

  const stream = fs.createReadStream(target);
  stream.on('error', () => { try { res.destroy(); } catch { /* noop */ } });
  stream.pipe(res);
  return true;
}

module.exports = { serve };
