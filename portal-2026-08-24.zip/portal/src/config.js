'use strict';
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');

/**
 * .env 파일을 조용히 읽어 들입니다 (있으면).
 * 이미 설정된 환경 변수를 덮어쓰지 않으므로, 서비스 등록 시 지정한 값이 우선합니다.
 */
function loadEnvFile(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch { return; }
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq < 1) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = value;
  }
}

loadEnvFile(path.join(ROOT, '.env'));

const config = {
  ROOT,
  PORT: Number(process.env.PORT || 3000),
  HOST: process.env.HOST || '0.0.0.0',

  // 디렉터리
  DATA_DIR: process.env.DATA_DIR || path.join(ROOT, 'data'),
  STORAGE_DIR: process.env.STORAGE_DIR || path.join(ROOT, 'storage', 'apps'),
  PUBLIC_DIR: path.join(ROOT, 'public'),
  LOG_DIR: process.env.LOG_DIR || path.join(ROOT, 'logs'),

  // HTTPS 리버스 프록시 뒤에서 운영할 때 true 로 설정하면
  // 세션 쿠키에 Secure 플래그가 붙습니다.
  SECURE_COOKIE: process.env.SECURE_COOKIE === 'true',

  // 프록시(IIS/Nginx)가 앞에 있으면 true. X-Forwarded-For 를 신뢰합니다.
  TRUST_PROXY: process.env.TRUST_PROXY === 'true',

  // 세션 수명
  SESSION_COOKIE: 'portal.sid',
  SESSION_ABSOLUTE_MS: Number(process.env.SESSION_ABSOLUTE_MS || 8 * 60 * 60 * 1000), // 8시간
  SESSION_IDLE_MS: Number(process.env.SESSION_IDLE_MS || 30 * 60 * 1000),             // 유휴 30분

  // 계정 잠금
  MAX_FAILED: Number(process.env.MAX_FAILED || 5),
  LOCK_MS: Number(process.env.LOCK_MS || 10 * 60 * 1000),

  // 로그인 요청 속도 제한 (IP 기준)
  LOGIN_RATE_MAX: Number(process.env.LOGIN_RATE_MAX || 20),
  LOGIN_RATE_WINDOW_MS: Number(process.env.LOGIN_RATE_WINDOW_MS || 10 * 60 * 1000),

  // 요청 본문 최대 크기 (일반 폼)
  MAX_BODY_BYTES: 1024 * 1024,

  // 콘텐츠 업로드 상한
  MAX_UPLOAD_BYTES: Number(process.env.MAX_UPLOAD_BYTES || 64 * 1024 * 1024),   // 업로드 파일
  MAX_EXTRACTED_BYTES: Number(process.env.MAX_EXTRACTED_BYTES || 200 * 1024 * 1024), // 압축 해제 후
  MAX_ENTRIES: Number(process.env.MAX_ENTRIES || 2000),                        // ZIP 안 파일 개수
  MAX_FILES_PER_UPLOAD: Number(process.env.MAX_FILES_PER_UPLOAD || 50),        // 한 번에 고를 파일 수

  // 압축 다운로드 상한 (메모리에서 ZIP 을 만들기 때문에 상한이 필요합니다)
  MAX_DOWNLOAD_BYTES: Number(process.env.MAX_DOWNLOAD_BYTES || 300 * 1024 * 1024),

  BRAND: process.env.BRAND || '사내 포탈',
};

module.exports = config;
