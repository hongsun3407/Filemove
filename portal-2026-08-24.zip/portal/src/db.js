'use strict';
/**
 * SQLite 접근 계층.
 * Node 22 내장 node:sqlite 를 사용하므로 네이티브 빌드가 필요 없습니다.
 * (better-sqlite3 로 교체하려면 이 파일의 open() 만 바꾸면 됩니다.)
 */
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');
const { migrate } = require('./migrations');

let db = null;

function open() {
  if (db) return db;
  fs.mkdirSync(config.DATA_DIR, { recursive: true });
  const file = path.join(config.DATA_DIR, 'portal.db');
  db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA foreign_keys = ON');
  db.exec('PRAGMA busy_timeout = 5000');
  migrate(api);
  return db;
}

function conn() {
  return db || open();
}

/** 결과를 반환하지 않는 문장 실행. { changes, lastInsertRowid } 반환 */
function run(sql, ...params) {
  const r = conn().prepare(sql).run(...params);
  return {
    changes: Number(r.changes),
    lastInsertRowid: Number(r.lastInsertRowid),
  };
}

/** 한 행 반환 (없으면 undefined) */
function get(sql, ...params) {
  return conn().prepare(sql).get(...params);
}

/** 모든 행 반환 */
function all(sql, ...params) {
  return conn().prepare(sql).all(...params);
}

/** 여러 문장 실행 (마이그레이션용) */
function exec(sql) {
  conn().exec(sql);
}

/** 트랜잭션으로 fn 실행 */
function tx(fn) {
  const c = conn();
  c.exec('BEGIN');
  try {
    const result = fn();
    c.exec('COMMIT');
    return result;
  } catch (err) {
    try { c.exec('ROLLBACK'); } catch { /* 이미 롤백됨 */ }
    throw err;
  }
}

function close() {
  if (db) { db.close(); db = null; }
}

const api = { open, run, get, all, exec, tx, close };
module.exports = api;
