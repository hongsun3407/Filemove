'use strict';
/**
 * 세션 관리 — 세션 ID 는 256비트 난수이며 서버(SQLite)에 저장됩니다.
 * 쿠키에는 식별자만 담기고 사용자 정보는 담기지 않으므로 위·변조가 불가능하고,
 * 관리자가 DB 행을 지우면 해당 세션은 즉시 무효화됩니다.
 */
const crypto = require('node:crypto');
const db = require('./db');
const config = require('./config');
const { parseCookies, setCookie, clearCookie, clientIp } = require('./lib/http');

function newId() {
  return crypto.randomBytes(32).toString('base64url');
}

function now() { return Date.now(); }

/* ------------------------------ 조회 / 부착 ------------------------------ */

/**
 * 요청에 req.session / req.user 를 붙입니다.
 * 유효하지 않거나 만료된 세션은 정리하고 익명으로 처리합니다.
 */
function attach(req, res) {
  req.cookies = parseCookies(req);
  req.session = null;
  req.user = null;

  const sid = req.cookies[config.SESSION_COOKIE];
  if (!sid) return;

  const row = db.get(
    `SELECT s.sid, s.user_id, s.data, s.created_at, s.last_seen_at, s.expires_at,
            u.login_id, u.name, u.dept, u.role, u.status, u.must_change_pw
       FROM sessions s
       JOIN users u ON u.id = s.user_id
      WHERE s.sid = ?`,
    sid
  );

  if (!row) { clearCookie(res, config.SESSION_COOKIE); return; }

  const t = now();

  // 절대 만료 / 유휴 만료
  if (row.expires_at <= t || row.last_seen_at + config.SESSION_IDLE_MS <= t) {
    db.run('DELETE FROM sessions WHERE sid = ?', sid);
    clearCookie(res, config.SESSION_COOKIE);
    return;
  }

  // 세션이 살아 있어도 계정이 비활성화되었으면 즉시 차단
  if (row.status !== 'active') {
    db.run('DELETE FROM sessions WHERE user_id = ?', row.user_id);
    clearCookie(res, config.SESSION_COOKIE);
    return;
  }

  // last_seen 갱신은 60초에 한 번으로 제한 (쓰기 부하 감소)
  if (t - row.last_seen_at > 60_000) {
    db.run('UPDATE sessions SET last_seen_at = ? WHERE sid = ?', t, sid);
  }

  let data = {};
  try { data = JSON.parse(row.data) || {}; } catch { data = {}; }

  req.session = {
    sid: row.sid,
    userId: row.user_id,
    data,
    save() {
      db.run('UPDATE sessions SET data = ? WHERE sid = ?', JSON.stringify(this.data), this.sid);
    },
  };

  req.user = {
    id: row.user_id,
    login_id: row.login_id,
    name: row.name,
    dept: row.dept,
    role: row.role,
    status: row.status,
    must_change_pw: row.must_change_pw,
  };
}

/* ------------------------------ 생성 / 파기 ------------------------------ */

/**
 * 로그인 성공 시 호출. 기존 세션을 버리고 새 ID 를 발급합니다.
 * (세션 고정 공격 방어)
 */
function create(req, res, userId) {
  const old = req.cookies && req.cookies[config.SESSION_COOKIE];
  if (old) db.run('DELETE FROM sessions WHERE sid = ?', old);

  const sid = newId();
  const t = now();
  db.run(
    `INSERT INTO sessions (sid, user_id, data, created_at, last_seen_at, expires_at, ip, user_agent)
     VALUES (?, ?, '{}', ?, ?, ?, ?, ?)`,
    sid, userId, t, t, t + config.SESSION_ABSOLUTE_MS,
    clientIp(req), String(req.headers['user-agent'] || '').slice(0, 400)
  );

  setCookie(res, config.SESSION_COOKIE, sid, {
    httpOnly: true,
    secure: config.SECURE_COOKIE,
    sameSite: 'Lax',
    // Max-Age 를 주지 않아 브라우저 종료 시 사라지는 세션 쿠키로 둡니다.
    // 실제 수명은 서버측 expires_at 이 결정합니다.
  });

  return sid;
}

function destroy(req, res) {
  if (req.session) db.run('DELETE FROM sessions WHERE sid = ?', req.session.sid);
  clearCookie(res, config.SESSION_COOKIE);
  req.session = null;
  req.user = null;
}

/** 관리자가 특정 사용자의 모든 세션을 강제 종료 */
function destroyAllForUser(userId) {
  return db.run('DELETE FROM sessions WHERE user_id = ?', userId).changes;
}

/** 만료 세션 정리 */
function sweep() {
  const t = now();
  return db.run(
    'DELETE FROM sessions WHERE expires_at <= ? OR last_seen_at + ? <= ?',
    t, config.SESSION_IDLE_MS, t
  ).changes;
}

/* ------------------------------ 일회성 메시지 ------------------------------ */

/**
 * 다음 화면에 한 번만 표시할 메시지를 세션에 넣습니다.
 * (임시 비밀번호처럼 리다이렉트 후에 보여야 하는 값에 사용)
 */
function setFlash(req, kind, text, extra = null) {
  if (!req.session) return;
  req.session.data.flash = { kind, text, extra };
  req.session.save();
}

/** 메시지를 꺼내고 즉시 지웁니다. */
function takeFlash(req) {
  if (!req.session || !req.session.data.flash) return null;
  const flash = req.session.data.flash;
  delete req.session.data.flash;
  req.session.save();
  return flash;
}

module.exports = {
  attach, create, destroy, destroyAllForUser, sweep,
  setFlash, takeFlash,
};
