'use strict';
/**
 * 화면 템플릿.
 * html`` 로 삽입되는 모든 값은 자동 이스케이프됩니다 (lib/html.js 참고).
 */
const { html, raw } = require('../lib/html');
const config = require('../config');
const richtext = require('../lib/richtext');

/* ------------------------------ 공통 ------------------------------ */

/** 콘텐츠 안의 파일을 가리키는 안전한 URL */
function appFileUrl(slug, file) {
  return richtext.safeImageSrc(slug, file) || '';
}

/** 이 사용자에게 다운로드 버튼을 보여줄지 (관리자는 항상 가능) */
function canDownload(user, app) {
  if (!user) return false;
  if (user.role === 'admin') return true;
  return !!app.allow_download;
}

function thumbOf(app, size) {
  if (app.thumbnail) {
    const url = appFileUrl(app.slug, app.thumbnail);
    if (url) return html`<img class="thumb ${size}" src="${url}" alt="" loading="lazy">`;
  }
  return html`<span class="thumb ${size} ph">${String(app.title || '?').trim().slice(0, 1)}</span>`;
}

/* ------------------------------ 사이드바 ------------------------------ */

function sidebar({ apps, activeSlug }) {
  return html`<aside class="sidebar">
  <a class="side-item home ${activeSlug ? '' : 'on'}" href="/">
    <span class="thumb sm ph">≡</span>
    <span class="t">전체 보기</span>
  </a>
  ${apps.length === 0
    ? html`<p class="side-empty">콘텐츠 없음</p>`
    : html`<nav>
        ${apps.map((a) => html`
          <a class="side-item ${a.slug === activeSlug ? 'on' : ''}" href="/view/${a.slug}"
             title="${a.title}">
            ${thumbOf(a, 'sm')}
            <span class="t">${a.title}</span>
          </a>`)}
      </nav>`}
</aside>`;
}

/* ------------------------------ 레이아웃 ------------------------------ */

/**
 * @param {object} opts
 * @param {boolean} [opts.bare]   로그인 화면처럼 가운데 카드만 보여줄 때
 * @param {object}  [opts.shell]  { apps, activeSlug, fill } 왼쪽 사이드바를 붙일 때
 */
function layout({ req, title, body, bare = false, shell = null }) {
  const user = req && req.user;
  const bodyClass = [
    bare ? 'bare' : '',
    shell ? 'has-shell' : '',
    shell && shell.fill ? 'fill' : '',
  ].filter(Boolean).join(' ');

  const main = shell
    ? html`<div class="shell-body">
        ${sidebar(shell)}
        <main class="viewer">${body}</main>
      </div>`
    : html`<main class="${bare ? 'centered' : 'page'}">${body}</main>`;

  return html`<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>${title ? `${title} · ${config.BRAND}` : config.BRAND}</title>
<link rel="stylesheet" href="/static/css/style.css">
</head>
<body class="${bodyClass}">
${bare ? '' : html`
<header class="topbar">
  <a class="brand" href="/">${config.BRAND}</a>
  <nav>
    ${user && user.role === 'admin' ? html`<a href="/admin/apps">관리자</a>` : ''}
    ${user ? html`
      <span class="who">${user.name || user.login_id}${user.dept ? ` · ${user.dept}` : ''}</span>
      <a href="/change-password">비밀번호 변경</a>
      <form method="post" action="/logout" class="inline">
        <input type="hidden" name="_csrf" value="${req.csrfToken}">
        <button type="submit" class="linklike">로그아웃</button>
      </form>
    ` : ''}
  </nav>
</header>`}
${main}
</body>
</html>`;
}

/* ------------------------------ 알림 배너 ------------------------------ */

const MESSAGES = {
  'password-changed': ['ok', '비밀번호가 변경되었습니다.'],
  'logged-out': ['ok', '로그아웃되었습니다.'],
  'session-expired': ['warn', '세션이 만료되어 로그아웃되었습니다. 다시 로그인해 주세요.'],
};

function banner(code) {
  const entry = MESSAGES[code];
  if (!entry) return '';
  const [kind, text] = entry;
  return html`<div class="banner ${kind}">${text}</div>`;
}

/* ------------------------------ 로그인 ------------------------------ */

function login({ req, error, loginId = '', next = '', notice = '' }) {
  return layout({
    req, title: '로그인', bare: true,
    body: html`
<div class="card login">
  <h1>${config.BRAND}</h1>
  <p class="sub">등록된 사용자만 이용할 수 있습니다.</p>
  ${banner(notice)}
  ${error ? html`<div class="banner err">${error}</div>` : ''}
  <form method="post" action="/login" autocomplete="off">
    <input type="hidden" name="_csrf" value="${req.csrfToken}">
    <input type="hidden" name="next" value="${next}">
    <label for="login_id">아이디</label>
    <input id="login_id" name="login_id" type="text" value="${loginId}"
           autocomplete="username" required autofocus maxlength="100">
    <label for="password">비밀번호</label>
    <input id="password" name="password" type="password"
           autocomplete="current-password" required maxlength="200">
    <button type="submit" class="primary">로그인</button>
  </form>
  <p class="foot">계정이 필요하면 시스템 관리자에게 문의하세요.</p>
</div>`,
  });
}

/* ------------------------------ 비밀번호 변경 ------------------------------ */

function changePassword({ req, error, forced = false }) {
  return layout({
    req, title: '비밀번호 변경', bare: forced,
    body: html`
<div class="card form-card">
  <h1>비밀번호 변경</h1>
  ${forced ? html`<div class="banner warn">
    임시 비밀번호로 로그인했습니다. 계속하려면 새 비밀번호를 설정해야 합니다.
  </div>` : ''}
  ${error ? html`<div class="banner err">${error}</div>` : ''}
  <form method="post" action="/change-password" autocomplete="off">
    <input type="hidden" name="_csrf" value="${req.csrfToken}">
    <label for="current">현재 비밀번호</label>
    <input id="current" name="current" type="password" autocomplete="current-password" required>
    <label for="next_pw">새 비밀번호</label>
    <input id="next_pw" name="next_pw" type="password" autocomplete="new-password" required>
    <p class="hint">10자 이상, 영문·숫자·특수문자 중 2종류 이상</p>
    <label for="confirm">새 비밀번호 확인</label>
    <input id="confirm" name="confirm" type="password" autocomplete="new-password" required>
    <button type="submit" class="primary">변경하기</button>
  </form>
</div>`,
  });
}

/* ------------------------------ 홈 (전체 보기) ------------------------------ */

function dashboard({ req, apps = [], notice = '', flash = null }) {
  return layout({
    req, title: '콘텐츠',
    shell: { apps, activeSlug: null, fill: false },
    body: html`
<div class="viewer-pad">
  ${banner(notice)}
  ${flash ? html`<div class="banner ${flash.kind}">${flash.text}</div>` : ''}
  <h1>이용 가능한 콘텐츠</h1>

  ${apps.length === 0
    ? html`<div class="empty">
        <p>아직 접근 가능한 콘텐츠가 없습니다.</p>
        <p class="hint">${req.user.role === 'admin'
          ? '관리자 화면에서 HTML을 업로드하면 여기와 왼쪽 목록에 표시됩니다.'
          : '필요한 콘텐츠가 있다면 관리자에게 권한을 요청하세요.'}</p>
      </div>`
    : html`<ul class="cards">
        ${apps.map((a) => html`
          <li class="app-card">
            <a class="card-main" href="/view/${a.slug}">
              <div class="card-head">
                ${thumbOf(a, 'md')}
                <h2>${a.title}</h2>
              </div>
              ${a.description
    ? html`<div class="desc">${richtext.render(a.description, a.slug)}</div>`
    : ''}
            </a>
            ${canDownload(req.user, a)
    ? html`<div class="card-foot">
        <a class="dl" href="/download/${a.slug}" download>압축 다운로드</a>
      </div>`
    : ''}
          </li>`)}
      </ul>`}
</div>`,
  });
}

/* ------------------------------ 뷰어 (사이드바 + 콘텐츠) ------------------------------ */

function viewer({ req, apps, app }) {
  return layout({
    req, title: app.title,
    shell: { apps, activeSlug: app.slug, fill: true },
    body: html`
<div class="viewer-bar">
  <h1>${app.title}</h1>
  <div class="btn-row">
    ${canDownload(req.user, app)
    ? html`<a class="btn small-btn" href="/download/${app.slug}" download>압축 다운로드</a>`
    : ''}
    <a class="btn small-btn" href="/app/${app.slug}/" target="_blank" rel="noopener">
      새 창으로 열기
    </a>
  </div>
</div>
<iframe class="content-frame" src="/app/${app.slug}/" title="${app.title}"></iframe>`,
  });
}

/* ------------------------------ 오류 ------------------------------ */

function error({ req, status = 500, title = '오류', message = '' }) {
  return layout({
    req, title, bare: !(req && req.user),
    body: html`
<div class="card error-card">
  <p class="code">${status}</p>
  <h1>${title}</h1>
  ${message ? html`<p>${message}</p>` : ''}
  <p><a href="/">처음으로</a></p>
</div>`,
  });
}

module.exports = {
  layout, login, changePassword, dashboard, viewer, error,
  banner, sidebar, thumbOf, appFileUrl, raw,
};
