'use strict';
/**
 * 관리자 화면 템플릿.
 * 삽입되는 모든 값은 html`` 이 자동으로 이스케이프합니다.
 */
const { html } = require('../lib/html');
const { layout, thumbOf } = require('./index');
const appstore = require('../lib/appstore');
const richtext = require('../lib/richtext');
const { fmtDateTime, fmtDateTimeSec, fmtBytes, fmtRelative } = require('../lib/format');

/* ------------------------------ 공통 조각 ------------------------------ */

function adminNav(active) {
  const items = [
    ['users', '/admin/users', '사용자'],
    ['apps', '/admin/apps', '콘텐츠'],
    ['logs', '/admin/logs', '접근 기록'],
    ['backup', '/admin/backup', '백업'],
  ];
  return html`<nav class="subnav">
    ${items.map(([key, href, label]) => html`
      <a href="${href}" class="${active === key ? 'on' : ''}">${label}</a>`)}
  </nav>`;
}

function flashBanner(flash) {
  if (!flash) return '';
  return html`<div class="banner ${flash.kind}">
    <div>${flash.text}</div>
    ${flash.extra ? html`<div class="secret">${flash.extra}</div>` : ''}
  </div>`;
}

function csrf(req) {
  return html`<input type="hidden" name="_csrf" value="${req.csrfToken}">`;
}

/** 위험한 동작을 위한 확인용 버튼 (JS 없이 동작하도록 폼 전송) */
function actionForm(req, action, label, { danger = false, confirm = null, small = true } = {}) {
  return html`<form method="post" action="${action}" class="inline">
    ${csrf(req)}
    ${confirm ? html`<input type="hidden" name="confirm" value="yes">` : ''}
    <button type="submit" class="${danger ? 'danger' : ''} ${small ? 'small' : ''}">${label}</button>
  </form>`;
}

function statusBadge(user) {
  if (user.status !== 'active') return html`<span class="badge off">비활성</span>`;
  if (user.locked_until && user.locked_until > Date.now()) {
    return html`<span class="badge warn">잠김</span>`;
  }
  if (user.must_change_pw) return html`<span class="badge info">임시 비밀번호</span>`;
  return html`<span class="badge ok">정상</span>`;
}

/* ------------------------------ 사용자 목록 ------------------------------ */

function usersList({ req, users, q = '', flash }) {
  return layout({
    req, title: '사용자 관리',
    body: html`
${adminNav('users')}
${flashBanner(flash)}

<div class="head-row">
  <h1>사용자 <span class="count">${users.length}</span></h1>
  <a class="btn primary-btn" href="/admin/users/new">계정 만들기</a>
</div>

<form method="get" action="/admin/users" class="searchbar">
  <input type="text" name="q" value="${q}" placeholder="아이디 · 이름 · 부서로 검색" maxlength="60">
  <button type="submit">검색</button>
  ${q ? html`<a href="/admin/users" class="clear">전체 보기</a>` : ''}
</form>

${users.length === 0
    ? html`<div class="empty"><p>조건에 맞는 사용자가 없습니다.</p></div>`
    : html`<table class="grid">
  <thead>
    <tr>
      <th>아이디</th><th>이름</th><th>부서</th><th>권한</th>
      <th>상태</th><th>마지막 로그인</th><th></th>
    </tr>
  </thead>
  <tbody>
    ${users.map((u) => html`
      <tr>
        <td><a href="/admin/users/${u.id}"><code>${u.login_id}</code></a></td>
        <td>${u.name}</td>
        <td class="muted">${u.dept || '-'}</td>
        <td>${u.role === 'admin' ? html`<span class="badge admin">관리자</span>` : '일반'}</td>
        <td>${statusBadge(u)}</td>
        <td class="muted">${fmtRelative(u.last_login_at)}</td>
        <td class="right"><a href="/admin/users/${u.id}">관리</a></td>
      </tr>`)}
  </tbody>
</table>`}`,
  });
}

/* ------------------------------ 계정 만들기 ------------------------------ */

function userNew({ req, error, form = {} }) {
  return layout({
    req, title: '계정 만들기',
    body: html`
${adminNav('users')}
<h1>계정 만들기</h1>

<div class="card form-card">
  ${error ? html`<div class="banner err">${error}</div>` : ''}
  <p class="hint top">
    비밀번호는 임시 비밀번호가 자동 생성되어 <strong>생성 직후 한 번만</strong> 표시됩니다.
    본인이 최초 로그인할 때 반드시 변경하게 됩니다.
  </p>
  <form method="post" action="/admin/users">
    ${csrf(req)}
    <label for="login_id">아이디 (사번 또는 이메일)</label>
    <input id="login_id" name="login_id" type="text" value="${form.login_id || ''}"
           required maxlength="100" autocomplete="off" autofocus>

    <label for="name">이름</label>
    <input id="name" name="name" type="text" value="${form.name || ''}" required maxlength="60">

    <label for="dept">부서 (생략 가능)</label>
    <input id="dept" name="dept" type="text" value="${form.dept || ''}" maxlength="60">

    <label for="role">권한</label>
    <select id="role" name="role">
      <option value="user" ${form.role === 'admin' ? '' : 'selected'}>일반 사용자</option>
      <option value="admin" ${form.role === 'admin' ? 'selected' : ''}>관리자</option>
    </select>
    <p class="hint">관리자는 계정과 콘텐츠를 모두 관리할 수 있고, 모든 콘텐츠를 열람합니다.</p>

    <button type="submit" class="primary">만들기</button>
  </form>
  <p class="foot"><a href="/admin/users">목록으로</a></p>
</div>`,
  });
}

/* ------------------------------ 사용자 상세 ------------------------------ */

function userDetail({ req, user, sessionCount, apps, permitted, recent, flash, error }) {
  const isSelf = req.user.id === user.id;
  const locked = user.locked_until && user.locked_until > Date.now();

  return layout({
    req, title: user.name || user.login_id,
    body: html`
${adminNav('users')}
${flashBanner(flash)}
${error ? html`<div class="banner err">${error}</div>` : ''}

<div class="head-row">
  <h1>${user.name || user.login_id} <code class="sub-id">${user.login_id}</code></h1>
  <a href="/admin/users" class="btn">목록</a>
</div>

${isSelf ? html`<div class="banner info">
  본인 계정입니다. 권한과 상태는 스스로 바꿀 수 없습니다.
</div>` : ''}

<div class="two-col">
  <section class="card">
    <h2>기본 정보</h2>
    <form method="post" action="/admin/users/${user.id}">
      ${csrf(req)}
      <label for="name">이름</label>
      <input id="name" name="name" type="text" value="${user.name}" required maxlength="60">

      <label for="dept">부서</label>
      <input id="dept" name="dept" type="text" value="${user.dept}" maxlength="60">

      <label for="role">권한</label>
      <select id="role" name="role" ${isSelf ? 'disabled' : ''}>
        <option value="user" ${user.role === 'admin' ? '' : 'selected'}>일반 사용자</option>
        <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>관리자</option>
      </select>

      <label for="status">상태</label>
      <select id="status" name="status" ${isSelf ? 'disabled' : ''}>
        <option value="active" ${user.status === 'active' ? 'selected' : ''}>활성</option>
        <option value="disabled" ${user.status === 'disabled' ? 'selected' : ''}>비활성 (로그인 차단)</option>
      </select>

      <button type="submit" class="primary">저장</button>
    </form>
  </section>

  <section class="card">
    <h2>계정 상태</h2>
    <dl class="facts">
      <dt>상태</dt><dd>${statusBadge(user)}</dd>
      <dt>생성</dt><dd>${fmtDateTime(user.created_at)}</dd>
      <dt>마지막 로그인</dt><dd>${fmtDateTime(user.last_login_at)}</dd>
      <dt>로그인 실패</dt><dd>${user.failed_count}회</dd>
      <dt>활성 세션</dt><dd>${sessionCount}개</dd>
    </dl>

    <div class="actions">
      ${actionForm(req, `/admin/users/${user.id}/reset`, '비밀번호 초기화')}
      ${locked ? actionForm(req, `/admin/users/${user.id}/unlock`, '잠금 해제') : ''}
      ${sessionCount > 0
    ? actionForm(req, `/admin/users/${user.id}/kill-sessions`, '모든 세션 종료')
    : ''}
    </div>

    ${isSelf ? '' : html`
      <div class="danger-zone">
        <h3>계정 삭제</h3>
        <p class="hint">
          되돌릴 수 없습니다. 이 사용자의 접근 기록은 남고 사용자 이름만 지워집니다.
          평소에는 삭제 대신 <strong>비활성</strong>을 쓰세요.
        </p>
        <form method="post" action="/admin/users/${user.id}/delete">
          ${csrf(req)}
          <label for="confirm_id">확인을 위해 아이디를 입력하세요</label>
          <input id="confirm_id" name="confirm_id" type="text" placeholder="${user.login_id}" autocomplete="off">
          <button type="submit" class="danger">영구 삭제</button>
        </form>
      </div>`}
  </section>
</div>

<section class="card">
  <h2>콘텐츠 접근 권한</h2>
  ${user.role === 'admin'
    ? html`<p class="hint">관리자는 모든 콘텐츠를 열람할 수 있습니다.</p>`
    : apps.length === 0
      ? html`<p class="hint">등록된 콘텐츠가 없습니다.</p>`
      : html`
      <form method="post" action="/admin/users/${user.id}/access">
        ${csrf(req)}
        <ul class="checklist">
          ${apps.map((a) => html`
            <li>
              <label class="check">
                <input type="checkbox" name="app" value="${a.id}"
                       ${permitted.has(a.id) ? 'checked' : ''}
                       ${a.visibility === 'all' ? 'disabled' : ''}>
                <span>${a.title}</span>
                <code>${a.slug}</code>
                ${a.visibility === 'all' ? html`<span class="badge info">전체 공개</span>` : ''}
              </label>
            </li>`)}
        </ul>
        <button type="submit" class="primary">권한 저장</button>
      </form>`}
</section>

<section class="card">
  <h2>최근 열람 기록</h2>
  ${recent.length === 0
    ? html`<p class="hint">아직 기록이 없습니다.</p>`
    : html`<table class="grid compact">
        <thead><tr><th>시각</th><th>콘텐츠</th><th>경로</th><th>결과</th></tr></thead>
        <tbody>
          ${recent.map((r) => html`<tr>
            <td class="muted">${fmtDateTimeSec(r.at)}</td>
            <td>${r.app_slug}</td>
            <td class="muted"><code>${r.path}</code></td>
            <td>${resultBadge(r.result)}</td>
          </tr>`)}
        </tbody>
      </table>`}
</section>`,
  });
}

function resultBadge(result) {
  if (result === 'ok') return html`<span class="badge ok">열람</span>`;
  if (result === 'download') return html`<span class="badge info">내려받음</span>`;
  if (result === 'denied') return html`<span class="badge err">거부</span>`;
  return html`<span class="badge">없음</span>`;
}

/* ------------------------------ 콘텐츠 목록 ------------------------------ */

function appsList({ req, apps, flash }) {
  return layout({
    req, title: '콘텐츠 관리',
    body: html`
${adminNav('apps')}
${flashBanner(flash)}

<div class="head-row">
  <h1>콘텐츠 <span class="count">${apps.length}</span></h1>
  <a class="btn primary-btn" href="/admin/apps/new">콘텐츠 올리기</a>
</div>

${apps.length === 0
    ? html`<div class="empty">
        <p>아직 등록된 콘텐츠가 없습니다.</p>
        <p class="hint">HTML 파일 하나 또는 index.html 이 들어 있는 ZIP 을 올리면 됩니다.</p>
      </div>`
    : html`
<p class="hint top">왼쪽 사이드바에 이 순서대로 표시됩니다. 화살표로 순서를 바꾸세요.</p>
<table class="grid">
  <thead>
    <tr>
      <th class="ord">순서</th><th>제목</th><th>주소</th>
      <th>공개 범위</th><th>파일</th><th>수정</th><th></th>
    </tr>
  </thead>
  <tbody>
    ${apps.map((a, i) => html`
      <tr class="${a.is_active ? '' : 'dim'}">
        <td class="ord">
          <div class="move">
            ${i > 0 ? html`
              <form method="post" action="/admin/apps/${a.id}/move" class="inline">
                ${csrf(req)}<input type="hidden" name="dir" value="up">
                <button type="submit" title="위로">↑</button>
              </form>` : html`<span class="spacer"></span>`}
            ${i < apps.length - 1 ? html`
              <form method="post" action="/admin/apps/${a.id}/move" class="inline">
                ${csrf(req)}<input type="hidden" name="dir" value="down">
                <button type="submit" title="아래로">↓</button>
              </form>` : html`<span class="spacer"></span>`}
          </div>
        </td>
        <td>
          <div class="title-cell">
            ${thumbOf(a, 'sm')}
            <a href="/admin/apps/${a.id}">${a.title}</a>
            ${a.is_active ? '' : html`<span class="badge off">숨김</span>`}
          </div>
        </td>
        <td><code>/app/${a.slug}/</code></td>
        <td>${a.visibility === 'all'
    ? html`<span class="badge info">전체 공개</span>`
    : html`<span class="badge">지정 ${a.grant_count}명</span>`}</td>
        <td class="muted">${a.file_count}개 · ${fmtBytes(a.total_bytes)}</td>
        <td class="muted">${fmtRelative(a.updated_at)}</td>
        <td class="right">
          ${a.is_active ? html`<a href="/view/${a.slug}" target="_blank">열기</a> · ` : ''}
          <a href="/admin/apps/${a.id}">관리</a>
        </td>
      </tr>`)}
  </tbody>
</table>`}`,
  });
}

/* ------------------------------ 콘텐츠 올리기 ------------------------------ */

function uploadHelp() {
  return html`<div class="help">
  <h3>올리는 방법</h3>
  <ul>
    <li><strong>HTML 과 이미지를 한 번에 고르세요.</strong> 파일 선택 창에서 Ctrl 을 누른 채 여러 개를
        고르면 됩니다. HTML 에서는 <code>./사진.png</code> 처럼 참조합니다.</li>
    <li><strong>ZIP 도 됩니다.</strong> 폴더 구조가 있으면 ZIP 이 편합니다.
        단, 루트에 <code>index.html</code> 이 있어야 하고 폴더로 한 번 더 감싸면 안 됩니다.</li>
    <li><strong>경로는 상대경로로.</strong> <code>/js/app.js</code> 처럼 <code>/</code> 로 시작하면 깨집니다.
        <code>./js/app.js</code> 로 바꿔 주세요.</li>
    <li><strong>외부 CDN 은 폐쇄망에서 안 잡힙니다.</strong> 라이브러리는 함께 올리세요.</li>
    <li>실행 파일(<code>.exe</code>, <code>.bat</code>, <code>.ps1</code> 등)이 하나라도 있으면 업로드 전체가 거부됩니다.</li>
    <li>HTML 안에서 <code>window.__PORTAL_USER__</code> 로 로그인한 사람의 이름·부서를 쓸 수 있습니다.</li>
  </ul>
</div>`;
}

/** 설명란 입력 도움말 */
function descriptionField(value, slug = '') {
  return html`
<label for="description">설명</label>
<textarea id="description" name="description" rows="4"
          placeholder="목록에 함께 표시될 설명입니다. 비워 두어도 됩니다.">${value || ''}</textarea>
<p class="hint">
  <code>**굵게**</code> · <code>*기울임*</code> · <code>- 목록</code> 을 쓸 수 있고,
  ${slug
    ? html`<code>![설명](사진.png)</code> 로 이 콘텐츠에 올린 이미지를 넣을 수 있습니다.`
    : html`파일을 올린 뒤에는 <code>![설명](사진.png)</code> 로 이미지도 넣을 수 있습니다.`}
</p>`;
}

function appNew({ req, error, form = {} }) {
  return layout({
    req, title: '콘텐츠 올리기',
    body: html`
${adminNav('apps')}
<h1>콘텐츠 올리기</h1>

<div class="two-col">
  <div class="card form-card">
    ${error ? html`<div class="banner err">${error}</div>` : ''}
    <form method="post" action="/admin/apps" enctype="multipart/form-data">
      ${csrf(req)}
      <label for="title">제목</label>
      <input id="title" name="title" type="text" value="${form.title || ''}"
             required maxlength="100" autofocus>

      <label for="slug">주소 (영문 소문자·숫자·하이픈)</label>
      <input id="slug" name="slug" type="text" value="${form.slug || ''}"
             maxlength="64" placeholder="비워 두면 제목에서 자동 생성">
      <p class="hint">접속 주소는 <code>/app/&lt;주소&gt;/</code> 가 됩니다.</p>

      ${descriptionField(form.description)}

      <label for="visibility">공개 범위</label>
      <select id="visibility" name="visibility">
        <option value="restricted" ${form.visibility === 'all' ? '' : 'selected'}>
          지정한 사용자만
        </option>
        <option value="all" ${form.visibility === 'all' ? 'selected' : ''}>
          로그인한 모든 사용자
        </option>
      </select>

      <label for="file">파일</label>
      <input id="file" name="file" type="file" required multiple
             accept=".html,.htm,.zip,.css,.js,.json,.csv,.txt,.svg,.png,.jpg,.jpeg,.gif,.webp,.ico,.woff,.woff2,.pdf">
      <p class="hint">HTML 하나 · HTML + 이미지 여러 개 · ZIP 하나 — 셋 중 아무 방식이나 됩니다.</p>

      <button type="submit" class="primary">올리기</button>
    </form>
    <p class="foot"><a href="/admin/apps">목록으로</a></p>
  </div>
  ${uploadHelp()}
</div>`,
  });
}

/* ------------------------------ 콘텐츠 상세 ------------------------------ */

function appDetail({ req, app, files, totalBytes, users, permitted, recent, flash, error }) {
  return layout({
    req, title: app.title,
    body: html`
${adminNav('apps')}
${flashBanner(flash)}
${error ? html`<div class="banner err">${error}</div>` : ''}

<div class="head-row">
  <h1>${app.title} ${app.is_active ? '' : html`<span class="badge off">숨김</span>`}</h1>
  <div class="btn-row">
    ${app.is_active ? html`<a class="btn" href="/view/${app.slug}" target="_blank">열어 보기</a>` : ''}
    <a class="btn" href="/download/${app.slug}">ZIP 내려받기</a>
    <a class="btn" href="/admin/apps">목록</a>
  </div>
</div>

<div class="two-col">
  <section class="card">
    <h2>정보</h2>
    <form method="post" action="/admin/apps/${app.id}">
      ${csrf(req)}
      <label for="title">제목</label>
      <input id="title" name="title" type="text" value="${app.title}" required maxlength="100">

      ${descriptionField(app.description, app.slug)}

      <label for="entry_file">시작 파일</label>
      <select id="entry_file" name="entry_file">
        ${files.filter((f) => /\.html?$/i.test(f.path)).map((f) => html`
          <option value="${f.path}" ${f.path === app.entry_file ? 'selected' : ''}>${f.path}</option>`)}
      </select>

      <label for="thumbnail">대표 이미지</label>
      <select id="thumbnail" name="thumbnail">
        <option value="">사용 안 함 (제목 첫 글자 표시)</option>
        ${files.filter((f) => appstore.isImage(f.path)).map((f) => html`
          <option value="${f.path}" ${f.path === app.thumbnail ? 'selected' : ''}>${f.path}</option>`)}
      </select>
      <p class="hint">왼쪽 사이드바와 목록에 작게 표시됩니다.</p>

      <label for="visibility">공개 범위</label>
      <select id="visibility" name="visibility">
        <option value="restricted" ${app.visibility === 'all' ? '' : 'selected'}>지정한 사용자만</option>
        <option value="all" ${app.visibility === 'all' ? 'selected' : ''}>로그인한 모든 사용자</option>
      </select>

      <label class="check standalone">
        <input type="checkbox" name="allow_download" value="1" ${app.allow_download ? 'checked' : ''}>
        <span>사용자가 ZIP 으로 내려받을 수 있게 허용</span>
      </label>
      <p class="hint">
        끄면 화면에서 보기만 가능합니다. 관리자는 이 설정과 무관하게 받을 수 있고,
        누가 언제 받았는지는 접근 기록에 남습니다.
      </p>

      <button type="submit" class="primary">저장</button>
    </form>

    <dl class="facts">
      <dt>주소</dt><dd><code>/app/${app.slug}/</code></dd>
      <dt>파일</dt><dd>${files.length}개 · ${fmtBytes(totalBytes)}</dd>
      <dt>마지막 수정</dt><dd>${fmtDateTime(app.updated_at)}</dd>
    </dl>

    <div class="actions">
      ${actionForm(req, `/admin/apps/${app.id}/toggle`,
    app.is_active ? '숨기기' : '다시 공개')}
    </div>
  </section>

  <section class="card">
    <h2>파일 교체</h2>
    <p class="hint top">
      새 파일을 올리면 기존 파일은 모두 지워지고 교체됩니다.
      검증에 실패하면 <strong>기존 버전이 그대로 유지</strong>됩니다.
    </p>
    <form method="post" action="/admin/apps/${app.id}/replace" enctype="multipart/form-data">
      ${csrf(req)}
      <input type="file" name="file" required multiple
             accept=".html,.htm,.zip,.css,.js,.json,.csv,.txt,.svg,.png,.jpg,.jpeg,.gif,.webp,.ico,.woff,.woff2,.pdf">
      <button type="submit" class="primary">교체하기</button>
    </form>

    <div class="danger-zone">
      <h3>콘텐츠 삭제</h3>
      <p class="hint">파일과 권한 설정이 모두 지워집니다. 되돌릴 수 없습니다.</p>
      <form method="post" action="/admin/apps/${app.id}/delete">
        ${csrf(req)}
        <label for="confirm_slug">확인을 위해 주소를 입력하세요</label>
        <input id="confirm_slug" name="confirm_slug" type="text" placeholder="${app.slug}" autocomplete="off">
        <button type="submit" class="danger">영구 삭제</button>
      </form>
    </div>
  </section>
</div>

<section class="card">
  <h2>접근 권한</h2>
  ${app.visibility === 'all'
    ? html`<p class="hint">지금은 <strong>로그인한 모든 사용자</strong>가 볼 수 있습니다.
        특정 인원만 지정하려면 위에서 공개 범위를 바꾸세요.</p>`
    : users.length === 0
      ? html`<p class="hint">등록된 일반 사용자가 없습니다.</p>`
      : html`
      <form method="post" action="/admin/apps/${app.id}/access">
        ${csrf(req)}
        <p class="hint top">관리자는 여기 없어도 모든 콘텐츠를 볼 수 있습니다.</p>
        <ul class="checklist cols">
          ${users.map((u) => html`
            <li>
              <label class="check">
                <input type="checkbox" name="user" value="${u.id}" ${permitted.has(u.id) ? 'checked' : ''}>
                <span>${u.name}</span>
                <code>${u.login_id}</code>
                ${u.dept ? html`<span class="muted">${u.dept}</span>` : ''}
              </label>
            </li>`)}
        </ul>
        <button type="submit" class="primary">권한 저장</button>
      </form>`}
</section>

<section class="card">
  <h2>파일 관리</h2>

  <form method="post" action="/admin/apps/${app.id}/files" enctype="multipart/form-data"
        class="addfiles">
    ${csrf(req)}
    <input type="file" name="file" multiple required
           accept=".html,.htm,.css,.js,.json,.csv,.txt,.svg,.png,.jpg,.jpeg,.gif,.webp,.ico,.woff,.woff2,.pdf">
    <button type="submit" class="primary inline-primary">파일 추가</button>
  </form>
  <p class="hint">
    이미지 한 장만 더하고 싶을 때 씁니다. 전체를 바꾸려면 위의 "파일 교체" 를 쓰세요.
    같은 이름이 있으면 덮어씁니다.
  </p>

  <ul class="filelist">
    ${files.map((f) => html`
      <li>
        <span class="fname">
          ${appstore.isImage(f.path)
    ? html`<img class="filethumb" src="/app/${app.slug}/${f.path}" alt="" loading="lazy">`
    : html`<span class="filethumb ph">${f.path.split('.').pop()}</span>`}
          <code>${f.path}</code>
          ${f.path === app.entry_file ? html`<span class="badge info">시작</span>` : ''}
          ${f.path === app.thumbnail ? html`<span class="badge">대표</span>` : ''}
        </span>
        <span class="fmeta">
          <span class="muted">${fmtBytes(f.size)}</span>
          ${f.path === app.entry_file ? '' : html`
            <form method="post" action="/admin/apps/${app.id}/files/delete" class="inline">
              ${csrf(req)}
              <input type="hidden" name="path" value="${f.path}">
              <button type="submit" class="small danger">삭제</button>
            </form>`}
        </span>
      </li>`)}
  </ul>
</section>

${app.description ? html`
<section class="card">
  <h2>설명 미리보기</h2>
  <div class="desc">${richtext.render(app.description, app.slug)}</div>
</section>` : ''}

<section class="card">
  <h2>최근 열람 기록</h2>
  ${recent.length === 0
    ? html`<p class="hint">아직 기록이 없습니다.</p>`
    : html`<table class="grid compact">
        <thead><tr><th>시각</th><th>사용자</th><th>경로</th><th>결과</th></tr></thead>
        <tbody>
          ${recent.map((r) => html`<tr>
            <td class="muted">${fmtDateTimeSec(r.at)}</td>
            <td>${r.login_id || '-'}</td>
            <td class="muted"><code>${r.path}</code></td>
            <td>${resultBadge(r.result)}</td>
          </tr>`)}
        </tbody>
      </table>`}
</section>`,
  });
}

/* ------------------------------ 접근 기록 ------------------------------ */

function logsList({ req, logs, filters, page, hasMore, apps, users }) {
  const qs = (over) => {
    const p = new URLSearchParams();
    if (filters.user) p.set('user', filters.user);
    if (filters.app) p.set('app', filters.app);
    if (filters.result) p.set('result', filters.result);
    for (const [k, v] of Object.entries(over)) {
      if (v === null) p.delete(k); else p.set(k, v);
    }
    const s = p.toString();
    return s ? `?${s}` : '';
  };

  return layout({
    req, title: '접근 기록',
    body: html`
${adminNav('logs')}

<div class="head-row">
  <h1>접근 기록</h1>
  <a class="btn" href="/admin/logs/export${qs({})}">CSV 내려받기</a>
</div>

<form method="get" action="/admin/logs" class="filterbar">
  <select name="user">
    <option value="">모든 사용자</option>
    ${users.map((u) => html`<option value="${u.id}" ${String(filters.user) === String(u.id) ? 'selected' : ''}>
      ${u.name} (${u.login_id})</option>`)}
  </select>
  <select name="app">
    <option value="">모든 콘텐츠</option>
    ${apps.map((a) => html`<option value="${a.id}" ${String(filters.app) === String(a.id) ? 'selected' : ''}>
      ${a.title}</option>`)}
  </select>
  <select name="result">
    <option value="">모든 결과</option>
    <option value="ok" ${filters.result === 'ok' ? 'selected' : ''}>열람</option>
    <option value="download" ${filters.result === 'download' ? 'selected' : ''}>내려받음</option>
    <option value="denied" ${filters.result === 'denied' ? 'selected' : ''}>거부</option>
    <option value="notfound" ${filters.result === 'notfound' ? 'selected' : ''}>없음</option>
  </select>
  <button type="submit">조회</button>
  <a href="/admin/logs" class="clear">초기화</a>
</form>

${logs.length === 0
    ? html`<div class="empty"><p>조건에 맞는 기록이 없습니다.</p></div>`
    : html`<table class="grid compact">
  <thead>
    <tr><th>시각</th><th>사용자</th><th>콘텐츠</th><th>경로</th><th>결과</th><th>IP</th></tr>
  </thead>
  <tbody>
    ${logs.map((r) => html`<tr>
      <td class="muted nowrap">${fmtDateTimeSec(r.at)}</td>
      <td>${r.login_id || '-'}</td>
      <td>${r.app_slug || '-'}</td>
      <td class="muted"><code>${r.path}</code></td>
      <td>${resultBadge(r.result)}</td>
      <td class="muted nowrap">${r.ip}</td>
    </tr>`)}
  </tbody>
</table>

<div class="pager">
  ${page > 1 ? html`<a href="/admin/logs${qs({ page: page - 1 })}">← 이전</a>` : ''}
  <span class="muted">${page} 쪽</span>
  ${hasMore ? html`<a href="/admin/logs${qs({ page: page + 1 })}">다음 →</a>` : ''}
</div>`}`,
  });
}

/* ------------------------------ 백업 ------------------------------ */

function backupPage({ req, apps, contentBytes, dbBytes, counts }) {
  const estimate = contentBytes + dbBytes;

  return layout({
    req, title: '백업',
    body: html`
${adminNav('backup')}
<h1>전체 백업</h1>

<div class="two-col">
  <section class="card">
    <h2>지금 백업 받기</h2>
    <p class="hint top">
      모든 콘텐츠 파일과 데이터베이스를 ZIP 하나로 내려받습니다.
      서버를 멈추지 않아도 되고, 데이터베이스는 일관된 스냅샷으로 담깁니다.
    </p>

    <dl class="facts">
      <dt>콘텐츠</dt><dd>${apps.length}개 · ${fmtBytes(contentBytes)}</dd>
      <dt>데이터베이스</dt><dd>${fmtBytes(dbBytes)}</dd>
      <dt>계정</dt><dd>${counts.users}개</dd>
      <dt>접근 기록</dt><dd>${counts.logs.toLocaleString('ko-KR')}건</dd>
      <dt>예상 크기</dt><dd>${fmtBytes(estimate)} 이하 (압축 전)</dd>
    </dl>

    <div class="actions">
      <a class="btn primary-btn" href="/admin/backup/download">백업 ZIP 내려받기</a>
    </div>
    <p class="hint">파일이 크면 만드는 데 시간이 걸립니다. 한 번만 누르고 기다려 주세요.</p>
  </section>

  <div class="help">
    <h3>백업에 들어가는 것</h3>
    <ul>
      <li><strong><code>data/portal.db</code></strong> — 계정, 권한, 접근 기록</li>
      <li><strong><code>storage/apps/…</code></strong> — 업로드된 HTML 콘텐츠</li>
      <li><strong><code>콘텐츠목록.csv</code></strong> — 어떤 번호가 어떤 콘텐츠인지</li>
      <li><strong><code>복구안내.txt</code></strong> — 되돌리는 순서</li>
    </ul>
    <h3>들어가지 않는 것</h3>
    <ul>
      <li>포탈 소스 코드와 <code>.env</code> — 이건 형상관리나 별도 복사로 챙기세요.</li>
    </ul>
    <h3>보관 시 주의</h3>
    <ul>
      <li>비밀번호 해시와 접근 기록이 들어 있습니다.
          <strong>백업 파일도 원본 서버와 같은 수준으로 보호</strong>해야 합니다.</li>
    </ul>
  </div>
</div>

<section class="card">
  <h2>정기 백업 자동화</h2>
  <p class="hint top">
    Windows 작업 스케줄러에 아래 명령을 등록하면 매일 자동으로 받을 수 있습니다.
    포탈을 멈추지 않고 폴더를 그대로 복사하면 데이터베이스가 깨질 수 있으니,
    이 방식이나 서비스 중지 후 복사 중 하나를 쓰세요.
  </p>
  <pre class="code-block">powershell -Command "Invoke-WebRequest -Uri 'http://localhost:${
  String(require('../config').PORT)}/admin/backup/download' -OutFile 'D:\\backup\\portal-$(Get-Date -f yyyy-MM-dd).zip' -WebSession $s"</pre>
  <p class="hint">
    위 명령은 로그인 세션이 필요합니다. 무인 자동화가 필요하면 말씀해 주세요 —
    백업 전용 키 방식으로 바꿔 드리겠습니다.
  </p>
</section>`,
  });
}

module.exports = {
  usersList, userNew, userDetail,
  appsList, appNew, appDetail,
  logsList, backupPage, adminNav, flashBanner,
};
