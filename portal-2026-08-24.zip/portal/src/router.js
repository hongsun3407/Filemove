'use strict';
/**
 * 아주 작은 라우터.
 * 패턴 예:  '/login'            → 정확히 일치
 *          '/admin/users/:id'  → params.id
 *          '/app/:slug/*'      → params.slug, params.wildcard
 */

function compile(pattern) {
  const keys = [];
  let src = '^';
  for (const seg of pattern.split('/')) {
    if (seg === '') continue;
    src += '/';
    if (seg === '*') {
      keys.push('wildcard');
      src += '(.*)';
    } else if (seg.startsWith(':')) {
      keys.push(seg.slice(1));
      src += '([^/]+)';
    } else {
      src += seg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
  }
  if (src === '^') src += '/';
  src += '$';
  return { regex: new RegExp(src), keys };
}

class Router {
  constructor() {
    this.routes = [];
  }

  add(method, pattern, ...handlers) {
    const { regex, keys } = compile(pattern);
    this.routes.push({ method, pattern, regex, keys, handlers });
    return this;
  }

  get(pattern, ...h) { return this.add('GET', pattern, ...h); }
  post(pattern, ...h) { return this.add('POST', pattern, ...h); }

  /**
   * @returns {{handlers: Function[], params: object}|null|'method-mismatch'}
   */
  match(method, pathname) {
    let pathMatched = false;
    for (const route of this.routes) {
      const m = route.regex.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (route.method !== method && !(method === 'HEAD' && route.method === 'GET')) continue;

      const params = Object.create(null);
      route.keys.forEach((k, i) => {
        let v = m[i + 1];
        try { v = decodeURIComponent(v); } catch { /* 잘못된 인코딩은 원문 유지 */ }
        params[k] = v;
      });
      return { handlers: route.handlers, params };
    }
    return pathMatched ? 'method-mismatch' : null;
  }

  /**
   * 매칭된 핸들러 체인을 순서대로 실행. 응답이 시작되면 중단합니다.
   *
   * writableEnded 만 보면 안 됩니다. 파일 스트리밍(res.pipe)은 핸들러가 반환된
   * 뒤에도 계속 진행 중이라 writableEnded 가 false 이고, 그대로 두면 호출부가
   * "아무도 처리하지 않았다"고 판단해 404 를 덧씌워 응답이 깨집니다.
   */
  async run(handlers, req, res) {
    for (const handler of handlers) {
      await handler(req, res);
      if (responded(res)) return true;
    }
    return responded(res);
  }
}

/** 응답이 이미 시작되었거나 끝났는가 */
function responded(res) {
  return res.headersSent || res.writableEnded;
}

module.exports = { Router, responded };
