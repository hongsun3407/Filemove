'use strict';
/**
 * Phase 2 / 3 — 관리자 기능, 업로드, 보호 서빙.
 * 이 파일이 "포탈이 실제로 막아 주는가" 를 검증합니다.
 */
const {
  test, section, assert, equal, createClient, csrfOf, login, tokenOf,
} = require('./harness');
const { makeZip } = require('./zipmaker');

const SAMPLE_HTML =
  '<!doctype html><html><head><title>영업 대시보드</title></head>' +
  '<body><h1>매출</h1><script src="./js/app.js"></script></body></html>';

/** 업로드 후 생성된 앱의 id 를 Location 에서 추출 */
function appIdOf(res) {
  const m = /\/admin\/apps\/(\d+)/.exec(res.location || '');
  if (!m) throw new Error(`앱 id 를 찾을 수 없습니다 (status=${res.status}, location=${res.location})`);
  return m[1];
}

module.exports = async function run() {
  const admin = await login('admin', 'Kw9!SecurePhrase26');

  /* ============================ Phase 2 ============================ */

  section('Phase 2 — 사용자 관리');

  let newUserId = null;
  let tempPassword = null;

  await test('관리자가 계정을 만들고 임시 비밀번호를 받는다', async () => {
    const res = await admin.form('/admin/users', {
      _csrf: tokenOf(admin),
      login_id: 'kim.cs', name: '김철수', dept: '생산관리팀', role: 'user',
    });
    equal(res.status, 302, '상태 코드');
    const m = /\/admin\/users\/(\d+)/.exec(res.location);
    assert(m, `Location 에 사용자 id 가 있어야 함 (실제: ${res.location})`);
    newUserId = m[1];

    const page = await admin.request(`/admin/users/${newUserId}`);
    equal(page.status, 200, '상세 화면');
    const secret = /<div class="secret">([^<]+)<\/div>/.exec(page.text);
    assert(secret, '임시 비밀번호가 한 번 표시되어야 함');
    tempPassword = secret[1];
    assert(tempPassword.length >= 12, '임시 비밀번호 길이');
  });

  await test('임시 비밀번호는 두 번째 조회에서 사라진다', async () => {
    const page = await admin.request(`/admin/users/${newUserId}`);
    assert(!page.text.includes('class="secret"'), '재조회 시 표시되면 안 됨');
  });

  await test('새 계정으로 로그인하면 비밀번호 변경이 강제된다', async () => {
    const c = createClient();
    const page = await c.request('/login');
    const res = await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'kim.cs', password: tempPassword, next: '/',
    });
    equal(res.status, 302, '로그인');
    equal(res.location, '/change-password', '강제 이동');

    const form = await c.request('/change-password');
    const done = await c.form('/change-password', {
      _csrf: csrfOf(form.text), current: tempPassword,
      next_pw: 'Cheolsu!2026#p', confirm: 'Cheolsu!2026#p',
    });
    equal(done.status, 302, '변경 성공');
  });

  await test('중복 아이디로는 계정을 만들 수 없다', async () => {
    const res = await admin.form('/admin/users', {
      _csrf: tokenOf(admin), login_id: 'kim.cs', name: '중복', dept: '', role: 'user',
    });
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('이미 사용 중인 아이디'), '오류 메시지');
  });

  /** 목록 화면에서 아이디로 사용자 id 찾기 */
  async function idOfUser(loginId) {
    const list = await admin.request(`/admin/users?q=${encodeURIComponent(loginId)}`);
    const re = new RegExp(`href="/admin/users/(\\d+)"><code>${loginId}</`);
    const m = re.exec(list.text);
    assert(m, `${loginId} 행을 찾아야 함`);
    return m[1];
  }

  await test('본인 계정은 삭제할 수 없다', async () => {
    const adminId = await idOfUser('admin');
    const res = await admin.form(`/admin/users/${adminId}/delete`, {
      _csrf: tokenOf(admin), confirm_id: 'admin',
    });
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('본인 계정은 삭제할 수 없습니다'), '거부 메시지');
    equal((await admin.request('/admin/users')).status, 200, '계정이 살아 있어야 함');
  });

  await test('본인 계정의 권한·상태는 바꿔도 반영되지 않는다', async () => {
    const adminId = await idOfUser('admin');

    const res = await admin.form(`/admin/users/${adminId}`, {
      _csrf: tokenOf(admin), name: '관리자', dept: '정보시스템팀',
      role: 'user', status: 'disabled',
    });
    equal(res.status, 302, '요청은 통과');

    // 여전히 관리자 화면을 쓸 수 있어야 합니다 (변경이 무시되었다는 뜻)
    equal((await admin.request('/admin/users')).status, 200, '관리자 권한 유지');
  });

  await test('계정을 비활성화하면 진행 중이던 세션이 즉시 끊긴다', async () => {
    const victim = await login('kim.cs', 'Cheolsu!2026#p');
    equal((await victim.request('/')).status, 200, '비활성화 전');

    const res = await admin.form(`/admin/users/${newUserId}`, {
      _csrf: tokenOf(admin), name: '김철수', dept: '생산관리팀',
      role: 'user', status: 'disabled',
    });
    equal(res.status, 302, '비활성화 요청');

    const after = await victim.request('/');
    equal(after.status, 302, '비활성화 후');
    assert(after.location.startsWith('/login'), '로그인 화면으로');
  });

  await test('다시 활성화하면 로그인할 수 있다', async () => {
    await admin.form(`/admin/users/${newUserId}`, {
      _csrf: tokenOf(admin), name: '김철수', dept: '생산관리팀',
      role: 'user', status: 'active',
    });
    const c = await login('kim.cs', 'Cheolsu!2026#p');
    equal((await c.request('/')).status, 200, '재로그인');
  });

  /* ============================ Phase 3 ============================ */

  section('Phase 3 — 업로드');

  let htmlAppId = null;
  let zipAppId = null;

  await test('단일 HTML 파일 업로드', async () => {
    const res = await admin.upload('/admin/apps', {
      _csrf: tokenOf(admin),
      title: '영업 대시보드', slug: 'sales', description: '월별 매출',
      visibility: 'restricted',
    }, { field: 'file', filename: 'report.html', data: SAMPLE_HTML, contentType: 'text/html' });

    equal(res.status, 302, '상태 코드');
    htmlAppId = appIdOf(res);
  });

  await test('ZIP 업로드 — 하위 폴더와 한글 파일명 포함', async () => {
    const zipBuf = makeZip([
      { name: 'index.html', data: '<html><head></head><body>ZIP 콘텐츠<img src="./img/사진.png"></body></html>' },
      { name: 'js/app.js', data: 'console.log("hello")' },
      { name: 'css/style.css', data: 'body{margin:0}' },
      { name: 'img/사진.png', data: Buffer.from([0x89, 0x50, 0x4e, 0x47, 1, 2, 3]) },
    ]);

    const res = await admin.upload('/admin/apps', {
      _csrf: tokenOf(admin),
      title: '품질 리포트', slug: 'quality', description: '', visibility: 'all',
    }, { field: 'file', filename: 'quality.zip', data: zipBuf, contentType: 'application/zip' });

    equal(res.status, 302, '상태 코드');
    zipAppId = appIdOf(res);

    const detail = await admin.request(`/admin/apps/${zipAppId}`);
    assert(detail.text.includes('js/app.js'), 'js 파일 목록 표시');
    assert(detail.text.includes('사진.png'), '한글 파일명 보존');
  });

  await test('zip slip (../) 이 든 ZIP 은 거부', async () => {
    const evil = makeZip([
      { name: 'index.html', data: 'ok' },
      { name: '../../pwned.html', data: 'pwned' },
    ]);
    const res = await admin.upload('/admin/apps', {
      _csrf: tokenOf(admin), title: '악성', slug: 'evil1', description: '', visibility: 'all',
    }, { field: 'file', filename: 'evil.zip', data: evil, contentType: 'application/zip' });

    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('안전하지 않은 경로'), '차단 메시지');
  });

  await test('백슬래시 경로 탈출이 든 ZIP 은 거부', async () => {
    const evil = makeZip([
      { name: 'index.html', data: 'ok' },
      { name: '..\\..\\pwned.html', data: 'pwned' },
    ]);
    const res = await admin.upload('/admin/apps', {
      _csrf: tokenOf(admin), title: '악성2', slug: 'evil2', description: '', visibility: 'all',
    }, { field: 'file', filename: 'evil.zip', data: evil, contentType: 'application/zip' });
    equal(res.status, 400, '상태 코드');
  });

  await test('실행 파일이 든 ZIP 은 업로드 전체가 거부', async () => {
    const evil = makeZip([
      { name: 'index.html', data: 'ok' },
      { name: 'setup.exe', data: 'MZ...' },
    ]);
    const res = await admin.upload('/admin/apps', {
      _csrf: tokenOf(admin), title: '악성3', slug: 'evil3', description: '', visibility: 'all',
    }, { field: 'file', filename: 'evil.zip', data: evil, contentType: 'application/zip' });

    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('허용되지 않는 파일'), '차단 메시지');
    assert(res.text.includes('setup.exe'), '문제 파일 표시');
  });

  await test('HTML 이 없는 ZIP 은 거부', async () => {
    const noHtml = makeZip([{ name: 'data.csv', data: 'a,b,c' }]);
    const res = await admin.upload('/admin/apps', {
      _csrf: tokenOf(admin), title: 'HTML없음', slug: 'nohtml', description: '', visibility: 'all',
    }, { field: 'file', filename: 'x.zip', data: noHtml, contentType: 'application/zip' });
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('HTML 파일이 없습니다'), '안내 메시지');
  });

  await test('CSRF 토큰 없는 업로드는 403', async () => {
    const res = await admin.upload('/admin/apps', {
      title: 'no-csrf', slug: 'nocsrf', description: '', visibility: 'all',
    }, { field: 'file', filename: 'a.html', data: SAMPLE_HTML });
    equal(res.status, 403, '상태 코드');
  });

  await test('일반 사용자는 업로드할 수 없다', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.upload('/admin/apps', {
      _csrf: tokenOf(c), title: '침입', slug: 'intrude', description: '', visibility: 'all',
    }, { field: 'file', filename: 'a.html', data: SAMPLE_HTML });
    equal(res.status, 403, '상태 코드');
  });

  await test('중복 주소(slug)는 거부', async () => {
    const res = await admin.upload('/admin/apps', {
      _csrf: tokenOf(admin), title: '중복', slug: 'sales', description: '', visibility: 'all',
    }, { field: 'file', filename: 'a.html', data: SAMPLE_HTML });
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('이미 사용 중인 주소'), '오류 메시지');
  });

  /* ------------------------------ 보호 서빙 ------------------------------ */

  section('Phase 3 — 보호 서빙 (핵심)');

  await test('비로그인 상태에서 콘텐츠 직접 접근 시 로그인 화면으로', async () => {
    const c = createClient();
    const res = await c.request('/app/quality/');
    equal(res.status, 302, '상태 코드');
    assert(res.location.startsWith('/login'), 'Location');
    assert(!res.text.includes('ZIP 콘텐츠'), '내용이 노출되면 안 됨');
  });

  await test('비로그인 상태에서 하위 리소스 직접 접근도 차단', async () => {
    const c = createClient();
    const res = await c.request('/app/quality/js/app.js');
    equal(res.status, 302, '상태 코드');
    assert(!res.text.includes('console.log'), '스크립트가 노출되면 안 됨');
  });

  await test('로그인하면 전체 공개 콘텐츠를 볼 수 있다', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/app/quality/');
    equal(res.status, 200, '상태 코드');
    assert(res.text.includes('ZIP 콘텐츠'), '본문 표시');
    equal(res.headers.get('content-type'), 'text/html; charset=utf-8', 'MIME');
  });

  await test('하위 리소스도 로그인 후에는 정상 제공되고 MIME 이 맞다', async () => {
    const c = await login('user1', 'UserPass!234');
    const js = await c.request('/app/quality/js/app.js');
    equal(js.status, 200, 'JS 상태 코드');
    assert(js.text.includes('console.log'), 'JS 내용');
    equal(js.headers.get('content-type'), 'text/javascript; charset=utf-8', 'JS MIME');

    const png = await c.request('/app/quality/img/%EC%82%AC%EC%A7%84.png');
    equal(png.status, 200, '한글 파일명 PNG');
    equal(png.headers.get('content-type'), 'image/png', 'PNG MIME');
  });

  await test('콘텐츠 응답은 캐시되지 않는다', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/app/quality/');
    assert(res.headers.get('cache-control').includes('no-store'), 'no-store 필요');
  });

  await test('HTML 에 로그인 사용자 정보가 주입된다', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/app/quality/');
    assert(res.text.includes('__PORTAL_USER__'), '주입 스크립트 존재');
    assert(res.text.includes('홍길동'), '사용자 이름 포함');
    assert(!res.text.includes('</script><script>alert'), '주입이 문서를 깨뜨리지 않음');
  });

  await test('/app/:slug 는 슬래시 붙은 주소로 리다이렉트 (상대경로 보존)', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/app/quality');
    equal(res.status, 301, '상태 코드');
    equal(res.location, '/app/quality/', 'Location');
  });

  section('Phase 3 — 경로 탈출 방어');

  const traversals = [
    ['상위 디렉터리', '/app/quality/../../data/portal.db'],
    ['인코딩된 상위', '/app/quality/%2e%2e%2f%2e%2e%2fdata%2fportal.db'],
    ['이중 인코딩', '/app/quality/%252e%252e%252fportal.db'],
    ['절대 경로 흉내', '/app/quality//etc/passwd'],
    ['다른 앱 침범', '/app/quality/../1/index.html'],
    ['널바이트', '/app/quality/index.html%00.png'],
  ];

  for (const [label, target] of traversals) {
    await test(`경로 탈출 차단 — ${label}`, async () => {
      const c = await login('user1', 'UserPass!234');
      const res = await c.request(target);
      assert(res.status >= 400 || res.status === 302,
        `차단되어야 함 (실제: ${res.status})`);
      assert(!res.text.includes('SQLite'), 'DB 내용 노출 없음');
      assert(!res.text.includes('root:'), 'passwd 내용 노출 없음');
    });
  }

  await test('허용되지 않은 확장자는 콘텐츠 폴더 안에서도 서빙되지 않음', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/app/quality/../../portal.db');
    assert(res.status >= 400, '차단');
  });

  section('Phase 3 — 접근 권한');

  await test('권한 없는 사용자는 지정 공개 콘텐츠를 열 수 없다 (403)', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/app/sales/');
    equal(res.status, 403, '상태 코드');
    assert(!res.text.includes('매출'), '내용이 노출되면 안 됨');
  });

  await test('권한을 부여하면 열 수 있다', async () => {
    const userId = await idOfUser('user1');
    const res = await admin.form(`/admin/apps/${htmlAppId}/access`, {
      _csrf: tokenOf(admin), user: [userId],
    });
    equal(res.status, 302, '권한 저장');

    const c = await login('user1', 'UserPass!234');
    const page = await c.request('/app/sales/');
    equal(page.status, 200, '접근 가능');
    assert(page.text.includes('매출'), '본문 표시');
  });

  await test('권한을 회수하면 다시 막힌다', async () => {
    const res = await admin.form(`/admin/apps/${htmlAppId}/access`, {
      _csrf: tokenOf(admin),
    });
    equal(res.status, 302, '권한 비우기');

    const c = await login('user1', 'UserPass!234');
    equal((await c.request('/app/sales/')).status, 403, '다시 403');
  });

  await test('관리자는 권한 지정 없이도 모든 콘텐츠를 볼 수 있다', async () => {
    equal((await admin.request('/app/sales/')).status, 200, '관리자 접근');
  });

  await test('대시보드에는 볼 수 있는 콘텐츠만 나온다', async () => {
    const c = await login('user1', 'UserPass!234');
    const home = await c.request('/');
    assert(home.text.includes('품질 리포트'), '전체 공개 콘텐츠는 보임');
    assert(!home.text.includes('영업 대시보드'), '권한 없는 콘텐츠는 안 보임');
  });

  await test('숨김 처리한 콘텐츠는 아무도 열 수 없다 (관리자 포함)', async () => {
    const res = await admin.form(`/admin/apps/${zipAppId}/toggle`, { _csrf: tokenOf(admin) });
    equal(res.status, 302, '숨김 요청');

    const c = await login('user1', 'UserPass!234');
    equal((await c.request('/app/quality/')).status, 404, '일반 사용자');
    equal((await admin.request('/app/quality/')).status, 404, '관리자');

    await admin.form(`/admin/apps/${zipAppId}/toggle`, { _csrf: tokenOf(admin) });
    equal((await admin.request('/app/quality/')).status, 200, '다시 공개');
  });

  section('Phase 3 — 교체 / 삭제 / 기록');

  await test('파일 교체가 반영된다', async () => {
    const zipBuf = makeZip([
      { name: 'index.html', data: '<html><head></head><body>새 버전입니다</body></html>' },
    ]);
    const res = await admin.upload(`/admin/apps/${zipAppId}/replace`, {
      _csrf: tokenOf(admin),
    }, { field: 'file', filename: 'v2.zip', data: zipBuf, contentType: 'application/zip' });
    equal(res.status, 302, '교체 요청');

    const page = await admin.request('/app/quality/');
    assert(page.text.includes('새 버전입니다'), '새 내용');

    const gone = await admin.request('/app/quality/js/app.js');
    equal(gone.status, 404, '이전 파일은 사라져야 함');
  });

  await test('교체에 실패하면 기존 버전이 유지된다', async () => {
    const evil = makeZip([
      { name: 'index.html', data: '덮어쓰기 시도' },
      { name: 'hack.bat', data: 'del *.*' },
    ]);
    const res = await admin.upload(`/admin/apps/${zipAppId}/replace`, {
      _csrf: tokenOf(admin),
    }, { field: 'file', filename: 'bad.zip', data: evil, contentType: 'application/zip' });
    equal(res.status, 400, '거부');

    const page = await admin.request('/app/quality/');
    assert(page.text.includes('새 버전입니다'), '기존 버전 유지');
  });

  await test('열람 기록이 남는다', async () => {
    const logs = await admin.request('/admin/logs');
    equal(logs.status, 200, '조회');
    assert(logs.text.includes('quality'), '콘텐츠 기록');
    assert(logs.text.includes('user1'), '사용자 기록');
  });

  await test('거부된 접근도 기록된다', async () => {
    const logs = await admin.request('/admin/logs?result=denied');
    equal(logs.status, 200, '조회');
    assert(logs.text.includes('sales'), '거부 기록에 대상 콘텐츠가 남아야 함');
  });

  await test('접근 기록 CSV 내려받기', async () => {
    const res = await admin.request('/admin/logs/export');
    equal(res.status, 200, '상태 코드');
    assert(res.headers.get('content-disposition').includes('attachment'), '첨부 헤더');
    equal(res.body[0], 0xef, 'UTF-8 BOM (Excel 한글)');
    assert(res.text.includes('시각,아이디,콘텐츠'), '머리글');
  });

  await test('콘텐츠를 삭제하면 파일도 접근 불가가 된다', async () => {
    const res = await admin.form(`/admin/apps/${htmlAppId}/delete`, {
      _csrf: tokenOf(admin), confirm_slug: 'sales',
    });
    equal(res.status, 302, '삭제 요청');
    equal((await admin.request('/app/sales/')).status, 404, '삭제 후 접근');
  });

  await test('확인 문자열이 틀리면 삭제되지 않는다', async () => {
    const res = await admin.form(`/admin/apps/${zipAppId}/delete`, {
      _csrf: tokenOf(admin), confirm_slug: 'wrong',
    });
    equal(res.status, 400, '거부');
    equal((await admin.request('/app/quality/')).status, 200, '콘텐츠 유지');
  });
};
