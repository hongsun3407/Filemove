'use strict';
/** Phase 1 — 인증 / 세션 / 접근 통제 */
const {
  test, section, assert, equal, createClient, csrfOf, login,
} = require('./harness');

module.exports = async function run() {
  section('접근 통제');

  await test('비로그인 상태로 / 요청 시 로그인 화면으로 리다이렉트', async () => {
    const c = createClient();
    const res = await c.request('/');
    equal(res.status, 302, '상태 코드');
    assert(res.location.startsWith('/login'), `Location (실제: ${res.location})`);
  });

  await test('비로그인 상태로 관리자 화면 요청 시 차단', async () => {
    const c = createClient();
    const res = await c.request('/admin/users');
    equal(res.status, 302, '상태 코드');
    assert(res.location.startsWith('/login'), 'Location');
  });

  await test('일반 사용자는 관리자 화면에 접근할 수 없음 (403)', async () => {
    const c = await login('user1', 'UserPass!234');
    equal((await c.request('/admin/users')).status, 403, '사용자 관리');
    equal((await c.request('/admin/apps')).status, 403, '콘텐츠 관리');
    equal((await c.request('/admin/logs')).status, 403, '접근 기록');
  });

  section('로그인');

  await test('잘못된 비밀번호는 401 로 거부', async () => {
    const c = createClient();
    const page = await c.request('/login');
    const res = await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'user1', password: 'wrong', next: '/',
    });
    equal(res.status, 401, '상태 코드');
    assert(res.text.includes('올바르지 않습니다'), '오류 메시지 표시');
  });

  await test('없는 아이디와 틀린 비밀번호의 메시지가 동일 (사용자 열거 방지)', async () => {
    const c1 = createClient();
    const p1 = await c1.request('/login');
    const r1 = await c1.form('/login', {
      _csrf: csrfOf(p1.text), login_id: 'nobody-here', password: 'x', next: '/',
    });

    const c2 = createClient();
    const p2 = await c2.request('/login');
    const r2 = await c2.form('/login', {
      _csrf: csrfOf(p2.text), login_id: 'user1', password: 'wrong', next: '/',
    });

    equal(r1.status, r2.status, '상태 코드');
    const msg = /class="banner err">([^<]+)</;
    equal(msg.exec(r1.text)[1], msg.exec(r2.text)[1], '오류 메시지');
  });

  await test('비활성화된 계정은 비밀번호가 맞아도 로그인 불가', async () => {
    const c = createClient();
    const page = await c.request('/login');
    const res = await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'gone', password: 'UserPass!234', next: '/',
    });
    equal(res.status, 401, '상태 코드');
    assert(!c.get('portal.sid'), '세션 쿠키가 발급되면 안 됨');
  });

  await test('정상 로그인 후 대시보드 접근', async () => {
    const c = await login('user1', 'UserPass!234');
    const home = await c.request('/');
    equal(home.status, 200, '대시보드 상태 코드');
    assert(home.text.includes('홍길동'), '사용자 이름 표시');
  });

  await test('로그인 시 세션 ID 가 새로 발급됨 (세션 고정 방어)', async () => {
    const c = createClient();
    const page = await c.request('/login');
    assert(!c.get('portal.sid'), '로그인 전 세션 쿠키 없음');
    const before = c.get('portal.csrf');
    await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'user1', password: 'UserPass!234', next: '/',
    });
    assert(c.get('portal.sid'), '로그인 후 세션 쿠키 발급');
    assert(c.get('portal.csrf') !== before, 'CSRF 토큰도 회전되어야 함');
  });

  section('CSRF');

  await test('CSRF 토큰 없는 POST 는 403', async () => {
    const c = createClient();
    await c.request('/login');
    const res = await c.form('/login', { login_id: 'user1', password: 'UserPass!234' });
    equal(res.status, 403, '상태 코드');
  });

  await test('위조된 CSRF 토큰은 403', async () => {
    const c = createClient();
    await c.request('/login');
    const res = await c.form('/login', {
      _csrf: 'forged-token-value', login_id: 'user1', password: 'UserPass!234',
    });
    equal(res.status, 403, '상태 코드');
  });

  section('임시 비밀번호 강제 변경');

  await test('임시 비밀번호 사용자는 비밀번호 변경 화면으로 강제 이동', async () => {
    const c = createClient();
    const page = await c.request('/login');
    const res = await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'admin', password: 'TempPass!234', next: '/',
    });
    equal(res.location, '/change-password', '로그인 직후 Location');
    const home = await c.request('/');
    equal(home.status, 302, '대시보드 접근 시 상태 코드');
    equal(home.location, '/change-password', '대시보드 접근 시 Location');
  });

  await test('약한 새 비밀번호는 거부', async () => {
    const c = createClient();
    const page = await c.request('/login');
    await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'admin', password: 'TempPass!234', next: '/',
    });
    const form = await c.request('/change-password');
    const res = await c.form('/change-password', {
      _csrf: csrfOf(form.text), current: 'TempPass!234', next_pw: 'short1', confirm: 'short1',
    });
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('10자 이상'), '정책 안내 표시');
  });

  await test('비밀번호에 아이디를 포함하면 거부', async () => {
    const c = createClient();
    const page = await c.request('/login');
    await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'admin', password: 'TempPass!234', next: '/',
    });
    const form = await c.request('/change-password');
    const res = await c.form('/change-password', {
      _csrf: csrfOf(form.text), current: 'TempPass!234',
      next_pw: 'NewAdminPass!2026', confirm: 'NewAdminPass!2026',
    });
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('아이디를 포함'), '정책 안내 표시');
  });

  await test('비밀번호 변경 성공 후 대시보드 사용 가능', async () => {
    const c = createClient();
    const page = await c.request('/login');
    await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'admin', password: 'TempPass!234', next: '/',
    });
    const form = await c.request('/change-password');
    const res = await c.form('/change-password', {
      _csrf: csrfOf(form.text), current: 'TempPass!234',
      next_pw: 'Kw9!SecurePhrase26', confirm: 'Kw9!SecurePhrase26',
    });
    equal(res.status, 302, '상태 코드');
    equal(res.location, '/?m=password-changed', 'Location');
    equal((await c.request('/')).status, 200, '대시보드 접근');
  });

  await test('변경된 비밀번호로 재로그인 가능하고 옛 비밀번호는 실패', async () => {
    const c = createClient();
    const page = await c.request('/login');
    const bad = await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'admin', password: 'TempPass!234', next: '/',
    });
    equal(bad.status, 401, '옛 비밀번호');

    const c2 = await login('admin', 'Kw9!SecurePhrase26');
    equal((await c2.request('/')).status, 200, '새 비밀번호로 접근');
  });

  section('계정 잠금');

  await test('5회 연속 실패 시 계정 잠금, 이후 올바른 비밀번호도 거부', async () => {
    const c = createClient();
    for (let i = 0; i < 5; i++) {
      const page = await c.request('/login');
      await c.form('/login', {
        _csrf: csrfOf(page.text), login_id: 'locktest', password: `wrong${i}`, next: '/',
      });
    }
    const page = await c.request('/login');
    const res = await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'locktest', password: 'UserPass!234', next: '/',
    });
    equal(res.status, 401, '상태 코드');
    assert(res.text.includes('잠겨'), '잠금 안내가 표시되어야 함');
  });

  section('로그아웃');

  await test('로그아웃 후 세션이 서버에서 무효화됨', async () => {
    const c = await login('user1', 'UserPass!234');
    const sid = c.get('portal.sid');
    equal((await c.request('/')).status, 200, '로그아웃 전 대시보드');

    const out = await c.form('/logout', { _csrf: c.get('portal.csrf') });
    equal(out.status, 302, '로그아웃 상태 코드');

    // 쿠키를 되살려도 서버측 세션이 지워졌으므로 통과하면 안 됩니다.
    c.jar.set('portal.sid', sid);
    const after = await c.request('/');
    equal(after.status, 302, '무효화된 세션으로 재접근');
    assert(after.location.startsWith('/login'), 'Location');
  });

  await test('로그아웃은 GET 으로 불가 (405)', async () => {
    const c = createClient();
    equal((await c.request('/logout')).status, 405, '상태 코드');
  });

  section('기타 방어');

  await test('오픈 리다이렉트 차단 (next=//evil.example)', async () => {
    const c = createClient();
    const page = await c.request('/login?next=//evil.example/path');
    assert(page.text.includes('name="next" value="/"'), 'next 값이 / 로 정규화되어야 함');

    const res = await c.form('/login', {
      _csrf: csrfOf(page.text), login_id: 'user1', password: 'UserPass!234',
      next: '//evil.example/path',
    });
    equal(res.location, '/', '외부 주소로 리다이렉트되면 안 됨');
  });

  await test('정적 경로 탈출 시도 차단', async () => {
    const c = createClient();
    const res = await c.request('/static/../data/portal.db');
    assert(res.status === 403 || res.status === 404, `403/404 여야 함 (실제: ${res.status})`);
    assert(!res.text.includes('SQLite'), 'DB 내용이 노출되면 안 됨');
  });

  await test('허용되지 않은 확장자의 정적 파일 요청 차단', async () => {
    const c = createClient();
    const res = await c.request('/static/../../package.json');
    assert(res.status === 403 || res.status === 404, '차단되어야 함');
  });

  await test('보안 응답 헤더가 설정됨', async () => {
    const c = createClient();
    const res = await c.request('/login');
    equal(res.headers.get('x-content-type-options'), 'nosniff', 'nosniff');
    equal(res.headers.get('x-frame-options'), 'SAMEORIGIN', 'X-Frame-Options');
    assert(res.headers.get('content-security-policy'), 'CSP 헤더 존재');
    assert(res.headers.get('x-robots-tag').includes('noindex'), '검색엔진 색인 차단');
    assert(!res.headers.get('x-powered-by'), 'X-Powered-By 노출 없음');
  });

  await test('인증 페이지 응답이 캐시되지 않음', async () => {
    const c = await login('user1', 'UserPass!234');
    const home = await c.request('/');
    assert(home.headers.get('cache-control').includes('no-store'), 'no-store 필요');
  });

  await test('세션 쿠키에 HttpOnly 와 SameSite 가 설정됨', async () => {
    const raw = await fetch(`${require('./harness').BASE}/login`, { redirect: 'manual' });
    await raw.text();
    const jar = raw.headers.getSetCookie();
    const csrfCookie = jar.find((c) => c.startsWith('portal.csrf='));
    assert(csrfCookie.includes('HttpOnly'), 'HttpOnly');
    assert(csrfCookie.includes('SameSite=Lax'), 'SameSite');
  });

  await test('HTML 이스케이프 동작 (XSS 방어)', async () => {
    const c = createClient();
    const page = await c.request('/login');
    const res = await c.form('/login', {
      _csrf: csrfOf(page.text),
      login_id: '"><script>alert(1)</script>',
      password: 'x', next: '/',
    });
    assert(!res.text.includes('<script>alert(1)</script>'), '스크립트가 그대로 삽입되면 안 됨');
    assert(res.text.includes('&lt;script&gt;'), '이스케이프된 형태로 표시되어야 함');
  });
};
