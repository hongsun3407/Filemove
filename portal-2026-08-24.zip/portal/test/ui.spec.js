'use strict';
/**
 * 사이드바 · 정렬 순서 · 다중 파일 업로드 · 파일 관리 · 썸네일 · 설명 서식
 */
const { test, section, assert, equal, login, tokenOf } = require('./harness');
const { makeZip } = require('./zipmaker');

const PNG = Buffer.from([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
  0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
]);

function appIdOf(res) {
  const m = /\/admin\/apps\/(\d+)/.exec(res.location || '');
  if (!m) throw new Error(`앱 id 를 찾을 수 없습니다 (status=${res.status}, location=${res.location})`);
  return m[1];
}

module.exports = async function run() {
  const admin = await login('admin', 'Kw9!SecurePhrase26');

  /* ------------------------------ 다중 파일 업로드 ------------------------------ */

  section('다중 파일 업로드');

  let multiId = null;

  await test('HTML 과 이미지를 한 번에 올릴 수 있다 (ZIP 없이)', async () => {
    const res = await admin.uploadMany('/admin/apps', {
      _csrf: tokenOf(admin),
      title: '생산 현황판', slug: 'prod', description: '', visibility: 'all',
    }, [
      { field: 'file', filename: 'index.html', contentType: 'text/html',
        data: '<html><head></head><body><img src="./로고.png"><p>현황</p></body></html>' },
      { field: 'file', filename: '로고.png', contentType: 'image/png', data: PNG },
      { field: 'file', filename: 'style.css', contentType: 'text/css', data: 'body{margin:0}' },
    ]);
    equal(res.status, 302, '상태 코드');
    multiId = appIdOf(res);

    const detail = await admin.request(`/admin/apps/${multiId}`);
    assert(detail.text.includes('로고.png'), '이미지 파일이 목록에 있어야 함');
    assert(detail.text.includes('style.css'), 'CSS 파일이 목록에 있어야 함');
  });

  await test('함께 올린 이미지가 콘텐츠 경로로 제공된다', async () => {
    const res = await admin.request('/app/prod/%EB%A1%9C%EA%B3%A0.png');
    equal(res.status, 200, '상태 코드');
    equal(res.headers.get('content-type'), 'image/png', 'MIME');
    equal(res.body.length, PNG.length, '내용 길이');
  });

  await test('첫 이미지가 대표 이미지로 자동 지정된다', async () => {
    const detail = await admin.request(`/admin/apps/${multiId}`);
    assert(/<option value="로고.png" selected>/.test(detail.text)
      || detail.text.includes('로고.png" selected'), '대표 이미지 선택 상태');
  });

  await test('여러 파일 중 실행 파일이 있으면 전체 거부', async () => {
    const res = await admin.uploadMany('/admin/apps', {
      _csrf: tokenOf(admin), title: '악성4', slug: 'evil4', description: '', visibility: 'all',
    }, [
      { field: 'file', filename: 'index.html', data: 'ok' },
      { field: 'file', filename: 'run.bat', data: 'del *.*' },
    ]);
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('허용되지 않는 파일'), '차단 메시지');
  });

  await test('파일 이름으로 경로 탈출 시도는 거부', async () => {
    const res = await admin.uploadMany('/admin/apps', {
      _csrf: tokenOf(admin), title: '악성5', slug: 'evil5', description: '', visibility: 'all',
    }, [
      { field: 'file', filename: '../../escape.html', data: 'pwned' },
    ]);
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('사용할 수 없는 파일 이름'), '차단 메시지');
  });

  await test('ZIP 과 다른 파일을 섞으면 거부', async () => {
    const zipBuf = makeZip([{ name: 'index.html', data: 'ok' }]);
    const res = await admin.uploadMany('/admin/apps', {
      _csrf: tokenOf(admin), title: '혼합', slug: 'mixed', description: '', visibility: 'all',
    }, [
      { field: 'file', filename: 'a.zip', data: zipBuf },
      { field: 'file', filename: 'b.png', data: PNG },
    ]);
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('ZIP 은 다른 파일과 함께'), '안내 메시지');
  });

  /* ------------------------------ 파일 추가 / 삭제 ------------------------------ */

  section('파일 관리 (추가 / 삭제)');

  await test('기존 콘텐츠에 이미지를 더할 수 있다', async () => {
    const res = await admin.uploadMany(`/admin/apps/${multiId}/files`, {
      _csrf: tokenOf(admin),
    }, [
      { field: 'file', filename: 'img/추가사진.png', contentType: 'image/png', data: PNG },
    ]);
    equal(res.status, 302, '상태 코드');

    const file = await admin.request('/app/prod/img/%EC%B6%94%EA%B0%80%EC%82%AC%EC%A7%84.png');
    equal(file.status, 200, '추가된 파일 접근');

    // 기존 파일도 그대로 있어야 합니다.
    equal((await admin.request('/app/prod/style.css')).status, 200, '기존 파일 유지');
  });

  await test('파일을 지울 수 있다', async () => {
    const res = await admin.form(`/admin/apps/${multiId}/files/delete`, {
      _csrf: tokenOf(admin), path: 'style.css',
    });
    equal(res.status, 302, '상태 코드');
    equal((await admin.request('/app/prod/style.css')).status, 404, '삭제 후 접근');
  });

  await test('시작 파일은 지울 수 없다', async () => {
    const res = await admin.form(`/admin/apps/${multiId}/files/delete`, {
      _csrf: tokenOf(admin), path: 'index.html',
    });
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('시작 파일은 지울 수 없습니다'), '거부 메시지');
    equal((await admin.request('/app/prod/')).status, 200, '콘텐츠 유지');
  });

  await test('파일 삭제도 경로 탈출을 막는다', async () => {
    for (const evil of ['../../../data/portal.db', '..\\..\\portal.db', '/etc/passwd']) {
      const res = await admin.form(`/admin/apps/${multiId}/files/delete`, {
        _csrf: tokenOf(admin), path: evil,
      });
      equal(res.status, 400, `거부되어야 함: ${evil}`);
    }
    equal((await admin.request('/app/prod/')).status, 200, '콘텐츠는 멀쩡해야 함');
  });

  /* ------------------------------ 정렬 순서 ------------------------------ */

  section('정렬 순서');

  function slugOrder(html) {
    return [...html.matchAll(/<code>\/app\/([a-z0-9-]+)\//g)].map((m) => m[1]);
  }

  await test('관리자 목록이 정렬 순서대로 나온다', async () => {
    const page = await admin.request('/admin/apps');
    equal(page.status, 200, '상태 코드');
    assert(slugOrder(page.text).length >= 2, '콘텐츠가 2개 이상이어야 순서를 확인할 수 있음');
  });

  await test('아래로 옮기면 순서가 바뀐다', async () => {
    const before = slugOrder((await admin.request('/admin/apps')).text);
    const first = before[0];

    const list = await admin.request('/admin/apps');
    const m = new RegExp(`/admin/apps/(\\d+)/move[\\s\\S]*?value="down"`).exec(list.text);
    assert(m, '이동 버튼을 찾아야 함');

    const res = await admin.form(`/admin/apps/${m[1]}/move`, {
      _csrf: tokenOf(admin), dir: 'down',
    });
    equal(res.status, 302, '상태 코드');

    const after = slugOrder((await admin.request('/admin/apps')).text);
    assert(after[0] !== first, `맨 위가 바뀌어야 함 (before=${before}, after=${after})`);
    equal(after[1], first, '내려간 항목이 두 번째여야 함');
  });

  /** 사이드바 영역 안의 링크 순서만 뽑습니다 (본문 카드 링크와 섞이지 않도록) */
  function sidebarOrder(html) {
    const aside = /<aside class="sidebar">([\s\S]*?)<\/aside>/.exec(html);
    if (!aside) throw new Error('사이드바를 찾지 못했습니다');
    return [...aside[1].matchAll(/href="\/view\/([a-z0-9-]+)"/g)].map((m) => m[1]);
  }

  await test('사이드바가 관리자 순서를 따른다', async () => {
    const adminOrder = slugOrder((await admin.request('/admin/apps')).text);
    const sideOrder = sidebarOrder((await admin.request('/')).text);

    assert(sideOrder.length >= 2, '사이드바에 콘텐츠가 2개 이상이어야 함');
    const activeInAdmin = adminOrder.filter((s) => sideOrder.includes(s));
    equal(sideOrder.join(','), activeInAdmin.join(','), '순서 일치');
  });

  await test('위로 옮기면 다시 돌아온다', async () => {
    const list = await admin.request('/admin/apps');
    const ids = [...list.matchAll ? [] : []];
    const m = /<tbody>[\s\S]*?<tr[\s\S]*?<\/tr>\s*<tr[\s\S]*?\/admin\/apps\/(\d+)\/move/.exec(list.text);
    assert(m, '두 번째 행의 이동 버튼을 찾아야 함');
    void ids;

    const res = await admin.form(`/admin/apps/${m[1]}/move`, {
      _csrf: tokenOf(admin), dir: 'up',
    });
    equal(res.status, 302, '상태 코드');
  });

  /* ------------------------------ 사이드바 / 뷰어 ------------------------------ */

  section('사이드바와 뷰어');

  await test('홈에 사이드바가 있고 콘텐츠 링크가 /view/ 를 가리킨다', async () => {
    const c = await login('user1', 'UserPass!234');
    const home = await c.request('/');
    equal(home.status, 200, '상태 코드');
    assert(home.text.includes('class="sidebar"'), '사이드바 존재');
    assert(home.text.includes('href="/view/prod"'), '뷰어 링크');
  });

  await test('뷰어 화면이 사이드바와 iframe 을 함께 보여준다', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/view/prod');
    equal(res.status, 200, '상태 코드');
    assert(res.text.includes('class="sidebar"'), '사이드바 유지');
    assert(res.text.includes('src="/app/prod/"'), 'iframe 이 콘텐츠를 가리킴');
    assert(res.text.includes('class="side-item on"'), '현재 항목이 강조되어야 함');
  });

  await test('권한 없는 콘텐츠의 뷰어는 404', async () => {
    const res = await admin.uploadMany('/admin/apps', {
      _csrf: tokenOf(admin),
      title: '비밀 자료', slug: 'secret', description: '', visibility: 'restricted',
    }, [{ field: 'file', filename: 'index.html',
      data: '<html><head></head><body>CONFIDENTIAL-BODY</body></html>' }]);
    equal(res.status, 302, '업로드');

    const c = await login('user1', 'UserPass!234');
    const view = await c.request('/view/secret');
    equal(view.status, 404, '상태 코드');
    assert(!view.text.includes('CONFIDENTIAL-BODY'), '본문 노출 없음');
    assert(!view.text.includes('비밀 자료'), '제목 노출 없음');
  });

  await test('비로그인 상태의 뷰어 접근은 로그인 화면으로', async () => {
    const { createClient } = require('./harness');
    const c = createClient();
    const res = await c.request('/view/prod');
    equal(res.status, 302, '상태 코드');
    assert(res.location.startsWith('/login'), 'Location');
  });

  /* ------------------------------ 썸네일 / 설명 ------------------------------ */

  section('대표 이미지와 설명 서식');

  await test('설명에 이미지와 서식을 넣으면 안전하게 렌더링된다', async () => {
    const res = await admin.form(`/admin/apps/${multiId}`, {
      _csrf: tokenOf(admin),
      title: '생산 현황판',
      description: '**중요** 라인 현황입니다.\n\n![로고](로고.png)\n\n- 첫째\n- 둘째',
      entry_file: 'index.html', thumbnail: '로고.png', visibility: 'all',
    });
    equal(res.status, 302, '저장');

    const home = await admin.request('/');
    assert(home.text.includes('<strong>중요</strong>'), '굵게 렌더링');
    assert(home.text.includes('<li>첫째</li>'), '목록 렌더링');
    assert(home.text.includes('src="/app/prod/%EB%A1%9C%EA%B3%A0.png"')
      || home.text.includes('src="/app/prod/로고.png"'), '이미지 렌더링');
  });

  await test('설명에 넣은 HTML 은 태그로 해석되지 않는다 (XSS 방어)', async () => {
    const res = await admin.form(`/admin/apps/${multiId}`, {
      _csrf: tokenOf(admin),
      title: '생산 현황판',
      description: '<script>alert(1)</script><img src=x onerror=alert(2)>',
      entry_file: 'index.html', thumbnail: '', visibility: 'all',
    });
    equal(res.status, 302, '저장');

    const home = await admin.request('/');
    // 이스케이프된 "텍스트"로 남는 것은 정상입니다. 실제 태그가 되면 안 됩니다.
    assert(!home.text.includes('<script>alert(1)</script>'), '스크립트 태그가 살아 있으면 안 됨');
    assert(!/<img[^>]*onerror/i.test(home.text), 'onerror 속성이 붙은 img 태그가 있으면 안 됨');
    assert(home.text.includes('&lt;script&gt;'), '이스케이프된 형태로 표시');
  });

  await test('설명 이미지로 외부 주소나 상위 경로는 쓸 수 없다', async () => {
    await admin.form(`/admin/apps/${multiId}`, {
      _csrf: tokenOf(admin),
      title: '생산 현황판',
      description: '![x](https://evil.example/track.gif)\n\n![y](../../portal.db)',
      entry_file: 'index.html', thumbnail: '', visibility: 'all',
    });
    const home = await admin.request('/');
    assert(!/<img[^>]*evil\.example/i.test(home.text), '외부 주소로 img 태그가 만들어지면 안 됨');
    assert(!home.text.includes('evil.example'), '외부 주소가 화면에 남지 않아야 함');
    assert(!/<img[^>]+\.\./.test(home.text), '상위 경로 차단');
    assert(home.text.includes('이미지를 표시할 수 없습니다'), '거부되었음을 알려야 함');
  });

  await test('없는 파일을 대표 이미지로 지정하면 거부', async () => {
    const res = await admin.form(`/admin/apps/${multiId}`, {
      _csrf: tokenOf(admin), title: '생산 현황판', description: '',
      entry_file: 'index.html', thumbnail: '../../portal.db', visibility: 'all',
    });
    equal(res.status, 400, '상태 코드');
    assert(res.text.includes('대표 이미지가 올바르지 않습니다'), '거부 메시지');
  });

  await test('대표 이미지 파일을 지우면 설정이 자동으로 비워진다', async () => {
    await admin.form(`/admin/apps/${multiId}`, {
      _csrf: tokenOf(admin), title: '생산 현황판', description: '',
      entry_file: 'index.html', thumbnail: '로고.png', visibility: 'all',
    });
    const res = await admin.form(`/admin/apps/${multiId}/files/delete`, {
      _csrf: tokenOf(admin), path: '로고.png',
    });
    equal(res.status, 302, '삭제');

    const home = await admin.request('/');
    assert(!home.text.includes('src="/app/prod/%EB%A1%9C%EA%B3%A0.png"'), '깨진 이미지가 남으면 안 됨');
    equal(home.status, 200, '홈은 정상 표시');
  });
};
