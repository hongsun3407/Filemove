'use strict';
/** 압축 다운로드 · 다운로드 허용 스위치 · 전체 백업 */
const { test, section, assert, equal, createClient, login, tokenOf } = require('./harness');
const zip = require('../src/lib/zip');

const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3, 4]);

function appIdOf(res) {
  const m = /\/admin\/apps\/(\d+)/.exec(res.location || '');
  if (!m) throw new Error(`앱 id 를 찾을 수 없습니다 (status=${res.status})`);
  return m[1];
}

/** 응답 본문을 우리 ZIP 리더로 되읽어 항목 이름 → 내용 맵으로 */
function unzip(body) {
  const map = new Map();
  for (const e of zip.read(body)) map.set(e.name, e.data);
  return map;
}

module.exports = async function run() {
  const admin = await login('admin', 'Kw9!SecurePhrase26');

  section('콘텐츠 압축 다운로드');

  let dlId = null;

  await test('내려받기용 콘텐츠 준비', async () => {
    const res = await admin.uploadMany('/admin/apps', {
      _csrf: tokenOf(admin),
      title: '배포용 자료', slug: 'dist', description: '', visibility: 'all',
    }, [
      { field: 'file', filename: 'index.html', contentType: 'text/html',
        data: '<html><head></head><body>배포 자료 본문</body></html>' },
      { field: 'file', filename: 'css/style.css', contentType: 'text/css', data: 'body{color:red}' },
      { field: 'file', filename: '그림.png', contentType: 'image/png', data: PNG },
    ]);
    equal(res.status, 302, '업로드');
    dlId = appIdOf(res);
  });

  await test('ZIP 을 받으면 올린 파일이 그대로 들어 있다', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/download/dist');

    equal(res.status, 200, '상태 코드');
    equal(res.headers.get('content-type'), 'application/zip', 'MIME');
    assert(res.headers.get('content-disposition').includes('attachment'), '첨부 헤더');
    assert(res.headers.get('content-disposition').includes("filename*=UTF-8''"),
      '한글 파일명 헤더');

    const files = unzip(res.body);
    equal(files.size, 3, '파일 개수');
    assert(files.get('index.html').toString('utf8').includes('배포 자료 본문'), 'HTML 내용');
    equal(files.get('css/style.css').toString('utf8'), 'body{color:red}', 'CSS 내용');
    assert(files.get('그림.png').equals(PNG), '한글 이름 이미지 내용');
  });

  await test('만든 ZIP 이 표준 도구로도 읽히는 형식이다', async () => {
    const c = await login('user1', 'UserPass!234');
    const res = await c.request('/download/dist');

    // EOCD 서명과 첫 로컬 헤더 서명 확인
    equal(res.body.readUInt32LE(0), 0x04034b50, '로컬 헤더 서명');
    const tail = res.body.subarray(res.body.length - 22);
    equal(tail.readUInt32LE(0), 0x06054b50, 'EOCD 서명');
    equal(tail.readUInt16LE(8), 3, '항목 수');
  });

  await test('비로그인 상태에서는 받을 수 없다', async () => {
    const c = createClient();
    const res = await c.request('/download/dist');
    equal(res.status, 302, '상태 코드');
    assert(res.location.startsWith('/login'), '로그인 화면으로');
    assert(!res.text.includes('배포 자료 본문'), '내용 노출 없음');
  });

  await test('권한 없는 콘텐츠는 받을 수 없다 (403)', async () => {
    const res = await admin.uploadMany('/admin/apps', {
      _csrf: tokenOf(admin),
      title: '대외비', slug: 'classified', description: '', visibility: 'restricted',
    }, [{ field: 'file', filename: 'index.html',
      data: '<html><head></head><body>CLASSIFIED-BODY</body></html>' }]);
    equal(res.status, 302, '업로드');

    const c = await login('user1', 'UserPass!234');
    const dl = await c.request('/download/classified');
    equal(dl.status, 403, '상태 코드');
    assert(!dl.text.includes('CLASSIFIED-BODY'), '내용 노출 없음');
  });

  await test('숨김 처리된 콘텐츠는 받을 수 없다 (404)', async () => {
    await admin.form(`/admin/apps/${dlId}/toggle`, { _csrf: tokenOf(admin) });

    const c = await login('user1', 'UserPass!234');
    equal((await c.request('/download/dist')).status, 404, '일반 사용자');

    await admin.form(`/admin/apps/${dlId}/toggle`, { _csrf: tokenOf(admin) });
    equal((await c.request('/download/dist')).status, 200, '다시 공개 후');
  });

  await test('없는 주소는 404', async () => {
    const c = await login('user1', 'UserPass!234');
    equal((await c.request('/download/no-such-app')).status, 404, '상태 코드');
  });

  section('다운로드 허용 스위치');

  await test('스위치를 끄면 일반 사용자는 받을 수 없다', async () => {
    const res = await admin.form(`/admin/apps/${dlId}`, {
      _csrf: tokenOf(admin), title: '배포용 자료', description: '',
      entry_file: 'index.html', thumbnail: '', visibility: 'all',
      // allow_download 를 보내지 않음 = 체크 해제
    });
    equal(res.status, 302, '저장');

    const c = await login('user1', 'UserPass!234');
    const dl = await c.request('/download/dist');
    equal(dl.status, 403, '상태 코드');
    assert(dl.text.includes('다운로드가 허용되지 않은'), '안내 메시지');
  });

  await test('스위치가 꺼져도 화면에서 보기는 된다', async () => {
    const c = await login('user1', 'UserPass!234');
    const view = await c.request('/app/dist/');
    equal(view.status, 200, '상태 코드');
    assert(view.text.includes('배포 자료 본문'), '본문 표시');
  });

  await test('스위치가 꺼지면 화면에 다운로드 버튼이 사라진다', async () => {
    const c = await login('user1', 'UserPass!234');
    const home = await c.request('/');
    const viewer = await c.request('/view/dist');
    assert(!home.text.includes('href="/download/dist"'), '홈 카드에 링크 없음');
    assert(!viewer.text.includes('href="/download/dist"'), '뷰어에 버튼 없음');
  });

  await test('스위치가 꺼져도 관리자는 받을 수 있다', async () => {
    const res = await admin.request('/download/dist');
    equal(res.status, 200, '상태 코드');
    assert(unzip(res.body).has('index.html'), 'ZIP 내용');
  });

  await test('스위치를 다시 켜면 일반 사용자도 받을 수 있다', async () => {
    await admin.form(`/admin/apps/${dlId}`, {
      _csrf: tokenOf(admin), title: '배포용 자료', description: '',
      entry_file: 'index.html', thumbnail: '', visibility: 'all',
      allow_download: '1',
    });
    const c = await login('user1', 'UserPass!234');
    const dl = await c.request('/download/dist');
    equal(dl.status, 200, '상태 코드');

    const home = await c.request('/');
    assert(home.text.includes('href="/download/dist"'), '홈 카드에 링크 표시');
  });

  section('다운로드 기록');

  await test('누가 무엇을 받았는지 기록에 남는다', async () => {
    const logs = await admin.request('/admin/logs?result=download');
    equal(logs.status, 200, '조회');
    assert(logs.text.includes('dist'), '콘텐츠 기록');
    assert(logs.text.includes('user1'), '사용자 기록');
    assert(logs.text.includes('내려받음'), '결과 표시');
  });

  await test('거부된 다운로드 시도도 기록된다', async () => {
    const logs = await admin.request('/admin/logs?result=denied');
    assert(logs.text.includes('(download)'), '거부 기록에 다운로드 시도가 남아야 함');
  });

  section('전체 백업');

  await test('백업 화면이 열린다', async () => {
    const res = await admin.request('/admin/backup');
    equal(res.status, 200, '상태 코드');
    assert(res.text.includes('백업 ZIP 내려받기'), '버튼 표시');
  });

  await test('일반 사용자는 백업에 접근할 수 없다', async () => {
    const c = await login('user1', 'UserPass!234');
    equal((await c.request('/admin/backup')).status, 403, '안내 화면');
    equal((await c.request('/admin/backup/download')).status, 403, '내려받기');
  });

  await test('백업 ZIP 에 DB 와 모든 콘텐츠가 들어 있다', async () => {
    const res = await admin.request('/admin/backup/download');
    equal(res.status, 200, '상태 코드');
    equal(res.headers.get('content-type'), 'application/zip', 'MIME');

    const files = unzip(res.body);

    assert(files.has('data/portal.db'), 'DB 포함');
    assert(files.has('복구안내.txt'), '복구 안내 포함');
    assert(files.has('콘텐츠목록.csv'), '콘텐츠 목록 포함');

    const dbBuf = files.get('data/portal.db');
    equal(dbBuf.subarray(0, 15).toString('latin1'), 'SQLite format 3',
      'SQLite 파일 형식이어야 함');

    const paths = [...files.keys()].filter((k) => k.startsWith('storage/apps/'));
    assert(paths.length >= 3, `콘텐츠 파일이 담겨야 함 (실제: ${paths.length}개)`);
    assert(paths.some((p) => p.endsWith('index.html')), 'HTML 포함');

    const csv = files.get('콘텐츠목록.csv').toString('utf8');
    assert(csv.includes('배포용 자료'), 'CSV 에 콘텐츠 제목');
    equal(files.get('콘텐츠목록.csv')[0], 0xef, 'CSV 에 UTF-8 BOM');
  });

  await test('백업의 DB 스냅샷이 실제로 열리는 SQLite 파일이다', async () => {
    const res = await admin.request('/admin/backup/download');
    const dbBuf = unzip(res.body).get('data/portal.db');

    const fs = require('node:fs');
    const os = require('node:os');
    const path = require('node:path');
    const { DatabaseSync } = require('node:sqlite');

    const tmp = path.join(os.tmpdir(), `portal-restore-test-${Date.now()}.db`);
    fs.writeFileSync(tmp, dbBuf);
    try {
      const restored = new DatabaseSync(tmp);
      const users = restored.prepare('SELECT COUNT(*) AS n FROM users').get();
      const apps = restored.prepare('SELECT slug FROM apps ORDER BY slug').all();
      restored.close();

      assert(Number(users.n) >= 4, `계정이 복구되어야 함 (실제: ${users.n})`);
      assert(apps.some((a) => a.slug === 'dist'), '콘텐츠 정보가 복구되어야 함');
    } finally {
      fs.rmSync(tmp, { force: true });
    }
  });

  await test('백업 행위가 감사 기록에 남는다', async () => {
    const db = require('../src/db');
    // 서버 프로세스와 같은 DB 파일을 읽습니다.
    const row = db.get(
      `SELECT action, actor FROM audit_logs WHERE action = 'backup.download'
        ORDER BY at DESC LIMIT 1`);
    assert(row, '백업 기록이 있어야 함');
    equal(row.actor, 'admin', '행위자');
  });
};
