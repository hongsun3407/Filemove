'use strict';
/**
 * 마이그레이션 업그레이드 경로 검증.
 *
 * 이미 운영 중인 데이터베이스(예: v1 이나 v2)에 새 버전을 적용했을 때
 * 기존 데이터가 그대로 남고 새 컬럼이 기본값으로 채워지는지 확인합니다.
 * 서버를 띄우지 않고 직접 검사합니다.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const { test, section, assert, equal } = require('./harness');
const { MIGRATIONS, migrate } = require('../src/migrations');

/** 지정한 버전까지만 적용된 데이터베이스를 만듭니다. */
function makeDbAtVersion(file, version) {
  const db = new DatabaseSync(file);
  for (let i = 0; i < version; i++) {
    db.exec(MIGRATIONS[i]);
    db.exec(`PRAGMA user_version = ${i + 1}`);
  }
  return db;
}

function apiFor(db) {
  return {
    get: (sql, ...p) => db.prepare(sql).get(...p),
    exec: (sql) => db.exec(sql),
  };
}

function withTempDb(version, fn) {
  const file = path.join(os.tmpdir(), `portal-mig-${version}-${Date.now()}-${Math.random().toString(36).slice(2)}.db`);
  const db = makeDbAtVersion(file, version);
  try {
    return fn(db);
  } finally {
    try { db.close(); } catch { /* noop */ }
    fs.rmSync(file, { force: true });
  }
}

module.exports = async function run() {
  section('마이그레이션 업그레이드 경로');

  await test('마이그레이션 목록이 노출된다', () => {
    assert(Array.isArray(MIGRATIONS) && MIGRATIONS.length >= 3,
      `버전이 3개 이상이어야 함 (실제: ${MIGRATIONS.length})`);
  });

  await test('v1 데이터베이스에 최신 버전을 적용해도 데이터가 남는다', () => {
    withTempDb(1, (db) => {
      const now = Date.now();
      db.prepare(
        `INSERT INTO users (login_id, name, dept, password_hash, role, status,
                            must_change_pw, created_at, updated_at)
         VALUES ('legacy', '기존사용자', '총무팀', 'scrypt$x', 'user', 'active', 0, ?, ?)`
      ).run(now, now);
      db.prepare(
        `INSERT INTO apps (slug, title, description, entry_file, visibility,
                           is_active, created_at, updated_at)
         VALUES ('legacy-app', '기존 콘텐츠', '', 'index.html', 'all', 1, ?, ?)`
      ).run(now, now);

      migrate(apiFor(db));

      equal(Number(db.prepare('PRAGMA user_version').get().user_version),
        MIGRATIONS.length, '최신 버전으로 올라가야 함');

      const user = db.prepare(`SELECT name, dept FROM users WHERE login_id = 'legacy'`).get();
      equal(user.name, '기존사용자', '사용자 데이터 유지');
      equal(user.dept, '총무팀', '부서 유지');

      const app = db.prepare(`SELECT * FROM apps WHERE slug = 'legacy-app'`).get();
      equal(app.title, '기존 콘텐츠', '콘텐츠 데이터 유지');
      equal(Number(app.sort_order), 1, 'sort_order 가 id 로 채워져야 함');
      equal(app.thumbnail, '', 'thumbnail 기본값');
      equal(Number(app.allow_download), 1, 'allow_download 기본값은 허용');
    });
  });

  await test('v2 데이터베이스에 v3 를 적용해도 정렬 순서가 보존된다', () => {
    withTempDb(2, (db) => {
      const now = Date.now();
      const insert = db.prepare(
        `INSERT INTO apps (slug, title, description, entry_file, visibility,
                           is_active, sort_order, thumbnail, created_at, updated_at)
         VALUES (?, ?, '', 'index.html', 'all', 1, ?, ?, ?, ?)`);
      insert.run('second', '두 번째', 2, 'a.png', now, now);
      insert.run('first', '첫 번째', 1, '', now, now);

      migrate(apiFor(db));

      const rows = db.prepare('SELECT slug, sort_order, thumbnail, allow_download FROM apps ORDER BY sort_order').all();
      equal(rows[0].slug, 'first', '정렬 순서 보존');
      equal(rows[1].slug, 'second', '정렬 순서 보존');
      equal(rows[1].thumbnail, 'a.png', '대표 이미지 보존');
      equal(Number(rows[0].allow_download), 1, '새 컬럼 기본값');
    });
  });

  await test('이미 최신 버전이면 아무 일도 하지 않는다', () => {
    withTempDb(MIGRATIONS.length, (db) => {
      const before = Number(db.prepare('PRAGMA user_version').get().user_version);
      migrate(apiFor(db));
      const after = Number(db.prepare('PRAGMA user_version').get().user_version);
      equal(after, before, '버전 그대로');
    });
  });

  await test('마이그레이션을 두 번 돌려도 안전하다', () => {
    withTempDb(1, (db) => {
      migrate(apiFor(db));
      migrate(apiFor(db));
      equal(Number(db.prepare('PRAGMA user_version').get().user_version),
        MIGRATIONS.length, '버전 유지');
    });
  });
};
