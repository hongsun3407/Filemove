'use strict';
/**
 * 통합 테스트 진입점.
 * 실제 서버 프로세스를 띄우고 HTTP 로 검증합니다.
 *
 *   npm test              결과만
 *   VERBOSE=1 npm test    서버 로그까지
 */
const harness = require('./harness');

// src/config 는 require 시점에 환경 변수를 읽으므로 먼저 설정합니다.
process.env.DATA_DIR = harness.ENV.DATA_DIR;
process.env.STORAGE_DIR = harness.ENV.STORAGE_DIR;
process.env.LOG_DIR = harness.ENV.LOG_DIR;

const db = require('../src/db');
const password = require('../src/lib/password');

/* ------------------------------ 기본 데이터 ------------------------------ */

async function seed() {
  db.open();
  const now = Date.now();

  const temp = await password.hash('TempPass!234');
  const settled = await password.hash('UserPass!234');

  const insert = (loginId, name, dept, hash, role, status, mustChange) =>
    db.run(
      `INSERT INTO users (login_id, name, dept, password_hash, role, status,
                          must_change_pw, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      loginId, name, dept, hash, role, status, mustChange, now, now
    );

  insert('admin', '관리자', '정보시스템팀', temp, 'admin', 'active', 1);
  insert('user1', '홍길동', '영업팀', settled, 'user', 'active', 0);
  insert('gone', '퇴사자', '', settled, 'user', 'disabled', 0);
  insert('locktest', '잠금테스트', '', settled, 'user', 'active', 0);

  db.close();
}

/* ------------------------------ 실행 ------------------------------ */

async function main() {
  await seed();
  const server = await harness.startServer();
  console.log(`\n포탈 통합 테스트 (${harness.BASE})`);

  try {
    await require('./migration.spec')();
    await require('./auth.spec')();
    await require('./content.spec')();
    await require('./ui.spec')();
    await require('./download.spec')();
  } finally {
    server.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 300));
    server.kill('SIGKILL');
    harness.cleanup();
  }

  process.exit(harness.summary() > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error('\n테스트 실행 중 오류:', err);
  harness.cleanup();
  process.exit(1);
});
