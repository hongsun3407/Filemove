'use strict';
/**
 * 화면 미리보기 생성기 (개발 확인용).
 * 각 화면을 CSS 를 인라인으로 넣은 정적 HTML 로 뽑아 저장합니다.
 * 서버를 띄우지 않고 레이아웃을 확인하거나 스크린샷을 찍을 때 사용합니다.
 *
 *   node test/render-preview.js [출력폴더]
 */
const fs = require('node:fs');
const path = require('node:path');
const views = require('../src/views');
const admin = require('../src/views/admin');
const { toString } = require('../src/lib/html');

const outDir = process.argv[2] || '/tmp/preview';
fs.mkdirSync(outDir, { recursive: true });

const css = fs.readFileSync(path.join(__dirname, '..', 'public', 'css', 'style.css'), 'utf8');

function fakeReq(user, query = '') {
  return { user, csrfToken: 'preview-token', query: new URLSearchParams(query) };
}

const adminUser = {
  id: 1, login_id: 'hslim', name: '임홍순', dept: '정보시스템팀',
  role: 'admin', status: 'active', must_change_pw: 0,
  failed_count: 0, locked_until: null,
  created_at: Date.now() - 86400000 * 30, last_login_at: Date.now() - 3600000,
};
const member = {
  id: 2, login_id: 'user1', name: '홍길동', dept: '영업팀',
  role: 'user', status: 'active', must_change_pw: 0,
  failed_count: 2, locked_until: null,
  created_at: Date.now() - 86400000 * 5, last_login_at: Date.now() - 7200000,
};

const users = [
  adminUser,
  member,
  { ...member, id: 3, login_id: 'kim.cs', name: '김철수', dept: '생산관리팀', must_change_pw: 1 },
  { ...member, id: 4, login_id: 'lee.yh', name: '이영희', dept: '품질팀', status: 'disabled' },
  { ...member, id: 5, login_id: 'park.js', name: '박지성', dept: '영업팀', locked_until: Date.now() + 300000 },
];

const apps = [
  {
    id: 1, slug: 'sales-2026', title: '2026 영업 실적 대시보드',
    description: '월별 매출 및 목표 대비 진척도', visibility: 'restricted',
    is_active: 1, updated_at: Date.now() - 3600000, grant_count: 12, thumbnail: 'chart.png',
    file_count: 24, total_bytes: 1841234, entry_file: 'index.html', allow_download: 1,
  },
  {
    id: 2, slug: 'qc-report', title: '품질 검사 리포트',
    description: '라인별 불량률 추이', visibility: 'all',
    is_active: 1, updated_at: Date.now() - 86400000 * 3, grant_count: 0, thumbnail: 'qc.png',
    file_count: 8, total_bytes: 402113, entry_file: 'index.html', allow_download: 0,
  },
  {
    id: 3, slug: 'inventory', title: '재고 현황판', description: '',
    visibility: 'restricted', is_active: 0, thumbnail: '', updated_at: Date.now() - 86400000 * 14,
    grant_count: 3, file_count: 3, total_bytes: 51200, entry_file: 'index.html', allow_download: 1,
  },
];

const files = [
  { path: 'index.html', size: 18234 },
  { path: 'css/style.css', size: 8102 },
  { path: 'js/app.js', size: 142330 },
  { path: 'js/chart.min.js', size: 201338 },
  { path: 'img/로고.png', size: 24110 },
];

const logs = [
  { id: 1, login_id: 'user1', app_slug: 'qc-report', path: 'index.html', result: 'ok', ip: '10.20.3.44', at: Date.now() - 120000 },
  { id: 2, login_id: 'kim.cs', app_slug: 'sales-2026', path: 'index.html', result: 'denied', ip: '10.20.3.51', at: Date.now() - 900000 },
  { id: 3, login_id: 'hslim', app_slug: 'sales-2026', path: 'reports/q3.html', result: 'ok', ip: '10.20.3.12', at: Date.now() - 3600000 },
  { id: 4, login_id: 'lee.yh', app_slug: 'inventory', path: 'index.html', result: 'notfound', ip: '10.20.3.77', at: Date.now() - 7200000 },
];

const sidebarApps = apps.filter((a) => a.is_active);

const pages = {
  'home.html': views.dashboard({
    req: fakeReq(adminUser),
    apps: sidebarApps.map((a, i) => ({
      ...a,
      description: i === 0
        ? '**월 마감 기준** 실적입니다.\n\n![차트](chart.png)\n\n- 목표 대비 달성률\n- 지점별 순위'
        : a.description,
    })),
  }),
  'viewer.html': views.viewer({
    req: fakeReq(adminUser), apps: sidebarApps, app: apps[0],
  }),

  'login.html': views.login({ req: fakeReq(null), next: '/' }),
  'login-error.html': views.login({
    req: fakeReq(null), next: '/',
    error: '아이디 또는 비밀번호가 올바르지 않습니다.', loginId: 'user1',
  }),
  'change-password-forced.html': views.changePassword({ req: fakeReq(adminUser), forced: true }),
  'dashboard-empty.html': views.dashboard({ req: fakeReq(member), apps: [] }),
  'dashboard.html': views.dashboard({
    req: fakeReq(adminUser), notice: 'password-changed',
    apps: apps.filter((a) => a.is_active),
  }),
  'error-403.html': views.error({
    req: fakeReq(member), status: 403, title: '접근 권한 없음',
    message: '이 페이지는 관리자만 사용할 수 있습니다.',
  }),

  'admin-users.html': admin.usersList({ req: fakeReq(adminUser), users, q: '' }),
  'admin-user-new.html': admin.userNew({ req: fakeReq(adminUser) }),
  'admin-user-detail.html': admin.userDetail({
    req: fakeReq(adminUser), user: users[2], sessionCount: 1,
    apps, permitted: new Set([2]),
    recent: logs.slice(0, 3),
    flash: {
      kind: 'ok',
      text: '김철수(kim.cs) 계정을 만들었습니다. 아래 임시 비밀번호를 본인에게 전달하세요. 이 화면을 벗어나면 다시 볼 수 없습니다.',
      extra: 'hT7kRm2xQpVn',
    },
  }),
  'admin-apps.html': admin.appsList({ req: fakeReq(adminUser), apps }),
  'admin-app-new.html': admin.appNew({ req: fakeReq(adminUser) }),
  'admin-app-detail.html': admin.appDetail({
    req: fakeReq(adminUser), app: apps[0], files,
    totalBytes: files.reduce((s, f) => s + f.size, 0),
    users: users.filter((u) => u.role !== 'admin'),
    permitted: new Set([2, 3]),
    recent: logs.slice(0, 3),
  }),
  'admin-backup.html': admin.backupPage({
    req: fakeReq(adminUser), apps,
    contentBytes: 2294547, dbBytes: 1204224,
    counts: { users: 24, logs: 8412 },
  }),
  'admin-logs.html': admin.logsList({
    req: fakeReq(adminUser), logs,
    filters: { user: '', app: '', result: '' },
    page: 1, hasMore: true, apps, users,
  }),
};

// 미리보기용 자리표시 이미지 (실제 서버에서는 콘텐츠 폴더에서 옵니다)
const PLACEHOLDER =
  'data:image/svg+xml;utf8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="80">' +
    '<rect width="120" height="80" fill="#c8d4e4"/>' +
    '<text x="60" y="45" font-size="13" text-anchor="middle" fill="#41597c">이미지</text></svg>');

// 뷰어 미리보기에서 iframe 이 가리킬 샘플 콘텐츠
fs.writeFileSync(path.join(outDir, 'sample-content.html'),
  `<!doctype html><html lang="ko"><head><meta charset="utf-8"><style>
   body{font-family:system-ui,sans-serif;margin:0;padding:32px;color:#1c2127}
   h1{margin:0 0 4px;font-size:20px} .m{color:#6b7580;font-size:14px;margin:0 0 24px}
   .row{display:flex;gap:16px;flex-wrap:wrap}
   .kpi{border:1px solid #dfe3e8;border-radius:8px;padding:16px 20px;min-width:150px}
   .kpi b{display:block;font-size:24px;margin-top:4px}
   </style></head><body>
   <h1>2026 영업 실적 대시보드</h1>
   <p class="m">여기에 직접 개발하신 HTML 이 그대로 표시됩니다.</p>
   <div class="row">
     <div class="kpi">누적 매출<b>₩ 42.8억</b></div>
     <div class="kpi">목표 달성률<b>103.4%</b></div>
     <div class="kpi">신규 거래처<b>17곳</b></div>
   </div></body></html>`, 'utf8');

for (const [name, page] of Object.entries(pages)) {
  if (name === 'sample-content.html') continue;

  const html = toString(page)
    .replace('<link rel="stylesheet" href="/static/css/style.css">', `<style>\n${css}\n</style>`)
    // iframe(콘텐츠 자체)은 샘플 문서로, 이미지는 자리표시 그림으로 바꿉니다.
    .replace(/src="(\/app\/[^"]*)"/g, (m, url) => (url.endsWith('/') || /\.html?$/i.test(url)
      ? 'src="./sample-content.html"'
      : `src="${PLACEHOLDER}"`));

  fs.writeFileSync(path.join(outDir, name), html, 'utf8');
  console.log(`  ${path.join(outDir, name)}`);
}
