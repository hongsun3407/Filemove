'use strict';
/**
 * 테스트 공용 도구 — 러너, 쿠키 클라이언트, 서버 기동.
 */
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-test-'));
const PORT = 3999 + Math.floor(Math.random() * 500);
const BASE = `http://127.0.0.1:${PORT}`;

const ENV = {
  ...process.env,
  PORT: String(PORT),
  HOST: '127.0.0.1',
  DATA_DIR: path.join(TMP, 'data'),
  STORAGE_DIR: path.join(TMP, 'storage'),
  LOG_DIR: path.join(TMP, 'logs'),
  MAX_FAILED: '5',
  LOCK_MS: '600000',
  SECURE_COOKIE: 'false',
};

/* ------------------------------ 러너 ------------------------------ */

const state = { passed: 0, failed: 0, failures: [] };

async function test(name, fn) {
  try {
    await fn();
    state.passed++;
    console.log(`  \x1b[32m✓\x1b[0m ${name}`);
  } catch (err) {
    state.failed++;
    state.failures.push({ name, err });
    console.log(`  \x1b[31m✗\x1b[0m ${name}`);
    console.log(`      ${err.message}`);
  }
}

function section(title) { console.log(`\n${title}`); }

function assert(cond, message) {
  if (!cond) throw new Error(message || '단언 실패');
}

function equal(actual, expected, message) {
  if (actual !== expected) {
    throw new Error(`${message || '값 불일치'} — 기대: ${expected}, 실제: ${actual}`);
  }
}

function summary() {
  console.log(`\n결과: ${state.passed}건 통과, ${state.failed}건 실패\n`);
  if (state.failed > 0) {
    for (const f of state.failures) {
      console.log(`  실패: ${f.name}`);
      console.log(`    ${f.err.stack.split('\n').slice(0, 2).join('\n    ')}`);
    }
  }
  return state.failed;
}

/* ------------------------------ 클라이언트 ------------------------------ */

function createClient() {
  const jar = new Map();

  function cookieHeader() {
    return [...jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
  }

  function absorb(res) {
    const setCookies = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    for (const c of setCookies) {
      const [pair, ...attrs] = c.split(';');
      const idx = pair.indexOf('=');
      const name = pair.slice(0, idx).trim();
      const value = pair.slice(idx + 1).trim();
      const maxAge = attrs.find((a) => a.trim().toLowerCase().startsWith('max-age='));
      if (maxAge && Number(maxAge.split('=')[1]) === 0) jar.delete(name);
      else jar.set(name, value);
    }
  }

  const client = {
    jar,
    get: (name) => jar.get(name),

    async request(pathname, options = {}) {
      const headers = { ...(options.headers || {}) };
      const cookies = cookieHeader();
      if (cookies) headers.cookie = cookies;
      const res = await fetch(BASE + pathname, { ...options, headers, redirect: 'manual' });
      absorb(res);
      const buf = Buffer.from(await res.arrayBuffer());
      return {
        status: res.status,
        headers: res.headers,
        body: buf,
        text: buf.toString('utf8'),
        location: res.headers.get('location'),
      };
    },

    async form(pathname, fields) {
      const params = new URLSearchParams();
      for (const [name, raw] of Object.entries(fields)) {
        for (const value of Array.isArray(raw) ? raw : [raw]) params.append(name, value);
      }
      return client.request(pathname, {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: params.toString(),
      });
    },

    /**
     * multipart/form-data 전송 (파일 여러 개).
     * @param {object} fields  텍스트 필드 (값이 배열이면 같은 이름으로 여러 번)
     * @param {Array<{field,filename,data,contentType}>} files
     */
    async uploadMany(pathname, fields, files = []) {
      const boundary = `----portaltest${crypto.randomBytes(8).toString('hex')}`;
      const parts = [];

      for (const [name, raw] of Object.entries(fields)) {
        for (const value of Array.isArray(raw) ? raw : [raw]) {
          parts.push(Buffer.from(
            `--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`,
            'utf8'));
        }
      }

      for (const file of files) {
        if (!file) continue;
        parts.push(Buffer.from(
          `--${boundary}\r\n` +
          `Content-Disposition: form-data; name="${file.field}"; filename="${file.filename}"\r\n` +
          `Content-Type: ${file.contentType || 'application/octet-stream'}\r\n\r\n`,
          'utf8'));
        parts.push(Buffer.isBuffer(file.data) ? file.data : Buffer.from(file.data, 'utf8'));
        parts.push(Buffer.from('\r\n', 'utf8'));
      }

      parts.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));

      return client.request(pathname, {
        method: 'POST',
        headers: { 'content-type': `multipart/form-data; boundary=${boundary}` },
        body: Buffer.concat(parts),
      });
    },

    /** 파일 하나짜리 단축형 */
    async upload(pathname, fields, file) {
      return client.uploadMany(pathname, fields, file ? [file] : []);
    },
  };

  return client;
}

/** 페이지 HTML 에서 CSRF hidden 값 추출 */
function csrfOf(html) {
  const m = /name="_csrf" value="([^"]+)"/.exec(html);
  if (!m) throw new Error('페이지에서 CSRF 토큰을 찾지 못했습니다');
  return m[1];
}

/** 로그인한 클라이언트를 만들어 반환 */
async function login(loginId, pw) {
  const c = createClient();
  const page = await c.request('/login');
  const res = await c.form('/login', {
    _csrf: csrfOf(page.text), login_id: loginId, password: pw, next: '/',
  });
  if (res.status !== 302) {
    throw new Error(`로그인 실패 (${loginId}): status=${res.status}`);
  }
  return c;
}

/** 현재 CSRF 토큰 (쿠키에서) */
function tokenOf(client) {
  return client.get('portal.csrf');
}

/* ------------------------------ 서버 ------------------------------ */

function startServer() {
  const child = spawn(process.execPath,
    ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'src', 'server.js')],
    { env: ENV, stdio: ['ignore', 'pipe', 'pipe'] });

  child.stdout.on('data', (d) => { if (process.env.VERBOSE) process.stdout.write(`  [srv] ${d}`); });
  child.stderr.on('data', (d) => { if (process.env.VERBOSE) process.stderr.write(`  [srv:err] ${d}`); });

  return new Promise((resolve, reject) => {
    const deadline = Date.now() + 15000;
    (async function poll() {
      if (child.exitCode !== null) return reject(new Error('서버가 조기 종료되었습니다'));
      try {
        const res = await fetch(`${BASE}/healthz`);
        if (res.ok) return resolve(child);
      } catch { /* 아직 기동 전 */ }
      if (Date.now() > deadline) return reject(new Error('서버 기동 시간 초과'));
      setTimeout(poll, 150);
    })();
  });
}

function cleanup() {
  fs.rmSync(TMP, { recursive: true, force: true });
}

module.exports = {
  TMP, PORT, BASE, ENV,
  test, section, assert, equal, summary,
  createClient, csrfOf, login, tokenOf,
  startServer, cleanup,
};
