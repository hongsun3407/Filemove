# 사내 HTML 배포 포탈 — 개발 계획서

**작성일** 2026-08-21 · **프로젝트 루트** `D:\portal`

---

## 0. 확정된 전제

| 항목 | 결정 |
|---|---|
| 배포 환경 | 사내 서버 / 온프레미스 |
| 인증 | 관리자가 계정을 직접 생성 (셀프 회원가입 화면 없음) |
| 보호 수준 | 로그인한 사용자만 접근 (세션 기반 게이트) |
| 콘텐츠 등록 | 관리자 화면에서 HTML 업로드 |

### 아직 정해야 할 것 (Phase 0에서 결정)

1. 서버 OS — Windows Server인지 Linux인지
2. 접속 범위 — 사내망 전용인지, VPN/외부 접속도 허용인지
3. HTTPS 인증서 — 사내 CA 발급인지 사설 인증서인지
4. 예상 사용자 수 / 동시 접속 규모
5. HTML 앱 1개당 대략적인 파일 크기와 개수

---

## 1. 이 포탈이 실제로 막는 것 / 못 막는 것

보안이 목적이므로 이 경계를 먼저 분명히 해야 합니다. 여기서 착각하면 나중에 "보호된다고 믿었는데 아니었다"가 됩니다.

### 막을 수 있는 것

- **URL 직접 접근** — 링크를 알아도 로그인 세션이 없으면 HTML 본문이 전송되지 않음
- **검색엔진/크롤러 노출** — 인증 뒤에 있으므로 색인 불가
- **퇴사자·권한 해제자 접근** — 계정 비활성화 즉시 차단
- **누가 무엇을 열었는지 모름** — 접근 로그로 추적 가능
- **파일 서버 공유의 무통제 확산** — "파일을 준다"에서 "보게 해준다"로 전환

### 막을 수 없는 것 (명시적으로 인정하고 가야 함)

- 로그인한 정당한 사용자가 **브라우저에서 소스 보기 / 저장 / 스크린샷** 하는 것
- 브라우저에 렌더링되는 순간 HTML·JS·CSS는 클라이언트 메모리에 존재합니다. 이건 기술적으로 우회 불가입니다.
- 따라서 이 포탈의 실질적 방어선은 **"접근 통제 + 추적 가능성"**이지 "복제 불가"가 아닙니다.

> 만약 "정당한 사용자조차 소스를 못 보게" 해야 한다면, 그건 웹 배포가 아니라 서버 사이드 렌더링(HTML 로직을 서버로 옮기고 결과 이미지/제한된 DOM만 전송)이나 전용 클라이언트 앱 영역입니다. 필요하면 별도로 논의합시다.

---

## 2. 전체 구조

```
[사용자 브라우저]
        │  HTTPS
        ▼
[리버스 프록시 (IIS / Nginx)]      ← TLS 종료, 사내망 IP 제한
        │
        ▼
[포탈 앱 (Node.js + Express)]
   ├─ 인증 미들웨어 (세션 검사) ──── 실패 시 /login 리다이렉트
   ├─ 관리자 라우트   /admin/*      (role=admin 만)
   ├─ 콘텐츠 라우트   /app/:slug/*  ★ 핵심 게이트
   └─ 감사 로그 기록
        │
        ├──▶ [SQLite]  users, apps, permissions, logs
        └──▶ [storage/]  업로드된 HTML  ※ 웹루트 밖, 정적 노출 절대 금지
```

### 핵심 설계 원칙 한 줄

> **업로드된 HTML은 절대 static 디렉터리에 두지 않는다.**
> 반드시 `/app/:slug/*` 라우트를 통과해서, 세션 검사 → 권한 검사 → 로그 기록 → 그 다음에 파일을 읽어 스트리밍한다.

이 원칙 하나가 지켜지면 나머지는 부수적입니다. 반대로 이게 깨지면(예: 편의상 `express.static('storage')` 한 줄 추가) 포탈 전체가 무의미해집니다.

---

## 3. 기술 스택 (제안)

| 영역 | 선택 | 이유 |
|---|---|---|
| 런타임 | Node.js 22 LTS | Windows/Linux 동일, 설치 간단 |
| 웹 프레임워크 | Express 5 | 라우트 단위 미들웨어 제어가 명확 |
| DB | SQLite (better-sqlite3) | 단일 파일, 별도 DB 서버 불필요, 백업=파일복사 |
| 세션 | express-session + connect-sqlite3 | 재시작해도 세션 유지, 서버측 즉시 무효화 가능 |
| 비밀번호 | argon2 (대안: bcrypt) | 현행 권장 알고리즘 |
| 템플릿 | EJS | 러닝커브 최소, 화면 수가 적음 |
| 업로드 | multer + unzipper | 단일 HTML 및 zip 패키지 모두 수용 |
| 보안 헤더 | helmet | CSP·프레임 정책 일괄 |
| 로그인 제한 | express-rate-limit | 무차별 대입 방어 |

**대안**: 파이썬이 더 편하시면 FastAPI + SQLite + Jinja2로 동일 설계가 그대로 성립합니다. 구조는 바뀌지 않습니다.

---

## 4. 폴더 구조

```
D:\portal\
├─ src\
│  ├─ app.js                 앱 진입점
│  ├─ db.js                  SQLite 연결 + 마이그레이션
│  ├─ middleware\
│  │   ├─ requireAuth.js     로그인 필수
│  │   ├─ requireAdmin.js    관리자 전용
│  │   └─ auditLog.js        접근 기록
│  ├─ routes\
│  │   ├─ auth.js            /login /logout /change-password
│  │   ├─ admin.js           /admin/users /admin/apps
│  │   └─ content.js         /app/:slug/*   ★ 보호 서빙
│  └─ views\                 EJS 템플릿
├─ public\                   포탈 자체 CSS/JS/로고만 (여기엔 절대 콘텐츠 X)
├─ storage\                  ★ 업로드된 HTML — 웹으로 직접 노출 안 됨
│  └─ apps\<appId>\...
├─ data\
│  ├─ portal.db
│  └─ sessions.db
├─ logs\
├─ .env                      SESSION_SECRET, PORT 등 (git 제외)
└─ package.json
```

---

## 5. 데이터 모델

```sql
users
  id            INTEGER PK
  login_id      TEXT UNIQUE      -- 사번 또는 이메일
  name          TEXT
  dept          TEXT
  password_hash TEXT
  role          TEXT             -- 'admin' | 'user'
  status        TEXT             -- 'active' | 'disabled'
  must_change_pw INTEGER         -- 최초 발급 후 강제 변경
  created_at, last_login_at, failed_count, locked_until

apps                            -- 붙일 HTML 콘텐츠 한 단위
  id            INTEGER PK
  slug          TEXT UNIQUE      -- URL에 쓰일 이름
  title, description
  entry_file    TEXT             -- 기본 'index.html'
  visibility    TEXT             -- 'all' | 'restricted'
  is_active     INTEGER
  created_at, updated_at, uploaded_by

app_permissions                 -- visibility='restricted' 일 때만 사용
  app_id, user_id               (PK 조합)

access_logs
  id, user_id, app_id, path, ip, user_agent, at, result
                                -- result: 'ok' | 'denied' | 'notfound'

audit_logs                      -- 관리자 행위 기록
  id, actor_id, action, target, detail, ip, at
```

부서/그룹 단위 권한이 필요해지면 `groups` + `user_groups` + `app_group_permissions`를 나중에 추가합니다. 초기엔 사용자 단위로 충분합니다.

---

## 6. 화면 구성

### 사용자

| 화면 | 경로 | 내용 |
|---|---|---|
| 로그인 | `/login` | ID/PW, 실패 횟수 제한 |
| 비밀번호 변경 | `/change-password` | 최초 로그인 시 강제 |
| 앱 목록 | `/` | 내가 접근 가능한 HTML 앱 카드 목록 |
| 앱 실행 | `/app/:slug/` | 실제 HTML 렌더링 |

### 관리자

| 화면 | 경로 | 내용 |
|---|---|---|
| 사용자 관리 | `/admin/users` | 생성·수정·비활성화·비밀번호 초기화 |
| 앱 관리 | `/admin/apps` | 업로드·교체·삭제·활성/비활성 |
| 권한 관리 | `/admin/apps/:id/access` | 앱별 접근 허용 사용자 지정 |
| 접근 로그 | `/admin/logs` | 사용자/앱/기간 필터, CSV 내보내기 |

---

## 7. 핵심 보안 설계

### 7-1. 보호 서빙 라우트 — 가장 중요한 부분

`GET /app/:slug/*` 처리 순서:

1. 세션 확인 → 없으면 `/login?next=...`로 리다이렉트
2. 사용자 `status='active'` 재확인 (세션이 살아있어도 계정이 죽었으면 차단)
3. `slug`로 앱 조회 → `is_active` 확인
4. `visibility='restricted'`면 `app_permissions` 확인
5. **경로 정규화 및 탈출 방지**
   ```js
   const base = path.resolve(STORAGE, String(app.id));
   const target = path.resolve(base, requestedPath);
   if (!target.startsWith(base + path.sep)) return res.sendStatus(403);
   ```
   `../`, URL 인코딩된 `%2e%2e`, 심볼릭 링크 모두 이 검사에서 걸립니다.
6. 파일 존재 확인 → MIME 추론 → 스트리밍
7. 응답 헤더: `Cache-Control: private, no-store`, `X-Content-Type-Options: nosniff`
8. 접근 로그 기록 (HTML 문서 요청만 기록. js/css/img 하위 리소스까지 다 남기면 로그가 폭발하니 확장자 필터링)

HTML 내부의 상대 경로 리소스(`./js/main.js`, `./img/a.png`)도 전부 같은 라우트를 타므로 **자동으로 동일한 인증을 받습니다.** 별도 처리 불필요.

### 7-2. 세션·쿠키

- 쿠키: `httpOnly`, `secure`(HTTPS 시), `sameSite: 'lax'`
- 유효기간: 8시간 + 유휴 30분 자동 만료
- 로그인 성공 시 세션 ID 재발급 (세션 고정 공격 방어)
- 관리자는 특정 사용자의 세션을 즉시 강제 종료 가능

### 7-3. 인증

- argon2id 해싱, 평문 저장 절대 없음
- 로그인 5회 실패 → 10분 잠금
- 관리자가 계정 생성 시 임시 비밀번호 발급 → 최초 로그인 시 변경 강제
- 모든 POST 요청에 CSRF 토큰

### 7-4. 업로드 방어

- 허용 확장자 화이트리스트: `.html .htm .css .js .png .jpg .gif .svg .webp .woff2 .json .csv` 등
- zip 해제 시 **zip slip** 방어 — 엔트리 경로에 `..`나 절대경로가 있으면 거부
- 파일 크기·개수 상한
- 업로드는 임시 폴더에 풀고 검증 통과 후 `storage/apps/<id>`로 원자적 교체 (실패 시 기존 버전 유지)

### 7-5. 헬멧/헤더

- `X-Frame-Options: SAMEORIGIN` — 외부 사이트에서 iframe으로 끌어가지 못하게
- CSP는 포탈 화면과 콘텐츠 화면을 분리 적용 (사용자 HTML이 인라인 스크립트를 쓸 수 있으므로 `/app/*`에는 완화된 정책)

---

## 8. HTML 앱을 붙이는 규칙 (개발 가이드)

기존에 만드신 HTML을 그대로 올릴 수 있게 하되, 몇 가지만 지키면 됩니다.

1. **패키징**: 단일 `index.html`이거나, `index.html`을 루트에 둔 zip
2. **경로는 상대경로로** — `/js/main.js` (절대경로) ❌ → `./js/main.js` ✅
   포탈이 `/app/<slug>/` 하위에 마운트하므로 절대경로는 깨집니다.
3. **외부 CDN 의존 최소화** — 사내망 폐쇄 환경이면 CDN이 안 잡힙니다. 라이브러리는 zip에 동봉
4. **저장이 필요하면** localStorage는 쓸 수 있지만, 서버 저장이 필요하면 포탈 API 추가 필요 (Phase 5 이후 확장)
5. **사용자 정보가 필요하면** 포탈이 주입해 주는 `window.__PORTAL_USER__` (이름·부서) 사용 — 워터마크나 개인화에 활용

---

## 9. 개발 로드맵

### Phase 0 — 환경 확정 (0.5일)
서버 OS/사양 확인, Node 설치, 포트 결정, HTTPS 인증서 준비, `D:\portal` 초기화
→ **완료 기준**: `npm run dev`로 "Hello" 페이지가 사내에서 열림

### Phase 1 — 인증 골격 (2일)
DB 스키마 + 마이그레이션, 로그인/로그아웃, 세션, 비밀번호 해싱, `requireAuth` 미들웨어, 최초 관리자 계정 생성 스크립트
→ **완료 기준**: 로그인 안 하면 어떤 페이지도 못 봄. 로그인하면 빈 대시보드가 보임

### Phase 2 — 관리자 사용자 관리 (1.5일)
사용자 CRUD 화면, 임시 비밀번호 발급, 강제 변경, 계정 비활성화, `requireAdmin`
→ **완료 기준**: 관리자가 계정을 만들어 주면 그 사람이 로그인해서 비밀번호를 바꿀 수 있음

### Phase 3 — 콘텐츠 업로드 & 보호 서빙 (3일) ★ 핵심
앱 업로드(단일 HTML / zip), 확장자·zip slip 검증, `/app/:slug/*` 보호 라우트, path traversal 방어, 앱 목록 화면
→ **완료 기준**: 로그아웃 상태에서 `/app/xxx/index.html`을 직접 쳐도 로그인 화면으로 튕김. 로그인하면 정상 렌더링

### Phase 4 — 권한 & 감사 로그 (2일)
앱별 접근 권한 지정, 접근 로그 기록·조회·CSV, 관리자 행위 로그
→ **완료 기준**: A 사용자는 앱1만, B 사용자는 앱2만 보임. 누가 언제 뭘 열었는지 조회됨

### Phase 5 — 운영 마감 (1.5일)
HTTPS 리버스 프록시, Windows 서비스 등록(NSSM) 또는 systemd, 자동 백업 스크립트(DB + storage), 오류 페이지, 로그 로테이션
→ **완료 기준**: 서버 재부팅 후 자동 기동. 백업 파일이 생성됨

### Phase 6 — 검증 & 인수 (1일)
아래 체크리스트 전수 점검, 실제 HTML 1~2개 올려서 사용자 시나리오 테스트
→ **완료 기준**: 체크리스트 전 항목 통과

**총 예상: 약 11~12 작업일** (기능 축소 시 Phase 1+3만으로 최소 동작 버전 = 약 5일)

---

## 10. 인수 검증 체크리스트

**접근 통제**
- [ ] 비로그인 상태에서 `/app/<slug>/index.html` 직접 요청 → 로그인 리다이렉트
- [ ] 비로그인 상태에서 하위 리소스(`/app/<slug>/js/main.js`) 직접 요청 → 차단
- [ ] 로그아웃 후 뒤로가기로 캐시된 콘텐츠가 보이지 않음 (`no-store` 확인)
- [ ] 비활성화된 계정의 기존 세션으로 접근 → 즉시 차단
- [ ] 권한 없는 앱의 slug를 알고 접근 → 403

**경로/업로드**
- [ ] `/app/<slug>/../../data/portal.db` → 403
- [ ] URL 인코딩 우회 `%2e%2e%2f` → 403
- [ ] `..\evil.html`을 포함한 zip 업로드 → 거부
- [ ] `.exe`, `.php` 포함 zip 업로드 → 해당 파일 거부 또는 전체 거부

**인증**
- [ ] 6회 연속 로그인 실패 → 계정 잠금
- [ ] DB에 비밀번호 평문이 없음
- [ ] 일반 사용자가 `/admin/users` 접근 → 403
- [ ] CSRF 토큰 없는 POST → 거부

**운영**
- [ ] 서버 재부팅 후 자동 기동
- [ ] 백업 파일로 복구 리허설 성공
- [ ] 접근 로그에 사용자/앱/시각/IP가 정확히 남음

---

## 11. 나중에 확장할 수 있는 것

우선순위가 낮아 초기 범위에서 뺐지만, 구조상 나중에 붙이기 쉽게 설계되어 있습니다.

- **사용자 워터마크** — 콘텐츠에 이름·사번·시각을 반투명 오버레이 (유출 억제 + 추적)
- **동시 접속 제한** — 계정 공유 방지
- **IP 대역 제한** — 사내망 대역만 허용
- **부서/그룹 단위 권한**
- **콘텐츠 버전 관리** — 업로드 이력 보관 및 롤백
- **사내 SSO(AD/LDAP) 연동** — 계정 관리 부담 제거
- **뷰어 API** — HTML 앱이 서버에 데이터를 저장해야 할 때

---

## 12. 다음 액션

1. 위 §0의 "아직 정해야 할 것" 5가지를 알려주세요 (특히 서버 OS와 Node vs Python)
2. 확정되면 Phase 0~1을 바로 코드로 만들어 `D:\portal`에 넣어 드립니다
3. 붙이실 HTML 샘플이 하나 있으면 Phase 3에서 바로 실전 검증이 가능합니다
