'use strict';
/**
 * 최초 관리자 계정 생성.
 *
 *   npm run create-admin
 *   npm run create-admin -- --id admin --name "홍길동" --dept "정보시스템팀"
 *
 * 비밀번호는 임시 비밀번호가 자동 생성되어 화면에 한 번만 표시됩니다.
 * 해당 계정은 최초 로그인 시 비밀번호를 반드시 변경해야 합니다.
 */
const readline = require('node:readline/promises');
const { stdin, stdout } = require('node:process');

const db = require('../src/db');
const password = require('../src/lib/password');
const audit = require('../src/lib/audit');

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (!argv[i].startsWith('--')) continue;
    const key = argv[i].slice(2);
    const val = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
    out[key] = val;
  }
  return out;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  db.open();

  let loginId = args.id;
  let name = args.name;
  let dept = args.dept || '';

  if (!loginId || !name) {
    const rl = readline.createInterface({ input: stdin, output: stdout });
    try {
      if (!loginId) loginId = (await rl.question('관리자 아이디 (사번 또는 이메일): ')).trim();
      if (!name) name = (await rl.question('이름: ')).trim();
      if (!args.dept) dept = (await rl.question('부서 (생략 가능): ')).trim();
    } finally {
      rl.close();
    }
  }

  if (!loginId) { console.error('아이디는 필수입니다.'); process.exit(1); }
  if (loginId.length > 100) { console.error('아이디가 너무 깁니다.'); process.exit(1); }

  const existing = db.get('SELECT id, role FROM users WHERE login_id = ?', loginId);
  if (existing) {
    console.error(`이미 존재하는 아이디입니다: ${loginId}`);
    console.error('비밀번호를 초기화하려면: npm run reset-password -- --id ' + loginId);
    process.exit(1);
  }

  const temp = password.generateTemporary(14);
  const hash = await password.hash(temp);
  const now = Date.now();

  const { lastInsertRowid } = db.run(
    `INSERT INTO users (login_id, name, dept, password_hash, role, status,
                        must_change_pw, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'admin', 'active', 1, ?, ?)`,
    loginId, name || loginId, dept, hash, now, now
  );

  audit.record({
    actorId: null, actor: 'cli', action: 'user.create',
    target: loginId, detail: 'role=admin (create-admin 스크립트)',
  });

  console.log('');
  console.log('  관리자 계정이 생성되었습니다.');
  console.log('  ─────────────────────────────────────────────');
  console.log(`  아이디       : ${loginId}`);
  console.log(`  임시 비밀번호 : ${temp}`);
  console.log('  ─────────────────────────────────────────────');
  console.log('  이 비밀번호는 다시 표시되지 않습니다. 지금 안전한 곳에 옮겨 두세요.');
  console.log('  최초 로그인 시 비밀번호 변경이 강제됩니다.');
  console.log('');

  db.close();
  return lastInsertRowid;
}

main().catch((err) => {
  console.error('생성 실패:', err.message);
  process.exit(1);
});
