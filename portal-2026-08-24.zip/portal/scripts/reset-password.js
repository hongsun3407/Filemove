'use strict';
/**
 * 비밀번호 초기화 (관리자 화면이 나오기 전까지 쓰는 비상용 CLI).
 *
 *   npm run reset-password -- --id admin
 *
 * 임시 비밀번호를 새로 발급하고, 해당 사용자의 모든 세션을 끊습니다.
 */
const db = require('../src/db');
const password = require('../src/lib/password');
const session = require('../src/session');
const audit = require('../src/lib/audit');

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (!argv[i].startsWith('--')) continue;
    const key = argv[i].slice(2);
    const val = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
    out[key] = val;
  }
  return out;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.id) {
    console.error('사용법: npm run reset-password -- --id <아이디>');
    process.exit(1);
  }

  db.open();
  const user = db.get('SELECT id, login_id, name FROM users WHERE login_id = ?', args.id);
  if (!user) { console.error(`사용자를 찾을 수 없습니다: ${args.id}`); process.exit(1); }

  const temp = password.generateTemporary(14);
  const hash = await password.hash(temp);

  db.run(
    `UPDATE users
        SET password_hash = ?, must_change_pw = 1,
            failed_count = 0, locked_until = NULL, updated_at = ?
      WHERE id = ?`,
    hash, Date.now(), user.id
  );

  const killed = session.destroyAllForUser(user.id);
  audit.record({
    actor: 'cli', action: 'password.reset',
    target: user.login_id, detail: `세션 ${killed}건 종료`,
  });

  console.log('');
  console.log(`  ${user.name || user.login_id} (${user.login_id}) 의 비밀번호를 초기화했습니다.`);
  console.log(`  임시 비밀번호 : ${temp}`);
  console.log(`  기존 세션 ${killed}건이 종료되었습니다. 최초 로그인 시 변경이 강제됩니다.`);
  console.log('');

  db.close();
}

main().catch((err) => {
  console.error('초기화 실패:', err.message);
  process.exit(1);
});
