@echo off
chcp 65001 >nul
title CSV Studio Server

rem ─────────────────────────────────────────────────────────────
rem  아래 두 줄만 우리 환경에 맞게 고치면 됩니다.
rem  공유 폴더는 Z:\ 같은 드라이브 문자보다 \\서버이름\공유\csv 형태를 권장합니다.
rem ─────────────────────────────────────────────────────────────
set CSV_DIR=\\파일서버\공유\csv
set CSV_PORT=8800

python server.py --dir "%CSV_DIR%" --port %CSV_PORT%
if errorlevel 1 (
  echo.
  echo 실행에 실패했습니다. python 이 설치되어 있는지 확인하세요.
)
pause
