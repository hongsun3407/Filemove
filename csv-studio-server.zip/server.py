#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CSV Studio Server — 사내 폐쇄망용 CSV 공동 편집 서버

  python server.py --dir "Z:\\공통\\csv" --port 8800

* 파이썬 3.8 이상, 표준 라이브러리만 사용합니다. (설치 필요 없음)
* 여러 사람이 같은 파일을 동시에 편집해도 셀 단위로 병합되어 덮어쓰기가 발생하지 않습니다.
* 저장은 서버가 원자적으로 처리하며, 원본 인코딩(UTF-8 / CP949)과 구분자를 유지합니다.
"""

import argparse
import csv
import io
import json
import os
import queue
import shutil
import socket
import sys
import threading
import time
import traceback
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

APP_NAME = "CSV Studio Server"
VERSION = "2.0"
META_DIR = ".csvstudio"          # 백업·로그·서버 잠금 파일이 들어가는 폴더
FLUSH_INTERVAL = 1.5             # 디스크 기록 지연(초) — 타이핑마다 쓰지 않도록 묶음 처리
BACKUP_MIN_GAP = 300             # 같은 파일 백업 최소 간격(초)
BACKUP_KEEP = 40                 # 파일당 보관 백업 수
HISTORY_KEEP = 400               # 메모리에 유지할 파일별 변경 이력 수
CLIENT_TIMEOUT = 45              # 이 시간(초) 동안 소식 없으면 접속 종료로 간주
SCAN_INTERVAL = 5.0              # 폴더 재검색 / 외부 변경 감지 주기(초)
MAX_DEPTH = 3

PALETTE = ["#5145e5", "#0f9d6e", "#d9480f", "#0b7285", "#a61e4d", "#5f3dc4",
           "#2b8a3e", "#c92a2a", "#1864ab", "#862e9c", "#b08900", "#087f5b"]


_log_lock = threading.Lock()


def log(*a):
    with _log_lock:
        print(datetime.now().strftime("[%H:%M:%S]"), *a, flush=True)


def now_ms():
    return int(time.time() * 1000)


def new_id():
    return uuid.uuid4().hex[:12]


# ────────────────────────────────────────────────────────────────
#  CSV 읽기 / 쓰기
# ────────────────────────────────────────────────────────────────
def decode_bytes(raw):
    """(text, encoding, bom) — UTF-8 / CP949 자동 감지"""
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw[3:].decode("utf-8", "replace"), "utf-8", True
    try:
        return raw.decode("utf-8"), "utf-8", False
    except UnicodeDecodeError:
        pass
    for enc in ("cp949", "euc-kr"):
        try:
            return raw.decode(enc), "cp949", False
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace"), "utf-8", False


def detect_delim(text):
    line = text.split("\n", 1)[0]
    best, best_n = ",", 0
    for d in (",", ";", "\t", "|"):
        n, q = 0, False
        for ch in line:
            if ch == '"':
                q = not q
            elif ch == d and not q:
                n += 1
        if n > best_n:
            best, best_n = d, n
    return best


def encode_text(text, encoding, bom):
    if encoding == "cp949":
        try:
            return text.encode("cp949"), "cp949"
        except UnicodeEncodeError:
            # CP949로 표현할 수 없는 문자가 새로 입력된 경우 UTF-8로 승격
            return b"\xef\xbb\xbf" + text.encode("utf-8"), "utf-8"
    data = text.encode("utf-8")
    return (b"\xef\xbb\xbf" + data if bom else data), "utf-8"


# ────────────────────────────────────────────────────────────────
#  문서 (파일 하나)
# ────────────────────────────────────────────────────────────────
class Doc:
    def __init__(self, root, rel):
        self.root = root
        self.rel = rel
        self.abs = os.path.join(root, rel.replace("/", os.sep))
        self.lock = threading.RLock()
        self.cols = []          # [{id, name}]
        self.rows = []          # [{id, c:{colId: value}}]
        self.rev = 0
        self.history = []       # [{rev, op, user, ts}]
        self.dirty = False
        self.last_flush = 0.0
        self.last_backup = 0.0
        self.mtime = 0.0
        self.encoding = "utf-8"
        self.bom = False
        self.delim = ","
        self.eol = "\r\n"
        self.error = None
        self.load()

    # ── 디스크 → 메모리 ────────────────────────────────────────
    def load(self):
        with self.lock:
            try:
                with open(self.abs, "rb") as f:
                    raw = f.read()
                text, enc, bom = decode_bytes(raw)
                self.encoding, self.bom = enc, bom
                self.delim = detect_delim(text)
                self.eol = "\r\n" if "\r\n" in text else "\n"
                table = list(csv.reader(io.StringIO(text, newline=""), delimiter=self.delim))
                while table and not any(x.strip() for x in table[-1]):
                    table.pop()
                header = table.pop(0) if table else ["A"]
                self.cols = [{"id": new_id(), "name": h} for h in header]
                self.rows = []
                for r in table:
                    cells = {}
                    for i, col in enumerate(self.cols):
                        if i < len(r) and r[i] != "":
                            cells[col["id"]] = r[i]
                    self.rows.append({"id": new_id(), "c": cells})
                self.mtime = os.path.getmtime(self.abs)
                self.dirty = False
                self.error = None
                self.rev += 1
            except Exception as e:
                self.error = str(e)
                log("!! 읽기 실패", self.rel, e)

    # ── 메모리 → 텍스트 ────────────────────────────────────────
    def serialize(self):
        out = io.StringIO(newline="")
        w = csv.writer(out, delimiter=self.delim, lineterminator=self.eol,
                       quoting=csv.QUOTE_MINIMAL)
        w.writerow([c["name"] for c in self.cols])
        for r in self.rows:
            w.writerow([r["c"].get(c["id"], "") for c in self.cols])
        return out.getvalue()

    # ── 메모리 → 디스크 (원자적) ───────────────────────────────
    def flush(self, force=False):
        with self.lock:
            if not self.dirty and not force:
                return False
            text = self.serialize()
            data, used = encode_text(text, self.encoding, self.bom)
            if used != self.encoding:
                log("!! CP949로 저장할 수 없는 문자가 있어 UTF-8로 전환:", self.rel)
                self.encoding, self.bom = "utf-8", True
            self.backup()
            tmp = self.abs + ".tmp-" + uuid.uuid4().hex[:6]
            try:
                with open(tmp, "wb") as f:
                    f.write(data)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(tmp, self.abs)
                self.mtime = os.path.getmtime(self.abs)
                self.dirty = False
                self.last_flush = time.time()
                return True
            except Exception as e:
                self.error = "저장 실패: %s" % e
                log("!! 저장 실패", self.rel, e)
                try:
                    os.remove(tmp)
                except OSError:
                    pass
                return False

    def backup(self):
        """저장 직전 현재 디스크 내용을 백업 폴더에 보관"""
        if time.time() - self.last_backup < BACKUP_MIN_GAP:
            return
        try:
            bdir = os.path.join(self.root, META_DIR, "backup")
            os.makedirs(bdir, exist_ok=True)
            flat = self.rel.replace("/", "__")
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            if os.path.exists(self.abs):
                shutil.copy2(self.abs, os.path.join(bdir, "%s.%s.bak" % (flat, stamp)))
            self.last_backup = time.time()
            olds = sorted(f for f in os.listdir(bdir) if f.startswith(flat + "."))
            for f in olds[:-BACKUP_KEEP]:
                try:
                    os.remove(os.path.join(bdir, f))
                except OSError:
                    pass
        except Exception as e:
            log("!! 백업 실패", self.rel, e)

    # ── 상태 ──────────────────────────────────────────────────
    def snapshot(self):
        with self.lock:
            return {
                "path": self.rel, "rev": self.rev,
                "cols": [dict(c) for c in self.cols],
                "rows": [{"id": r["id"], "c": dict(r["c"])} for r in self.rows],
                "encoding": self.encoding, "delim": self.delim,
                "error": self.error,
            }

    def info(self):
        with self.lock:
            return {"path": self.rel, "rev": self.rev, "rows": len(self.rows),
                    "cols": len(self.cols), "encoding": self.encoding,
                    "dirty": self.dirty, "error": self.error}

    def col_index(self, cid):
        for i, c in enumerate(self.cols):
            if c["id"] == cid:
                return i
        return -1

    def row_index(self, rid):
        for i, r in enumerate(self.rows):
            if r["id"] == rid:
                return i
        return -1

    # ── 변경 적용 ─────────────────────────────────────────────
    def apply(self, ops, user):
        """유효한 op만 적용하고, 실제로 반영된 op 목록을 돌려준다."""
        applied = []
        with self.lock:
            for op in ops:
                t = op.get("t")
                try:
                    if t == "set":
                        i = self.row_index(op["row"])
                        if i < 0 or self.col_index(op["col"]) < 0:
                            continue
                        v = str(op.get("v", ""))
                        cur = self.rows[i]["c"].get(op["col"], "")
                        if cur == v:
                            continue
                        if v == "":
                            self.rows[i]["c"].pop(op["col"], None)
                        else:
                            self.rows[i]["c"][op["col"]] = v
                    elif t == "row+":
                        rid = op.get("id") or new_id()
                        if self.row_index(rid) >= 0:
                            continue
                        cells = {k: str(v) for k, v in (op.get("c") or {}).items()
                                 if self.col_index(k) >= 0}
                        at = len(self.rows)
                        if op.get("after"):
                            j = self.row_index(op["after"])
                            at = j + 1 if j >= 0 else len(self.rows)
                        elif op.get("at") is not None:
                            at = max(0, min(int(op["at"]), len(self.rows)))
                        self.rows.insert(at, {"id": rid, "c": cells})
                        op = dict(op, id=rid, at=at)
                    elif t == "row-":
                        i = self.row_index(op["row"])
                        if i < 0:
                            continue
                        self.rows.pop(i)
                    elif t == "col+":
                        cid = op.get("id") or new_id()
                        if self.col_index(cid) >= 0:
                            continue
                        at = len(self.cols)
                        if op.get("after"):
                            j = self.col_index(op["after"])
                            at = j + 1 if j >= 0 else len(self.cols)
                        elif op.get("at") is not None:
                            at = max(0, min(int(op["at"]), len(self.cols)))
                        self.cols.insert(at, {"id": cid, "name": str(op.get("name", "새 열"))})
                        vals = op.get("vals") or {}
                        for r in self.rows:
                            if r["id"] in vals and vals[r["id"]] != "":
                                r["c"][cid] = str(vals[r["id"]])
                        op = dict(op, id=cid, at=at)
                    elif t == "col-":
                        i = self.col_index(op["col"])
                        if i < 0 or len(self.cols) <= 1:
                            continue
                        self.cols.pop(i)
                        for r in self.rows:
                            r["c"].pop(op["col"], None)
                    elif t == "colname":
                        i = self.col_index(op["col"])
                        if i < 0:
                            continue
                        self.cols[i]["name"] = str(op.get("name", ""))
                    else:
                        continue
                except Exception:
                    log("!! op 처리 오류", traceback.format_exc())
                    continue

                self.rev += 1
                rec = {"rev": self.rev, "op": op, "user": user, "ts": now_ms()}
                applied.append(rec)
                self.history.append(rec)

            if applied:
                self.dirty = True
                del self.history[:-HISTORY_KEEP]
                self.write_log(applied)
        return applied

    def write_log(self, recs):
        try:
            ldir = os.path.join(self.root, META_DIR, "log")
            os.makedirs(ldir, exist_ok=True)
            p = os.path.join(ldir, self.rel.replace("/", "__") + ".jsonl")
            with open(p, "a", encoding="utf-8") as f:
                for r in recs:
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
        except Exception:
            pass


# ────────────────────────────────────────────────────────────────
#  접속자
# ────────────────────────────────────────────────────────────────
class Client:
    def __init__(self, sid, name, color):
        self.sid = sid
        self.name = name
        self.color = color
        self.q = queue.Queue(maxsize=500)
        self.seen = time.time()
        self.focus = None       # {path, row, col}

    def send(self, event, data):
        try:
            self.q.put_nowait((event, data))
        except queue.Full:
            pass

    def public(self):
        return {"sid": self.sid, "name": self.name, "color": self.color, "focus": self.focus}


# ────────────────────────────────────────────────────────────────
#  허브 (문서 + 접속자 관리)
# ────────────────────────────────────────────────────────────────
class Hub:
    def __init__(self, root):
        self.root = root
        self.docs = {}
        self.clients = {}
        self.lock = threading.RLock()
        self.color_i = 0
        self.scan()

    # ── 폴더 검색 ─────────────────────────────────────────────
    def scan(self):
        found = []
        for base, dirs, files in os.walk(self.root):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d != META_DIR]
            depth = os.path.relpath(base, self.root).count(os.sep)
            if os.path.relpath(base, self.root) == ".":
                depth = -1
            if depth >= MAX_DEPTH:
                dirs[:] = []
            for fn in files:
                if fn.startswith(".") or fn.startswith("~$") or fn.endswith(".tmp"):
                    continue
                if not fn.lower().endswith((".csv", ".tsv")):
                    continue
                rel = os.path.relpath(os.path.join(base, fn), self.root).replace(os.sep, "/")
                found.append(rel)
        found.sort()
        added, removed = [], []
        with self.lock:
            for rel in found:
                if rel not in self.docs:
                    self.docs[rel] = Doc(self.root, rel)
                    added.append(rel)
            for rel in list(self.docs):
                if rel not in found:
                    del self.docs[rel]
                    removed.append(rel)
        return added, removed

    def get(self, rel):
        with self.lock:
            return self.docs.get(rel)

    def files(self):
        with self.lock:
            return [d.info() for d in sorted(self.docs.values(), key=lambda x: x.rel)]

    # ── 접속자 ────────────────────────────────────────────────
    def join(self, name):
        with self.lock:
            color = PALETTE[self.color_i % len(PALETTE)]
            self.color_i += 1
            c = Client(new_id(), name, color)
            self.clients[c.sid] = c
        self.broadcast("users", {"users": self.users()})
        log("접속:", name, "(현재 %d명)" % len(self.clients))
        return c

    def leave(self, sid):
        with self.lock:
            c = self.clients.pop(sid, None)
        if c:
            log("나감:", c.name, "(현재 %d명)" % len(self.clients))
            self.broadcast("users", {"users": self.users()})

    def users(self):
        with self.lock:
            return [c.public() for c in self.clients.values()]

    def broadcast(self, event, data, exclude=None):
        with self.lock:
            targets = [c for sid, c in self.clients.items() if sid != exclude]
        for c in targets:
            c.send(event, data)

    def sweep(self):
        dead = []
        with self.lock:
            for sid, c in self.clients.items():
                if time.time() - c.seen > CLIENT_TIMEOUT:
                    dead.append(sid)
        for sid in dead:
            self.leave(sid)


# ────────────────────────────────────────────────────────────────
#  백그라운드 작업 (저장 · 폴더 감시)
# ────────────────────────────────────────────────────────────────
def background(hub, stop):
    last_scan = 0.0
    while not stop.is_set():
        time.sleep(0.4)
        try:
            # 1) 변경분 디스크 기록
            with hub.lock:
                docs = list(hub.docs.values())
            for d in docs:
                if d.dirty and time.time() - d.last_flush > FLUSH_INTERVAL:
                    if d.flush():
                        hub.broadcast("saved", {"path": d.rel, "ts": now_ms()})

            # 2) 폴더 재검색 · 외부 변경 감지
            if time.time() - last_scan > SCAN_INTERVAL:
                last_scan = time.time()
                added, removed = hub.scan()
                if added or removed:
                    hub.broadcast("files", {"files": hub.files(),
                                            "added": added, "removed": removed})
                for d in docs:
                    if d.dirty:
                        continue
                    try:
                        m = os.path.getmtime(d.abs)
                    except OSError:
                        continue
                    if m > d.mtime + 0.001:
                        log("외부에서 변경됨 → 다시 읽음:", d.rel)
                        d.load()
                        hub.broadcast("reload", {"path": d.rel, "rev": d.rev})

            hub.sweep()
        except Exception:
            log("!! 백그라운드 오류\n" + traceback.format_exc())


# ────────────────────────────────────────────────────────────────
#  HTTP 핸들러
# ────────────────────────────────────────────────────────────────
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "CSVStudio/" + VERSION

    def log_message(self, *a):
        pass

    # ── 응답 도우미 ───────────────────────────────────────────
    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path, ctype):
        try:
            with open(path, "rb") as f:
                body = f.read()
        except OSError:
            return self.send_json({"error": "not found"}, 404)
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def client(self, q):
        sid = (q.get("sid") or [None])[0] or self.headers.get("X-Sid")
        c = HUB.clients.get(sid) if sid else None
        if c:
            c.seen = time.time()
        return c

    # ── GET ───────────────────────────────────────────────────
    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        p = u.path
        try:
            if p in ("/", "/index.html"):
                return self.send_file(os.path.join(BASE_DIR, "app.html"),
                                      "text/html; charset=utf-8")
            if p == "/api/files":
                return self.send_json({"files": HUB.files(), "users": HUB.users(),
                                       "root": os.path.basename(ROOT.rstrip("/\\")) or ROOT})
            if p == "/api/doc":
                rel = (q.get("path") or [""])[0]
                d = HUB.get(rel)
                if not d:
                    return self.send_json({"error": "파일을 찾을 수 없습니다."}, 404)
                return self.send_json(d.snapshot())
            if p == "/api/history":
                rel = (q.get("path") or [""])[0]
                d = HUB.get(rel)
                if not d:
                    return self.send_json({"error": "not found"}, 404)
                with d.lock:
                    return self.send_json({"history": d.history[-120:][::-1]})
            if p == "/api/stream":
                return self.stream(q)
            if p == "/api/download":
                rel = (q.get("path") or [""])[0]
                d = HUB.get(rel)
                if not d:
                    return self.send_json({"error": "not found"}, 404)
                d.flush(force=True)
                data, _ = encode_text(d.serialize(), d.encoding, True)
                self.send_response(200)
                self.send_header("Content-Type", "text/csv")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Content-Disposition",
                                 "attachment; filename*=UTF-8''" +
                                 os.path.basename(rel).encode("utf-8").hex())
                self.end_headers()
                return self.wfile.write(data)
            return self.send_json({"error": "not found"}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            log("!! GET 오류 %s\n%s" % (p, traceback.format_exc()))
            try:
                self.send_json({"error": "server error"}, 500)
            except Exception:
                pass

    # ── POST ──────────────────────────────────────────────────
    def do_POST(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        p = u.path
        try:
            b = self.body_json()
            if p == "/api/hello":
                name = (b.get("name") or "").strip()[:24] or "사용자"
                c = HUB.join(name)
                return self.send_json({"sid": c.sid, "name": c.name, "color": c.color,
                                       "files": HUB.files(), "users": HUB.users(),
                                       "root": os.path.basename(ROOT.rstrip("/\\")) or ROOT,
                                       "server": VERSION})
            c = self.client(q)
            if not c:
                return self.send_json({"error": "세션이 만료되었습니다.", "reauth": True}, 401)

            if p == "/api/ops":
                rel = b.get("path") or ""
                d = HUB.get(rel)
                if not d:
                    return self.send_json({"error": "파일을 찾을 수 없습니다."}, 404)
                applied = d.apply(b.get("ops") or [], c.name)
                if applied:
                    HUB.broadcast("ops", {"path": rel, "recs": applied,
                                          "by": c.public()}, exclude=c.sid)
                return self.send_json({"rev": d.rev, "applied": applied})

            if p == "/api/focus":
                c.focus = b.get("focus")
                HUB.broadcast("focus", {"sid": c.sid, "name": c.name,
                                        "color": c.color, "focus": c.focus}, exclude=c.sid)
                return self.send_json({"ok": True})

            if p == "/api/flush":
                rel = b.get("path")
                docs = [HUB.get(rel)] if rel else list(HUB.docs.values())
                n = 0
                for d in docs:
                    if d and d.flush(force=False):
                        n += 1
                        HUB.broadcast("saved", {"path": d.rel, "ts": now_ms()})
                if rel and not n:
                    # 이미 저장된 상태였음 — 요청자에게만 알린다
                    c.send("saved", {"path": rel, "ts": now_ms()})
                return self.send_json({"saved": n})

            if p == "/api/bye":
                HUB.leave(c.sid)
                return self.send_json({"ok": True})

            return self.send_json({"error": "not found"}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            log("!! POST 오류 %s\n%s" % (p, traceback.format_exc()))
            try:
                self.send_json({"error": "server error"}, 500)
            except Exception:
                pass

    # ── SSE 스트림 ────────────────────────────────────────────
    def stream(self, q):
        c = self.client(q)
        if not c:
            return self.send_json({"error": "세션이 만료되었습니다.", "reauth": True}, 401)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        try:
            self.wfile.write(b": connected\n\n")
            self.wfile.flush()
            while True:
                try:
                    event, data = c.q.get(timeout=12)
                    payload = "event: %s\ndata: %s\n\n" % (
                        event, json.dumps(data, ensure_ascii=False))
                except queue.Empty:
                    payload = ": ping\n\n"
                c.seen = time.time()
                self.wfile.write(payload.encode("utf-8"))
                self.wfile.flush()
                if c.sid not in HUB.clients:
                    break
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            HUB.leave(c.sid)


class Server(ThreadingHTTPServer):
    """동시 접속이 몰려도 연결이 거절되지 않도록 대기열을 넉넉히 잡는다."""
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 128


# ────────────────────────────────────────────────────────────────
#  서버 중복 실행 방지
# ────────────────────────────────────────────────────────────────
def acquire_server_lock(root, port):
    d = os.path.join(root, META_DIR)
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "server.lock")
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                info = json.load(f)
            stale = False
            if info.get("host") == socket.gethostname():
                # 같은 PC에서 남은 잠금이라면 그 프로세스가 살아 있는지 직접 확인한다
                try:
                    os.kill(int(info.get("pid", -1)), 0)
                except (OSError, ValueError, TypeError):
                    stale = True
            if stale:
                log("이전 서버의 잠금 파일이 남아 있어 정리했습니다.")
            elif time.time() - info.get("heartbeat", 0) < 90:
                print("\n  !! 이 폴더에는 이미 서버가 실행 중입니다.")
                print("     호스트: %s / PID: %s / 포트: %s" %
                      (info.get("host"), info.get("pid"), info.get("port")))
                print("     같은 폴더에 서버를 두 개 띄우면 데이터가 손상될 수 있습니다.")
                print("     정말 실행하려면 다음 파일을 지우고 다시 시도하세요:\n     %s\n" % p)
                return None
        except Exception:
            pass

    def beat():
        while True:
            try:
                with open(p, "w", encoding="utf-8") as f:
                    json.dump({"host": socket.gethostname(), "pid": os.getpid(),
                               "port": port, "heartbeat": time.time()}, f)
            except Exception:
                pass
            time.sleep(30)

    threading.Thread(target=beat, daemon=True).start()
    return p


def local_ips():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    return ips


# ────────────────────────────────────────────────────────────────
def main():
    global HUB, ROOT, BASE_DIR
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

    ap = argparse.ArgumentParser(description=APP_NAME)
    ap.add_argument("--dir", "-d", default=os.environ.get("CSV_DIR", "."),
                    help="CSV가 들어 있는 폴더 (공유 드라이브 경로)")
    ap.add_argument("--port", "-p", type=int, default=int(os.environ.get("CSV_PORT", 8800)))
    ap.add_argument("--host", default="0.0.0.0", help="바인딩 주소 (기본: 모든 인터페이스)")
    args = ap.parse_args()

    ROOT = os.path.abspath(args.dir)
    if not os.path.isdir(ROOT):
        print("폴더를 찾을 수 없습니다:", ROOT)
        sys.exit(1)
    if not os.access(ROOT, os.W_OK):
        print("이 폴더에 쓰기 권한이 없습니다:", ROOT)
        sys.exit(1)
    if not os.path.exists(os.path.join(BASE_DIR, "app.html")):
        print("app.html 이 server.py 와 같은 폴더에 있어야 합니다.")
        sys.exit(1)

    if acquire_server_lock(ROOT, args.port) is None:
        sys.exit(1)

    HUB = Hub(ROOT)
    stop = threading.Event()
    threading.Thread(target=background, args=(HUB, stop), daemon=True).start()

    srv = Server((args.host, args.port), Handler)

    print("\n" + "═" * 58)
    print("  %s %s" % (APP_NAME, VERSION))
    print("═" * 58)
    print("  데이터 폴더 : %s" % ROOT)
    print("  CSV 파일    : %d개" % len(HUB.docs))
    print("  접속 주소   : http://localhost:%d" % args.port)
    for ip in local_ips():
        print("                http://%s:%d   ← 다른 사람에게 알려줄 주소" % (ip, args.port))
    print("═" * 58)
    print("  종료하려면 Ctrl+C 를 누르세요. 종료 시 변경분은 모두 저장됩니다.\n")

    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n종료하는 중… 변경분을 저장합니다.")
    finally:
        stop.set()
        n = 0
        for d in list(HUB.docs.values()):
            if d.flush():
                n += 1
        print("저장 완료: %d개 파일. 안녕히 가세요." % n)


if __name__ == "__main__":
    main()
