#!/bin/sh
# 공유 폴더 경로와 포트만 환경에 맞게 고치세요.
CSV_DIR="${CSV_DIR:-/mnt/share/csv}"
CSV_PORT="${CSV_PORT:-8800}"
cd "$(dirname "$0")" || exit 1
exec python3 server.py --dir "$CSV_DIR" --port "$CSV_PORT"
