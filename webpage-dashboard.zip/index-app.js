// ============================================================
// 전체 개요 페이지 로직
// ============================================================

(function () {
  "use strict";

  const { el } = window.NavKit;
  const contentRoot = document.getElementById("content-root");

  function emptyState(title, bodyHtml) {
    const box = el("div", { class: "empty-state" });
    box.innerHTML = `<h3>${title}</h3>${bodyHtml}`;
    return box;
  }

  function showServerError(err) {
    contentRoot.innerHTML = "";
    contentRoot.appendChild(emptyState(
      "서버에 연결할 수 없습니다",
      `<p>백엔드(server.js)가 실행 중인지 확인해주세요. 오류: <code>${(err && err.message) || err}</code></p>`
    ));
  }

  function showOverview(systems) {
    contentRoot.innerHTML = "";
    if (systems.length === 0) {
      contentRoot.appendChild(emptyState(
        "등록된 시스템 폴더가 없습니다",
        `<p>서버의 데이터 폴더(config.json의 <code>dataRoot</code>) 아래에 시스템별 하위 폴더를 만들고
         그 안에 .xlsx 소티 파일을 넣어주세요. 폴더 이름이 그대로 시스템 탭 이름이 됩니다. 예:</p>
         <ul>
           <li><code>데이터폴더/엔진/HL-7801_KE905_2026-08-19.xlsx</code></li>
           <li><code>데이터폴더/유압/...</code></li>
           <li><code>데이터폴더/새시스템/...</code> ← 폴더만 추가하면 코드 수정 없이 자동으로 탭이 생깁니다.</li>
         </ul>
         <p>엑셀 안에는 <code>Data</code> 시트(1행 헤더, 첫 열은 시간)에 <code>파라미터명(단위)</code> 형식의
         헤더를 쓰면 같은 단위끼리 자동으로 한 차트에 묶입니다. 상태 배지(정상/주의/위험)를 쓰려면
         <code>Thresholds</code> 시트에 <code>parameter, warn, crit, direction</code> 열을 추가하세요.</p>
         <p>엔진/유압/연료/착륙장치 폴더는 각각 전용 시각화(엔진 좌우 비교, 유압 기준밴드, 연료 누적영역,
         착륙장치 게이지)가 자동 적용되고, 그 외 폴더는 기본 라인차트로 표시됩니다.</p>`
      ));
      return;
    }

    const grid = el("div", { class: "kpi-grid" });
    contentRoot.appendChild(grid);

    systems.forEach(({ name, sortieCount }) => {
      const card = el("a", { class: "kpi-card", href: "system.html?system=" + encodeURIComponent(name) });
      card.appendChild(el("div", { class: "kpi-head" }, [
        el("h4", { text: name }),
        el("span", {
          class: "status-pill",
          style: `background:${sortieCount > 0 ? "var(--status-good)" : "var(--text-muted)"}`,
          text: sortieCount > 0 ? `${sortieCount}개 소티` : "파일 없음",
        }),
      ]));
      grid.appendChild(card);
    });
  }

  window.NavKit.mount({
    activeKey: "overview",
    root: document.getElementById("sidebar-root"),
    onReady: showOverview,
    onError: showServerError,
  });
})();
