// ============================================================
// 공용 사이드바 — index.html과 system.html이 동일하게 사용합니다.
// 시스템 목록은 백엔드 API(GET /api/systems)에서 가져옵니다 — 서버의
// 중앙 데이터 폴더 아래 "하위 폴더 이름"이 곧 시스템 탭입니다. 나중에
// 서버 쪽 데이터 폴더에 새 시스템 폴더가 추가되면, 페이지만 새로고침해도
// 코드 수정 없이 탭이 자동으로 늘어납니다.
// ============================================================

(function (root) {
  "use strict";

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach((k) => {
        if (k === "class") node.setAttribute("class", attrs[k]);
        else if (k === "text") node.textContent = attrs[k];
        else if (k === "href") node.setAttribute("href", attrs[k]);
        else node.setAttribute(k, attrs[k]);
      });
    }
    (children || []).forEach((c) => c && node.appendChild(c));
    return node;
  }

  function applyStoredTheme() {
    const saved = localStorage.getItem("fdr-theme");
    if (saved === "dark") document.documentElement.setAttribute("data-theme", "dark");
  }

  function toggleTheme() {
    const isDark = document.documentElement.getAttribute("data-theme") === "dark";
    document.documentElement.setAttribute("data-theme", isDark ? "light" : "dark");
    localStorage.setItem("fdr-theme", isDark ? "light" : "dark");
    return !isDark;
  }

  /**
   * mount({ activeKey, onReady, onError, root: containerEl })
   * activeKey: "overview" | 시스템 폴더명
   * onReady(systems): 시스템 목록 로딩에 성공하면 호출. systems = [{name, sortieCount}]
   * onError(err): API 호출 실패(서버 다운 등) 시 호출
   */
  async function mount(opts) {
    applyStoredTheme();
    const container = opts.root || document.getElementById("sidebar-root");

    container.innerHTML = "";
    const brand = el("div", { class: "brand" }, [
      el("div", { class: "title", text: "항공기 시스템 모니터링" }),
      el("div", { class: "subtitle", text: "시스템별 소티 데이터" }),
    ]);

    const overviewGroupLabel = el("div", { class: "nav-group-label", text: "개요" });
    const overviewLink = el("a", { class: "nav-item" + (opts.activeKey === "overview" ? " active" : ""), href: "index.html" }, [
      el("span", { class: "dot", style: "background:var(--series-1)" }),
      el("span", { text: "전체 개요" }),
    ]);

    const sysGroupLabel = el("div", { class: "nav-group-label", text: "시스템별" });
    const navList = el("nav", { id: "system-nav-list" });
    const navStatus = el("div", { class: "folder-access-box" }); // 로딩/오류 메시지 표시용

    const themeToggle = el("div", { class: "theme-toggle" }, [
      el("button", { type: "button", id: "theme-btn", text: document.documentElement.getAttribute("data-theme") === "dark" ? "라이트 모드로 전환" : "다크 모드로 전환" }),
    ]);

    container.appendChild(brand);
    container.appendChild(overviewGroupLabel);
    container.appendChild(overviewLink);
    container.appendChild(sysGroupLabel);
    container.appendChild(navList);
    container.appendChild(navStatus);
    container.appendChild(themeToggle);

    themeToggle.querySelector("#theme-btn").addEventListener("click", (e) => {
      const nowDark = toggleTheme();
      e.target.textContent = nowDark ? "라이트 모드로 전환" : "다크 모드로 전환";
      if (opts.onThemeChange) opts.onThemeChange(nowDark);
    });

    function renderNavItems(systems) {
      navList.innerHTML = "";
      systems.forEach(({ name }) => {
        const href = "system.html?system=" + encodeURIComponent(name);
        const item = el("a", { class: "nav-item" + (opts.activeKey === name ? " active" : ""), href }, [
          el("span", { class: "dot", style: "background:var(--text-muted)" }),
          el("span", { text: name }),
        ]);
        navList.appendChild(item);
      });
      if (systems.length === 0) {
        navList.appendChild(el("div", { class: "nav-empty-note", text: "등록된 시스템 폴더가 없습니다" }));
      }
    }

    navStatus.appendChild(el("div", { class: "folder-access-note", text: "시스템 목록을 불러오는 중…" }));

    try {
      const systems = await root.ApiClient.listSystems();
      navStatus.innerHTML = "";
      renderNavItems(systems);
      if (opts.onReady) await opts.onReady(systems);
    } catch (err) {
      navStatus.innerHTML = "";
      navStatus.appendChild(el("div", { class: "folder-access-note", text: `서버에 연결할 수 없습니다: ${err.message || err}` }));
      if (opts.onError) opts.onError(err);
    }
  }

  root.NavKit = { mount, el };
})(typeof window !== "undefined" ? window : globalThis);
