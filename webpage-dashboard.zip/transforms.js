// ============================================================
// 전처리(파생 파라미터) 정의 — 여기가 "정의할 곳"입니다.
//
// 엑셀에서 읽은 원본 컬럼(columns)에 사칙연산/비트분해/스케일변환 같은
// 전처리를 적용해 "파생 파라미터"를 만들고 싶을 때 이 파일을 고칩니다.
// system-app.js가 엑셀을 파싱한 직후, 차트를 그리기 전에 이 파일의
// applyForKey()를 호출해서 반환된 컬럼(원본 + 파생)을 그대로 차트/타일에
// 사용합니다.
//
// 아래 DERIVED 안의 각 항목은 예시이며, 실제 원시 파라미터 이름/비트
// 배치/스케일 값에 맞게 고쳐서 쓰세요. 정의하지 않은 시스템은 원본
// 컬럼을 그대로 통과시킵니다(default).
// ============================================================

(function (root) {
  "use strict";

  // ---------------------------------------------------------
  // 재사용 가능한 저수준 변환 함수 (사칙연산 / 비트 분해 / 스케일 변환)
  // ---------------------------------------------------------

  // 사칙연산: raw * scale + offset  (예: ADC 카운트 -> 공학단위)
  function scaleOffset(values, scale, offset) {
    return values.map((v) => (v === null || v === undefined || Number.isNaN(v) ? null : v * scale + offset));
  }

  // 정수 워드에서 비트 하나 추출 (0 또는 1)
  function bit(rawValue, bitIndex) {
    if (rawValue === null || rawValue === undefined || Number.isNaN(rawValue)) return null;
    return (Math.trunc(rawValue) >> bitIndex) & 1;
  }

  // 정수 워드에서 여러 비트(필드) 추출 (예: 4비트 = 0~15 코드)
  function bitField(rawValue, startBit, numBits) {
    if (rawValue === null || rawValue === undefined || Number.isNaN(rawValue)) return null;
    const mask = (1 << numBits) - 1;
    return (Math.trunc(rawValue) >> startBit) & mask;
  }

  // col(컬럼 하나)의 특정 비트를 0/1 시계열(파생 컬럼)로 뽑아냅니다.
  function extractBitSeries(col, bitIndex, name) {
    return { name, unit: "", values: col.values.map((v) => bit(v, bitIndex)) };
  }

  // col의 여러 비트를 코드값(또는 lookup 테이블로 사람이 읽을 수 있는 값)으로 뽑아냅니다.
  // lookup 예: {0:'UP', 1:'1도', 2:'5도', ...} — 넘기지 않으면 코드값 그대로.
  function extractBitFieldSeries(col, startBit, numBits, name, lookup, unit) {
    return {
      name,
      unit: unit || "",
      values: col.values.map((v) => {
        const code = bitField(v, startBit, numBits);
        if (code === null) return null;
        return lookup ? (lookup[code] !== undefined ? lookup[code] : code) : code;
      }),
    };
  }

  // 여러 컬럼을 사칙연산으로 조합 (예: 평균/차이/합계/비율).
  // colsByName: {이름: column}, names: 사용할 컬럼 이름들, fn: (v1,v2,...) => 값
  function combine(colsByName, names, fn, outName, outUnit) {
    const arrays = names.map((n) => colsByName[n] && colsByName[n].values);
    if (arrays.some((a) => !a)) return null; // 필요한 원본 컬럼이 없으면 조용히 건너뜀
    const len = arrays[0].length;
    const values = [];
    for (let i = 0; i < len; i++) {
      const args = arrays.map((a) => a[i]);
      values.push(args.some((v) => v === null || v === undefined || Number.isNaN(v)) ? null : fn(...args));
    }
    return { name: outName, unit: outUnit || "", values };
  }

  // 변화율 (예: psi/min, ft/min) — 급격한 변화를 잡아내는 파생 파라미터
  function rateOfChange(time, col, outName, outUnit) {
    const values = col.values.map((v, i) => {
      if (i === 0) return null;
      const prev = col.values[i - 1];
      const dt = time[i] - time[i - 1];
      if (v === null || prev === null || !dt) return null;
      return (v - prev) / dt;
    });
    return { name: outName, unit: outUnit || (col.unit ? `${col.unit}/min` : ""), values };
  }

  // 이동평균 (노이즈가 심한 원시값을 매끈하게)
  function movingAverage(col, windowSize, outName) {
    const values = col.values.map((_, i) => {
      const start = Math.max(0, i - windowSize + 1);
      const slice = col.values.slice(start, i + 1).filter((v) => v !== null && v !== undefined && !Number.isNaN(v));
      if (!slice.length) return null;
      return slice.reduce((a, b) => a + b, 0) / slice.length;
    });
    return { name: outName, unit: col.unit, values };
  }

  function byName(columns) {
    const map = {};
    columns.forEach((c) => { map[c.name] = c; });
    return map;
  }

  // spec 목록을 순서대로 실행하며, 만들어진 파생 컬럼을 map에도 즉시 반영합니다.
  // (뒤에 나오는 spec이 앞에서 만든 파생 컬럼을 다시 참조할 수 있음 — 예: 총연료 -> 총연료 소모율)
  function applyDerived(columns, specs) {
    const map = byName(columns);
    const out = [...columns];
    specs.forEach((spec) => {
      let col;
      try { col = spec.build(map, out); } catch (e) { col = null; }
      if (col) { out.push(col); map[col.name] = col; }
    });
    return out;
  }

  // ---------------------------------------------------------
  // 시스템별 파생 파라미터 정의 — 예시입니다. 실제 원시 파라미터 이름/
  // 비트 배치/스케일 값에 맞게 고쳐서 쓰세요.
  // ---------------------------------------------------------
  const DERIVED = {
    engine: (time, columns) => applyDerived(columns, [
      // 좌우 엔진 N1 평균
      { build: (m) => combine(m, ["ENG1_N1", "ENG2_N1"], (a, b) => (a + b) / 2, "N1_AVG", "%") },
      // EGT 레드라인(예시 950°C) 대비 남은 마진 — 값이 작아질수록 위험
      { build: (m) => m["ENG1_EGT"] && { name: "ENG1_EGT_MARGIN", unit: "°C", values: m["ENG1_EGT"].values.map((v) => (v === null ? null : 950 - v)) } },
      { build: (m) => m["ENG2_EGT"] && { name: "ENG2_EGT_MARGIN", unit: "°C", values: m["ENG2_EGT"].values.map((v) => (v === null ? null : 950 - v)) } },
      // 예시: 원시 스로틀 레버 카운트값(THROTTLE_RAW)이 있다면 실제 %로 스케일 변환
      // { build: (m) => m["THROTTLE_RAW"] && { name: "THROTTLE_PCT", unit: "%", values: scaleOffset(m["THROTTLE_RAW"].values, 0.1, 0) } },
      // 예시: 엔진 상태 워드(정수, 비트 packed)를 비트별로 분해
      // { build: (m) => m["ENG1_STATUS_WORD"] && extractBitSeries(m["ENG1_STATUS_WORD"], 0, "ENG1_IGNITION_ON") },
      // { build: (m) => m["ENG1_STATUS_WORD"] && extractBitSeries(m["ENG1_STATUS_WORD"], 1, "ENG1_REVERSER_DEPLOYED") },
    ]),

    hydraulics: (time, columns) => applyDerived(columns, [
      // 압력 강하율 — 급격한 누유/실속 감지용
      { build: (m) => m["SYS_A"] && rateOfChange(time, m["SYS_A"], "SYS_A_dPdt") },
      { build: (m) => m["SYS_B"] && rateOfChange(time, m["SYS_B"], "SYS_B_dPdt") },
      // 두 계통 압력차 — 크로스 밸브 개폐 판단에 유용
      { build: (m) => combine(m, ["SYS_A", "SYS_B"], (a, b) => a - b, "SYS_A_MINUS_B", "psi") },
      // 예시: 밸브 상태 워드 비트 분해
      // { build: (m) => m["HYD_STATUS_WORD"] && extractBitSeries(m["HYD_STATUS_WORD"], 2, "PTU_ACTIVE") },
    ]),

    fuel: (time, columns) => applyDerived(columns, [
      // 탱크 합계 — 개요/타일에서 총연료량을 바로 보고 싶을 때
      { build: (m) => combine(m, ["TankL", "TankC", "TankR"], (a, b, c) => a + b + c, "FUEL_TOTAL", "kg") },
      // 총연료 소모율 (위에서 만든 FUEL_TOTAL을 그대로 다시 사용)
      { build: (m) => m["FUEL_TOTAL"] && rateOfChange(time, m["FUEL_TOTAL"], "FUEL_FLOW_RATE") },
      // 좌우 탱크 불균형
      { build: (m) => combine(m, ["TankL", "TankR"], (a, b) => Math.abs(a - b), "TANK_LR_IMBALANCE", "kg") },
    ]),

    landingGear: (time, columns) => applyDerived(columns, [
      // 좌우 브레이크 온도차 — 편제동/마모 감지
      { build: (m) => combine(m, ["L_Brake", "R_Brake"], (a, b) => Math.abs(a - b), "BRAKE_TEMP_DELTA", "°C") },
      // 예시: 기어 위치 워드(정수, 비트 packed) 디코딩 — 실제로 매우 흔한 패턴입니다.
      // { build: (m) => m["GEAR_STATUS_WORD"] && extractBitSeries(m["GEAR_STATUS_WORD"], 0, "NOSE_DOWNLOCKED") },
      // { build: (m) => m["GEAR_STATUS_WORD"] && extractBitSeries(m["GEAR_STATUS_WORD"], 1, "LEFT_DOWNLOCKED") },
      // { build: (m) => m["GEAR_STATUS_WORD"] && extractBitSeries(m["GEAR_STATUS_WORD"], 2, "RIGHT_DOWNLOCKED") },
    ]),

    pressurization: (time, columns) => applyDerived(columns, [
      // 객실고도 변화율 — 급격한 감압 감지에 중요
      { build: (m) => m["CabinAlt"] && rateOfChange(time, m["CabinAlt"], "CABIN_ALT_RATE") },
    ]),

    electrical: (time, columns) => applyDerived(columns, [
      // 예시: 버스 상태 워드 비트 분해 (버스 절체, APU 발전기 연결 등)
      // { build: (m) => m["ELEC_STATUS_WORD"] && extractBitSeries(m["ELEC_STATUS_WORD"], 0, "AC_BUS1_OFF") },
    ]),

    flightControls: (time, columns) => applyDerived(columns, []),

    default: (time, columns) => columns,
  };

  // ---------------------------------------------------------
  // 시스템 폴더명을 위 DERIVED 키로 매칭 — visualizers.js의 분류와는
  // 독립적입니다(시각화 전략과 전처리 정의는 서로 다른 확장 지점이라
  // 일부러 따로 뒀습니다. 예: 전기 시스템은 기본 라인차트를 쓰면서도
  // 자체 전처리는 필요할 수 있음).
  // ---------------------------------------------------------
  function normalize(str) {
    return String(str || "").toLowerCase().replace(/[\s\-_/]+/g, "");
  }

  const ALIASES = {
    engine: ["엔진", "engine"],
    hydraulics: ["유압", "hydraulics", "hydraulic"],
    fuel: ["연료", "fuel"],
    landingGear: ["착륙장치", "landinggear", "landing gear"],
    pressurization: ["공조여압", "공조/여압", "여압", "pressurization", "aircond", "aircondition"],
    electrical: ["전기", "electrical", "electric"],
    flightControls: ["비행조종", "flightcontrols", "flight control", "flightcontrol"],
  };

  function classifySystemName(systemName) {
    const n = normalize(systemName);
    for (const key of Object.keys(ALIASES)) {
      if (ALIASES[key].some((a) => normalize(a) === n)) return key;
    }
    return "default";
  }

  // 폴더명(예: "엔진", "hydraulics")을 받아 그 시스템에 맞는 파생 파라미터를 적용합니다.
  function applyForSystem(systemName, time, columns) {
    const fn = DERIVED[classifySystemName(systemName)] || DERIVED.default;
    return fn(time, columns);
  }

  const Transforms = {
    scaleOffset, bit, bitField, extractBitSeries, extractBitFieldSeries,
    combine, rateOfChange, movingAverage, applyDerived, applyForSystem, classifySystemName, DERIVED,
  };
  root.Transforms = Transforms;
  if (typeof module !== "undefined" && module.exports) module.exports = Transforms;
})(typeof window !== "undefined" ? window : globalThis);
