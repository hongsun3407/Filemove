// ============================================================
// Plotly.js 기반 차트 렌더러
// - 파라미터 = 색상(카테고리 컬러, dataviz 팔레트 고정 슬롯)
// - 소티(비행) = 실선/점선(dash) — "비교 소티" 선택 시 같은 파라미터를
//   같은 색으로, 점선으로 겹쳐 그려 새로운 색을 만들지 않고 구분합니다.
// - x축 통합 hover(크로스헤어형 툴팁), 확대/축소/리셋/이미지 저장은
//   Plotly 기본 모드바를 그대로 사용합니다.
// - 접근성용 "표로 보기" 토글은 별도 HTML 테이블로 제공합니다.
// ============================================================

(function (global) {
  "use strict";

  const STATUS_LABEL = { good: "정상", warning: "주의", serious: "경고", critical: "위험" };

  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  function statusColorVar(status) {
    return `var(--status-${status || "good"})`;
  }

  // "#2a78d6" + 0.22 -> "#2a78d638" (8자리 헥스 알파) — Plotly의 SVG fill 속성에
  // var()/color-mix()를 중첩하지 않고 안전하게 반투명 채우기색을 넘기기 위해 사용.
  function hexWithAlpha(hex, alpha) {
    const a = Math.round(Math.max(0, Math.min(1, alpha)) * 255).toString(16).padStart(2, "0");
    return `${hex}${a}`;
  }

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach((k) => {
        if (k === "class") node.setAttribute("class", attrs[k]);
        else if (k === "text") node.textContent = attrs[k];
        else node.setAttribute(k, attrs[k]);
      });
    }
    (children || []).forEach((c) => c && node.appendChild(c));
    return node;
  }

  /**
   * chartSpec: { title, unit, series: [{name, color, points:[{x,y}]}] }
   * opts: {
   *   compareSeries: 같은 shape의 series 배열 (비교 소티 데이터, 선택),
   *   primaryLabel: 기본 소티 라벨,
   *   compareLabel: 비교 소티 라벨,
   * }
   */
  function renderLineChart(container, chartSpec, opts) {
    opts = opts || {};
    const isCompare = !!opts.compareSeries;

    const surface = cssVar("--surface-1");
    const textSecondary = cssVar("--text-secondary");
    const textMuted = cssVar("--text-muted");
    const gridline = cssVar("--gridline");
    const baseline = cssVar("--baseline");

    const card = el("div", { class: "chart-card" });
    const head = el("div", { class: "chart-card-head" }, [
      el("h3", { text: chartSpec.title }),
      el("div", { class: "unit-note", text: chartSpec.unit ? `단위: ${chartSpec.unit}` : "" }),
    ]);
    const toolbar = el("div", { class: "chart-toolbar" });
    const tableBtn = el("button", { class: "icon-btn", type: "button", text: "표로 보기" });
    toolbar.appendChild(tableBtn);
    head.appendChild(toolbar);
    card.appendChild(head);

    if (isCompare) {
      card.appendChild(el("div", { class: "compare-note" }, [
        el("span", {}, [
          Object.assign(document.createElement("span"), { className: "solid-sample" }),
          document.createTextNode(opts.primaryLabel || "기본 소티"),
        ]),
        el("span", {}, [
          Object.assign(document.createElement("span"), { className: "dash-sample" }),
          document.createTextNode(opts.compareLabel || "비교 소티"),
        ]),
      ]));
    }

    const plotDiv = el("div", { class: "plotly-div" });
    const svgWrap = el("div", { class: "chart-svg-wrap" }, [plotDiv]);
    card.appendChild(svgWrap);

    const table = el("table", { class: "table-view hidden" });
    card.appendChild(table);

    function buildTable() {
      table.innerHTML = "";
      const xs = chartSpec.series[0].points.map((p) => p.x);
      const sampleIdx = [];
      const step = Math.max(1, Math.floor(xs.length / 12));
      for (let i = 0; i < xs.length; i += step) sampleIdx.push(i);
      if (sampleIdx[sampleIdx.length - 1] !== xs.length - 1) sampleIdx.push(xs.length - 1);

      const thead = el("tr", {}, [el("th", { text: "시간(분)" }), ...chartSpec.series.map((s) => el("th", { text: `${s.name} (${chartSpec.unit || ""})` }))]);
      table.appendChild(el("thead", {}, [thead]));
      const tbody = el("tbody");
      sampleIdx.forEach((i) => {
        const cells = [el("td", { text: String(xs[i]) })];
        chartSpec.series.forEach((s) => cells.push(el("td", { text: String(s.points[i].y) })));
        tbody.appendChild(el("tr", {}, cells));
      });
      table.appendChild(tbody);
      if (isCompare) {
        table.appendChild(el("caption", { text: "표는 기본 소티 데이터 기준입니다 (비교 소티는 차트에서만 표시)." }));
      }
    }
    buildTable();

    tableBtn.addEventListener("click", () => {
      const showing = !table.classList.contains("hidden");
      table.classList.toggle("hidden", showing);
      svgWrap.classList.toggle("hidden", !showing);
      tableBtn.textContent = showing ? "표로 보기" : "차트로 보기";
    });

    // ---- Plotly traces ----
    const traces = [];
    chartSpec.series.forEach((s) => {
      const color = cssVar(`--${s.color}`);
      traces.push({
        x: s.points.map((p) => p.x),
        y: s.points.map((p) => p.y),
        name: isCompare ? `${s.name} · ${opts.primaryLabel || "기본"}` : s.name,
        mode: "lines",
        line: { color, width: 2, dash: "solid" },
        hovertemplate: `%{y} ${chartSpec.unit || ""}<extra>${s.name}</extra>`,
      });
    });
    if (isCompare) {
      opts.compareSeries.forEach((s) => {
        const color = cssVar(`--${s.color}`);
        traces.push({
          x: s.points.map((p) => p.x),
          y: s.points.map((p) => p.y),
          name: `${s.name} · ${opts.compareLabel || "비교"}`,
          mode: "lines",
          line: { color, width: 2, dash: "dot" },
          hovertemplate: `%{y} ${chartSpec.unit || ""}<extra>${s.name} (비교)</extra>`,
        });
      });
    }

    const layout = {
      paper_bgcolor: surface,
      plot_bgcolor: surface,
      font: { family: "system-ui, -apple-system, 'Segoe UI', 'Malgun Gothic', sans-serif", size: 11.5, color: textSecondary },
      margin: { l: 48, r: 16, t: 8, b: 36 },
      height: 260,
      hovermode: "x unified",
      xaxis: {
        title: { text: chartSpec.unitLabel || "시간(분)", font: { size: 10.5, color: textMuted } },
        gridcolor: gridline,
        zerolinecolor: baseline,
        tickfont: { color: textMuted, size: 10.5 },
        showspikes: true,
        spikemode: "across",
        spikethickness: 1,
        spikedash: "dot",
        spikecolor: textMuted,
      },
      yaxis: {
        gridcolor: gridline,
        zerolinecolor: baseline,
        tickfont: { color: textMuted, size: 10.5 },
      },
      legend: (chartSpec.series.length >= 2 || isCompare)
        ? { orientation: "h", y: -0.28, font: { color: textSecondary, size: 11 } }
        : { visible: false },
      modebar: { bgcolor: surface, color: textMuted, activecolor: textSecondary },
    };

    const config = {
      displayModeBar: true,
      displaylogo: false,
      modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d"],
      responsive: true,
      locale: "ko",
    };

    Plotly.newPlot(plotDiv, traces, layout, config);

    container.appendChild(card);
    return card;
  }

  // 공통 카드 뼈대(제목/툴바/비교노트) — 여러 차트 유형이 재사용합니다.
  function createCardShell(title, unitNote, opts) {
    const card = el("div", { class: "chart-card" });
    const head = el("div", { class: "chart-card-head" }, [
      el("h3", { text: title }),
      el("div", { class: "unit-note", text: unitNote || "" }),
    ]);
    card.appendChild(head);
    if (opts && opts.isCompare) {
      card.appendChild(el("div", { class: "compare-note" }, [
        el("span", {}, [
          Object.assign(document.createElement("span"), { className: "solid-sample" }),
          document.createTextNode(opts.primaryLabel || "기본 소티"),
        ]),
        el("span", {}, [
          Object.assign(document.createElement("span"), { className: "dash-sample" }),
          document.createTextNode(opts.compareLabel || "비교 소티"),
        ]),
      ]));
    }
    return { card, head };
  }

  function commonLayoutBits() {
    return {
      surface: cssVar("--surface-1"),
      textSecondary: cssVar("--text-secondary"),
      textMuted: cssVar("--text-muted"),
      gridline: cssVar("--gridline"),
      baseline: cssVar("--baseline"),
      good: cssVar("--status-good"),
      warning: cssVar("--status-warning"),
      critical: cssVar("--status-critical"),
    };
  }

  const FONT_FAMILY = "system-ui, -apple-system, 'Segoe UI', 'Malgun Gothic', sans-serif";

  /**
   * 엔진류: ENG1 vs ENG2 처럼 짝을 이루는 두 계열을 위 칸에, 그 차이(Δ)를
   * 0 기준선 아래 칸에 그려 좌우 비대칭을 한눈에 보게 합니다.
   * pair: { title, unit, unitLabel, a:{name,color,points}, b:{name,color,points} }
   */
  function renderPairDeltaChart(container, pair, opts) {
    opts = opts || {};
    const c = commonLayoutBits();
    const { card } = createCardShell(`${pair.title} — ${pair.a.name} vs ${pair.b.name}`, pair.unit ? `단위: ${pair.unit}` : "", opts);
    card.appendChild(el("div", { class: "unit-note", text: "아래 칸: 두 계열의 차이(Δ = " + pair.b.name + " − " + pair.a.name + "), 기본 소티 기준" }));

    const plotDiv = el("div", { class: "plotly-div", style: "min-height:340px" });
    card.appendChild(el("div", { class: "chart-svg-wrap" }, [plotDiv]));
    container.appendChild(card);

    const xs = pair.a.points.map((p) => p.x);
    const yA = pair.a.points.map((p) => p.y);
    const yB = pair.b.points.map((p) => p.y);
    const delta = xs.map((x, i) => (yA[i] != null && yB[i] != null ? +(yB[i] - yA[i]).toFixed(3) : null));
    const pos = delta.map((d) => (d != null && d >= 0 ? d : null));
    const neg = delta.map((d) => (d != null && d < 0 ? d : null));

    const traces = [
      { x: xs, y: yA, name: pair.a.name, mode: "lines", line: { color: cssVar(`--${pair.a.color}`), width: 2 }, xaxis: "x", yaxis: "y", hovertemplate: `%{y} ${pair.unit || ""}<extra>${pair.a.name}</extra>` },
      { x: xs, y: yB, name: pair.b.name, mode: "lines", line: { color: cssVar(`--${pair.b.color}`), width: 2 }, xaxis: "x", yaxis: "y", hovertemplate: `%{y} ${pair.unit || ""}<extra>${pair.b.name}</extra>` },
      { x: xs, y: pos, name: "Δ ≥ 0", mode: "lines", line: { color: cssVar("--series-1"), width: 1.5 }, fill: "tozeroy", fillcolor: hexWithAlpha(cssVar("--series-1"), 0.22), xaxis: "x", yaxis: "y2", hovertemplate: `Δ %{y}<extra></extra>`, showlegend: false },
      { x: xs, y: neg, name: "Δ < 0", mode: "lines", line: { color: cssVar("--series-8"), width: 1.5 }, fill: "tozeroy", fillcolor: hexWithAlpha(cssVar("--series-8"), 0.22), xaxis: "x", yaxis: "y2", hovertemplate: `Δ %{y}<extra></extra>`, showlegend: false },
    ];

    const layout = {
      paper_bgcolor: c.surface,
      plot_bgcolor: c.surface,
      font: { family: FONT_FAMILY, size: 11.5, color: c.textSecondary },
      margin: { l: 48, r: 16, t: 8, b: 36 },
      height: 340,
      hovermode: "x unified",
      xaxis: { anchor: "y2", title: { text: pair.unitLabel || "시간(분)", font: { size: 10.5, color: c.textMuted } }, gridcolor: c.gridline, zerolinecolor: c.baseline, tickfont: { color: c.textMuted, size: 10.5 } },
      yaxis: { domain: [0.55, 1], gridcolor: c.gridline, zerolinecolor: c.baseline, tickfont: { color: c.textMuted, size: 10.5 } },
      yaxis2: { domain: [0, 0.4], title: { text: "Δ", font: { size: 10.5, color: c.textMuted } }, gridcolor: c.gridline, zerolinecolor: c.baseline, tickfont: { color: c.textMuted, size: 10.5 } },
      legend: { orientation: "h", y: -0.2, font: { color: c.textSecondary, size: 11 } },
      modebar: { bgcolor: c.surface, color: c.textMuted, activecolor: c.textSecondary },
    };
    const config = { displayModeBar: true, displaylogo: false, modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d"], responsive: true, locale: "ko" };
    Plotly.newPlot(plotDiv, traces, layout, config);
    return card;
  }

  /**
   * 유압류: 정상/주의/위험 기준선 밴드를 배경에 깔아 현재 트레이스가
   * 어느 구간에 있는지 바로 보이게 합니다.
   * bandRule: { warn, crit, direction: 'up'|'down', paramName }
   */
  function renderBandedLineChart(container, chartSpec, bandRule, opts) {
    opts = opts || {};
    const isCompare = !!opts.compareSeries;
    const c = commonLayoutBits();
    const { card } = createCardShell(chartSpec.title, chartSpec.unit ? `단위: ${chartSpec.unit}` : "", { ...opts, isCompare });
    if (bandRule) {
      card.appendChild(el("div", { class: "unit-note", text: `배경 밴드 기준: ${bandRule.paramName} (주의 ${bandRule.warn}, 위험 ${bandRule.crit})` }));
    }
    const plotDiv = el("div", { class: "plotly-div" });
    card.appendChild(el("div", { class: "chart-svg-wrap" }, [plotDiv]));
    container.appendChild(card);

    const allY = chartSpec.series.flatMap((s) => s.points.map((p) => p.y));
    if (isCompare) opts.compareSeries.forEach((s) => allY.push(...s.points.map((p) => p.y)));
    const yMin = Math.min(...allY), yMax = Math.max(...allY);
    const pad = (yMax - yMin) * 0.15 || 10;
    const lo = yMin - pad, hi = yMax + pad;

    const shapes = [];
    if (bandRule) {
      const { warn, crit, direction } = bandRule;
      const higherWorse = direction !== "down";
      if (higherWorse) {
        shapes.push({ type: "rect", xref: "paper", x0: 0, x1: 1, y0: lo, y1: warn, fillcolor: c.good, opacity: 0.08, line: { width: 0 } });
        shapes.push({ type: "rect", xref: "paper", x0: 0, x1: 1, y0: warn, y1: crit, fillcolor: c.warning, opacity: 0.12, line: { width: 0 } });
        shapes.push({ type: "rect", xref: "paper", x0: 0, x1: 1, y0: crit, y1: hi, fillcolor: c.critical, opacity: 0.12, line: { width: 0 } });
      } else {
        shapes.push({ type: "rect", xref: "paper", x0: 0, x1: 1, y0: warn, y1: hi, fillcolor: c.good, opacity: 0.08, line: { width: 0 } });
        shapes.push({ type: "rect", xref: "paper", x0: 0, x1: 1, y0: crit, y1: warn, fillcolor: c.warning, opacity: 0.12, line: { width: 0 } });
        shapes.push({ type: "rect", xref: "paper", x0: 0, x1: 1, y0: lo, y1: crit, fillcolor: c.critical, opacity: 0.12, line: { width: 0 } });
      }
    }

    const traces = chartSpec.series.map((s) => ({
      x: s.points.map((p) => p.x),
      y: s.points.map((p) => p.y),
      name: isCompare ? `${s.name} · ${opts.primaryLabel || "기본"}` : s.name,
      mode: "lines",
      line: { color: cssVar(`--${s.color}`), width: 2 },
      hovertemplate: `%{y} ${chartSpec.unit || ""}<extra>${s.name}</extra>`,
    }));
    if (isCompare) {
      opts.compareSeries.forEach((s) => {
        traces.push({
          x: s.points.map((p) => p.x), y: s.points.map((p) => p.y),
          name: `${s.name} · ${opts.compareLabel || "비교"}`, mode: "lines",
          line: { color: cssVar(`--${s.color}`), width: 2, dash: "dot" },
          hovertemplate: `%{y} ${chartSpec.unit || ""}<extra>${s.name} (비교)</extra>`,
        });
      });
    }

    const layout = {
      paper_bgcolor: c.surface,
      plot_bgcolor: c.surface,
      font: { family: FONT_FAMILY, size: 11.5, color: c.textSecondary },
      margin: { l: 48, r: 16, t: 8, b: 36 },
      height: 260,
      hovermode: "x unified",
      shapes,
      xaxis: { title: { text: chartSpec.unitLabel || "시간(분)", font: { size: 10.5, color: c.textMuted } }, gridcolor: c.gridline, zerolinecolor: c.baseline, tickfont: { color: c.textMuted, size: 10.5 } },
      yaxis: { range: [lo, hi], gridcolor: c.gridline, zerolinecolor: c.baseline, tickfont: { color: c.textMuted, size: 10.5 } },
      legend: { orientation: "h", y: -0.28, font: { color: c.textSecondary, size: 11 } },
      modebar: { bgcolor: c.surface, color: c.textMuted, activecolor: c.textSecondary },
    };
    const config = { displayModeBar: true, displaylogo: false, modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d"], responsive: true, locale: "ko" };
    Plotly.newPlot(plotDiv, traces, layout, config);
    return card;
  }

  /**
   * 연료류: 부분-전체 구성을 보여주는 누적 영역 차트.
   */
  function renderStackedAreaChart(container, chartSpec) {
    const c = commonLayoutBits();
    const { card } = createCardShell(chartSpec.title, chartSpec.unit ? `단위: ${chartSpec.unit} · 누적 합계` : "", {});
    const plotDiv = el("div", { class: "plotly-div" });
    card.appendChild(el("div", { class: "chart-svg-wrap" }, [plotDiv]));
    container.appendChild(card);

    const traces = chartSpec.series.map((s, i) => ({
      x: s.points.map((p) => p.x),
      y: s.points.map((p) => p.y),
      name: s.name,
      mode: "lines",
      stackgroup: "one",
      line: { color: cssVar(`--${s.color}`), width: 1 },
      hovertemplate: `%{y} ${chartSpec.unit || ""}<extra>${s.name}</extra>`,
    }));

    const layout = {
      paper_bgcolor: c.surface,
      plot_bgcolor: c.surface,
      font: { family: FONT_FAMILY, size: 11.5, color: c.textSecondary },
      margin: { l: 48, r: 16, t: 8, b: 36 },
      height: 260,
      hovermode: "x unified",
      xaxis: { title: { text: chartSpec.unitLabel || "시간(분)", font: { size: 10.5, color: c.textMuted } }, gridcolor: c.gridline, zerolinecolor: c.baseline, tickfont: { color: c.textMuted, size: 10.5 } },
      yaxis: { gridcolor: c.gridline, zerolinecolor: c.baseline, tickfont: { color: c.textMuted, size: 10.5 } },
      legend: { orientation: "h", y: -0.28, font: { color: c.textSecondary, size: 11 } },
      modebar: { bgcolor: c.surface, color: c.textMuted, activecolor: c.textSecondary },
    };
    const config = { displayModeBar: true, displaylogo: false, modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d"], responsive: true, locale: "ko" };
    Plotly.newPlot(plotDiv, traces, layout, config);
    return card;
  }

  /**
   * 착륙장치류: 현재값을 기준/주의/위험 구간이 표시된 게이지로 보여주는 행.
   * gauges: [{label, value, unit, warn, crit, direction}]
   */
  function renderGaugeRow(container, gauges) {
    const c = commonLayoutBits();
    const row = el("div", { class: "gauge-row" });
    gauges.forEach((g) => {
      const card = el("div", { class: "gauge-card" });
      card.appendChild(el("div", { class: "gauge-label", text: g.label }));
      const plotDiv = el("div", { class: "gauge-plot" });
      card.appendChild(plotDiv);
      row.appendChild(card);

      const higherWorse = g.direction !== "down";
      const gaugeMax = g.crit != null ? Math.max(g.crit, g.value) * 1.15 : Math.max(g.value * 1.3, 1);
      const steps = [];
      if (g.warn != null && g.crit != null) {
        if (higherWorse) {
          steps.push({ range: [0, g.warn], color: c.good });
          steps.push({ range: [g.warn, g.crit], color: c.warning });
          steps.push({ range: [g.crit, gaugeMax], color: c.critical });
        } else {
          steps.push({ range: [0, g.crit], color: c.critical });
          steps.push({ range: [g.crit, g.warn], color: c.warning });
          steps.push({ range: [g.warn, gaugeMax], color: c.good });
        }
      } else {
        steps.push({ range: [0, gaugeMax], color: c.good });
      }

      const trace = [{
        type: "indicator",
        mode: "gauge+number",
        value: g.value,
        number: { suffix: g.unit ? ` ${g.unit}` : "", font: { size: 22, color: c.textSecondary } },
        gauge: {
          axis: { range: [0, gaugeMax], tickfont: { color: c.textMuted, size: 9 } },
          bar: { color: c.textSecondary, thickness: 0.25 },
          bgcolor: c.surface,
          borderwidth: 0,
          steps,
        },
      }];
      const layout = {
        paper_bgcolor: c.surface,
        font: { family: FONT_FAMILY, color: c.textSecondary },
        margin: { l: 18, r: 18, t: 10, b: 4 },
        height: 160,
      };
      Plotly.newPlot(plotDiv, trace, layout, { displayModeBar: false, responsive: true });
    });
    container.appendChild(row);
    return row;
  }

  function renderStatTile(tile) {
    return el("div", { class: "stat-tile" }, [
      el("div", { class: "label", text: tile.label }),
      el("div", { class: "value-row" }, [
        el("span", { class: "value", text: String(tile.value) }),
        el("span", { class: "unit", text: tile.unit || "" }),
      ]),
      el("div", { class: "status-chip" }, [
        el("span", { class: "swatch", style: `background:${statusColorVar(tile.status)}` }),
        el("span", { text: STATUS_LABEL[tile.status] || "정상" }),
      ]),
    ]);
  }

  function renderStatusPill(status) {
    return el("span", { class: "status-pill", style: `background:${statusColorVar(status)}`, text: STATUS_LABEL[status] || "정상" });
  }

  global.ChartKit = {
    renderLineChart,
    renderPairDeltaChart,
    renderBandedLineChart,
    renderStackedAreaChart,
    renderGaugeRow,
    renderStatTile,
    renderStatusPill,
    el,
    STATUS_LABEL,
  };
})(window);
