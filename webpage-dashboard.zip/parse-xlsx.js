// ============================================================
// 서버 전용 엑셀 파싱 모듈 (Node.js, "xlsx"(SheetJS) 패키지 사용)
//
// 기존 브라우저용 data.js의 parseSortieWorkbook()과 동일한 규칙을
// 그대로 따릅니다 (Data 시트, 헤더 "이름(단위)", 첫 열=시간, Thresholds 시트).
// 백엔드 구조로 바뀌면서 엑셀 파싱은 서버에서만 하고, 브라우저는
// 이미 파싱된 JSON만 받습니다 — 그래서 클라이언트에는 더 이상
// SheetJS(xlsx.full.min.js)를 넣을 필요가 없습니다.
// ============================================================

"use strict";

const fs = require("fs");
const XLSX = require("xlsx");

function normalize(str) {
  return String(str || "").toLowerCase().replace(/[\s\-_/]+/g, "");
}

// "ENG1_N1(%)" -> { name: "ENG1_N1", unit: "%" }
function parseHeaderUnit(header) {
  const s = String(header || "").trim();
  const m = s.match(/^(.*?)\s*\(([^)]+)\)\s*$/);
  if (m) return { name: m[1].trim(), unit: m[2].trim() };
  return { name: s, unit: "" };
}

/**
 * 엑셀 파일 절대 경로를 받아 파싱합니다.
 * 반환: { time:[...], columns:[{header,name,unit,values:[...]}], thresholds:{name:{warn,crit,direction}}, sheetName }
 */
function parseSortieWorkbook(filePath) {
  const buf = fs.readFileSync(filePath);
  const wb = XLSX.read(buf, { type: "buffer" });

  const sheetName = wb.SheetNames.find((n) => normalize(n) === "data") || wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: null });
  if (!rows.length) throw new Error(`"${sheetName}" 시트에 데이터가 없습니다.`);

  const headers = rows[0];
  const dataRows = rows.slice(1).filter((r) => r.some((v) => v !== null && v !== ""));
  const time = dataRows.map((r) => r[0]);
  const columns = [];
  for (let c = 1; c < headers.length; c++) {
    if (headers[c] === null || headers[c] === undefined || headers[c] === "") continue;
    const { name, unit } = parseHeaderUnit(headers[c]);
    columns.push({
      header: String(headers[c]),
      name,
      unit,
      values: dataRows.map((r) => (typeof r[c] === "number" ? r[c] : (r[c] === null ? null : Number(r[c])))),
    });
  }

  const thresholds = {};
  const thSheetName = wb.SheetNames.find((n) => normalize(n) === "thresholds");
  if (thSheetName) {
    const thRows = XLSX.utils.sheet_to_json(wb.Sheets[thSheetName], { defval: null });
    thRows.forEach((row) => {
      const paramKey = row.parameter || row.Parameter || row.param;
      if (!paramKey) return;
      thresholds[String(paramKey).trim()] = {
        warn: row.warn !== null && row.warn !== undefined ? Number(row.warn) : undefined,
        crit: row.crit !== null && row.crit !== undefined ? Number(row.crit) : undefined,
        direction: (row.direction || "up").toString().toLowerCase(),
      };
    });
  }

  return { time, columns, thresholds, sheetName };
}

module.exports = { normalize, parseHeaderUnit, parseSortieWorkbook };
