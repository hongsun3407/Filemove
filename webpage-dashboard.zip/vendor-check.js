// ============================================================
// vendor/ 폴더에 Plotly.js 파일이 없을 때 (폐쇄망에서 흔한 실수)
// 조용히 깨지는 대신 눈에 띄는 안내를 띄웁니다.
// ============================================================
(function () {
  "use strict";

  function showBanner() {
    var missing = [];
    if (typeof window.Plotly === "undefined") missing.push("vendor/plotly.min.js");
    if (missing.length === 0) return;

    var box = document.createElement("div");
    box.setAttribute("role", "alert");
    box.style.cssText = [
      "position:fixed", "top:0", "left:0", "right:0", "z-index:9999",
      "background:#7a1f1f", "color:#fff", "padding:12px 20px",
      "font:14px/1.5 -apple-system,'Segoe UI',sans-serif",
      "box-shadow:0 2px 8px rgba(0,0,0,.3)",
    ].join(";");
    box.innerHTML =
      "<b>필요한 파일을 찾을 수 없습니다:</b> " + missing.join(", ") +
      " &mdash; vendor/README.md 안내대로 파일을 내려받아 프로젝트의 vendor 폴더에 넣어주세요. " +
      "이 파일들이 없으면 차트가 그려지지 않습니다.";
    document.addEventListener("DOMContentLoaded", function () {
      document.body.insertBefore(box, document.body.firstChild);
    });
    if (document.body) document.body.insertBefore(box, document.body.firstChild);
  }

  showBanner();
})();
