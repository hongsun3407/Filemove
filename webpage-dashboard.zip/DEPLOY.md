# 폐쇄망 배포 가이드

## 구조가 바뀐 이유

예전 버전은 브라우저가 File System Access API로 **사용자 PC의 폴더를 직접 열어**
엑셀을 읽었습니다. 개인이 자기 PC에서 쓰기엔 좋지만, "여러 사람이 사내 웹서버로
접속하고 데이터는 서버 한 곳에서 중앙 관리"하는 서비스 형태와는 맞지 않았습니다
(사용자마다 폴더를 직접 선택/승인해야 하고, File System Access API 자체가
HTTPS(또는 localhost) 환경에서만 동작하는 제약도 있었습니다).

그래서 작은 백엔드 서버(`server.js`)를 추가했습니다. 이제 구조는 이렇습니다.

```
[중앙 데이터 폴더]  --(server.js가 읽고 엑셀을 파싱)-->  [/api/... JSON]
                                                              |
                                                    사용자 브라우저 여러 명
                                                    (index.html / system.html)
```

- 엑셀 파싱은 이제 서버(`parse-xlsx.js`)에서만 합니다. 브라우저는 이미 파싱된
  JSON만 받으므로, 브라우저에 필요한 외부 라이브러리는 **Plotly.js 하나**뿐입니다
  (SheetJS는 서버 쪽 `node_modules`로 들어갑니다).
- 사용자는 폴더 선택/권한 승인 없이 그냥 페이지를 열면 바로 시스템 목록이 보입니다.
- File System Access API를 더 이상 쓰지 않으므로, **Chrome/Edge가 아니어도**
  (예: Firefox) `fetch`만 되면 정상 동작합니다. HTTPS도 더 이상 필수는 아니지만,
  사내 인증서가 있다고 하셨으니 아래 4단계처럼 적용하는 걸 권장합니다.

## 준비물

- 인터넷이 되는 PC 1대 (라이브러리/패키지를 최초 한 번만 받는 용도)
- 폐쇄망 안의 서버 1대 — Node.js 설치, 여기에 이 프로젝트를 올립니다
- (선택) 사내 인증서(HTTPS)

## 1단계 — 인터넷 PC에서 준비

가장 빠른 방법: 이 프로젝트 폴더를 인터넷 되는 PC로 옮긴 뒤, 그 폴더 안에서
아래 스크립트 하나만 실행하면 됩니다 (Plotly.js 다운로드 + `npm install`을
한 번에 처리합니다).

- Windows(PowerShell): `.\fetch-vendor.ps1`
- macOS/Linux: `bash fetch-vendor.sh`

수동으로 하나씩 하고 싶다면:

1. `vendor/plotly.min.js` 받기 (`vendor/README.md` 참고)
2. 이 프로젝트 최상위 폴더(package.json이 있는 곳)에서:
   ```bash
   npm install
   ```
   → `node_modules` 폴더가 생기고 그 안에 엑셀 파싱용 `xlsx` 패키지가 들어갑니다.
   `xlsx`는 순수 JS 패키지라 OS/CPU 아키텍처를 안 타므로, 폐쇄망 서버와 다른
   환경에서 설치해도 대부분 문제없이 그대로 옮겨 쓸 수 있습니다.
3. 프로젝트 폴더 전체(코드 + `vendor/` + `node_modules/` + 예시 `data/`)를
   USB나 사내 반입 절차를 통해 폐쇄망 서버로 옮깁니다.
4. Node.js 설치파일도 함께 반입해서 폐쇄망 서버에 설치해두세요
   (Node.js 공식 사이트에서 Windows용 `.msi` 인스톨러를 받으면 됩니다).

## 2단계 — 폐쇄망 서버 설정

1. Node.js 설치 확인: `node -v`
2. `config.json`을 실제 환경에 맞게 수정:
   ```json
   {
     "port": 8080,
     "dataRoot": "D:/AircraftData"
   }
   ```
   `dataRoot`는 시스템별 하위 폴더(엔진/유압/…)가 들어있는 **중앙 데이터 폴더**
   경로입니다. 서버 로컬 디스크(`D:/AircraftData`)여도 되고, 사내 공유 드라이브
   (`//fileserver/share/aircraft-data`)여도 됩니다.
3. 실행:
   - **Windows에서 가장 쉬운 방법**: `start-server.cmd`를 더블클릭하세요. Node.js
     설치 여부, `node_modules`/`vendor/plotly.min.js` 유무를 먼저 확인해주고
     문제가 있으면 원인을 알려준 뒤 서버를 띄웁니다. 이 창을 닫으면 서버도
     함께 종료됩니다.
   - 또는 cmd/PowerShell/터미널에서 직접:
     ```bash
     npm start
     ```
     (또는 `node server.js`)
4. 서버가 있는 PC의 브라우저로 `http://localhost:8080` 을 열어 정상 동작하는지
   먼저 확인한 뒤, 다른 PC에서 `http://<서버IP>:8080` 으로 접속해보세요.

## 3단계 — 재부팅해도 자동으로 켜지게 (상시 서비스 등록)

Windows 서버라면 둘 중 편한 쪽으로:

- **NSSM** (Non-Sucking Service Manager)로 Windows 서비스 등록 — 가장 흔히 쓰는 방법.
  `nssm install AircraftDashboard` 실행 후 `node.exe`와 `server.js` 경로만 지정하면 됩니다.
- **작업 스케줄러**에 "컴퓨터 시작 시" 트리거로 `node server.js`를 실행하는 작업 등록.

  (`start-server.cmd`는 사람이 더블클릭해서 상태를 눈으로 확인하는 수동 실행/테스트용입니다.
  서비스로 등록할 땐 `node.exe` + `server.js`를 직접 지정하세요 — `.cmd`의 `pause`가
  서비스 환경에선 불필요합니다.)

Linux 서버라면 `systemd` 유닛 파일 하나로 동일하게 처리할 수 있습니다.

## 4단계 — HTTPS 적용 (선택, 권장)

사내에 인증서를 발급할 수 있다고 하셨으니, 편한 쪽으로 선택하세요.

- **옵션 A (추천) — 사내 IIS/Nginx를 앞단 리버스 프록시로**: 기존에 이미 운영 중인
  사내 웹서버가 있다면, 그 서버가 HTTPS(443)를 처리하고 내부적으로
  `http://localhost:8080` (이 Node 서버)로 요청을 전달하도록 설정합니다. 인증서
  관리를 기존 인프라에 맡길 수 있어 가장 간단합니다.
- **옵션 B — server.js가 직접 HTTPS 처리**: `config.json`에 인증서 경로를 추가합니다.
  ```json
  {
    "port": 8443,
    "dataRoot": "D:/AircraftData",
    "tls": { "cert": "./certs/server.crt", "key": "./certs/server.key" }
  }
  ```
  `certs/` 폴더에 사내 CA가 발급한 인증서/키 파일을 넣으면, 서버가 자동으로
  HTTPS로 뜹니다 (`tls`가 없으면 지금처럼 HTTP로 동작).

## 5단계 — 데이터 운영

- 데이터 담당자가 `dataRoot` 아래 시스템별 폴더에 엑셀 파일을 넣고 빼기만 하면
  됩니다 — 서버 재시작이 필요 없습니다. (같은 파일을 여러 번 조회할 때는
  수정 시각(mtime) 기준으로 캐시해서 매번 다시 파싱하지 않습니다.)
- 새 시스템 폴더를 추가하면 코드 수정 없이 자동으로 탭이 생깁니다 (기존과 동일).
- 시스템별 전용 시각화(엔진/유압/연료/착륙장치)와 전처리(`transforms.js`)는
  폴더 이름으로 자동 매칭됩니다. 목록에 없는 폴더명은 기본 라인차트로 표시됩니다.

## 방화벽

서버가 리스닝하는 포트(기본 8080, HTTPS라면 443 또는 지정한 포트)를 사내
방화벽/보안 정책에서 허용해야 다른 PC에서 접속할 수 있습니다.

## 문제 해결

- 화면 위에 빨간 배너가 뜨면 `vendor/plotly.min.js`가 없거나 이름이 다른 것입니다.
- "서버에 연결할 수 없습니다"가 뜨면 `server.js`가 꺼져 있거나 포트/방화벽 문제입니다.
- 시스템 탭이 하나도 안 보이면 `config.json`의 `dataRoot` 경로가 실제 데이터
  폴더를 가리키는지 확인하세요 (서버 실행 로그에 현재 `dataRoot` 경로가 출력됩니다).
