// ============================================================
// 항공기 시스템 대시보드 — 백엔드 서버
//
// 역할 두 가지:
//  1) 정적 파일 서빙 (index.html, system.html, *.js, *.css, vendor/*)
//  2) 데이터 API — config.json의 dataRoot(중앙 데이터 서버 폴더)를 읽어
//     시스템 목록/소티 목록/파싱된 엑셀 데이터를 JSON으로 제공
//
// 외부 패키지는 "xlsx"(SheetJS) 하나만 씁니다 (프레임워크 없이 Node 내장
// http 모듈만 사용) — 폐쇄망으로 옮길 때 vendoring해야 할 게 최소화됩니다.
//
// 실행: node server.js   (기본 포트/데이터 경로는 config.json 참고)
// ============================================================

"use strict";

const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const { parseSortieWorkbook } = require("./parse-xlsx");

const ROOT_DIR = __dirname;
const CONFIG_PATH = path.join(ROOT_DIR, "config.json");

function loadConfig() {
  const defaults = { port: 8080, dataRoot: "./data" };
  try {
    const raw = fs.readFileSync(CONFIG_PATH, "utf8");
    return Object.assign(defaults, JSON.parse(raw));
  } catch (e) {
    console.warn(`[config] config.json을 읽지 못해 기본값을 사용합니다: ${e.message}`);
    return defaults;
  }
}

const config = loadConfig();
const DATA_ROOT = path.resolve(ROOT_DIR, config.dataRoot);
const XLSX_RE = /\.xlsx?$/i;

// ---------- 유틸 ----------

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
  });
  res.end(body);
}

function sendError(res, status, message) {
  sendJson(res, status, { error: message });
}

// "이름" 형태의 URL 세그먼트를 안전한 폴더/파일명으로 정리 (경로 이탈 방지)
function safeSegment(seg) {
  const decoded = decodeURIComponent(seg || "");
  const base = path.basename(decoded); // ../ 등 경로 구분자 제거
  if (!base || base === "." || base === "..") return null;
  return base;
}

function listSystemDirs() {
  if (!fs.existsSync(DATA_ROOT)) return [];
  return fs
    .readdirSync(DATA_ROOT, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name)
    .sort((a, b) => a.localeCompare(b, "ko"));
}

function listSortieFiles(systemName) {
  const dir = path.join(DATA_ROOT, systemName);
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return null;
  return fs
    .readdirSync(dir)
    .filter((f) => XLSX_RE.test(f) && !f.startsWith("~$"))
    .map((f) => ({ name: f.replace(XLSX_RE, ""), fileName: f }))
    .sort((a, b) => a.name.localeCompare(b.name, "ko"));
}

// 파싱 결과를 mtime 기준으로 캐싱 — 같은 파일을 여러 사용자가 반복 조회해도
// 파일이 바뀌지 않으면 다시 파싱하지 않습니다.
const parseCache = new Map(); // filePath -> { mtimeMs, data }

function parseSortieCached(filePath) {
  const stat = fs.statSync(filePath);
  const cached = parseCache.get(filePath);
  if (cached && cached.mtimeMs === stat.mtimeMs) return cached.data;
  const data = parseSortieWorkbook(filePath);
  parseCache.set(filePath, { mtimeMs: stat.mtimeMs, data });
  return data;
}

// ---------- API 핸들러 ----------

function handleApi(req, res, parts) {
  // parts: ["api", "systems", ...]
  if (parts.length === 2 && parts[1] === "systems") {
    const names = listSystemDirs();
    const systems = names.map((name) => {
      const files = listSortieFiles(name) || [];
      return { name, sortieCount: files.length };
    });
    return sendJson(res, 200, systems);
  }

  if (parts.length >= 3 && parts[1] === "systems") {
    const systemName = safeSegment(parts[2]);
    if (!systemName || !listSystemDirs().includes(systemName)) {
      return sendError(res, 404, `시스템 "${parts[2]}"을(를) 찾을 수 없습니다.`);
    }

    if (parts.length === 4 && parts[3] === "sorties") {
      const files = listSortieFiles(systemName);
      return sendJson(res, 200, files || []);
    }

    if (parts.length === 5 && parts[3] === "sorties") {
      const fileSeg = safeSegment(parts[4]);
      if (!fileSeg) return sendError(res, 400, "잘못된 파일명입니다.");
      const files = listSortieFiles(systemName) || [];
      const match = files.find((f) => f.fileName === fileSeg);
      if (!match) return sendError(res, 404, `소티 파일 "${parts[4]}"을(를) 찾을 수 없습니다.`);
      const fullPath = path.join(DATA_ROOT, systemName, match.fileName);
      try {
        const parsed = parseSortieCached(fullPath);
        return sendJson(res, 200, parsed);
      } catch (e) {
        return sendError(res, 500, `엑셀을 읽는 중 오류: ${e.message}`);
      }
    }
  }

  return sendError(res, 404, "알 수 없는 API 경로입니다.");
}

// ---------- 정적 파일 서빙 ----------

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".map": "application/json; charset=utf-8",
};

// 정적으로 내어줄 수 있는 최상위 항목만 허용 (데이터 폴더/서버 소스는 절대 노출하지 않음)
const STATIC_ALLOW = new Set([
  "index.html", "system.html", "styles.css",
  "storage.js", "nav.js", "data.js", "transforms.js", "charts.js",
  "visualizers.js", "index-app.js", "system-app.js", "api.js", "vendor-check.js",
]);

function serveStatic(req, res, urlPath) {
  let rel = urlPath === "/" ? "index.html" : decodeURIComponent(urlPath.replace(/^\//, ""));
  const topSegment = rel.split("/")[0];
  const isVendor = topSegment === "vendor" && !rel.includes("..");

  if (!isVendor && !STATIC_ALLOW.has(rel)) {
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    return res.end("Not found");
  }

  const filePath = path.join(ROOT_DIR, rel);
  if (!filePath.startsWith(ROOT_DIR)) {
    res.writeHead(400);
    return res.end("Bad request");
  }

  fs.readFile(filePath, (err, buf) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("Not found");
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(buf);
  });
}

// ---------- 요청 라우팅 ----------

function requestHandler(req, res) {
  const urlPath = req.url.split("?")[0];
  if (urlPath.startsWith("/api/")) {
    const parts = urlPath.replace(/^\//, "").split("/"); // ["api","systems",...]
    return handleApi(req, res, parts);
  }
  return serveStatic(req, res, urlPath);
}

// ---------- 서버 시작 (HTTPS 인증서가 config.json에 지정돼 있으면 HTTPS로) ----------

function start() {
  console.log(`[data] 데이터 폴더: ${DATA_ROOT}`);
  if (!fs.existsSync(DATA_ROOT)) {
    console.warn(`[data] 경고: 데이터 폴더가 존재하지 않습니다. config.json의 dataRoot를 확인하세요.`);
  }

  if (config.tls && config.tls.cert && config.tls.key) {
    const options = {
      cert: fs.readFileSync(path.resolve(ROOT_DIR, config.tls.cert)),
      key: fs.readFileSync(path.resolve(ROOT_DIR, config.tls.key)),
    };
    https.createServer(options, requestHandler).listen(config.port, () => {
      console.log(`[server] HTTPS로 실행 중: https://localhost:${config.port}`);
    });
  } else {
    http.createServer(requestHandler).listen(config.port, () => {
      console.log(`[server] HTTP로 실행 중: http://localhost:${config.port}`);
      console.log(`[server] (사내 인증서를 쓰려면 config.json에 "tls":{"cert":...,"key":...}를 추가하거나, IIS/Nginx로 HTTPS 리버스 프록시를 앞단에 두세요.)`);
    });
  }
}

start();
