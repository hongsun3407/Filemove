// ============================================================
// 시스템 상세 페이지 로직 (system.html?system=<폴더명>)
// ============================================================

(function () {
  "use strict";

  const { el } = window.NavKit;
  const pageTitle = document.getElementById("page-title");
  const contentRoot = document.getElementById("content-root");

  const params = new URLSearchParams(location.search);
  const systemName = params.get("system") || "";
  pageTitle.textContent = systemName || "시스템";

  const state = { sortie: "", compare: "" };
  const loadCache = new Map(); // fileName -> Promise<{time,columns,thresholds}>
  let renderToken = 0;

  function emptyState(title, bodyHtml) {
    const box = el("div", { class: "empty-state" });
    box.innerHTML = `<h3>${title}</h3>${bodyHtml}`;
    return box;
  }

  function showServerError(err) {
    contentRoot.innerHTML = "";
    contentRoot.appendChild(emptyState(
      "서버에 연결할 수 없습니다",
      `<p>백엔드(server.js)가 실행 중인지 확인해주세요. 오류: <code>${(err && err.message) || err}</code></p>`
    ));
  }

  function showSystemNotFound(systems) {
    contentRoot.innerHTML = "";
    const names = systems.map((s) => s.name);
    contentRoot.appendChild(emptyState(
      `"${systemName}" 시스템을 찾을 수 없습니다`,
      `<p>서버의 데이터 폴더 아래에 다음 시스템이 등록돼 있습니다: ${names.map((n) => `<code>${n}</code>`).join(", ") || "(없음)"}</p>
       <p><a href="index.html">전체 개요</a>로 돌아가서 시스템을 다시 선택해주세요.</p>`
    ));
  }

  async function onReady(systems) {
    if (!systems.some((s) => s.name === systemName)) { showSystemNotFound(systems); return; }

    let files;
    try {
      files = await window.ApiClient.listSorties(systemName);
    } catch (err) {
      showServerError(err);
      return;
    }

    contentRoot.innerHTML = "";
    if (!files || files.length === 0) {
      contentRoot.appendChild(emptyState(
        `"${systemName}" 폴더에서 엑셀 파일을 찾지 못했습니다`,
        `<p>서버 데이터 폴더의 <code>${systemName}</code> 하위에 .xlsx 소티 파일을 넣어주세요.</p>`
      ));
      return;
    }

    if (!state.sortie || !files.some((f) => f.fileName === state.sortie)) state.sortie = files[0].fileName;
    if (state.compare && !files.some((f) => f.fileName === state.compare)) state.compare = "";

    const selectRow = el("div", { class: "select-row" });
    const sortieSelect = el("select", { class: "filter-select" });
    files.forEach((f) => {
      const opt = el("option", { value: f.fileName, text: f.name });
      if (f.fileName === state.sortie) opt.setAttribute("selected", "selected");
      sortieSelect.appendChild(opt);
    });
    const compareSelect = el("select", { class: "filter-select" });
    compareSelect.appendChild(el("option", { value: "", text: "비교 안 함" }));
    files.forEach((f) => {
      if (f.fileName === state.sortie) return;
      const opt = el("option", { value: f.fileName, text: f.name });
      if (f.fileName === state.compare) opt.setAttribute("selected", "selected");
      compareSelect.appendChild(opt);
    });

    sortieSelect.addEventListener("change", () => {
      state.sortie = sortieSelect.value;
      if (state.compare === state.sortie) state.compare = "";
      renderBody(files);
    });
    compareSelect.addEventListener("change", () => {
      state.compare = compareSelect.value;
      renderBody(files);
    });

    selectRow.appendChild(el("div", { class: "field" }, [el("label", { text: "소티" }), sortieSelect]));
    selectRow.appendChild(el("div", { class: "field" }, [el("label", { text: "비교 소티" }), compareSelect]));
    contentRoot.appendChild(selectRow);

    const body = el("div");
    contentRoot.appendChild(body);
    renderBody(files);

    function renderBody(fileList) {
      body.innerHTML = "";
      body.appendChild(el("div", { class: "loading-note", text: "데이터를 불러오는 중…" }));

      const myToken = ++renderToken;
      const sortieEntry = fileList.find((f) => f.fileName === state.sortie);
      const compareEntry = state.compare ? fileList.find((f) => f.fileName === state.compare) : null;

      Promise.all([loadEntry(sortieEntry), compareEntry ? loadEntry(compareEntry) : null])
        .then(([primary, compare]) => {
          if (myToken !== renderToken) return;
          body.innerHTML = "";

          // 원본 컬럼에 시스템별 파생 파라미터(전처리)를 적용 — 정의는 transforms.js에.
          const columns = window.Transforms ? window.Transforms.applyForSystem(systemName, primary.time, primary.columns) : primary.columns;
          const compareColumns = compare
            ? (window.Transforms ? window.Transforms.applyForSystem(systemName, compare.time, compare.columns) : compare.columns)
            : null;

          const tiles = window.FDR.buildTiles(columns, primary.thresholds);
          const tileRow = el("div", { class: "tile-row" });
          tiles.forEach((t) => tileRow.appendChild(window.ChartKit.renderStatTile(t)));
          body.appendChild(tileRow);

          const ctx = {
            time: primary.time,
            columns,
            thresholds: primary.thresholds,
            compare: compare ? { time: compare.time, columns: compareColumns } : null,
            primaryLabel: sortieEntry.name,
            compareLabel: compareEntry ? compareEntry.name : "",
          };
          const renderFn = window.Visualizers.pickVisualizer(systemName);
          renderFn(body, ctx);

          const sourceParts = [`출처: ${systemName}/${sortieEntry.fileName}`];
          if (compareEntry) sourceParts.push(`비교: ${systemName}/${compareEntry.fileName}`);
          body.appendChild(el("footer", { class: "source-note", text: sourceParts.join(" · ") }));
        })
        .catch((err) => {
          if (myToken !== renderToken) return;
          body.innerHTML = "";
          body.appendChild(el("div", { class: "error-note", text: `데이터를 불러오는 중 오류가 발생했습니다: ${err.message || err}` }));
        });
    }
  }

  function loadEntry(entry) {
    if (!entry) return Promise.resolve(null);
    if (!loadCache.has(entry.fileName)) {
      const p = window.ApiClient.loadSortie(systemName, entry.fileName)
        .catch((err) => { loadCache.delete(entry.fileName); throw err; });
      loadCache.set(entry.fileName, p);
    }
    return loadCache.get(entry.fileName);
  }

  window.NavKit.mount({
    activeKey: systemName,
    root: document.getElementById("sidebar-root"),
    onReady,
    onError: showServerError,
  });
})();
