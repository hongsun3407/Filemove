#!/usr/bin/env bash
# ============================================================
# 인터넷이 되는 PC에서 딱 한 번 실행하는 스크립트.
# 1) 브라우저용 Plotly.js를 vendor/ 폴더에 받고
# 2) 서버용 xlsx(SheetJS) 패키지를 npm install로 받습니다.
#
# 실행: 이 webpage 폴더에서
#   bash fetch-vendor.sh
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

echo "1) vendor/plotly.min.js 받는 중..."
mkdir -p vendor
curl -L -o vendor/plotly.min.js "https://cdnjs.cloudflare.com/ajax/libs/plotly.js/3.4.0/plotly.min.js"

size=$(wc -c < vendor/plotly.min.js)
if [ "$size" -lt 100000 ]; then
  echo "경고: plotly.min.js 크기가 너무 작습니다 (${size} bytes) — 다운로드가 제대로 안 됐을 수 있습니다. 다시 시도해주세요." >&2
else
  echo "   -> 완료 (${size} bytes)"
fi

echo "2) 서버용 xlsx 패키지(npm install) 받는 중..."
npm install

echo ""
echo "완료! 이제 이 webpage 폴더 전체(vendor/plotly.min.js, node_modules 포함)를"
echo "USB 등으로 폐쇄망 서버에 옮기면 됩니다. 자세한 절차는 DEPLOY.md를 참고하세요."
