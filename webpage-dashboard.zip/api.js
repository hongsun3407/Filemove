// ============================================================
// 백엔드 API 클라이언트
//
// 예전에는 브라우저가 File System Access API로 폴더를 직접 열어
// 엑셀을 파싱했지만, 이제는 서버(server.js)가 중앙 데이터 폴더를 읽어
// 이미 파싱된 JSON을 내려줍니다. 그래서 폴더 선택/권한 화면이 사라지고,
// 페이지를 열면 바로 시스템 목록이 뜹니다.
// ============================================================

(function (root) {
  "use strict";

  async function getJson(url) {
    const res = await fetch(url, { credentials: "same-origin" });
    if (!res.ok) {
      let msg = `${res.status} ${res.statusText}`;
      try {
        const body = await res.json();
        if (body && body.error) msg = body.error;
      } catch (e) {}
      throw new Error(msg);
    }
    return res.json();
  }

  // -> [{ name, sortieCount }]
  function listSystems() {
    return getJson("/api/systems");
  }

  // -> [{ name, fileName }]
  function listSorties(systemName) {
    return getJson(`/api/systems/${encodeURIComponent(systemName)}/sorties`);
  }

  // -> { time, columns, thresholds, sheetName }
  function loadSortie(systemName, fileName) {
    return getJson(`/api/systems/${encodeURIComponent(systemName)}/sorties/${encodeURIComponent(fileName)}`);
  }

  root.ApiClient = { listSystems, listSorties, loadSortie };
  if (typeof module !== "undefined" && module.exports) module.exports = root.ApiClient;
})(typeof window !== "undefined" ? window : globalThis);
