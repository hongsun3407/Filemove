// ============================================================
// (더 이상 사용되지 않음 — 백엔드 API 구조로 바뀌면서 api.js로 대체됨)
//
// 이 파일은 브라우저의 File System Access API로 사용자가 직접 폴더를
// 골라 로컬에서 엑셀을 읽던 "폴더 선택형" 이전 구조에서 쓰이던
// 스크립트입니다. 지금은 여러 사용자가 사내 웹서버에 접속하고
// 데이터는 서버 한 곳(server.js + config.json의 dataRoot)에서 중앙
// 관리하는 구조로 바뀌어서, 폴더 선택/권한 승인 절차 자체가 없어졌고
// index.html / system.html 어디에서도 이 파일을 더 이상 불러오지
// 않습니다. api.js가 그 자리를 대신합니다. 삭제하셔도 됩니다.
// ============================================================

(function (root) {
  "use strict";

  const DB_NAME = "fdr-dashboard";
  const DB_VERSION = 1;
  const STORE = "handles";
  const ROOT_KEY = "rootDir";

  function isSupported() {
    return typeof window !== "undefined" && "showDirectoryPicker" in window && "indexedDB" in window;
  }

  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function idbGet(key) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function idbSet(key, value) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function saveRootHandle(handle) {
    await idbSet(ROOT_KEY, handle);
  }

  async function loadRootHandle() {
    try {
      return (await idbGet(ROOT_KEY)) || null;
    } catch (e) {
      return null;
    }
  }

  // queryPermission은 사용자 제스처 없이도 호출 가능(조용히 상태만 확인).
  async function queryPermission(handle, mode) {
    if (!handle || !handle.queryPermission) return "granted"; // 테스트용 더미 핸들 호환
    return handle.queryPermission({ mode: mode || "read" });
  }

  // requestPermission은 반드시 클릭 등 사용자 제스처 안에서 호출해야 브라우저가 프롬프트를 띄웁니다.
  async function requestPermission(handle, mode) {
    if (!handle || !handle.requestPermission) return "granted";
    return handle.requestPermission({ mode: mode || "read" });
  }

  async function pickRootHandle() {
    const handle = await window.showDirectoryPicker();
    await saveRootHandle(handle);
    return handle;
  }

  async function listSubdirectories(dirHandle) {
    const dirs = [];
    for await (const [name, entry] of dirHandle.entries()) {
      if (entry.kind === "directory") dirs.push(name);
    }
    dirs.sort((a, b) => a.localeCompare(b, "ko"));
    return dirs;
  }

  const XLSX_RE = /\.xlsx?$/i;

  async function listSortieFiles(dirHandle) {
    const files = [];
    for await (const [name, entry] of dirHandle.entries()) {
      if (entry.kind === "file" && XLSX_RE.test(name) && !name.startsWith("~$")) {
        files.push({ name: name.replace(XLSX_RE, ""), fileName: name, handle: entry });
      }
    }
    files.sort((a, b) => a.name.localeCompare(b.name, "ko"));
    return files;
  }

  root.FolderStore = {
    isSupported,
    saveRootHandle,
    loadRootHandle,
    queryPermission,
    requestPermission,
    pickRootHandle,
    listSubdirectories,
    listSortieFiles,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = root.FolderStore;
})(typeof window !== "undefined" ? window : globalThis);
