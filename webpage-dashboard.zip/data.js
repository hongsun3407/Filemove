// ============================================================
// 엑셀(xlsx) 파싱 + 차트용 데이터 가공 유틸리티
//
// 데이터 규칙
// -----------
// 1) 데이터 폴더 아래의 "하위 폴더 이름"이 곧 시스템 탭 이름입니다.
//    (index.html에서 폴더를 고르면 하위 폴더를 그대로 읽어 탭을 만듭니다.
//    새 시스템 폴더를 추가하면 코드 수정 없이 자동으로 탭이 생깁니다.)
// 2) 하위 폴더 안의 각 .xlsx 파일 하나 = 소티(비행) 1회.
//    파일명(확장자 제외)이 그대로 소티 선택 목록에 표시됩니다.
// 3) 엑셀의 "Data" 시트(없으면 첫 시트): 1행 = 헤더, 첫 번째 열 = 시간(분 등),
//    나머지 열 = 파라미터. 헤더는 "이름(단위)" 형식을 권장합니다.
//    예) ENG1_N1(%), ENG1_EGT(°C)  — 단위가 같은 열끼리 한 차트로 묶입니다.
// 4) 선택: "Thresholds" 시트 — parameter, warn, crit, direction(up/down) 열로
//    상태(정상/주의/위험) 배지를 계산합니다. 없으면 모두 "정상"으로 표시됩니다.
// ============================================================

(function (root) {
  "use strict";

  function normalize(str) {
    return String(str || "").toLowerCase().replace(/[\s\-_/]+/g, "");
  }

  // "ENG1_N1(%)" -> { name: "ENG1_N1", unit: "%" }
  function parseHeaderUnit(header) {
    const s = String(header || "").trim();
    const m = s.match(/^(.*?)\s*\(([^)]+)\)\s*$/);
    if (m) return { name: m[1].trim(), unit: m[2].trim() };
    return { name: s, unit: "" };
  }

  function statusFromThreshold(value, rule) {
    if (!rule || value === null || value === undefined || Number.isNaN(value)) return "good";
    const higherIsWorse = rule.direction !== "down";
    const warn = rule.warn, crit = rule.crit;
    if (higherIsWorse) {
      if (crit !== undefined && value >= crit) return "critical";
      if (warn !== undefined && value >= warn) return "warning";
    } else {
      if (crit !== undefined && value <= crit) return "critical";
      if (warn !== undefined && value <= warn) return "warning";
    }
    return "good";
  }

  // 엑셀 파싱은 이제 서버(parse-xlsx.js)에서만 합니다 — 브라우저는
  // api.js를 통해 이미 파싱된 { time, columns, thresholds } JSON을 받습니다.
  // (예전엔 여기서 window.XLSX로 직접 파싱했지만, 백엔드 API 구조로 바뀌면서
  // 클라이언트에 SheetJS를 더 이상 넣지 않습니다.)

  const PALETTE_SLOTS = ["series-1", "series-2", "series-3", "series-4", "series-5", "series-6", "series-7", "series-8"];
  const MAX_SERIES_PER_CHART = 8; // dataviz 팔레트 카테고리 안전 한도

  /**
   * columns를 단위(unit)별로 묶어 chartSpec[] 생성. (한 차트 = 한 y축 = 한 단위)
   * 같은 단위 파라미터가 8개를 넘으면 여러 차트로 분할합니다.
   */
  function buildChartsFromColumns(time, columns) {
    const byUnit = new Map();
    columns.forEach((col) => {
      const key = col.unit || "";
      if (!byUnit.has(key)) byUnit.set(key, []);
      byUnit.get(key).push(col);
    });

    const charts = [];
    byUnit.forEach((cols, unit) => {
      for (let start = 0; start < cols.length; start += MAX_SERIES_PER_CHART) {
        const chunk = cols.slice(start, start + MAX_SERIES_PER_CHART);
        const part = cols.length > MAX_SERIES_PER_CHART ? ` (${Math.floor(start / MAX_SERIES_PER_CHART) + 1}부)` : "";
        charts.push({
          title: (unit ? `${unit} 계열` : "값") + part,
          unit,
          unitLabel: "시간(분)",
          series: chunk.map((col, i) => ({
            name: col.name,
            color: PALETTE_SLOTS[i % PALETTE_SLOTS.length],
            points: time.map((t, idx) => ({ x: t, y: col.values[idx] })).filter((p) => p.y !== null && !Number.isNaN(p.y)),
          })),
        });
      }
    });
    return charts;
  }

  function buildTiles(columns, thresholds) {
    return columns.map((col) => {
      const last = [...col.values].reverse().find((v) => v !== null && !Number.isNaN(v));
      const rule = thresholds ? thresholds[col.name] : null;
      return {
        label: col.name,
        value: last === undefined ? "-" : (Number.isInteger(last) ? last : Math.round(last * 100) / 100),
        unit: col.unit,
        status: last === undefined ? "good" : statusFromThreshold(last, rule),
      };
    });
  }

  const FDR = {
    PALETTE_SLOTS,
    MAX_SERIES_PER_CHART,
    normalize,
    parseHeaderUnit,
    buildChartsFromColumns,
    buildTiles,
    statusFromThreshold,
  };

  root.FDR = FDR;
  if (typeof module !== "undefined" && module.exports) module.exports = FDR;
})(typeof window !== "undefined" ? window : globalThis);
