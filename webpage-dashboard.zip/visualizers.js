// ============================================================
// 시스템별 시각화 전략 레지스트리
//
// 폴더 이름으로 알려진 시스템(엔진/유압/연료/착륙장치)이면 그 시스템에
// 맞는 전용 시각화를 쓰고, 그 외(새로 추가된 시스템 포함)는 기본
// 라인차트로 자동 처리됩니다 — 새 시스템 폴더를 추가해도 코드 수정 없이
// 바로 동작하되, 나중에 그 시스템만의 시각화를 추가하고 싶으면
// VISUALIZERS 배열에 항목을 하나 더 추가하면 됩니다.
// ============================================================

(function (root) {
  "use strict";

  function normalize(str) {
    return String(str || "").toLowerCase().replace(/[\s\-_/]+/g, "");
  }

  const KNOWN = {
    engine: ["엔진", "engine"],
    hydraulics: ["유압", "hydraulics", "hydraulic"],
    fuel: ["연료", "fuel"],
    landingGear: ["착륙장치", "landinggear", "landing gear"],
  };

  function classify(systemName) {
    const n = normalize(systemName);
    for (const key of Object.keys(KNOWN)) {
      if (KNOWN[key].some((a) => normalize(a) === n)) return key;
    }
    return "default";
  }

  // 이름이 토큰 하나(1/2, A/B, L/R)만 다르고 나머지는 같은 두 파라미터를 짝짓습니다.
  // 예) ENG1_N1 <-> ENG2_N1, L_Brake <-> R_Brake, SYS_A <-> SYS_B
  const TOKEN_PAIRS = [["1", "2"], ["A", "B"], ["L", "R"]];

  function detectPairs(names) {
    const nameSet = new Set(names);
    const used = new Set();
    const pairs = [];
    names.forEach((name) => {
      if (used.has(name)) return;
      for (const [lo, hi] of TOKEN_PAIRS) {
        const idx = name.indexOf(lo);
        if (idx === -1) continue;
        const candidate = name.slice(0, idx) + hi + name.slice(idx + lo.length);
        if (candidate !== name && nameSet.has(candidate) && !used.has(candidate)) {
          pairs.push([name, candidate]);
          used.add(name);
          used.add(candidate);
          break;
        }
      }
    });
    return pairs;
  }

  function pairTitle(nameA, nameB) {
    let preLen = 0;
    while (preLen < nameA.length && preLen < nameB.length && nameA[preLen] === nameB[preLen]) preLen++;
    let sufLen = 0;
    while (
      sufLen < nameA.length - preLen &&
      sufLen < nameB.length - preLen &&
      nameA[nameA.length - 1 - sufLen] === nameB[nameB.length - 1 - sufLen]
    ) sufLen++;
    const common = (nameA.slice(0, preLen) + nameA.slice(nameA.length - sufLen)).replace(/[_\s]+$/, "").replace(/^[_\s]+/, "");
    return common || `${nameA} / ${nameB}`;
  }

  function pointsFrom(time, col) {
    return time.map((t, i) => ({ x: t, y: col.values[i] })).filter((p) => p.y !== null && !Number.isNaN(p.y));
  }

  function lastNonNull(values) {
    for (let i = values.length - 1; i >= 0; i--) {
      const v = values[i];
      if (v !== null && v !== undefined && !Number.isNaN(v)) return v;
    }
    return undefined;
  }

  function buildCompareSeries(chartSeries, compareTime, compareColumns) {
    const byName = new Map(compareColumns.map((c) => [c.name, c]));
    return chartSeries
      .map((s) => {
        const col = byName.get(s.name);
        if (!col) return null;
        return { name: s.name, color: s.color, points: pointsFrom(compareTime, col) };
      })
      .filter(Boolean);
  }

  function compareOptsFor(chart, ctx) {
    if (!ctx.compare) return {};
    const compareSeries = buildCompareSeries(chart.series, ctx.compare.time, ctx.compare.columns);
    if (!compareSeries.length) return {};
    return { compareSeries, primaryLabel: ctx.primaryLabel, compareLabel: ctx.compareLabel };
  }

  // ---- 기본: 단위별 라인차트 (알 수 없는/새 시스템에 자동 적용) ----
  function renderDefaultView(container, ctx) {
    const charts = window.FDR.buildChartsFromColumns(ctx.time, ctx.columns);
    if (charts.length === 0) {
      container.appendChild(window.ChartKit.el("div", { class: "empty-state", text: "표시할 수치형 파라미터가 없습니다." }));
      return;
    }
    charts.forEach((chart) => {
      window.ChartKit.renderLineChart(container, chart, compareOptsFor(chart, ctx));
    });
  }

  // ---- 엔진: ENG1 vs ENG2 짝은 위/아래 2단(값 + 차이Δ), 나머지는 기본 라인차트 ----
  function renderEngineView(container, ctx) {
    const names = ctx.columns.map((c) => c.name);
    const pairs = detectPairs(names);
    const pairedNames = new Set(pairs.flat());

    pairs.forEach(([nameA, nameB]) => {
      const colA = ctx.columns.find((c) => c.name === nameA);
      const colB = ctx.columns.find((c) => c.name === nameB);
      if (!colA || !colB || colA.unit !== colB.unit) { pairedNames.delete(nameA); pairedNames.delete(nameB); return; }
      window.ChartKit.renderPairDeltaChart(container, {
        title: pairTitle(nameA, nameB),
        unit: colA.unit,
        unitLabel: "시간(분)",
        a: { name: nameA, color: "series-1", points: pointsFrom(ctx.time, colA) },
        b: { name: nameB, color: "series-2", points: pointsFrom(ctx.time, colB) },
      });
    });

    const rest = ctx.columns.filter((c) => !pairedNames.has(c.name));
    if (rest.length) {
      const charts = window.FDR.buildChartsFromColumns(ctx.time, rest);
      charts.forEach((chart) => window.ChartKit.renderLineChart(container, chart, compareOptsFor(chart, ctx)));
    }
  }

  // ---- 유압: 임계값 기반 정상/주의/위험 밴드를 배경에 표시 ----
  function renderHydraulicsView(container, ctx) {
    const charts = window.FDR.buildChartsFromColumns(ctx.time, ctx.columns);
    if (charts.length === 0) {
      container.appendChild(window.ChartKit.el("div", { class: "empty-state", text: "표시할 수치형 파라미터가 없습니다." }));
      return;
    }
    charts.forEach((chart) => {
      let rule = null;
      for (const s of chart.series) {
        const r = ctx.thresholds[s.name];
        if (r && r.warn !== undefined && r.crit !== undefined) { rule = { ...r, paramName: s.name }; break; }
      }
      window.ChartKit.renderBandedLineChart(container, chart, rule, compareOptsFor(chart, ctx));
    });
  }

  // ---- 연료: 탱크 구성 = 부분-전체 → 누적 영역 차트 ----
  function renderFuelView(container, ctx) {
    const charts = window.FDR.buildChartsFromColumns(ctx.time, ctx.columns);
    if (charts.length === 0) {
      container.appendChild(window.ChartKit.el("div", { class: "empty-state", text: "표시할 수치형 파라미터가 없습니다." }));
      return;
    }
    charts.forEach((chart) => window.ChartKit.renderStackedAreaChart(container, chart));
    if (ctx.compare) {
      container.appendChild(window.ChartKit.el("div", { class: "unit-note", text: "누적 영역 차트는 비교 소티를 겹쳐 표시하지 않습니다 (구성 비율이 겹치면 읽기 어려워지기 때문입니다)." }));
    }
  }

  // ---- 착륙장치: 현재값 게이지 + 아래에 추세 라인차트 ----
  function renderLandingGearView(container, ctx) {
    const gauges = ctx.columns.map((col) => {
      const rule = ctx.thresholds[col.name];
      return {
        label: col.name,
        value: lastNonNull(col.values),
        unit: col.unit,
        warn: rule ? rule.warn : undefined,
        crit: rule ? rule.crit : undefined,
        direction: rule ? rule.direction : "up",
      };
    }).filter((g) => g.value !== undefined);
    if (gauges.length) window.ChartKit.renderGaugeRow(container, gauges);

    const charts = window.FDR.buildChartsFromColumns(ctx.time, ctx.columns);
    charts.forEach((chart) => window.ChartKit.renderLineChart(container, chart, compareOptsFor(chart, ctx)));
  }

  const RENDERERS = {
    engine: renderEngineView,
    hydraulics: renderHydraulicsView,
    fuel: renderFuelView,
    landingGear: renderLandingGearView,
    default: renderDefaultView,
  };

  function pickVisualizer(systemName) {
    return RENDERERS[classify(systemName)] || renderDefaultView;
  }

  const Visualizers = { classify, detectPairs, pairTitle, buildCompareSeries, pickVisualizer, RENDERERS };
  root.Visualizers = Visualizers;
  if (typeof module !== "undefined" && module.exports) module.exports = Visualizers;
})(typeof window !== "undefined" ? window : globalThis);
