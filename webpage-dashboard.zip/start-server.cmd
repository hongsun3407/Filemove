@echo off
rem ============================================================
rem 항공기 시스템 대시보드 서버를 Windows에서 더블클릭으로 실행하기 위한 스크립트.
rem 이 창을 닫으면 서버도 함께 종료됩니다 (재부팅 시 자동 시작이 필요하면
rem DEPLOY.md의 "3단계 - 상시 서비스로 등록" 부분을 참고하세요).
rem ============================================================
setlocal

cd /d "%~dp0"

echo ============================================================
echo  항공기 시스템 모니터링 대시보드 - 서버 시작
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [오류] Node.js가 설치되어 있지 않습니다.
  echo        https://nodejs.org 에서 LTS 버전을 설치한 뒤 다시 실행해주세요.
  echo.
  pause
  exit /b 1
)

for /f "delims=" %%v in ('node -v') do echo Node.js 버전: %%v

if not exist "node_modules" (
  echo.
  echo [오류] node_modules 폴더가 없습니다 ^(엑셀을 읽는 xlsx 패키지가 필요합니다^).
  echo        인터넷이 되는 PC에서 fetch-vendor.ps1을 먼저 실행하거나,
  echo        이 폴더에서 "npm install"을 실행한 뒤 그 결과를 옮겨주세요.
  echo.
  pause
  exit /b 1
)

if not exist "vendor\plotly.min.js" (
  echo.
  echo [경고] vendor\plotly.min.js가 없어 차트가 표시되지 않을 수 있습니다.
  echo        vendor\README.md 또는 fetch-vendor.ps1을 참고해 받아주세요.
  echo.
)

if not exist "config.json" (
  echo [경고] config.json이 없습니다 - 기본값^(포트 8080, dataRoot ./data^)으로 실행됩니다.
  echo.
)

echo 서버를 시작합니다. 종료하려면 이 창에서 Ctrl+C를 누르세요.
echo ------------------------------------------------------------
echo.

node server.js

echo.
echo ------------------------------------------------------------
echo 서버가 종료되었습니다.
pause
